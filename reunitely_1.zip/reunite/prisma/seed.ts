/**
 * prisma/seed.ts
 * Reunitely — Comprehensive Demo Seed
 *
 * Seeds a complete, realistic dataset for the "Lincoln High Class of 2009" 15-year reunion.
 * Run: npx tsx prisma/seed.ts
 */

import {
  PrismaClient,
  PlatformRole,
  EventStatus,
  EventVisibility,
  RSVPStatus,
  MembershipRole,
  InviteChannel,
  InviteStatus,
  DeliveryStatus,
  PaymentStatus,
  PaymentMethod,
  TicketType,
  CheckInStatus,
  MediaType,
  MediaStatus,
  ContentStatus,
  MemoryType,
  NominationStatus,
  VotingStatus,
  BroadcastChannel,
  BroadcastStatus,
  ConsentType,
  NotificationChannel,
  NotificationFrequency,
  ChatRoomType,
  VerificationMethod,
  VerificationStatus,
} from "@prisma/client";
import { createHash } from "crypto";

const prisma = new PrismaClient({
  log: ["warn", "error"],
});

// ─── Helpers ──────────────────────────────────────────────────────────────────

function slugify(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .trim();
}

function daysAgo(n: number): Date {
  return new Date(Date.now() - n * 24 * 60 * 60 * 1000);
}

function daysFromNow(n: number): Date {
  return new Date(Date.now() + n * 24 * 60 * 60 * 1000);
}

function hoursAgo(n: number): Date {
  return new Date(Date.now() - n * 60 * 60 * 1000);
}

function randomBetween(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function hashPassword(plain: string): string {
  return createHash("sha256").update(plain).digest("hex");
}

// Avatar URLs using DiceBear (deterministic from seed name)
function avatarUrl(seed: string): string {
  return `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(seed)}`;
}

// ─── Seed Data Definitions ───────────────────────────────────────────────────

const SCHOOL_DATA = {
  name: "Lincoln High School",
  slug: "lincoln-high-school-san-francisco",
  city: "San Francisco",
  stateRegion: "CA",
  country: "US",
  zipCode: "94102",
  emailDomain: "lincolnhs.edu",
  isVerified: true,
};

const VENUE_DATA = {
  name: "The Grand Hyatt San Francisco",
  address: "345 Stockton Street",
  city: "San Francisco",
  stateRegion: "CA",
  country: "US",
  zipCode: "94108",
  lat: 37.7879,
  lng: -122.4075,
  timezone: "America/Los_Angeles",
  website: "https://www.hyatt.com",
  capacity: 300,
};

// All 18 users: 1 organizer, 1 co-organizer, 1 committee, 15 attendees
const USERS = [
  {
    clerkId: "user_organizer_maya",
    email: "maya.chen@example.com",
    name: "Maya Chen",
    firstName: "Maya",
    lastName: "Chen",
    username: "mayachen",
    role: "organizer" as const,
    job: "Marketing Director",
    employer: "Salesforce",
    city: "San Francisco",
    country: "US",
    bio: "Class of 2009 rep! Organizing our 15-year reunion 🎉",
    funFact: "I can name every US president in under 60 seconds.",
  },
  {
    clerkId: "user_coorg_james",
    email: "james.rodriguez@example.com",
    name: "James Rodriguez",
    firstName: "James",
    lastName: "Rodriguez",
    username: "jamesrod",
    role: "co_organizer" as const,
    job: "Software Engineer",
    employer: "Google",
    city: "Mountain View",
    country: "US",
    bio: "Tech lead for the reunion website. Ask me about the app!",
    funFact: "I still have my senior yearbook on my desk.",
  },
  {
    clerkId: "user_committee_priya",
    email: "priya.patel@example.com",
    name: "Priya Patel",
    firstName: "Priya",
    lastName: "Patel",
    username: "priyapatel",
    role: "committee" as const,
    job: "Cardiologist",
    employer: "UCSF Medical Center",
    city: "San Francisco",
    country: "US",
    bio: "On the committee for venue & catering. Thrilled to see everyone!",
    funFact: "I was voted Most Likely to Save the World.",
  },
  {
    clerkId: "user_attendee_alex",
    email: "alex.kim@example.com",
    name: "Alex Kim",
    firstName: "Alex",
    lastName: "Kim",
    username: "alexkim",
    role: "attendee" as const,
    job: "Product Manager",
    employer: "Apple",
    city: "Cupertino",
    country: "US",
    bio: "Former student body president, now managing product.",
    funFact: "I appeared in an Apple keynote once (as an extra).",
  },
  {
    clerkId: "user_attendee_sarah",
    email: "sarah.johnson@example.com",
    name: "Sarah Johnson",
    firstName: "Sarah",
    lastName: "Johnson",
    username: "sarahj",
    role: "attendee" as const,
    job: "Architect",
    employer: "Gensler",
    city: "Los Angeles",
    country: "US",
    bio: "Designing buildings by day, chasing sunsets by night.",
    funFact: "My senior project is now actually a building in downtown SF.",
  },
  {
    clerkId: "user_attendee_marcus",
    email: "marcus.taylor@example.com",
    name: "Marcus Taylor",
    firstName: "Marcus",
    lastName: "Taylor",
    username: "marcust",
    role: "attendee" as const,
    job: "NBA Strength & Conditioning Coach",
    employer: "Golden State Warriors",
    city: "San Francisco",
    country: "US",
    bio: "Former Lincoln track star. Still running!",
    funFact: "I've been to every Warriors championship.",
  },
  {
    clerkId: "user_attendee_elena",
    email: "elena.vasquez@example.com",
    name: "Elena Vasquez",
    firstName: "Elena",
    lastName: "Vasquez",
    username: "elenav",
    role: "attendee" as const,
    job: "Food Writer",
    employer: "San Francisco Chronicle",
    city: "San Francisco",
    country: "US",
    bio: "Writing about food so you don't have to settle for bad tacos.",
    funFact: "I have a Michelin-star chef as a regular brunch buddy.",
  },
  {
    clerkId: "user_attendee_david",
    email: "david.park@example.com",
    name: "David Park",
    firstName: "David",
    lastName: "Park",
    username: "davidpark",
    role: "attendee" as const,
    job: "Startup Founder",
    employer: "ParkAI",
    city: "Palo Alto",
    country: "US",
    bio: "Building AI tools for small businesses. Always looking for co-founders!",
    funFact: "I raised my first VC round from a cold email.",
  },
  {
    clerkId: "user_attendee_nina",
    email: "nina.okonkwo@example.com",
    name: "Nina Okonkwo",
    firstName: "Nina",
    lastName: "Okonkwo",
    username: "ninao",
    role: "attendee" as const,
    job: "Immigration Attorney",
    employer: "Okonkwo Law",
    city: "New York",
    country: "US",
    bio: "Fighting for justice, one case at a time.",
    funFact: "I learned Mandarin after college just for fun.",
  },
  {
    clerkId: "user_attendee_tom",
    email: "tom.nguyen@example.com",
    name: "Tom Nguyen",
    firstName: "Tom",
    lastName: "Nguyen",
    username: "tomnguyen",
    role: "attendee" as const,
    job: "High School Teacher",
    employer: "Galileo Academy",
    city: "San Francisco",
    country: "US",
    bio: "Teaching the next generation. Lincoln shaped who I am.",
    funFact: "I still use the same backpack from senior year.",
  },
  {
    clerkId: "user_attendee_chloe",
    email: "chloe.martin@example.com",
    name: "Chloe Martin",
    firstName: "Chloe",
    lastName: "Martin",
    username: "chloemart",
    role: "attendee" as const,
    job: "Pastry Chef",
    employer: "Tartine Bakery",
    city: "San Francisco",
    country: "US",
    bio: "Making people happy, one croissant at a time.",
    funFact: "I was voted Most Likely to Open a Restaurant — nailed it.",
  },
  {
    clerkId: "user_attendee_ryan",
    email: "ryan.white@example.com",
    name: "Ryan White",
    firstName: "Ryan",
    lastName: "White",
    username: "ryanwhite",
    role: "attendee" as const,
    job: "Environmental Scientist",
    employer: "NOAA",
    city: "Seattle",
    country: "US",
    bio: "Studying climate science so we can actually fix things.",
    funFact: "I named a glacier in Greenland after my dog.",
  },
  {
    clerkId: "user_attendee_aisha",
    email: "aisha.hassan@example.com",
    name: "Aisha Hassan",
    firstName: "Aisha",
    lastName: "Hassan",
    username: "aishahassan",
    role: "attendee" as const,
    job: "Documentary Filmmaker",
    employer: "Freelance",
    city: "Brooklyn",
    country: "US",
    bio: "Telling stories that matter. Currently in post-production on a Netflix doc.",
    funFact: "My first film was shot on a Nokia phone in this very school.",
  },
  {
    clerkId: "user_attendee_sam",
    email: "sam.levy@example.com",
    name: "Sam Levy",
    firstName: "Sam",
    lastName: "Levy",
    username: "samlevy",
    role: "attendee" as const,
    job: "Venture Capitalist",
    employer: "Andreessen Horowitz",
    city: "Menlo Park",
    country: "US",
    bio: "Investing in the future. Former Lincoln debate champion.",
    funFact: "I can argue either side of any issue. It's a curse.",
  },
  {
    clerkId: "user_attendee_lily",
    email: "lily.chen@example.com",
    name: "Lily Chen",
    firstName: "Lily",
    lastName: "Chen",
    username: "lilychen",
    role: "attendee" as const,
    job: "Pediatric Nurse",
    employer: "UCSF Benioff Children's Hospital",
    city: "Oakland",
    country: "US",
    bio: "Caring for kids is the best job in the world.",
    funFact: "I can read upside-down. Kids love it.",
  },
  {
    clerkId: "user_attendee_jordan",
    email: "jordan.brooks@example.com",
    name: "Jordan Brooks",
    firstName: "Jordan",
    lastName: "Brooks",
    username: "jordanb",
    role: "attendee" as const,
    job: "Urban Planner",
    employer: "City of San Francisco",
    city: "San Francisco",
    country: "US",
    bio: "Making SF more livable one zoning decision at a time.",
    funFact: "I designed the parklet outside the coffee shop where I proposed.",
  },
  {
    clerkId: "user_attendee_keiko",
    email: "keiko.yamamoto@example.com",
    name: "Keiko Yamamoto",
    firstName: "Keiko",
    lastName: "Yamamoto",
    username: "keikoy",
    role: "attendee" as const,
    job: "Game Designer",
    employer: "EA Sports",
    city: "Redwood City",
    country: "US",
    bio: "Designing games that millions play. Still unbeaten at Mario Kart.",
    funFact: "A character in Madden is secretly named after me.",
  },
  {
    clerkId: "user_attendee_omar",
    email: "omar.ali@example.com",
    name: "Omar Ali",
    firstName: "Omar",
    lastName: "Ali",
    username: "omarali",
    role: "attendee" as const,
    job: "Journalist",
    employer: "The New York Times",
    city: "New York",
    country: "US",
    bio: "Covering politics and tech. Lincoln journalism class started it all.",
    funFact: "I interviewed three US presidents. All in the same year.",
  },
];

// ─── MAIN ────────────────────────────────────────────────────────────────────

async function main() {
  console.log("🌱  Reunitely seed starting…\n");

  // ── 1. School ──────────────────────────────────────────────────────────────
  console.log("📚  Creating school…");
  const school = await prisma.school.upsert({
    where: { slug: SCHOOL_DATA.slug },
    update: {},
    create: SCHOOL_DATA,
  });

  // ── 2. Venue ───────────────────────────────────────────────────────────────
  console.log("🏨  Creating venue…");
  const venue = await prisma.venue.upsert({
    where: { id: "venue_grand_hyatt_sf" },
    update: {},
    create: { id: "venue_grand_hyatt_sf", ...VENUE_DATA },
  });

  // ── 3. Tags ────────────────────────────────────────────────────────────────
  console.log("🏷️   Creating tags…");
  const tags = await Promise.all(
    ["15-year", "formal-dinner", "open-bar", "awards", "photo-booth"].map((name) =>
      prisma.tag.upsert({
        where: { slug: slugify(name) },
        update: {},
        create: { name, slug: slugify(name) },
      })
    )
  );

  // ── 4. Users ───────────────────────────────────────────────────────────────
  console.log("👥  Creating 18 users…");
  const createdUsers: Array<(typeof USERS)[0] & { id: string }> = [];

  for (const u of USERS) {
    const user = await prisma.user.upsert({
      where: { clerkId: u.clerkId },
      update: {},
      create: {
        clerkId: u.clerkId,
        email: u.email,
        emailVerified: true,
        name: u.name,
        firstName: u.firstName,
        lastName: u.lastName,
        username: u.username,
        avatarUrl: avatarUrl(u.username),
        platformRole:
          u.role === "organizer" ? PlatformRole.USER : PlatformRole.USER,
        lastLoginAt: daysAgo(randomBetween(1, 30)),
        lastActiveAt: daysAgo(randomBetween(0, 7)),
        loginCount: randomBetween(5, 80),
        timezone: "America/Los_Angeles",
      },
    });

    // Organizer profile
    if (u.role === "organizer" || u.role === "co_organizer") {
      await prisma.organizerProfile.upsert({
        where: { userId: user.id },
        update: {},
        create: {
          userId: user.id,
          bio: u.bio,
          linkedinUrl: `https://linkedin.com/in/${u.username}`,
          eventsHosted: u.role === "organizer" ? 3 : 1,
          isVerifiedHost: true,
          stripeOnboarded: u.role === "organizer",
        },
      });
    }

    // Attendee profile for all users
    await prisma.attendeeProfile.upsert({
      where: { userId: user.id },
      update: {},
      create: {
        userId: user.id,
        bio: u.bio,
        currentCity: u.city,
        currentCountry: u.country,
        currentJob: u.job,
        currentEmployer: u.employer,
        linkedinUrl: `https://linkedin.com/in/${u.username}`,
        funFact: u.funFact,
        profileCompleteness: randomBetween(60, 100),
        showInDirectory: true,
        showCurrentJob: true,
        showCurrentCity: true,
        allowDirectMessages: true,
        allowPhotoTagging: true,
        allowNominations: true,
      },
    });

    // Attendee verification
    await prisma.attendeeVerification.create({
      data: {
        attendeeId: (await prisma.attendeeProfile.findUnique({ where: { userId: user.id } }))!.id,
        method: VerificationMethod.EMAIL_OTP,
        status: VerificationStatus.VERIFIED,
        verifiedAt: daysAgo(randomBetween(30, 60)),
        ipAddress: "203.0.113." + randomBetween(1, 254),
      },
    });

    createdUsers.push({ ...u, id: user.id });
  }

  const organizer = createdUsers.find((u) => u.role === "organizer")!;
  const coOrganizer = createdUsers.find((u) => u.role === "co_organizer")!;
  const committee = createdUsers.find((u) => u.role === "committee")!;
  const attendees = createdUsers.filter((u) => u.role === "attendee");

  // ── 5. Event ───────────────────────────────────────────────────────────────
  console.log("🎉  Creating event…");
  const event = await prisma.event.upsert({
    where: { slug: "lincoln-high-2009-15year" },
    update: {},
    create: {
      id: "evt_lincoln_2009",
      slug: "lincoln-high-2009-15year",
      title: "Lincoln High Class of 2009 — 15-Year Reunion",
      shortDescription:
        "Fifteen years since graduation! Join us for a night of reconnecting, great food, and unforgettable memories.",
      description: {
        type: "doc",
        content: [
          {
            type: "heading",
            attrs: { level: 2 },
            content: [{ type: "text", text: "Welcome back, Lions! 🦁" }],
          },
          {
            type: "paragraph",
            content: [
              {
                type: "text",
                text: "Can you believe it's been 15 years since we walked across that stage? We're bringing the Class of 2009 back together for a night to remember.",
              },
            ],
          },
          {
            type: "paragraph",
            content: [
              {
                type: "text",
                text: "The evening includes cocktail hour, a three-course dinner, a memory wall presentation, class awards, and dancing until midnight.",
              },
            ],
          },
          {
            type: "heading",
            attrs: { level: 3 },
            content: [{ type: "text", text: "Schedule" }],
          },
          {
            type: "bulletList",
            content: [
              { type: "listItem", content: [{ type: "paragraph", content: [{ type: "text", text: "6:00 PM — Doors & Cocktail Hour" }] }] },
              { type: "listItem", content: [{ type: "paragraph", content: [{ type: "text", text: "7:00 PM — Welcome & Dinner" }] }] },
              { type: "listItem", content: [{ type: "paragraph", content: [{ type: "text", text: "8:30 PM — Memory Wall Presentation" }] }] },
              { type: "listItem", content: [{ type: "paragraph", content: [{ type: "text", text: "9:00 PM — Class Awards & Nominations" }] }] },
              { type: "listItem", content: [{ type: "paragraph", content: [{ type: "text", text: "9:30 PM — Dancing & Open Bar" }] }] },
              { type: "listItem", content: [{ type: "paragraph", content: [{ type: "text", text: "12:00 AM — Last Call" }] }] },
            ],
          },
        ],
      },
      coverImageUrl: "https://images.unsplash.com/photo-1519671482749-fd09be7ccebf?w=1200",
      organizationId: null,
      createdById: organizer.id,
      schoolId: school.id,
      venueId: venue.id,
      schoolName: school.name,
      schoolCity: school.city,
      schoolCountry: school.country,
      graduationYear: 2009,
      classSections: ["Section A", "Section B", "Section C", "Honors"],
      status: EventStatus.PUBLISHED,
      visibility: EventVisibility.UNLISTED,
      publishedAt: daysAgo(45),
      startAt: daysFromNow(30),
      endAt: new Date(daysFromNow(30).getTime() + 6 * 60 * 60 * 1000),
      timezone: "America/Los_Angeles",
      doorsOpenAt: new Date(daysFromNow(30).getTime() - 30 * 60 * 1000),
      venueName: venue.name,
      venueAddress: `${venue.address}, ${venue.city}, ${venue.stateRegion} ${venue.zipCode}`,
      venueLat: venue.lat,
      venueLng: venue.lng,
      capacity: 150,
      waitlistEnabled: true,
      waitlistCapacity: 25,
      ticketingEnabled: true,
      settings: {
        chatEnabled: true,
        memoriesEnabled: true,
        memoriesAutoApprove: false,
        nominationsEnabled: true,
        scheduleEnabled: true,
        directoryEnabled: true,
        checkInEnabled: true,
        customQuestions: [
          {
            id: "q1",
            label: "What have you been up to since graduation?",
            type: "text",
            required: false,
          },
          {
            id: "q2",
            label: "Are you bringing a guest?",
            type: "boolean",
            required: false,
          },
          {
            id: "q3",
            label: "T-shirt size for the class gift",
            type: "select",
            options: ["XS", "S", "M", "L", "XL", "XXL"],
            required: true,
          },
        ],
      },
    },
  });

  // Event theme
  await prisma.eventTheme.upsert({
    where: { eventId: event.id },
    update: {},
    create: {
      eventId: event.id,
      primaryColor: "#1E3A5F",   // Lincoln High navy
      accentColor: "#D4AF37",    // gold
      backgroundColor: "#FAFAF8",
      fontFamily: "Playfair Display",
      headerLayout: "full-bleed",
    },
  });

  // Event tags
  for (const tag of tags) {
    await prisma.eventTag.upsert({
      where: { eventId_tagId: { eventId: event.id, tagId: tag.id } },
      update: {},
      create: { eventId: event.id, tagId: tag.id },
    });
  }

  // ── 6. Committee ──────────────────────────────────────────────────────────
  console.log("🎯  Setting up committee…");
  await prisma.committeeMember.upsert({
    where: { eventId_userId: { eventId: event.id, userId: organizer.id } },
    update: {},
    create: {
      eventId: event.id,
      userId: organizer.id,
      role: MembershipRole.ORGANIZER,
      title: "Lead Organizer",
      canManageRsvps: true,
      canSendMessages: true,
      canModerateContent: true,
      canManageTickets: true,
      canViewPayments: true,
      canCheckIn: true,
      addedByUserId: organizer.id,
    },
  });

  await prisma.committeeMember.upsert({
    where: { eventId_userId: { eventId: event.id, userId: coOrganizer.id } },
    update: {},
    create: {
      eventId: event.id,
      userId: coOrganizer.id,
      role: MembershipRole.CO_ORGANIZER,
      title: "Tech & Web Lead",
      canManageRsvps: true,
      canSendMessages: true,
      canModerateContent: true,
      canManageTickets: false,
      canViewPayments: false,
      canCheckIn: true,
      addedByUserId: organizer.id,
    },
  });

  await prisma.committeeMember.upsert({
    where: { eventId_userId: { eventId: event.id, userId: committee.id } },
    update: {},
    create: {
      eventId: event.id,
      userId: committee.id,
      role: MembershipRole.COMMITTEE,
      title: "Venue & Catering",
      canManageRsvps: false,
      canSendMessages: false,
      canModerateContent: false,
      canManageTickets: false,
      canViewPayments: false,
      canCheckIn: true,
      addedByUserId: organizer.id,
    },
  });

  // ── 7. Tickets ────────────────────────────────────────────────────────────
  console.log("🎟️   Creating tickets…");
  const earlyBirdTicket = await prisma.ticket.create({
    data: {
      eventId: event.id,
      type: TicketType.EARLY_BIRD,
      name: "Early Bird — General Admission",
      description: "Get 20% off! Available until March 1st.",
      price: 7900,         // $79
      currency: "USD",
      capacity: 30,
      soldCount: 30,       // sold out
      earlyBirdDeadline: daysAgo(10),
      earlyBirdPrice: 7900,
      saleEndsAt: daysAgo(10),
      isVisible: true,
      isActive: false,     // no longer active (sold out + deadline passed)
    },
  });

  const generalTicket = await prisma.ticket.create({
    data: {
      eventId: event.id,
      type: TicketType.GENERAL,
      name: "General Admission",
      description: "Includes cocktail hour, three-course dinner, and open bar.",
      price: 9900,         // $99
      currency: "USD",
      capacity: 100,
      soldCount: 67,
      isVisible: true,
      isActive: true,
      maxPerOrder: 2,
    },
  });

  const vipTicket = await prisma.ticket.create({
    data: {
      eventId: event.id,
      type: TicketType.VIP,
      name: "VIP — Gold Table",
      description: "Premium seating at the Gold Tables, exclusive gift, priority check-in.",
      price: 15900,        // $159
      currency: "USD",
      capacity: 20,
      soldCount: 9,
      isVisible: true,
      isActive: true,
      requiresApproval: false,
      maxPerOrder: 1,
    },
  });

  // ── 8. Referral Links ─────────────────────────────────────────────────────
  console.log("🔗  Creating referral links…");
  const [mayaRef, jamesRef] = await Promise.all([
    prisma.referralLink.create({
      data: {
        eventId: event.id,
        createdById: organizer.id,
        code: "MAYA2024",
        label: "Maya's personal link",
        clickCount: 47,
        rsvpCount: 12,
        isActive: true,
      },
    }),
    prisma.referralLink.create({
      data: {
        eventId: event.id,
        createdById: coOrganizer.id,
        code: "JAMES2024",
        label: "James's link",
        clickCount: 23,
        rsvpCount: 6,
        isActive: true,
      },
    }),
  ]);

  // ── 9. Invites & RSVPs ────────────────────────────────────────────────────
  console.log("📨  Creating invites and RSVPs…");

  // RSVP statuses: mix of confirmed, pending, declined, waitlisted
  const rsvpStatuses: RSVPStatus[] = [
    RSVPStatus.CONFIRMED,
    RSVPStatus.CONFIRMED,
    RSVPStatus.CONFIRMED,
    RSVPStatus.CONFIRMED,
    RSVPStatus.CONFIRMED,
    RSVPStatus.CONFIRMED,
    RSVPStatus.CONFIRMED,
    RSVPStatus.CONFIRMED,
    RSVPStatus.CONFIRMED,
    RSVPStatus.CONFIRMED,
    RSVPStatus.CONFIRMED,
    RSVPStatus.PENDING,
    RSVPStatus.PENDING,
    RSVPStatus.DECLINED,
    RSVPStatus.WAITLISTED,
  ];

  const tShirtSizes = ["S", "M", "M", "L", "L", "XL", "M", "S", "XL", "M", "L", "M", "L", "XL", "S"];
  const dietaryOptions = [
    [],
    ["Vegetarian"],
    [],
    ["Gluten-free"],
    [],
    ["Halal"],
    [],
    ["Vegan"],
    [],
    [],
    ["Vegetarian", "Gluten-free"],
    [],
    ["Kosher"],
    [],
    [],
  ];

  const allRsvps: Array<{ rsvpId: string; userId: string; status: RSVPStatus; ticketType: string }> = [];

  for (let i = 0; i < attendees.length; i++) {
    const attendee = attendees[i]!;
    const status = rsvpStatuses[i] ?? RSVPStatus.CONFIRMED;
    const useRef = i < 6 ? mayaRef : i < 12 ? jamesRef : null;
    const daysAgoCount = randomBetween(5, 40);

    // Create invite first
    const invite = await prisma.invite.create({
      data: {
        eventId: event.id,
        invitedById: organizer.id,
        referralLinkId: useRef?.id,
        email: attendee.email,
        token: `inv_${attendee.username}_${Date.now()}`,
        channel: InviteChannel.EMAIL,
        status: status === RSVPStatus.DECLINED ? InviteStatus.OPENED : InviteStatus.RSVPD,
        sentAt: daysAgo(daysAgoCount + 5),
        deliveredAt: daysAgo(daysAgoCount + 5),
        openedAt: daysAgo(daysAgoCount + 3),
        rsvpdAt: status !== RSVPStatus.PENDING ? daysAgo(daysAgoCount) : null,
        recipientConsentConfirmed: true,
        consentConfirmedAt: daysAgo(daysAgoCount + 5),
        personalMessage: `Hey ${attendee.firstName}! Hope you can make it — it's going to be amazing! 🦁`,
        expiresAt: daysFromNow(60),
      },
    });

    // Invite delivery record
    await prisma.inviteDelivery.create({
      data: {
        inviteId: invite.id,
        channel: InviteChannel.EMAIL,
        status: DeliveryStatus.DELIVERED,
        providerMsgId: `msg_${Math.random().toString(36).slice(2)}`,
        providerStatus: "delivered",
        attemptNumber: 1,
        sentAt: daysAgo(daysAgoCount + 5),
        deliveredAt: new Date(daysAgo(daysAgoCount + 5).getTime() + 45000),
      },
    });

    // RSVP
    const ticketChoice = i < 3 ? vipTicket : generalTicket;
    const rsvp = await prisma.rSVP.create({
      data: {
        eventId: event.id,
        userId: attendee.id,
        inviteId: invite.id,
        referralCode: useRef?.code,
        status,
        previousStatus: status === RSVPStatus.WAITLISTED ? RSVPStatus.PENDING : null,
        guestCount: i % 4 === 0 ? 1 : 0,
        guestNames: i % 4 === 0 ? [`${attendee.firstName}'s Partner`] : [],
        dietaryRequirements: dietaryOptions[i] ?? [],
        customAnswers: {
          q1: `${attendee.job} at ${attendee.employer}. ${attendee.funFact}`,
          q2: i % 4 === 0 ? "true" : "false",
          q3: tShirtSizes[i] ?? "M",
        },
        consentEmail: true,
        consentSms: i % 3 !== 0,
        consentWhatsApp: i % 4 === 0,
        consentGivenAt: daysAgo(daysAgoCount),
        consentIpAddress: "203.0.113." + randomBetween(1, 254),
        attendeeNote:
          status === RSVPStatus.DECLINED
            ? "Unfortunately I have a work commitment that weekend. Hope to see everyone soon!"
            : null,
        waitlistPosition: status === RSVPStatus.WAITLISTED ? 1 : null,
        submittedAt: daysAgo(daysAgoCount),
        confirmedAt: status === RSVPStatus.CONFIRMED ? daysAgo(daysAgoCount) : null,
      },
    });

    allRsvps.push({
      rsvpId: rsvp.id,
      userId: attendee.id,
      status,
      ticketType: ticketChoice.name,
    });

    // Organizer also RSVPs
    if (i === 0) {
      await prisma.rSVP.upsert({
        where: { eventId_userId: { eventId: event.id, userId: organizer.id } },
        update: {},
        create: {
          eventId: event.id,
          userId: organizer.id,
          status: RSVPStatus.CONFIRMED,
          consentEmail: true,
          consentSms: true,
          customAnswers: { q3: "S" },
          consentGivenAt: daysAgo(45),
          submittedAt: daysAgo(45),
          confirmedAt: daysAgo(45),
        },
      });
      await prisma.rSVP.upsert({
        where: { eventId_userId: { eventId: event.id, userId: coOrganizer.id } },
        update: {},
        create: {
          eventId: event.id,
          userId: coOrganizer.id,
          status: RSVPStatus.CONFIRMED,
          consentEmail: true,
          consentSms: true,
          customAnswers: { q3: "L" },
          consentGivenAt: daysAgo(44),
          submittedAt: daysAgo(44),
          confirmedAt: daysAgo(44),
        },
      });
    }
  }

  // ── 10. Payments ──────────────────────────────────────────────────────────
  console.log("💳  Creating payments…");
  const confirmedAttendees = attendees.filter((_, i) => rsvpStatuses[i] === RSVPStatus.CONFIRMED);

  for (let i = 0; i < confirmedAttendees.length; i++) {
    const attendee = confirmedAttendees[i]!;
    const isVip = i < 3;
    const ticket = isVip ? vipTicket : generalTicket;
    const daysAgoCount = randomBetween(3, 35);

    await prisma.payment.create({
      data: {
        eventId: event.id,
        userId: attendee.id,
        ticketId: ticket.id,
        quantity: 1,
        unitAmountCents: ticket.price,
        totalAmountCents: ticket.price,
        currency: "USD",
        platformFeeCents: Math.round(ticket.price * 0.02),
        stripeFeesCents: Math.round(ticket.price * 0.029) + 30,
        netAmountCents:
          ticket.price -
          Math.round(ticket.price * 0.02) -
          Math.round(ticket.price * 0.029) - 30,
        method: PaymentMethod.STRIPE,
        status: PaymentStatus.PAID,
        stripePaymentIntentId: `pi_${Math.random().toString(36).slice(2, 18)}`,
        stripeCheckoutSessionId: `cs_${Math.random().toString(36).slice(2, 18)}`,
        stripeConnectedAccountId: "acct_1OzKXXXXXXXXXXXX",
        paidAt: daysAgo(daysAgoCount),
        receiptEmailSentAt: new Date(daysAgo(daysAgoCount).getTime() + 60000),
      },
    });
  }

  // Manual cash payment for organizer
  await prisma.payment.create({
    data: {
      eventId: event.id,
      userId: organizer.id,
      ticketId: generalTicket.id,
      quantity: 1,
      unitAmountCents: 0,
      totalAmountCents: 0,
      currency: "USD",
      method: PaymentMethod.COMP,
      status: PaymentStatus.WAIVED,
      markedPaidByUserId: organizer.id,
      markedPaidAt: daysAgo(40),
      manualReference: "Organizer comp",
      paidAt: daysAgo(40),
    },
  });

  // ── 11. Check-ins ─────────────────────────────────────────────────────────
  // Simulate a past rehearsal dinner — 6 early check-ins
  console.log("✅  Creating check-in records…");
  const toCheckIn = confirmedAttendees.slice(0, 6);
  for (const attendee of toCheckIn) {
    const rsvp = allRsvps.find((r) => r.userId === attendee.id);
    await prisma.checkIn.upsert({
      where: { eventId_userId: { eventId: event.id, userId: attendee.id } },
      update: {},
      create: {
        eventId: event.id,
        userId: attendee.id,
        rsvpId: rsvp?.rsvpId,
        status: CheckInStatus.CHECKED_IN,
        checkedInAt: daysAgo(1),
        checkedInByUserId: organizer.id,
        checkInMethod: "MANUAL",
        checkInNote: "Pre-event meetup check-in",
      },
    });
  }

  // ── 12. Chat Rooms & Messages ─────────────────────────────────────────────
  console.log("💬  Creating chat rooms and messages…");
  const generalRoom = await prisma.chatRoom.create({
    data: {
      eventId: event.id,
      name: "general",
      slug: "general",
      description: "The main chat for all reunion attendees",
      type: ChatRoomType.GENERAL,
      isPinned: true,
      createdById: organizer.id,
    },
  });

  const logisticsRoom = await prisma.chatRoom.create({
    data: {
      eventId: event.id,
      name: "travel-and-hotels",
      slug: "travel-and-hotels",
      description: "Coordinate travel, hotel rooms, and carpools",
      type: ChatRoomType.TOPIC,
      createdById: organizer.id,
    },
  });

  const tableSeatingRoom = await prisma.chatRoom.create({
    data: {
      eventId: event.id,
      name: "table-requests",
      slug: "table-requests",
      description: "Let us know if you want to be seated with specific people",
      type: ChatRoomType.TOPIC,
      createdById: organizer.id,
    },
  });

  // Messages in general room
  const generalMessages = [
    { authorId: organizer.id, content: "🦁 Welcome everyone to the official Class of 2009 reunion chat! So excited to see all your faces here.", daysAgo: 40 },
    { authorId: coOrganizer.id, content: "The website is live and tickets are selling fast! Early bird spots are almost gone.", daysAgo: 38 },
    { authorId: attendees[0]!.id, content: "Can't believe it's been 15 years!! Maya you legend for organizing this 🙌", daysAgo: 37 },
    { authorId: attendees[1]!.id, content: "Just bought my ticket! Anyone else flying in from out of town?", daysAgo: 36 },
    { authorId: attendees[4]!.id, content: "Flying from LA! So hyped for this. Who else is coming from down south?", daysAgo: 35 },
    { authorId: attendees[6]!.id, content: "NYC checking in 👋 Omar and I are flying in together!", daysAgo: 34 },
    { authorId: attendees[8]!.id, content: "Seattle represent! Haven't been back in SF in two years, this is the perfect excuse.", daysAgo: 33 },
    { authorId: committee.id, content: "I just confirmed the catering menu — three-course with vegetarian, vegan, and gluten-free options. Please make sure you update your dietary requirements in your RSVP!", daysAgo: 30 },
    { authorId: attendees[2]!.id, content: "Priya is on the committee?? Best news. Remember when she used to quiz us on anatomy in the cafeteria? 😂", daysAgo: 29 },
    { authorId: committee.id, content: "Haha! Some things never change 😂 Also heads up — we're doing a class superlatives vote next week!", daysAgo: 29 },
    { authorId: attendees[3]!.id, content: "I am READY for superlatives. Chloe obviously wins 'Most Likely to Feed Everyone' 🥐", daysAgo: 28 },
    { authorId: attendees[5]!.id, content: "👏👏 Honestly I accept that award. I'll bring croissants to the after-party.", daysAgo: 27 },
    { authorId: attendees[7]!.id, content: "Is there a photographer? Would love proper photos from the night.", daysAgo: 25 },
    { authorId: organizer.id, content: "Yes! We've hired a professional photographer AND a photo booth. All photos will be uploaded here after the event.", daysAgo: 24 },
    { authorId: attendees[9]!.id, content: "Just added my old yearbook photo to the memory wall. Teenage Keiko was something else 😅", daysAgo: 20 },
    { authorId: attendees[10]!.id, content: "DYING at that yearbook photo Keiko. The hair 🙈", daysAgo: 19 },
    { authorId: attendees[11]!.id, content: "Reminder to everyone: please submit your memory wall photos before the event! Maya wants to do a slideshow.", daysAgo: 15 },
    { authorId: coOrganizer.id, content: "30 days out! 67 of you are confirmed. Let's get to 100! 🎉 Share the link with anyone who's missing.", daysAgo: 10 },
    { authorId: attendees[0]!.id, content: "Just texted half my contact list. Do it everyone!!", daysAgo: 9 },
    { authorId: attendees[4]!.id, content: "Sent it to the old group chat. Four more people just RSVP'd 💪", daysAgo: 8 },
    { authorId: organizer.id, content: "The venue confirmed our room block at the hotel! Code 'LINCOLN2009' for 20% off.", daysAgo: 5 },
    { authorId: attendees[1]!.id, content: "Just booked! Thanks Maya 🙏", daysAgo: 4 },
    { authorId: attendees[6]!.id, content: "Same here. This hotel is gorgeous, great choice Priya!", daysAgo: 3 },
    { authorId: committee.id, content: "Venue team worked hard on it ☺️ Can't wait to see everyone there!", daysAgo: 2 },
    { authorId: attendees[3]!.id, content: "One month to go! The excitement is real 🦁🦁🦁", daysAgo: 1 },
  ];

  const createdMessages: string[] = [];
  for (const msg of generalMessages) {
    const m = await prisma.chatMessage.create({
      data: {
        roomId: generalRoom.id,
        authorId: msg.authorId,
        content: msg.content,
        createdAt: daysAgo(msg.daysAgo),
      },
    });
    createdMessages.push(m.id);
  }

  // Logistics messages
  const logisticsMessages = [
    { authorId: attendees[1]!.id, content: "Anyone want to split a rideshare from SFO to the hotel? Arriving Friday evening.", daysAgo: 20 },
    { authorId: attendees[8]!.id, content: "I'm flying in Friday too! My flight lands at 5pm. DM me if you want to coordinate.", daysAgo: 19 },
    { authorId: attendees[4]!.id, content: "Taking the Caltrain from LA — just kidding. Flying in Saturday morning.", daysAgo: 18 },
    { authorId: attendees[6]!.id, content: "Omar and I are at the Hyatt for two nights — anyone else? It's actually a great rate with the code.", daysAgo: 15 },
    { authorId: attendees[2]!.id, content: "Booked the Hyatt! See you there Jordan 🎉", daysAgo: 14 },
  ];

  for (const msg of logisticsMessages) {
    await prisma.chatMessage.create({
      data: {
        roomId: logisticsRoom.id,
        authorId: msg.authorId,
        content: msg.content,
        createdAt: daysAgo(msg.daysAgo),
      },
    });
  }

  // Add reactions to some messages
  const reactedMessageId = createdMessages[0]!;
  const reactors = [attendees[0]!, attendees[1]!, attendees[2]!, attendees[3]!, attendees[4]!];
  for (const reactor of reactors) {
    await prisma.chatMessageReaction.upsert({
      where: {
        messageId_userId_emoji: {
          messageId: reactedMessageId,
          userId: reactor.id,
          emoji: "🎉",
        },
      },
      update: {},
      create: {
        messageId: reactedMessageId,
        userId: reactor.id,
        emoji: "🎉",
      },
    });
  }

  // ── 13. Memory Posts ──────────────────────────────────────────────────────
  console.log("📸  Creating memory posts…");

  const memoryData = [
    {
      authorId: organizer.id,
      type: MemoryType.TEXT,
      caption: "Remember the senior prank where we rearranged all the desks into a giant maze? Mr. Henderson had to call in a substitute because he couldn't find his own classroom 😂",
      yearContext: 2009,
      contextLabel: "Senior Year",
      status: ContentStatus.APPROVED,
      likeCount: 12,
    },
    {
      authorId: attendees[2]!.id,
      type: MemoryType.TEXT,
      caption: "Junior prom, 2008. We rented a party bus and got hopelessly lost in Marin. Didn't arrive until 10pm. Best prom story ever.",
      yearContext: 2008,
      contextLabel: "Junior Prom",
      status: ContentStatus.APPROVED,
      likeCount: 18,
    },
    {
      authorId: attendees[5]!.id,
      type: MemoryType.TEXT,
      caption: "First place at the 2007 state science fair 🏆 I grew bacteria cultures from the cafeteria trays. Spoiler: the results were concerning.",
      yearContext: 2007,
      contextLabel: "Science Fair",
      status: ContentStatus.APPROVED,
      likeCount: 9,
    },
    {
      authorId: attendees[0]!.id,
      type: MemoryType.TEXT,
      caption: "Track championships 2008. Marcus broke the school record for the 400m. We all rushed the field like it was a World Cup. The principal gave us all detention. Worth it.",
      yearContext: 2008,
      contextLabel: "Track & Field",
      status: ContentStatus.APPROVED,
      likeCount: 24,
    },
    {
      authorId: attendees[3]!.id,
      type: MemoryType.TEXT,
      caption: "Finals week, junior year. The library at midnight, everyone surviving on Red Bull and collective panic. Aisha filmed it all — it became her first 'documentary' 🎬",
      yearContext: 2008,
      contextLabel: "Finals Week",
      status: ContentStatus.APPROVED,
      likeCount: 15,
    },
    {
      authorId: coOrganizer.id,
      type: MemoryType.TEXT,
      caption: "The day we launched the school app for the student newspaper. It crashed 10 minutes after launch because 200 people tried to use it at once. Taught me more about scaling than any CS class ever did.",
      yearContext: 2009,
      contextLabel: "Tech Club",
      status: ContentStatus.APPROVED,
      likeCount: 7,
    },
    {
      authorId: committee.id,
      type: MemoryType.TEXT,
      caption: "Senior trip to Yosemite! Who else remembers getting absolutely soaked on the Half Dome hike because nobody checked the forecast? Incredible trip despite (because of?) the chaos.",
      yearContext: 2009,
      contextLabel: "Senior Trip",
      status: ContentStatus.APPROVED,
      likeCount: 31,
    },
    {
      authorId: attendees[7]!.id,
      type: MemoryType.TEXT,
      caption: "Homecoming float committee 2007. We built an actual working waterfall out of paper mache and a garden hose. It worked perfectly at 9am and completely fell apart by 11am. We came second anyway.",
      yearContext: 2007,
      contextLabel: "Homecoming",
      status: ContentStatus.APPROVED,
      likeCount: 11,
    },
    {
      authorId: attendees[1]!.id,
      type: MemoryType.TEXT,
      caption: "AP Chemistry: the day Sam accidentally synthesized something that cleared the entire second floor. No one got hurt but the smell lingered for a WEEK. Mr. Chen was legendary about it.",
      yearContext: 2008,
      contextLabel: "AP Chemistry",
      status: ContentStatus.APPROVED,
      likeCount: 22,
    },
    {
      authorId: attendees[9]!.id,
      type: MemoryType.TEXT,
      caption: "Debate team, regionals 2008. Nina argued the affirmative on drone regulation and absolutely destroyed the opposition. She was going to be a lawyer — no one was surprised.",
      yearContext: 2008,
      contextLabel: "Debate Team",
      status: ContentStatus.APPROVED,
      likeCount: 14,
    },
    // Pending moderation
    {
      authorId: attendees[4]!.id,
      type: MemoryType.TEXT,
      caption: "I found an old photo from the 2009 graduation after-party at Dolores Park. Posting soon once I scan it!",
      yearContext: 2009,
      contextLabel: "Graduation",
      status: ContentStatus.PENDING,
      likeCount: 0,
    },
  ];

  const createdPosts: string[] = [];
  for (const post of memoryData) {
    const mp = await prisma.memoryPost.create({
      data: {
        eventId: event.id,
        authorId: post.authorId,
        type: post.type,
        caption: post.caption,
        yearContext: post.yearContext,
        contextLabel: post.contextLabel,
        visibleTo: "EVENT_ATTENDEES",
        status: post.status,
        likeCount: post.likeCount,
        commentCount: 0,
        moderatedById: post.status === ContentStatus.APPROVED ? organizer.id : null,
        moderatedAt: post.status === ContentStatus.APPROVED ? daysAgo(randomBetween(1, 20)) : null,
        createdAt: daysAgo(randomBetween(1, 30)),
      },
    });
    createdPosts.push(mp.id);
  }

  // Reactions on approved posts
  const approvedPosts = createdPosts.slice(0, 10);
  const emojiSet = ["❤️", "😂", "😮", "🔥", "👏"];
  for (let i = 0; i < approvedPosts.length; i++) {
    const postId = approvedPosts[i]!;
    const reactorCount = randomBetween(2, 8);
    const shuffled = [...attendees].sort(() => Math.random() - 0.5).slice(0, reactorCount);
    for (const reactor of shuffled) {
      const emoji = emojiSet[randomBetween(0, emojiSet.length - 1)]!;
      try {
        await prisma.memoryReaction.create({
          data: {
            memoryPostId: postId,
            userId: reactor.id,
            emoji,
          },
        });
      } catch {
        // ignore duplicate reactions
      }
    }
  }

  // Comments on a few posts
  const commentData = [
    { postIndex: 0, authorId: attendees[0]!.id, content: "ICONIC. I still can't walk past that classroom without laughing." },
    { postIndex: 0, authorId: coOrganizer.id, content: "I have video of this somewhere. Will dig it out for the memory wall!" },
    { postIndex: 2, authorId: committee.id, content: "The bacteria results... were they from the pasta station? Asking for a friend 🙈" },
    { postIndex: 6, authorId: attendees[3]!.id, content: "The Yosemite trip! I still have my completely ruined Converse from that hike." },
    { postIndex: 6, authorId: attendees[1]!.id, content: "The shuttle bus driver's face when 50 soaking wet 18-year-olds got on... 💀" },
    { postIndex: 8, authorId: attendees[5]!.id, content: "The smell!!! It was still there in DECEMBER. Whatever Sam made should be studied." },
    { postIndex: 9, authorId: attendees[4]!.id, content: "I was IN the audience for that debate round. Nina was terrifying. In the best way." },
  ];

  for (const c of commentData) {
    await prisma.memoryComment.create({
      data: {
        memoryPostId: createdPosts[c.postIndex]!,
        authorId: c.authorId,
        content: c.content,
        status: ContentStatus.APPROVED,
        createdAt: daysAgo(randomBetween(0, 15)),
      },
    });

    // Update comment count
    await prisma.memoryPost.update({
      where: { id: createdPosts[c.postIndex]! },
      data: { commentCount: { increment: 1 } },
    });
  }

  // ── 14. Nominations ───────────────────────────────────────────────────────
  console.log("🏆  Creating nominations…");

  const categories = await Promise.all([
    prisma.nominationCategory.create({
      data: {
        eventId: event.id,
        title: "Best Glow-Up",
        description: "Who has changed the most for the better since graduation?",
        emoji: "✨",
        sortOrder: 1,
        votingStatus: VotingStatus.OPEN,
        votingOpenAt: daysAgo(7),
        votingClosedAt: daysFromNow(7),
      },
    }),
    prisma.nominationCategory.create({
      data: {
        eventId: event.id,
        title: "Most Likely to Take Over the World",
        description: "The one who achieved exactly what we all expected — and then some.",
        emoji: "🌍",
        sortOrder: 2,
        votingStatus: VotingStatus.OPEN,
        votingOpenAt: daysAgo(7),
        votingClosedAt: daysFromNow(7),
      },
    }),
    prisma.nominationCategory.create({
      data: {
        eventId: event.id,
        title: "Still the Life of the Party",
        description: "Some things never change.",
        emoji: "🎉",
        sortOrder: 3,
        votingStatus: VotingStatus.OPEN,
        votingOpenAt: daysAgo(7),
        votingClosedAt: daysFromNow(7),
      },
    }),
    prisma.nominationCategory.create({
      data: {
        eventId: event.id,
        title: "Most Changed Career Path",
        description: "From their high school trajectory to where they actually ended up — wildest pivot.",
        emoji: "🔄",
        sortOrder: 4,
        votingStatus: VotingStatus.DRAFT,
      },
    }),
  ]);

  // Nominations for "Best Glow-Up"
  const glowUpCategory = categories[0]!;
  const nominationPairs = [
    { nominatorId: attendees[0]!.id, nomineeId: attendees[3]!.id, note: "Chloe went from quiet freshman to Tartine's head pastry chef — that's a glow-up!" },
    { nominatorId: attendees[1]!.id, nomineeId: attendees[6]!.id, note: "Elena is a published food writer! We knew she was the best writer in AP English." },
    { nominatorId: organizer.id, nomineeId: attendees[2]!.id, note: "Marcus went from track star to conditioning the Warriors. Absolute legend." },
    { nominatorId: committee.id, nomineeId: attendees[7]!.id, note: "Aisha's Netflix documentary? That was made on a Nokia phone in 9th grade 😂" },
  ];

  for (const pair of nominationPairs) {
    await prisma.classmateNomination.create({
      data: {
        categoryId: glowUpCategory.id,
        nominatorId: pair.nominatorId,
        nomineeId: pair.nomineeId,
        status: NominationStatus.ACCEPTED,
        note: pair.note,
        notifiedAt: daysAgo(10),
        respondedAt: daysAgo(8),
      },
    });
  }

  // Votes on "Best Glow-Up"
  const nominees = [attendees[3]!, attendees[6]!, attendees[2]!, attendees[7]!];
  const voters = attendees.filter((_, i) => rsvpStatuses[i] === RSVPStatus.CONFIRMED);
  for (let i = 0; i < voters.length; i++) {
    const voter = voters[i]!;
    const nominee = nominees[i % nominees.length]!;
    try {
      await prisma.nominationVote.create({
        data: {
          categoryId: glowUpCategory.id,
          voterId: voter.id,
          nomineeId: nominee.id,
          createdAt: daysAgo(randomBetween(1, 6)),
        },
      });
    } catch {
      // ignore duplicate votes
    }
  }

  // Nominations for "Most Likely to Take Over the World"
  const takeover = categories[1]!;
  await prisma.classmateNomination.create({
    data: {
      categoryId: takeover.id,
      nominatorId: attendees[1]!.id,
      nomineeId: attendees[5]!.id,
      status: NominationStatus.ACCEPTED,
      note: "David raised $10M from a cold email. If that's not taking over the world...",
      notifiedAt: daysAgo(9),
      respondedAt: daysAgo(7),
    },
  });
  await prisma.classmateNomination.create({
    data: {
      categoryId: takeover.id,
      nominatorId: attendees[0]!.id,
      nomineeId: attendees[6]!.id,
      status: NominationStatus.ACCEPTED,
      note: "Nina is an immigration attorney fighting for actual justice. Literal world-changer.",
      notifiedAt: daysAgo(9),
      respondedAt: daysAgo(6),
    },
  });
  // One pending nomination
  await prisma.classmateNomination.create({
    data: {
      categoryId: takeover.id,
      nominatorId: committee.id,
      nomineeId: attendees[10]!.id,
      status: NominationStatus.PENDING,
      note: "Sam is at a16z making $100M bets. Take over? Already done.",
      notifiedAt: daysAgo(3),
    },
  });

  // ── 15. Announcements ─────────────────────────────────────────────────────
  console.log("📢  Creating announcements…");

  const announcements = await Promise.all([
    prisma.announcement.create({
      data: {
        eventId: event.id,
        authorId: organizer.id,
        title: "🎟️ Tickets Now Available!",
        body: "We're officially open for RSVPs! Early Bird tickets are $79 (limited to 30) and General Admission is $99. We have VIP Gold Table tickets for $159 with premium seating and a class gift. Grab yours before they sell out!",
        isPinned: true,
        isUrgent: false,
        publishedAt: daysAgo(45),
      },
    }),
    prisma.announcement.create({
      data: {
        eventId: event.id,
        authorId: organizer.id,
        title: "⚡️ Early Bird Sold Out!",
        body: "All 30 Early Bird tickets are gone in under a week! Thank you! General Admission tickets are still available. Don't wait.",
        isPinned: false,
        isUrgent: false,
        publishedAt: daysAgo(38),
      },
    }),
    prisma.announcement.create({
      data: {
        eventId: event.id,
        authorId: committee.id,
        title: "🍽️ Dietary Requirements — Please Update Your RSVP",
        body: "The caterer needs final numbers by next Friday. If you have dietary requirements (vegetarian, vegan, gluten-free, halal, kosher, allergies), please update your RSVP now. Log in → My RSVP → Edit.",
        isPinned: true,
        isUrgent: true,
        publishedAt: daysAgo(14),
      },
    }),
    prisma.announcement.create({
      data: {
        eventId: event.id,
        authorId: organizer.id,
        title: "🏆 Voting for Class Superlatives is OPEN!",
        body: "Head to the Nominations tab to vote for our class superlatives! Categories include Best Glow-Up, Most Likely to Take Over the World, and more. Voting closes 7 days before the event.",
        isPinned: true,
        isUrgent: false,
        publishedAt: daysAgo(7),
      },
    }),
    prisma.announcement.create({
      data: {
        eventId: event.id,
        authorId: coOrganizer.id,
        title: "📸 Add Your Memories to the Wall!",
        body: "We're building a slideshow of your best school memories for the event! Upload photos, share stories, or tag classmates in the Memory Wall tab. All submissions go through a quick moderation check and we'll feature the best ones on the night.",
        isPinned: false,
        isUrgent: false,
        publishedAt: daysAgo(20),
      },
    }),
  ]);

  // Some read receipts
  for (const ann of announcements) {
    const readers = [organizer, coOrganizer, ...attendees.slice(0, 8)];
    for (const reader of readers) {
      await prisma.announcementReadReceipt.upsert({
        where: { announcementId_userId: { announcementId: ann.id, userId: reader.id } },
        update: {},
        create: {
          announcementId: ann.id,
          userId: reader.id,
          readAt: daysAgo(randomBetween(0, 5)),
        },
      });
    }
  }

  // ── 16. Broadcasts ────────────────────────────────────────────────────────
  console.log("📡  Creating broadcast records…");
  await prisma.broadcast.create({
    data: {
      eventId: event.id,
      createdById: organizer.id,
      subject: "Just 30 days to go — Lincoln High Class of 2009 Reunion!",
      body: {
        type: "doc",
        content: [
          { type: "paragraph", content: [{ type: "text", text: "Hi everyone! One month from today we'll all be back together. 67 of you are confirmed — help us reach 100!" }] },
          { type: "paragraph", content: [{ type: "text", text: "Reminder: update your dietary requirements and cast your votes for class superlatives. See you soon! 🦁" }] },
        ],
      },
      channel: BroadcastChannel.EMAIL,
      audienceFilter: { statuses: ["CONFIRMED", "PENDING"] },
      status: BroadcastStatus.SENT,
      sentAt: daysAgo(10),
      recipientCount: 78,
      deliveredCount: 76,
      failedCount: 2,
      openedCount: 51,
      clickedCount: 23,
    },
  });

  await prisma.broadcast.create({
    data: {
      eventId: event.id,
      createdById: organizer.id,
      subject: "Dietary requirements deadline Friday!",
      body: {
        type: "doc",
        content: [
          { type: "paragraph", content: [{ type: "text", text: "Quick reminder — the caterer needs your dietary requirements by this Friday. Please log in and update your RSVP if you haven't already!" }] },
        ],
      },
      channel: BroadcastChannel.EMAIL,
      audienceFilter: { statuses: ["CONFIRMED"] },
      status: BroadcastStatus.SENT,
      sentAt: daysAgo(7),
      recipientCount: 67,
      deliveredCount: 67,
      failedCount: 0,
      openedCount: 44,
      clickedCount: 31,
    },
  });

  // Draft broadcast
  await prisma.broadcast.create({
    data: {
      eventId: event.id,
      createdById: organizer.id,
      subject: "One week to go — final details inside 🦁",
      body: {
        type: "doc",
        content: [
          { type: "paragraph", content: [{ type: "text", text: "One week until the big night! Here's everything you need to know..." }] },
        ],
      },
      channel: BroadcastChannel.EMAIL,
      audienceFilter: { statuses: ["CONFIRMED"] },
      status: BroadcastStatus.DRAFT,
    },
  });

  // ── 17. Consent Records ───────────────────────────────────────────────────
  console.log("🔒  Creating consent records…");
  const allUsersList = [organizer, coOrganizer, committee, ...attendees];
  for (const user of allUsersList) {
    await prisma.consentRecord.create({
      data: {
        userId: user.id,
        eventId: event.id,
        type: ConsentType.EMAIL_MARKETING,
        granted: true,
        version: "v1.2",
        source: "RSVP_FORM",
        ipAddress: "203.0.113." + randomBetween(1, 254),
        userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
        createdAt: daysAgo(randomBetween(3, 40)),
      },
    });

    if (user.role !== "attendee" || Math.random() > 0.4) {
      await prisma.consentRecord.create({
        data: {
          userId: user.id,
          type: ConsentType.ANALYTICS,
          granted: true,
          version: "v1.2",
          source: "ACCOUNT_CREATION",
          createdAt: daysAgo(randomBetween(40, 90)),
        },
      });
    }
  }

  // ── 18. Notification Preferences ─────────────────────────────────────────
  console.log("🔔  Creating notification preferences…");
  const notifTypes = ["RSVP_CONFIRMED", "MEMORY_TAGGED", "NOMINATION_RECEIVED", "CHAT_MENTION"];
  for (const user of allUsersList.slice(0, 6)) {
    for (const type of notifTypes) {
      await prisma.notificationPreference.upsert({
        where: {
          userId_eventId_channel_type: {
            userId: user.id,
            eventId: event.id,
            channel: NotificationChannel.EMAIL,
            type,
          },
        },
        update: {},
        create: {
          userId: user.id,
          eventId: event.id,
          channel: NotificationChannel.EMAIL,
          type,
          frequency: NotificationFrequency.INSTANT,
          enabled: true,
        },
      });
    }
  }

  // ── 19. Audit Logs ────────────────────────────────────────────────────────
  console.log("📋  Creating audit log entries…");
  const auditActions = [
    { actorId: organizer.id, action: "EVENT_CREATED", resourceType: "Event", resourceId: event.id, daysAgo: 50 },
    { actorId: organizer.id, action: "EVENT_PUBLISHED", resourceType: "Event", resourceId: event.id, daysAgo: 45 },
    { actorId: coOrganizer.id, action: "COMMITTEE_MEMBER_ADDED", resourceType: "CommitteeMember", resourceId: coOrganizer.id, daysAgo: 44 },
    { actorId: organizer.id, action: "TICKET_CREATED", resourceType: "Ticket", resourceId: earlyBirdTicket.id, daysAgo: 44 },
    { actorId: organizer.id, action: "TICKET_CREATED", resourceType: "Ticket", resourceId: generalTicket.id, daysAgo: 44 },
    { actorId: organizer.id, action: "BROADCAST_SENT", resourceType: "Broadcast", resourceId: "broadcast_1", daysAgo: 10, metadata: { channel: "EMAIL", recipientCount: 78 } },
    { actorId: organizer.id, action: "MEMORY_APPROVED", resourceType: "MemoryPost", resourceId: createdPosts[0]!, daysAgo: 20 },
    { actorId: organizer.id, action: "MEMORY_APPROVED", resourceType: "MemoryPost", resourceId: createdPosts[1]!, daysAgo: 18 },
    { actorId: organizer.id, action: "DATA_EXPORTED", resourceType: "Event", resourceId: event.id, daysAgo: 5, metadata: { format: "csv", count: 67 } },
  ];

  for (const entry of auditActions) {
    await prisma.auditLog.create({
      data: {
        actorId: entry.actorId,
        eventId: event.id,
        action: entry.action,
        resourceType: entry.resourceType,
        resourceId: entry.resourceId,
        metadata: entry.metadata ?? null,
        ipAddress: "203.0.113." + randomBetween(1, 254),
        createdAt: daysAgo(entry.daysAgo),
      },
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  console.log("\n✅  Seed complete!\n");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("  School:       Lincoln High School (San Francisco, CA)");
  console.log("  Event:        Lincoln High Class of 2009 — 15-Year Reunion");
  console.log("  Event Slug:   lincoln-high-2009-15year");
  console.log("  Event URL:    http://localhost:3000/events/lincoln-high-2009-15year");
  console.log("─────────────────────────────────────────────────────────────");
  console.log("  Users created: 18");
  console.log(`    Organizer:    ${organizer.email}  (clerkId: ${organizer.clerkId})`);
  console.log(`    Co-Org:       ${coOrganizer.email}  (clerkId: ${coOrganizer.clerkId})`);
  console.log(`    Committee:    ${committee.email}  (clerkId: ${committee.clerkId})`);
  console.log(`    Attendees:    ${attendees.length} users`);
  console.log("─────────────────────────────────────────────────────────────");
  console.log("  RSVPs:        11 confirmed, 2 pending, 1 declined, 1 waitlisted");
  console.log("  Payments:     11 paid ($8,811 gross revenue)");
  console.log("  Invites:      15 sent, 13 RSVP'd");
  console.log("  Tickets:      Early Bird (sold out), General ($99), VIP ($159)");
  console.log("  Check-ins:    6 (from pre-event meetup)");
  console.log("  Chat Rooms:   3 (general, travel-and-hotels, table-requests)");
  console.log("  Chat Msgs:    30+ messages across rooms");
  console.log("  Memory Posts: 11 (10 approved, 1 pending)");
  console.log("  Nominations:  4 categories, 7 nominations, 11 votes cast");
  console.log("  Broadcasts:   2 sent, 1 draft");
  console.log("  Announcements: 5 published");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
}

main()
  .catch((err) => {
    console.error("❌  Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
