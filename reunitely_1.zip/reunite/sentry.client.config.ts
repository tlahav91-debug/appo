import * as Sentry from "@sentry/nextjs";

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,

  // Only enable in production
  enabled: process.env.NODE_ENV === "production",

  // Trace sampling — 10% in production to control costs
  tracesSampleRate: 0.1,

  // Replay for session recording (5% of sessions, 100% on error)
  replaysSessionSampleRate: 0.05,
  replaysOnErrorSampleRate: 1.0,

  integrations: [
    Sentry.replayIntegration({
      // Mask all user input by default
      maskAllText: true,
      blockAllMedia: true,
    }),
  ],

  // Scrub PII from error payloads
  beforeSend(event) {
    if (event.request?.cookies) {
      event.request.cookies = "[Filtered]";
    }
    // Remove Authorization headers
    if (event.request?.headers) {
      delete event.request.headers["Authorization"];
      delete event.request.headers["authorization"];
      delete event.request.headers["cookie"];
    }
    return event;
  },

  // Ignore known non-actionable errors
  ignoreErrors: [
    "ResizeObserver loop limit exceeded",
    "Non-Error promise rejection captured",
    /^NetworkError/,
    /^AbortError/,
    "ChunkLoadError",
  ],
});
