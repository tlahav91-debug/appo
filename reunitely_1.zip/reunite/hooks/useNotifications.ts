"use client";

import { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useUser } from "@clerk/nextjs";
import { getPusherClient, pusherChannels, pusherEvents } from "@/lib/pusher";
import type { TypedNotification } from "@/types";

async function fetchNotifications(): Promise<TypedNotification[]> {
  const res = await fetch("/api/notifications");
  if (!res.ok) throw new Error("Failed to fetch notifications");
  const json = await res.json();
  return json.data ?? [];
}

async function markAllReadApi(): Promise<void> {
  await fetch("/api/notifications/read-all", { method: "POST" });
}

export function useNotifications() {
  const { user } = useUser();
  const queryClient = useQueryClient();

  const { data: notifications = [] } = useQuery({
    queryKey: ["notifications"],
    queryFn: fetchNotifications,
    enabled: !!user,
    refetchOnWindowFocus: true,
    staleTime: 30_000,
  });

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  // Subscribe to real-time notifications via Pusher
  useEffect(() => {
    if (!user?.id) return;

    const pusher = getPusherClient();
    const channelName = pusherChannels.userNotifications(user.id);
    const channel = pusher.subscribe(channelName);

    channel.bind(pusherEvents.NEW_NOTIFICATION, (notification: TypedNotification) => {
      // Prepend new notification to cache
      queryClient.setQueryData<TypedNotification[]>(
        ["notifications"],
        (old = []) => [notification, ...old]
      );
    });

    return () => {
      pusher.unsubscribe(channelName);
    };
  }, [user?.id, queryClient]);

  const markAllReadMutation = useMutation({
    mutationFn: markAllReadApi,
    onMutate: async () => {
      // Optimistic update
      queryClient.setQueryData<TypedNotification[]>(
        ["notifications"],
        (old = []) => old.map((n) => ({ ...n, isRead: true }))
      );
    },
    onError: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
    },
  });

  return {
    notifications,
    unreadCount,
    markAllRead: markAllReadMutation.mutate,
  };
}
