"use client";

import { useEffect, useRef } from "react";

/**
 * useUnsavedChangesWarning
 *
 * Shows a browser native confirm dialog before the user:
 * - Closes or refreshes the tab
 * - Navigates away via the address bar
 *
 * Does NOT block Next.js router navigation (which requires useRouter).
 * For wizard use: disabled once the form is saved or published.
 */
export function useUnsavedChangesWarning(hasUnsavedChanges: boolean) {
  const hasChangesRef = useRef(hasUnsavedChanges);

  useEffect(() => {
    hasChangesRef.current = hasUnsavedChanges;
  }, [hasUnsavedChanges]);

  useEffect(() => {
    function handleBeforeUnload(e: BeforeUnloadEvent) {
      if (!hasChangesRef.current) return;
      e.preventDefault();
      // Most browsers show their own message regardless of this string
      e.returnValue = "You have unsaved changes. Are you sure you want to leave?";
      return e.returnValue;
    }

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, []);
}
