"use client";

import { useState, useCallback } from "react";

export type UploadStatus = "idle" | "requesting" | "uploading" | "done" | "error";

export interface UploadedFile {
  s3Key: string;
  publicUrl: string;
  previewUrl: string; // local blob URL for instant preview
  file: File;
  width?: number;
  height?: number;
}

interface UseUploadOptions {
  folder?: string;
  maxFiles?: number;
  maxSizeMb?: number;
}

interface UploadState {
  files: UploadedFile[];
  progress: number; // 0-100
  status: UploadStatus;
  error: string | null;
}

export function useUpload({
  folder = "events/memories",
  maxFiles = 10,
  maxSizeMb = 25,
}: UseUploadOptions = {}) {
  const [state, setState] = useState<UploadState>({
    files: [],
    progress: 0,
    status: "idle",
    error: null,
  });

  const upload = useCallback(
    async (selectedFiles: File[]): Promise<UploadedFile[]> => {
      if (selectedFiles.length === 0) return [];
      if (state.files.length + selectedFiles.length > maxFiles) {
        setState((s) => ({
          ...s,
          error: `Maximum ${maxFiles} files allowed.`,
        }));
        return [];
      }

      const oversized = selectedFiles.find(
        (f) => f.size > maxSizeMb * 1024 * 1024
      );
      if (oversized) {
        setState((s) => ({
          ...s,
          error: `${oversized.name} is too large. Maximum ${maxSizeMb}MB.`,
        }));
        return [];
      }

      setState((s) => ({ ...s, status: "requesting", error: null, progress: 0 }));

      const uploaded: UploadedFile[] = [];

      for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i]!;
        const ext = file.name.split(".").pop()?.toLowerCase() ?? "jpg";

        try {
          // 1. Get presigned URL
          const presignRes = await fetch("/api/upload", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              folder,
              contentType: file.type,
              fileSize: file.size,
              fileExtension: ext,
            }),
          });

          if (!presignRes.ok) {
            const json = await presignRes.json().catch(() => ({}));
            throw new Error(json.error?.message ?? "Failed to get upload URL");
          }

          const { data } = await presignRes.json();
          const { uploadUrl, key, publicUrl } = data as {
            uploadUrl: string;
            key: string;
            publicUrl: string;
          };

          setState((s) => ({ ...s, status: "uploading" }));

          // 2. Upload directly to S3
          const uploadRes = await fetch(uploadUrl, {
            method: "PUT",
            body: file,
            headers: { "Content-Type": file.type },
          });

          if (!uploadRes.ok) {
            throw new Error(`Upload failed: ${uploadRes.statusText}`);
          }

          // 3. Get image dimensions for display
          const dims = await getImageDimensions(file);

          uploaded.push({
            s3Key: key,
            publicUrl,
            previewUrl: URL.createObjectURL(file),
            file,
            width: dims.width,
            height: dims.height,
          });

          setState((s) => ({
            ...s,
            files: [...s.files, uploaded[uploaded.length - 1]!],
            progress: Math.round(((i + 1) / selectedFiles.length) * 100),
          }));
        } catch (err) {
          setState((s) => ({
            ...s,
            status: "error",
            error:
              err instanceof Error ? err.message : "Upload failed",
          }));
          return uploaded;
        }
      }

      setState((s) => ({ ...s, status: "done", progress: 100 }));
      return uploaded;
    },
    [folder, maxFiles, maxSizeMb, state.files.length]
  );

  const remove = useCallback((s3Key: string) => {
    setState((s) => ({
      ...s,
      files: s.files.filter((f) => f.s3Key !== s3Key),
    }));
  }, []);

  const reset = useCallback(() => {
    // Revoke blob URLs to avoid memory leaks
    state.files.forEach((f) => URL.revokeObjectURL(f.previewUrl));
    setState({ files: [], progress: 0, status: "idle", error: null });
  }, [state.files]);

  const clearError = useCallback(() => {
    setState((s) => ({ ...s, error: null }));
  }, []);

  return {
    files: state.files,
    progress: state.progress,
    status: state.status,
    error: state.error,
    upload,
    remove,
    reset,
    clearError,
    isUploading: state.status === "uploading" || state.status === "requesting",
    isDone: state.status === "done",
  };
}

async function getImageDimensions(
  file: File
): Promise<{ width: number; height: number }> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      resolve({ width: img.naturalWidth, height: img.naturalHeight });
      URL.revokeObjectURL(url);
    };
    img.onerror = () => {
      resolve({ width: 0, height: 0 });
      URL.revokeObjectURL(url);
    };
    img.src = url;
  });
}
