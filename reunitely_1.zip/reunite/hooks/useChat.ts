"use client";

import { useEffect, useRef, useCallback, useState } from "react";
import {
  useInfiniteQuery,
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";
import { getPusherClient, pusherChannels, pusherEvents } from "@/lib/pusher";
import type { ChatMessageWithAuthor } from "@/types";

const PAGE_SIZE = 50;

// ─── Fetchers ─────────────────────────────────────────────────────────────────

async function fetchMessages(
  roomId: string,
  cursor?: string
): Promise<{ items: ChatMessageWithAuthor[]; nextCursor: string | null }> {
  const params = new URLSearchParams({ limit: String(PAGE_SIZE) });
  if (cursor) params.set("cursor", cursor);
  const res = await fetch(`/api/chat/rooms/${roomId}/messages?${params}`);
  if (!res.ok) throw new Error("Failed to load messages");
  return (await res.json()).data;
}

async function postMessage(
  roomId: string,
  payload: { content: string; replyToId?: string; mediaUrl?: string }
): Promise<ChatMessageWithAuthor> {
  const res = await fetch(`/api/chat/rooms/${roomId}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message ?? "Failed to send message");
  }
  return (await res.json()).data;
}

async function deleteMsg(messageId: string): Promise<void> {
  const res = await fetch(`/api/chat/messages/${messageId}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete message");
}

async function editMsg(messageId: string, content: string): Promise<void> {
  const res = await fetch(`/api/chat/messages/${messageId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content }),
  });
  if (!res.ok) throw new Error("Failed to edit message");
}

async function toggleReaction(
  roomId: string,
  messageId: string,
  emoji: string
): Promise<void> {
  await fetch(`/api/chat/rooms/${roomId}/react`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messageId, emoji }),
  });
}

async function pinMessage(
  roomId: string,
  messageId: string,
  pinned: boolean
): Promise<void> {
  await fetch(`/api/chat/rooms/${roomId}/pin`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messageId, pinned }),
  });
}

// ─── Types ────────────────────────────────────────────────────────────────────

export interface SlowModeState {
  seconds: number;
  remaining: number; // seconds until next message allowed
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useChat(roomId: string, slowModeSeconds?: number | null) {
  const queryClient = useQueryClient();
  const bottomRef = useRef<HTMLDivElement>(null);
  const [slowModeRemaining, setSlowModeRemaining] = useState(0);

  // Paginated messages (cursor = oldest createdAt in current batch)
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
  } = useInfiniteQuery({
    queryKey: ["chat", roomId],
    queryFn: ({ pageParam }) =>
      fetchMessages(roomId, pageParam as string | undefined),
    initialPageParam: undefined as string | undefined,
    getNextPageParam: (lastPage) => lastPage.nextCursor ?? undefined,
    enabled: !!roomId,
    staleTime: Infinity, // Real-time via Pusher
  });

  // Flatten pages — oldest first for rendering
  const messages =
    data?.pages
      .flatMap((p) => p.items)
      .slice()
      .reverse() ?? [];

  // ── Pusher subscription ────────────────────────────────────────────────────
  useEffect(() => {
    if (!roomId) return;
    const pusher = getPusherClient();
    const channel = pusher.subscribe(pusherChannels.chatRoom(roomId));

    // New message
    channel.bind(pusherEvents.NEW_MESSAGE, (msg: ChatMessageWithAuthor) => {
      queryClient.setQueryData(["chat", roomId], (old: typeof data) => {
        if (!old) return old;
        const pages = [...old.pages];
        const last = pages[pages.length - 1];
        if (!last) return old;
        // Prepend (API returns desc, we flip for display)
        pages[pages.length - 1] = { ...last, items: [msg, ...last.items] };
        return { ...old, pages };
      });
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    });

    // Message deleted
    channel.bind(pusherEvents.MESSAGE_DELETED, ({ messageId }: { messageId: string }) => {
      queryClient.setQueryData(["chat", roomId], (old: typeof data) => {
        if (!old) return old;
        return {
          ...old,
          pages: old.pages.map((page) => ({
            ...page,
            items: page.items.map((m) =>
              m.id === messageId ? { ...m, isDeleted: true, content: "" } : m
            ),
          })),
        };
      });
    });

    // Message edited
    channel.bind(pusherEvents.MESSAGE_EDITED, (updated: ChatMessageWithAuthor) => {
      queryClient.setQueryData(["chat", roomId], (old: typeof data) => {
        if (!old) return old;
        return {
          ...old,
          pages: old.pages.map((page) => ({
            ...page,
            items: page.items.map((m) => (m.id === updated.id ? updated : m)),
          })),
        };
      });
    });

    // Reaction updated — patch reactions array on the affected message
    channel.bind(
      pusherEvents.REACTION_ADDED,
      ({ messageId, reactions }: { messageId: string; reactions: Array<{ emoji: string; userId: string }> }) => {
        queryClient.setQueryData(["chat", roomId], (old: typeof data) => {
          if (!old) return old;
          return {
            ...old,
            pages: old.pages.map((page) => ({
              ...page,
              items: page.items.map((m) =>
                m.id === messageId ? { ...m, reactions } : m
              ),
            })),
          };
        });
      }
    );

    // Pin state change
    channel.bind(
      "message-pinned",
      ({ messageId, pinned }: { messageId: string; pinned: boolean }) => {
        queryClient.setQueryData(["chat", roomId], (old: typeof data) => {
          if (!old) return old;
          return {
            ...old,
            pages: old.pages.map((page) => ({
              ...page,
              items: page.items.map((m) =>
                m.id === messageId ? { ...m, isPinned: pinned } : m
              ),
            })),
          };
        });
      }
    );

    // Slow mode changed
    channel.bind(
      "slow-mode-changed",
      ({ slowModeSeconds: sms }: { slowModeSeconds: number | null }) => {
        // Parent component re-renders when room data refreshes
        queryClient.invalidateQueries({ queryKey: ["chat-rooms"] });
      }
    );

    return () => {
      pusher.unsubscribe(pusherChannels.chatRoom(roomId));
    };
  }, [roomId, queryClient]);

  // ── Slow mode countdown ────────────────────────────────────────────────────
  useEffect(() => {
    if (!slowModeSeconds || slowModeRemaining <= 0) return;
    const id = setInterval(() => {
      setSlowModeRemaining((s) => Math.max(0, s - 1));
    }, 1000);
    return () => clearInterval(id);
  }, [slowModeSeconds, slowModeRemaining]);

  // ── Mutations ──────────────────────────────────────────────────────────────
  const sendMutation = useMutation({
    mutationFn: (payload: { content: string; replyToId?: string }) =>
      postMessage(roomId, payload),
    onSuccess: () => {
      if (slowModeSeconds) setSlowModeRemaining(slowModeSeconds);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: deleteMsg,
    onSuccess: (_, messageId) => {
      queryClient.setQueryData(["chat", roomId], (old: typeof data) => {
        if (!old) return old;
        return {
          ...old,
          pages: old.pages.map((p) => ({
            ...p,
            items: p.items.map((m) =>
              m.id === messageId ? { ...m, isDeleted: true, content: "" } : m
            ),
          })),
        };
      });
    },
  });

  const editMutation = useMutation({
    mutationFn: ({ messageId, content }: { messageId: string; content: string }) =>
      editMsg(messageId, content),
  });

  const reactMutation = useMutation({
    mutationFn: ({ messageId, emoji }: { messageId: string; emoji: string }) =>
      toggleReaction(roomId, messageId, emoji),
  });

  const pinMutation = useMutation({
    mutationFn: ({ messageId, pinned }: { messageId: string; pinned: boolean }) =>
      pinMessage(roomId, messageId, pinned),
  });

  const loadOlderMessages = useCallback(() => {
    if (hasNextPage && !isFetchingNextPage) fetchNextPage();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  // Pinned messages derived from current data
  const pinnedMessages = messages.filter((m) => m.isPinned && !m.isDeleted);

  return {
    messages,
    isLoading,
    hasOlderMessages: hasNextPage,
    isLoadingOlder: isFetchingNextPage,
    loadOlderMessages,
    pinnedMessages,
    // Send
    sendMessage: sendMutation.mutateAsync,
    isSending: sendMutation.isPending,
    sendError: sendMutation.error?.message,
    // Delete
    deleteMessage: deleteMutation.mutate,
    // Edit
    editMessage: editMutation.mutateAsync,
    // React
    addReaction: reactMutation.mutate,
    // Pin
    pinMessage: pinMutation.mutate,
    // Slow mode
    slowModeRemaining,
    bottomRef,
  };
}
