"use client";

import { useUser } from "@clerk/nextjs";
import { useQuery } from "@tanstack/react-query";
import type { AttendeeProfile, OrganizerProfile } from "@prisma/client";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface CurrentUser {
  id: string;
  clerkId: string;
  name: string;
  email: string;
  username: string | null;
  avatarUrl: string | null;
  platformRole: "USER" | "MODERATOR" | "SUPER_ADMIN";
  attendeeProfile: AttendeeProfile | null;
  organizerProfile: OrganizerProfile | null;
}

// ─── Fetcher ──────────────────────────────────────────────────────────────────

async function fetchCurrentUser(): Promise<CurrentUser> {
  const res = await fetch("/api/profile");
  if (!res.ok) throw new Error("Failed to fetch user profile");
  const json = await res.json();
  return json.data;
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useCurrentUser() {
  const { user: clerkUser, isLoaded: clerkLoaded, isSignedIn } = useUser();

  const {
    data: dbUser,
    isLoading: dbLoading,
    error,
    refetch,
  } = useQuery<CurrentUser>({
    queryKey: ["current-user"],
    queryFn: fetchCurrentUser,
    enabled: clerkLoaded && isSignedIn,
    staleTime: 5 * 60 * 1000, // 5 min — profile rarely changes mid-session
    retry: 1,
  });

  const platformRole =
    (clerkUser?.publicMetadata?.platformRole as string) ?? dbUser?.platformRole ?? "USER";

  return {
    // Clerk data (always fresh — no DB call)
    clerkUser,
    isLoaded: clerkLoaded,
    isSignedIn: isSignedIn ?? false,

    // DB data (enriched)
    dbUser: dbUser ?? null,
    isDbLoading: dbLoading,
    error,
    refetch,

    // Derived
    name: dbUser?.name ?? clerkUser?.fullName ?? "",
    email: dbUser?.email ?? clerkUser?.primaryEmailAddress?.emailAddress ?? "",
    avatarUrl: dbUser?.avatarUrl ?? clerkUser?.imageUrl ?? null,
    platformRole: platformRole as "USER" | "MODERATOR" | "SUPER_ADMIN",
    isSuperAdmin: platformRole === "SUPER_ADMIN",
    isModerator: platformRole === "MODERATOR" || platformRole === "SUPER_ADMIN",

    // Profile completeness (for onboarding prompts)
    profileCompleteness: dbUser?.attendeeProfile?.profileCompleteness ?? 0,
    hasOrganizerProfile: !!dbUser?.organizerProfile,
  };
}
