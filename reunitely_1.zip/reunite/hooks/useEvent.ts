"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { EventWithMeta } from "@/types";

// ─── Fetchers ─────────────────────────────────────────────────────────────────

async function fetchEvent(id: string): Promise<EventWithMeta> {
  const res = await fetch(`/api/events/${id}`);
  if (!res.ok) throw new Error("Failed to load event");
  const json = await res.json();
  return json.data;
}

async function publishEvent(id: string): Promise<EventWithMeta> {
  const res = await fetch(`/api/events/${id}/publish`, { method: "POST" });
  if (!res.ok) {
    const json = await res.json().catch(() => ({}));
    throw new Error(json.error?.message ?? "Failed to publish event");
  }
  return (await res.json()).data;
}

async function archiveEvent(id: string): Promise<void> {
  const res = await fetch(`/api/events/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to archive event");
}

// ─── Hooks ────────────────────────────────────────────────────────────────────

export function useEvent(id: string) {
  return useQuery({
    queryKey: ["event", id],
    queryFn: () => fetchEvent(id),
    enabled: !!id,
  });
}

export function usePublishEvent(id: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => publishEvent(id),
    onSuccess: (updated) => {
      queryClient.setQueryData(["event", id], updated);
      toast.success("Event published! Share the link with your classmates.");
    },
    onError: (err: Error) => {
      toast.error(err.message);
    },
  });
}

export function useArchiveEvent(id: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => archiveEvent(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["events"] });
      queryClient.removeQueries({ queryKey: ["event", id] });
      toast.success("Event archived.");
    },
    onError: () => {
      toast.error("Failed to archive event. Please try again.");
    },
  });
}
