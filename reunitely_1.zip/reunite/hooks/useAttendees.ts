"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { AttendeeRow, AttendeeFilter } from "@/types";
import type { RSVPStatus } from "@prisma/client";

async function fetchAttendees(
  eventId: string,
  filter: AttendeeFilter
): Promise<AttendeeRow[]> {
  const params = new URLSearchParams();
  if (filter.search) params.set("search", filter.search);
  if (filter.status?.length) params.set("status", filter.status.join(","));
  if (filter.cursor) params.set("cursor", filter.cursor);
  if (filter.limit) params.set("limit", String(filter.limit));

  const res = await fetch(`/api/events/${eventId}/memberships?${params}`);
  if (!res.ok) throw new Error("Failed to load attendees");
  return (await res.json()).data ?? [];
}

async function updateAttendeeStatus(
  eventId: string,
  userId: string,
  status: RSVPStatus
): Promise<void> {
  const res = await fetch(`/api/events/${eventId}/memberships/${userId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status }),
  });
  if (!res.ok) throw new Error("Failed to update attendee status");
}

async function removeAttendee(
  eventId: string,
  userId: string
): Promise<void> {
  const res = await fetch(`/api/events/${eventId}/memberships/${userId}`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error("Failed to remove attendee");
}

async function checkInAttendee(
  eventId: string,
  userId: string
): Promise<void> {
  const res = await fetch(`/api/events/${eventId}/check-in/${userId}`, {
    method: "POST",
  });
  if (!res.ok) throw new Error("Failed to check in attendee");
}

// ─── Hooks ────────────────────────────────────────────────────────────────────

export function useAttendees(eventId: string, filter: AttendeeFilter = {}) {
  return useQuery({
    queryKey: ["attendees", eventId, filter],
    queryFn: () => fetchAttendees(eventId, filter),
    enabled: !!eventId,
    placeholderData: (prev) => prev,
  });
}

export function useUpdateAttendeeStatus(eventId: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ userId, status }: { userId: string; status: RSVPStatus }) =>
      updateAttendeeStatus(eventId, userId, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["attendees", eventId] });
      queryClient.invalidateQueries({ queryKey: ["event-stats", eventId] });
      toast.success("Attendee status updated");
    },
    onError: () => toast.error("Failed to update status"),
  });
}

export function useRemoveAttendee(eventId: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (userId: string) => removeAttendee(eventId, userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["attendees", eventId] });
      toast.success("Attendee removed from event");
    },
    onError: () => toast.error("Failed to remove attendee"),
  });
}

export function useCheckIn(eventId: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (userId: string) => checkInAttendee(eventId, userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["attendees", eventId] });
      toast.success("✓ Checked in");
    },
    onError: () => toast.error("Check-in failed"),
  });
}

async function undoCheckIn(eventId: string, userId: string): Promise<void> {
  const res = await fetch(`/api/events/${eventId}/check-in/${userId}`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error("Failed to undo check-in");
}

async function qrCheckIn(
  eventId: string,
  qrPayload: string
): Promise<{ alreadyCheckedIn: boolean; attendeeName: string; guestCount: number; ticketCode: string | null }> {
  const res = await fetch(`/api/events/${eventId}/check-in/qr`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ qrPayload }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error?.message ?? "QR check-in failed");
  return data.data;
}

export function useUndoCheckIn(eventId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (userId: string) => undoCheckIn(eventId, userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["attendees", eventId] });
      queryClient.invalidateQueries({ queryKey: ["checkin-stats", eventId] });
      toast.success("Check-in undone");
    },
    onError: () => toast.error("Failed to undo check-in"),
  });
}

export function useQrCheckIn(eventId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (qrPayload: string) => qrCheckIn(eventId, qrPayload),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["attendees", eventId] });
      queryClient.invalidateQueries({ queryKey: ["checkin-stats", eventId] });
      if (!result.alreadyCheckedIn) {
        toast.success(`✓ ${result.attendeeName} checked in!`);
      }
    },
  });
}

export function useCheckInStats(eventId: string) {
  return useQuery({
    queryKey: ["checkin-stats", eventId],
    queryFn: async () => {
      const res = await fetch(`/api/events/${eventId}/check-in/stats`);
      if (!res.ok) throw new Error("Failed to load stats");
      return (await res.json()).data as {
        confirmed: number;
        checkedIn: number;
        remaining: number;
        percentCheckedIn: number;
      };
    },
    refetchInterval: 30_000, // refresh every 30s on event day
    enabled: !!eventId,
  });
}
