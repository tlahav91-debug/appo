// env.ts — validated at startup, import this instead of process.env directly
import { z } from "zod";

const envSchema = z.object({
  // ─── App ──────────────────────────────────────────────────────────
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  NEXT_PUBLIC_APP_URL: z.string().url(),
  NEXT_PUBLIC_APP_NAME: z.string().default("Reunitely"),

  // ─── Database ─────────────────────────────────────────────────────
  DATABASE_URL: z.string().url(),
  DATABASE_URL_UNPOOLED: z.string().url().optional(), // for migrations (Neon/Supabase)

  // ─── Auth — Clerk ─────────────────────────────────────────────────
  NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: z.string().min(1),
  CLERK_SECRET_KEY: z.string().min(1),
  CLERK_WEBHOOK_SECRET: z.string().min(1),
  NEXT_PUBLIC_CLERK_SIGN_IN_URL: z.string().default("/login"),
  NEXT_PUBLIC_CLERK_SIGN_UP_URL: z.string().default("/signup"),
  NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL: z.string().default("/dashboard"),
  NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL: z.string().default("/dashboard"),

  // ─── Redis — Upstash ──────────────────────────────────────────────
  UPSTASH_REDIS_REST_URL: z.string().url(),
  UPSTASH_REDIS_REST_TOKEN: z.string().min(1),

  // ─── Storage — S3 / Cloudflare R2 ────────────────────────────────
  S3_BUCKET_NAME: z.string().min(1),
  S3_REGION: z.string().default("auto"),
  S3_ENDPOINT: z.string().url().optional(), // for R2: https://<account>.r2.cloudflarestorage.com
  S3_ACCESS_KEY_ID: z.string().min(1),
  S3_SECRET_ACCESS_KEY: z.string().min(1),
  NEXT_PUBLIC_CDN_URL: z.string().url().optional(), // optional CDN prefix for public assets

  // ─── Email — Resend ───────────────────────────────────────────────
  RESEND_API_KEY: z.string().min(1),
  EMAIL_FROM_ADDRESS: z.string().email().default("noreply@reunitely.app"),
  EMAIL_FROM_NAME: z.string().default("Reunitely"),
  EMAIL_REPLY_TO: z.string().email().optional(),

  // ─── SMS / WhatsApp — Twilio ──────────────────────────────────────
  TWILIO_ACCOUNT_SID: z.string().min(1),
  TWILIO_AUTH_TOKEN: z.string().min(1),
  TWILIO_FROM_NUMBER: z.string().min(1), // E.164 format: +15551234567
  TWILIO_WHATSAPP_FROM: z.string().optional(), // whatsapp:+15551234567

  // ─── Payments — Stripe ────────────────────────────────────────────
  NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY: z.string().min(1),
  STRIPE_SECRET_KEY: z.string().min(1),
  STRIPE_WEBHOOK_SECRET: z.string().min(1),
  STRIPE_CONNECT_CLIENT_ID: z.string().optional(), // for Connect onboarding

  // ─── Real-time — Pusher ───────────────────────────────────────────
  NEXT_PUBLIC_PUSHER_APP_KEY: z.string().min(1),
  NEXT_PUBLIC_PUSHER_APP_CLUSTER: z.string().default("us2"),
  PUSHER_APP_ID: z.string().min(1),
  PUSHER_APP_SECRET: z.string().min(1),

  // ─── Analytics — PostHog ──────────────────────────────────────────
  NEXT_PUBLIC_POSTHOG_KEY: z.string().min(1),
  NEXT_PUBLIC_POSTHOG_HOST: z.string().url().default("https://app.posthog.com"),

  // ─── Error tracking — Sentry ─────────────────────────────────────
  NEXT_PUBLIC_SENTRY_DSN: z.string().url().optional(),
  SENTRY_ORG: z.string().optional(),
  SENTRY_PROJECT: z.string().optional(),
  SENTRY_AUTH_TOKEN: z.string().optional(),

  // ─── Content moderation ──────────────────────────────────────────
  AWS_REKOGNITION_ACCESS_KEY_ID: z.string().optional(),
  AWS_REKOGNITION_SECRET_ACCESS_KEY: z.string().optional(),
  AWS_REKOGNITION_REGION: z.string().default("us-east-1"),

  // ─── Internal ────────────────────────────────────────────────────
  CRON_SECRET: z.string().min(32), // used to secure cron endpoints
  INTERNAL_API_SECRET: z.string().min(32), // for service-to-service calls
});

// Separate schema for NEXT_PUBLIC_ vars that must be available client-side
const clientEnvSchema = z.object({
  NEXT_PUBLIC_APP_URL: z.string().url(),
  NEXT_PUBLIC_APP_NAME: z.string(),
  NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: z.string(),
  NEXT_PUBLIC_CLERK_SIGN_IN_URL: z.string(),
  NEXT_PUBLIC_CLERK_SIGN_UP_URL: z.string(),
  NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL: z.string(),
  NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL: z.string(),
  NEXT_PUBLIC_PUSHER_APP_KEY: z.string(),
  NEXT_PUBLIC_PUSHER_APP_CLUSTER: z.string(),
  NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY: z.string(),
  NEXT_PUBLIC_POSTHOG_KEY: z.string(),
  NEXT_PUBLIC_POSTHOG_HOST: z.string(),
  NEXT_PUBLIC_CDN_URL: z.string().optional(),
  NEXT_PUBLIC_SENTRY_DSN: z.string().optional(),
});

// Validate server env (only runs server-side)
function validateEnv() {
  const parsed = envSchema.safeParse(process.env);
  if (!parsed.success) {
    console.error(
      "❌ Invalid environment variables:\n",
      parsed.error.flatten().fieldErrors
    );
    throw new Error("Invalid environment variables");
  }
  return parsed.data;
}

// Lazy singleton — only validated once on server startup
let _env: z.infer<typeof envSchema> | undefined;

export function getEnv() {
  if (typeof window !== "undefined") {
    throw new Error("getEnv() must only be called server-side");
  }
  if (!_env) {
    _env = validateEnv();
  }
  return _env;
}

// Client-safe env (NEXT_PUBLIC_ only)
export const clientEnv = clientEnvSchema.parse({
  NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
  NEXT_PUBLIC_APP_NAME: process.env.NEXT_PUBLIC_APP_NAME,
  NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY,
  NEXT_PUBLIC_CLERK_SIGN_IN_URL: process.env.NEXT_PUBLIC_CLERK_SIGN_IN_URL,
  NEXT_PUBLIC_CLERK_SIGN_UP_URL: process.env.NEXT_PUBLIC_CLERK_SIGN_UP_URL,
  NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL: process.env.NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL,
  NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL: process.env.NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL,
  NEXT_PUBLIC_PUSHER_APP_KEY: process.env.NEXT_PUBLIC_PUSHER_APP_KEY,
  NEXT_PUBLIC_PUSHER_APP_CLUSTER: process.env.NEXT_PUBLIC_PUSHER_APP_CLUSTER,
  NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY: process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY,
  NEXT_PUBLIC_POSTHOG_KEY: process.env.NEXT_PUBLIC_POSTHOG_KEY,
  NEXT_PUBLIC_POSTHOG_HOST: process.env.NEXT_PUBLIC_POSTHOG_HOST,
  NEXT_PUBLIC_CDN_URL: process.env.NEXT_PUBLIC_CDN_URL,
  NEXT_PUBLIC_SENTRY_DSN: process.env.NEXT_PUBLIC_SENTRY_DSN,
});

export type Env = z.infer<typeof envSchema>;
export type ClientEnv = z.infer<typeof clientEnvSchema>;
