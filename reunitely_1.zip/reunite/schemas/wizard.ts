/**
 * schemas/wizard.ts
 *
 * Zod schemas for the 8-step event creation wizard.
 * Each step has its own schema for per-step validation via form.trigger().
 * The combined WizardFormData type is the single form state.
 */

import { z } from "zod";

const currentYear = new Date().getFullYear();

// ─── Step 1: Basic event info ─────────────────────────────────────────────────

export const step1Schema = z.object({
  title: z
    .string()
    .min(5, "Event name must be at least 5 characters")
    .max(120, "Event name must be under 120 characters"),
  shortDescription: z
    .string()
    .max(300, "Keep it under 300 characters")
    .optional()
    .or(z.literal("")),
  eventType: z.enum(["REUNION", "MINI_REUNION", "VIRTUAL", "FUNDRAISER"], {
    required_error: "Select an event type",
  }),
  visibility: z.enum(["PUBLIC", "UNLISTED", "PRIVATE"]).default("UNLISTED"),
  password: z
    .string()
    .min(4, "Password must be at least 4 characters")
    .max(50)
    .optional()
    .or(z.literal("")),
});

// ─── Step 2: School and cohort details ───────────────────────────────────────

export const step2Schema = z.object({
  schoolName: z
    .string()
    .min(2, "School name is required")
    .max(100, "School name must be under 100 characters"),
  schoolCity: z.string().max(100).optional().or(z.literal("")),
  schoolCountry: z.string().max(100).default("United States"),
  graduationYear: z
    .number({
      required_error: "Graduation year is required",
      invalid_type_error: "Enter a valid year",
    })
    .int()
    .min(1950, "Year must be 1950 or later")
    .max(currentYear + 1, "Year is too far in the future"),
  classSections: z
    .array(z.string().min(1).max(50))
    .max(10, "Maximum 10 sections")
    .default([]),
  reunionNumber: z
    .number()
    .int()
    .min(1)
    .max(100)
    .optional()
    .describe("Which reunion is this? e.g. 10 for 10-year"),
});

// ─── Step 3: Date, time, location ────────────────────────────────────────────

export const step3Schema = z
  .object({
    startDate: z
      .string()
      .min(1, "Start date is required"),
    startTime: z
      .string()
      .min(1, "Start time is required")
      .regex(/^\d{2}:\d{2}$/, "Use HH:MM format"),
    endDate: z.string().optional().or(z.literal("")),
    endTime: z
      .string()
      .optional()
      .or(z.literal(""))
      .refine(
        (v) => !v || /^\d{2}:\d{2}$/.test(v),
        "Use HH:MM format"
      ),
    timezone: z.string().min(1, "Timezone is required"),
    doorsOpenTime: z
      .string()
      .optional()
      .or(z.literal(""))
      .refine(
        (v) => !v || /^\d{2}:\d{2}$/.test(v),
        "Use HH:MM format"
      ),
    venueType: z.enum(["PHYSICAL", "VIRTUAL", "HYBRID"]).default("PHYSICAL"),
    venueName: z.string().max(100).optional().or(z.literal("")),
    venueAddress: z.string().max(300).optional().or(z.literal("")),
    venueCity: z.string().max(100).optional().or(z.literal("")),
    venueState: z.string().max(50).optional().or(z.literal("")),
    venueCountry: z.string().max(100).optional().or(z.literal("")),
    virtualLink: z
      .string()
      .url("Must be a valid URL")
      .optional()
      .or(z.literal("")),
    virtualPlatform: z
      .enum(["ZOOM", "GOOGLE_MEET", "TEAMS", "OTHER"])
      .optional(),
  })
  .superRefine((data, ctx) => {
    if (data.startDate) {
      const start = new Date(`${data.startDate}T${data.startTime || "00:00"}`);
      if (isNaN(start.getTime())) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Invalid start date/time",
          path: ["startDate"],
        });
      } else if (start < new Date()) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Start date must be in the future",
          path: ["startDate"],
        });
      }
    }
    if (data.endDate && data.startDate) {
      const start = new Date(`${data.startDate}T${data.startTime || "00:00"}`);
      const end = new Date(`${data.endDate}T${data.endTime || "23:59"}`);
      if (!isNaN(end.getTime()) && end <= start) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "End time must be after start time",
          path: ["endDate"],
        });
      }
    }
    if (data.venueType === "PHYSICAL" && !data.venueName) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Venue name is required for in-person events",
        path: ["venueName"],
      });
    }
    if (data.venueType !== "PHYSICAL" && !data.virtualLink) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Virtual meeting link is required",
        path: ["virtualLink"],
      });
    }
  });

// ─── Step 4: Branding and theme ──────────────────────────────────────────────

export const step4Schema = z.object({
  coverImageUrl: z
    .string()
    .url("Must be a valid URL")
    .optional()
    .or(z.literal("")),
  primaryColor: z
    .string()
    .regex(/^#[0-9A-Fa-f]{6}$/, "Must be a hex color like #1E3A5F")
    .default("#1E3A5F"),
  accentColor: z
    .string()
    .regex(/^#[0-9A-Fa-f]{6}$/, "Must be a hex color like #D4AF37")
    .default("#D4AF37"),
  description: z.unknown().optional(), // Tiptap JSON
  descriptionText: z
    .string()
    .max(5000, "Description is too long")
    .optional()
    .or(z.literal("")),
  headerLayout: z
    .enum(["CENTERED", "LEFT", "FULL_BLEED"])
    .default("CENTERED"),
});

// ─── Step 5: RSVP settings ───────────────────────────────────────────────────

export const step5Schema = z.object({
  capacity: z
    .number()
    .int()
    .positive("Must be a positive number")
    .max(10000, "Maximum 10,000 attendees")
    .optional(),
  capacityUnlimited: z.boolean().default(true),
  waitlistEnabled: z.boolean().default(true),
  waitlistCapacity: z
    .number()
    .int()
    .positive()
    .max(1000)
    .optional(),
  rsvpDeadline: z.string().optional().or(z.literal("")),
  allowGuestPlus1: z.boolean().default(true),
  maxGuestsPerRsvp: z
    .number()
    .int()
    .min(0)
    .max(10)
    .default(1),
  requireApproval: z.boolean().default(false),
  ticketingEnabled: z.boolean().default(false),
  ticketPrice: z
    .number()
    .min(0, "Price must be 0 or more")
    .max(100000, "Maximum $100,000")
    .optional(),
  ticketCurrency: z.string().length(3).default("USD"),
  ticketName: z.string().max(80).default("General Admission"),
  ticketCapacity: z.number().int().positive().optional(),
  earlyBirdEnabled: z.boolean().default(false),
  earlyBirdPrice: z.number().min(0).optional(),
  earlyBirdDeadline: z.string().optional().or(z.literal("")),
  customQuestions: z
    .array(
      z.object({
        id: z.string(),
        label: z.string().min(1).max(200),
        type: z.enum(["TEXT", "SELECT", "BOOLEAN"]),
        options: z.array(z.string().max(50)).max(10).optional(),
        required: z.boolean().default(false),
      })
    )
    .max(10, "Maximum 10 custom questions")
    .default([]),
});

// ─── Step 6: Invite settings ─────────────────────────────────────────────────

export const step6Schema = z.object({
  inviteMode: z
    .enum(["OPEN", "INVITE_ONLY", "APPROVAL"])
    .default("OPEN")
    .describe("Who can RSVP: anyone with link, invited only, or requires approval"),
  allowAttendeesInvite: z
    .boolean()
    .default(true)
    .describe("Can confirmed attendees invite others?"),
  referralLinksEnabled: z
    .boolean()
    .default(true)
    .describe("Generate personal referral links for attendees"),
  showAttendeeCount: z.boolean().default(true),
  showAttendeeList: z.boolean().default(false),
  verifySchoolEmail: z
    .boolean()
    .default(false)
    .describe("Require a matching school email domain to RSVP"),
  schoolEmailDomain: z
    .string()
    .max(100)
    .optional()
    .or(z.literal("")),
});

// ─── Step 7: Messaging preferences ───────────────────────────────────────────

export const step7Schema = z.object({
  chatEnabled: z.boolean().default(true),
  memoriesEnabled: z.boolean().default(true),
  memoriesAutoApprove: z.boolean().default(false),
  nominationsEnabled: z.boolean().default(true),
  directoryEnabled: z.boolean().default(true),
  scheduleEnabled: z.boolean().default(false),
  sendRsvpConfirmation: z.boolean().default(true),
  sendEventReminder: z.boolean().default(true),
  reminderDaysBefore: z
    .number()
    .int()
    .min(1)
    .max(30)
    .default(3),
  smsRemindersEnabled: z.boolean().default(false),
  whatsappRemindersEnabled: z.boolean().default(false),
  notificationEmail: z
    .string()
    .email("Must be a valid email")
    .optional()
    .or(z.literal(""))
    .describe("Where to receive organizer notifications"),
});

// ─── Step 8: Review — no new fields, reads from all previous steps ────────────

export const step8Schema = z.object({
  // Acknowledgment checkbox
  agreedToTerms: z
    .literal(true, {
      errorMap: () => ({ message: "You must agree to continue" }),
    })
    .optional(),
});

// ─── Combined wizard schema ────────────────────────────────────────────────────

export const wizardSchema = step1Schema
  .merge(step2Schema)
  .merge(step3Schema)
  .merge(step4Schema)
  .merge(step5Schema)
  .merge(step6Schema)
  .merge(step7Schema)
  .merge(step8Schema);

export type WizardFormData = z.infer<typeof wizardSchema>;

// ─── Step field map — used by wizard to trigger validation per step ───────────

export const STEP_FIELDS: Record<number, (keyof WizardFormData)[]> = {
  1: ["title", "shortDescription", "eventType", "visibility"],
  2: ["schoolName", "graduationYear"],
  3: ["startDate", "startTime", "timezone", "venueName", "venueType"],
  4: ["primaryColor", "accentColor"],
  5: [],
  6: [],
  7: [],
  8: [],
};

export const STEP_SCHEMAS: Record<number, z.ZodTypeAny> = {
  1: step1Schema,
  2: step2Schema,
  3: step3Schema,
  4: step4Schema,
  5: step5Schema,
  6: step6Schema,
  7: step7Schema,
  8: step8Schema,
};

// ─── Default values ───────────────────────────────────────────────────────────

export const WIZARD_DEFAULTS: Partial<WizardFormData> = {
  eventType: "REUNION",
  visibility: "UNLISTED",
  schoolCountry: "United States",
  classSections: [],
  graduationYear: currentYear - 10,
  timezone: "America/New_York",
  venueType: "PHYSICAL",
  primaryColor: "#1E3A5F",
  accentColor: "#D4AF37",
  headerLayout: "CENTERED",
  capacityUnlimited: true,
  waitlistEnabled: true,
  allowGuestPlus1: true,
  maxGuestsPerRsvp: 1,
  requireApproval: false,
  ticketingEnabled: false,
  ticketCurrency: "USD",
  ticketName: "General Admission",
  earlyBirdEnabled: false,
  customQuestions: [],
  inviteMode: "OPEN",
  allowAttendeesInvite: true,
  referralLinksEnabled: true,
  showAttendeeCount: true,
  showAttendeeList: false,
  verifySchoolEmail: false,
  chatEnabled: true,
  memoriesEnabled: true,
  memoriesAutoApprove: false,
  nominationsEnabled: true,
  directoryEnabled: true,
  scheduleEnabled: false,
  sendRsvpConfirmation: true,
  sendEventReminder: true,
  reminderDaysBefore: 3,
  smsRemindersEnabled: false,
  whatsappRemindersEnabled: false,
};

// ─── Step metadata ─────────────────────────────────────────────────────────────

export const WIZARD_STEPS = [
  { id: 1, label: "Event", description: "Basic info" },
  { id: 2, label: "School", description: "Cohort details" },
  { id: 3, label: "Date & Venue", description: "When & where" },
  { id: 4, label: "Branding", description: "Look & feel" },
  { id: 5, label: "RSVPs", description: "Capacity & tickets" },
  { id: 6, label: "Invites", description: "Access & sharing" },
  { id: 7, label: "Comms", description: "Messaging" },
  { id: 8, label: "Review", description: "Publish" },
] as const;

export type WizardStepId = (typeof WIZARD_STEPS)[number]["id"];
