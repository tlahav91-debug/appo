import { z } from "zod";

// ─── Event ────────────────────────────────────────────────────────────────────

export const createEventSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters").max(120),
  schoolName: z.string().min(2, "School name is required").max(100),
  schoolCity: z.string().max(100).optional(),
  schoolCountry: z.string().max(100).optional(),
  graduationYear: z
    .number()
    .int()
    .min(1950, "Year must be 1950 or later")
    .max(new Date().getFullYear() + 1, "Year cannot be in the future"),
  classSections: z.array(z.string().max(50)).max(10).optional(),
  startAt: z.string().datetime({ message: "Valid date/time required" }),
  endAt: z.string().datetime().optional(),
  timezone: z.string().max(50),
  venueName: z.string().max(100).optional(),
  venueAddress: z.string().max(200).optional(),
  description: z.unknown().optional(),
  coverImageUrl: z.string().url().optional().or(z.literal("")),
  capacity: z.number().int().positive().optional(),
  waitlistEnabled: z.boolean().default(true),
  ticketingEnabled: z.boolean().default(false),
  organizationId: z.string().cuid().optional(),
});

export const updateEventSchema = createEventSchema.partial().extend({
  settings: z.record(z.unknown()).optional(),
  passwordHash: z.string().optional(),
});

export type CreateEventInput = z.infer<typeof createEventSchema>;
export type UpdateEventInput = z.infer<typeof updateEventSchema>;

// ─── RSVP ─────────────────────────────────────────────────────────────────────

export const rsvpSchema = z.object({
  status: z.enum(["CONFIRMED", "DECLINED", "PENDING"]),
  guestCount: z.number().int().min(0).max(4).default(0),
  dietaryRequirements: z
    .array(z.string().max(50))
    .max(10)
    .default([]),
  customAnswers: z.record(z.string().max(500)).default({}),
  consentEmail: z.boolean({
    required_error: "You must agree to be contacted about this event",
  }),
  consentSms: z.boolean().default(false),
  consentWhatsApp: z.boolean().default(false),
});

export type RsvpInput = z.infer<typeof rsvpSchema>;

// ─── Invite ───────────────────────────────────────────────────────────────────

const emailEntry = z.object({
  email: z.string().email("Invalid email address"),
  name: z.string().max(100).optional(),
});

export const sendInvitesSchema = z.object({
  channel: z.enum(["EMAIL", "SMS", "WHATSAPP", "LINK"]),
  recipients: z
    .array(emailEntry)
    .min(1, "At least one recipient required")
    .max(200, "Maximum 200 recipients per batch"),
  message: z.string().max(500).optional(),
  consentConfirmed: z.literal(true, {
    errorMap: () => ({
      message: "You must confirm recipients have consented to be contacted",
    }),
  }),
});

export type SendInvitesInput = z.infer<typeof sendInvitesSchema>;

// ─── Ticket ───────────────────────────────────────────────────────────────────

export const ticketSchema = z.object({
  name: z.string().min(1).max(80),
  description: z.string().max(300).optional(),
  price: z
    .number()
    .int()
    .nonnegative("Price must be 0 or more")
    .max(100_000_00, "Price cannot exceed $100,000"),
  currency: z.string().length(3).default("USD"),
  capacity: z.number().int().positive().optional(),
  earlyBirdDeadline: z.string().datetime().optional(),
  isVisible: z.boolean().default(true),
});

export type TicketInput = z.infer<typeof ticketSchema>;

// ─── Memory ───────────────────────────────────────────────────────────────────

export const createMemorySchema = z
  .object({
    type: z.enum(["PHOTO", "TEXT", "VIDEO"]),
    content: z.string().max(2000).optional(),
    mediaUrls: z.array(z.string().url()).max(10).default([]),
    videoEmbedUrl: z.string().url().optional(),
    yearContext: z
      .number()
      .int()
      .min(1950)
      .max(new Date().getFullYear())
      .optional(),
    textContext: z.string().max(100).optional(),
    taggedUserIds: z.array(z.string().cuid()).max(20).default([]),
  })
  .superRefine((data, ctx) => {
    if (data.type === "PHOTO" && data.mediaUrls.length === 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "At least one photo is required for PHOTO memories",
        path: ["mediaUrls"],
      });
    }
    if (data.type === "TEXT" && !data.content?.trim()) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Content is required for TEXT memories",
        path: ["content"],
      });
    }
    if (data.type === "VIDEO" && !data.videoEmbedUrl) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Video URL is required for VIDEO memories",
        path: ["videoEmbedUrl"],
      });
    }
  });

export type CreateMemoryInput = z.infer<typeof createMemorySchema>;

// ─── Comment ──────────────────────────────────────────────────────────────────

export const createCommentSchema = z.object({
  content: z.string().min(1).max(1000),
  parentId: z.string().cuid().optional(),
});

export type CreateCommentInput = z.infer<typeof createCommentSchema>;

// ─── Nomination ───────────────────────────────────────────────────────────────

export const nominationCategorySchema = z.object({
  title: z.string().min(2).max(100),
  description: z.string().max(300).optional(),
  votingOpenAt: z.string().datetime().optional(),
  votingClosedAt: z.string().datetime().optional(),
});

export const createNominationSchema = z.object({
  categoryId: z.string().cuid(),
  nomineeId: z.string().cuid(),
  note: z.string().max(200).optional(),
});

export type NominationCategoryInput = z.infer<typeof nominationCategorySchema>;
export type CreateNominationInput = z.infer<typeof createNominationSchema>;

// ─── Chat ─────────────────────────────────────────────────────────────────────

export const sendMessageSchema = z.object({
  content: z.string().min(1).max(4000).trim(),
  replyToId: z.string().cuid().optional(),
  mediaUrl: z.string().url().optional(),
});

export const createRoomSchema = z.object({
  name: z
    .string()
    .min(1)
    .max(50)
    .regex(/^[a-z0-9-\s]+$/i, "Room name can only contain letters, numbers, hyphens and spaces"),
  description: z.string().max(200).optional(),
  type: z.enum(["GROUP", "DIRECT"]).default("GROUP"),
});

export type SendMessageInput = z.infer<typeof sendMessageSchema>;
export type CreateRoomInput = z.infer<typeof createRoomSchema>;

// ─── Broadcast ────────────────────────────────────────────────────────────────

export const createBroadcastSchema = z.object({
  subject: z.string().min(1).max(200).optional(),
  body: z.unknown(), // Tiptap JSON or plain text
  channel: z.enum(["EMAIL", "SMS", "WHATSAPP", "IN_APP"]),
  templateId: z.string().optional(),
  audienceFilter: z
    .object({
      statuses: z
        .array(
          z.enum(["CONFIRMED", "PENDING", "DECLINED", "WAITLISTED", "CANCELLED"])
        )
        .default(["CONFIRMED"]),
      cities: z.array(z.string()).optional(),
    })
    .default({ statuses: ["CONFIRMED"] }),
  scheduledAt: z.string().datetime().optional(),        // ISO string
  quietHoursStart: z.number().int().min(0).max(23).optional(), // e.g. 22
  quietHoursEnd: z.number().int().min(0).max(23).optional(),   // e.g. 8
});

export type CreateBroadcastInput = z.infer<typeof createBroadcastSchema>;

// ─── Profile ──────────────────────────────────────────────────────────────────

export const updateProfileSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  username: z
    .string()
    .min(3)
    .max(30)
    .regex(/^[a-z0-9_-]+$/, "Username can only contain lowercase letters, numbers, hyphens and underscores")
    .optional(),
  bio: z.string().max(280).optional(),
  currentCity: z.string().max(100).optional(),
  currentJob: z.string().max(100).optional(),
  funFact: z.string().max(200).optional(),
  linkedinUrl: z
    .string()
    .url()
    .refine((u) => u.includes("linkedin.com"), "Must be a LinkedIn URL")
    .optional()
    .or(z.literal("")),
  instagramHandle: z
    .string()
    .max(30)
    .regex(/^[a-zA-Z0-9._]*$/, "Invalid Instagram handle")
    .optional(),
});

export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;

// ─── Upload presign ───────────────────────────────────────────────────────────

export const presignUploadSchema = z.object({
  folder: z.enum([
    "events/covers",
    "events/memories",
    "users/avatars",
    "users/exports",
  ]),
  contentType: z.enum(["image/jpeg", "image/png", "image/webp", "image/gif"]),
  fileSize: z.number().int().positive(),
  fileExtension: z
    .string()
    .regex(/^[a-z0-9]{1,10}$/)
    .toLowerCase(),
});

export type PresignUploadInput = z.infer<typeof presignUploadSchema>;
