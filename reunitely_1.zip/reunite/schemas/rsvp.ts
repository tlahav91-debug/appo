/**
 * schemas/rsvp.ts
 *
 * Production RSVP schema — supports:
 * - attending / maybe / cannot attend
 * - plus-one with names
 * - dietary, accessibility, transportation
 * - attendee profile creation/update
 * - privacy preferences
 * - consent management
 * - custom event questions
 * - payment hook metadata
 */

import { z } from "zod";

// ─── Attendance status ────────────────────────────────────────────────────────

export const RSVP_STATUS = {
  CONFIRMED: "CONFIRMED",  // attending
  PENDING:   "PENDING",    // maybe / interested
  DECLINED:  "DECLINED",   // cannot attend
} as const;

export type RsvpStatusValue = typeof RSVP_STATUS[keyof typeof RSVP_STATUS];

// ─── Plus-one guest ───────────────────────────────────────────────────────────

export const guestSchema = z.object({
  name: z
    .string()
    .min(1, "Guest name is required")
    .max(80, "Name too long")
    .trim(),
  dietaryRequirements: z
    .array(z.string().max(50))
    .max(5)
    .default([]),
  accessibilityNeeds: z.string().max(300).optional().or(z.literal("")),
});

export type GuestInput = z.infer<typeof guestSchema>;

// ─── Core RSVP fields ─────────────────────────────────────────────────────────

export const rsvpCoreSchema = z.object({
  // ── Attendance ─────────────────────────────────────────────────────────────
  status: z.enum(["CONFIRMED", "PENDING", "DECLINED"], {
    required_error: "Please select your attendance status",
  }),

  // ── Plus ones ──────────────────────────────────────────────────────────────
  bringGuest: z.boolean().default(false),
  guestCount: z.number().int().min(0).max(4).default(0),
  guests: z.array(guestSchema).max(4).default([]),

  // ── Food & dietary ─────────────────────────────────────────────────────────
  dietaryRequirements: z
    .array(z.string().max(50))
    .max(10)
    .default([]),
  dietaryNotes: z
    .string()
    .max(300, "Keep it under 300 characters")
    .optional()
    .or(z.literal("")),

  // ── Accessibility ──────────────────────────────────────────────────────────
  hasAccessibilityNeeds: z.boolean().default(false),
  accessibilityNeeds: z
    .string()
    .max(500, "Keep it under 500 characters")
    .optional()
    .or(z.literal("")),

  // ── Transportation ─────────────────────────────────────────────────────────
  transportationMode: z
    .enum(["DRIVING", "FLYING", "TRAIN", "LOCAL", "NEED_RIDE", "OFFERING_RIDE", ""])
    .optional(),
  transportationNotes: z
    .string()
    .max(300)
    .optional()
    .or(z.literal("")),
  offeringSeats: z
    .number()
    .int()
    .min(0)
    .max(8)
    .optional(),
  arrivalCity: z
    .string()
    .max(100)
    .optional()
    .or(z.literal("")),

  // ── Personal note ──────────────────────────────────────────────────────────
  attendeeNote: z
    .string()
    .max(500, "Message too long — keep it under 500 characters")
    .optional()
    .or(z.literal("")),

  // ── Custom event questions ─────────────────────────────────────────────────
  customAnswers: z
    .record(z.string().max(1000))
    .default({}),

  // ── Consent ────────────────────────────────────────────────────────────────
  consentEmail: z.boolean({
    required_error: "Please confirm you agree to be contacted about this event",
  }),
  consentSms: z.boolean().default(false),
  consentWhatsApp: z.boolean().default(false),
  consentPhotoTagging: z.boolean().default(true),
});

// ─── Profile update (embedded in RSVP flow) ───────────────────────────────────

export const rsvpProfileSchema = z.object({
  updateProfile: z.boolean().default(false),
  currentCity: z.string().max(100).optional().or(z.literal("")),
  currentJob: z.string().max(100).optional().or(z.literal("")),
  currentEmployer: z.string().max(100).optional().or(z.literal("")),
  bio: z.string().max(280).optional().or(z.literal("")),
  funFact: z.string().max(200).optional().or(z.literal("")),
  linkedinUrl: z
    .string()
    .url("Must be a valid LinkedIn URL")
    .refine((v) => v.includes("linkedin.com"), "Must be a LinkedIn URL")
    .optional()
    .or(z.literal("")),
});

// ─── Privacy preferences ──────────────────────────────────────────────────────

export const rsvpPrivacySchema = z.object({
  showInDirectory: z.boolean().default(true),
  showCurrentJob: z.boolean().default(true),
  showCurrentCity: z.boolean().default(true),
  allowDirectMessages: z.boolean().default(true),
  allowNominations: z.boolean().default(true),
  profileVisibleTo: z
    .enum(["EVENT_ATTENDEES", "ORGANIZERS_ONLY", "NOBODY"])
    .default("EVENT_ATTENDEES"),
});

// ─── Full RSVP form schema ────────────────────────────────────────────────────

export const fullRsvpSchema = rsvpCoreSchema
  .merge(rsvpProfileSchema)
  .merge(rsvpPrivacySchema)
  .superRefine((data, ctx) => {
    // Consent required when confirming or maybe
    if (data.status !== "DECLINED" && !data.consentEmail) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["consentEmail"],
        message:
          "You must agree to receive event updates to complete your RSVP.",
      });
    }

    // If bringing guest, must have at least 1 guest entry
    if (data.bringGuest && data.guestCount > 0 && data.guests.length === 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["guests"],
        message: "Please enter your guest's name.",
      });
    }

    // If has accessibility needs, must describe them
    if (data.hasAccessibilityNeeds && !data.accessibilityNeeds?.trim()) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["accessibilityNeeds"],
        message: "Please describe your accessibility requirements.",
      });
    }

    // Offering a ride requires seat count
    if (
      data.transportationMode === "OFFERING_RIDE" &&
      (!data.offeringSeats || data.offeringSeats < 1)
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["offeringSeats"],
        message: "Please enter how many seats you're offering.",
      });
    }
  });

export type FullRsvpInput = z.infer<typeof fullRsvpSchema>;

// ─── Step field map ───────────────────────────────────────────────────────────
// Controls which fields trigger() for each step to validate on Continue

export const RSVP_STEP_FIELDS: Record<number, (keyof FullRsvpInput)[]> = {
  1: ["status"],
  2: ["bringGuest", "guestCount", "guests", "dietaryRequirements", "dietaryNotes",
      "hasAccessibilityNeeds", "accessibilityNeeds", "transportationMode",
      "transportationNotes", "offeringSeats", "attendeeNote", "customAnswers"],
  3: ["updateProfile", "currentCity", "currentJob", "currentEmployer", "bio",
      "showInDirectory", "showCurrentJob", "showCurrentCity",
      "allowDirectMessages", "allowNominations", "profileVisibleTo",
      "consentEmail", "consentSms", "consentWhatsApp", "consentPhotoTagging"],
};

// ─── Default values ───────────────────────────────────────────────────────────

export const RSVP_DEFAULTS: FullRsvpInput = {
  status: "CONFIRMED",
  bringGuest: false,
  guestCount: 0,
  guests: [],
  dietaryRequirements: [],
  dietaryNotes: "",
  hasAccessibilityNeeds: false,
  accessibilityNeeds: "",
  transportationMode: "",
  transportationNotes: "",
  offeringSeats: undefined,
  arrivalCity: "",
  attendeeNote: "",
  customAnswers: {},
  consentEmail: false,
  consentSms: false,
  consentWhatsApp: false,
  consentPhotoTagging: true,
  updateProfile: false,
  currentCity: "",
  currentJob: "",
  currentEmployer: "",
  bio: "",
  funFact: "",
  linkedinUrl: "",
  showInDirectory: true,
  showCurrentJob: true,
  showCurrentCity: true,
  allowDirectMessages: true,
  allowNominations: true,
  profileVisibleTo: "EVENT_ATTENDEES",
};

// ─── Dietary options ──────────────────────────────────────────────────────────

export const DIETARY_OPTIONS = [
  { value: "NONE", label: "No restrictions", emoji: "🍽️" },
  { value: "VEGETARIAN", label: "Vegetarian", emoji: "🥗" },
  { value: "VEGAN", label: "Vegan", emoji: "🌱" },
  { value: "HALAL", label: "Halal", emoji: "☪️" },
  { value: "KOSHER", label: "Kosher", emoji: "✡️" },
  { value: "GLUTEN_FREE", label: "Gluten-free", emoji: "🌾" },
  { value: "NUT_ALLERGY", label: "Nut allergy", emoji: "⚠️" },
  { value: "DAIRY_FREE", label: "Dairy-free", emoji: "🥛" },
  { value: "SHELLFISH_ALLERGY", label: "Shellfish allergy", emoji: "🦐" },
  { value: "OTHER", label: "Other (specify below)", emoji: "📝" },
] as const;

// ─── Transportation modes ─────────────────────────────────────────────────────

export const TRANSPORT_OPTIONS = [
  { value: "DRIVING", label: "Driving myself", emoji: "🚗" },
  { value: "FLYING", label: "Flying in", emoji: "✈️" },
  { value: "TRAIN", label: "Train / bus", emoji: "🚆" },
  { value: "LOCAL", label: "Local — no travel needed", emoji: "🏠" },
  { value: "NEED_RIDE", label: "I need a ride / carpool", emoji: "👋" },
  { value: "OFFERING_RIDE", label: "I can offer rides", emoji: "🤝" },
] as const;

// ─── API request payload (subset sent to server) ──────────────────────────────
// The server action receives the full form data; the API route receives this trimmed shape

export const rsvpApiSchema = z.object({
  status: z.enum(["CONFIRMED", "PENDING", "DECLINED"]),
  guestCount: z.number().int().min(0).max(4).default(0),
  guestNames: z.array(z.string().max(80)).max(4).default([]),
  dietaryRequirements: z.array(z.string().max(50)).max(10).default([]),
  mealChoice: z.string().max(50).optional(),
  accessibilityNeeds: z.string().max(500).optional().or(z.literal("")),
  transportationMode: z.string().max(20).optional().or(z.literal("")),
  transportationNotes: z.string().max(300).optional().or(z.literal("")),
  attendeeNote: z.string().max(500).optional().or(z.literal("")),
  customAnswers: z.record(z.string().max(1000)).default({}),
  consentEmail: z.boolean(),
  consentSms: z.boolean().default(false),
  consentWhatsApp: z.boolean().default(false),
  inviteToken: z.string().optional(),
  // Profile update
  profileUpdate: z.object({
    currentCity: z.string().max(100).optional(),
    currentJob: z.string().max(100).optional(),
    currentEmployer: z.string().max(100).optional(),
    bio: z.string().max(280).optional(),
    funFact: z.string().max(200).optional(),
    linkedinUrl: z.string().url().optional().or(z.literal("")),
  }).optional(),
  // Privacy
  privacy: z.object({
    showInDirectory: z.boolean().default(true),
    showCurrentJob: z.boolean().default(true),
    showCurrentCity: z.boolean().default(true),
    allowDirectMessages: z.boolean().default(true),
    allowNominations: z.boolean().default(true),
    profileVisibleTo: z
      .enum(["EVENT_ATTENDEES", "ORGANIZERS_ONLY", "NOBODY"])
      .default("EVENT_ATTENDEES"),
  }).optional(),
});

export type RsvpApiInput = z.infer<typeof rsvpApiSchema>;
