import type {
  User,
  Event,
  RSVP,
  CommitteeMember,
  ChatMessage,
  Notification,
  RSVPStatus,
  EventStatus,
  MemoryType,
  ContentStatus,
  BroadcastChannel,
  MembershipRole,
} from "@prisma/client";

// ─── API response envelope ────────────────────────────────────────────────────

export type ApiResponse<T> =
  | { data: T; error: null }
  | { data: null; error: { code: string; message: string; details?: unknown } };

// ─── Pagination ───────────────────────────────────────────────────────────────

export interface PaginatedResponse<T> {
  items: T[];
  nextCursor: string | null;
  total?: number;
}

export interface PaginationParams {
  cursor?: string;
  limit?: number;
}

// ─── User / Profile ───────────────────────────────────────────────────────────

export type PublicProfile = Pick<
  User,
  | "id"
  | "name"
  | "username"
  | "avatarUrl"
  | "bio"
  | "currentCity"
  | "currentJob"
  | "funFact"
  | "linkedinUrl"
  | "instagramHandle"
  | "createdAt"
>;

export type SafeUser = Omit<User, "deletedAt">;

// ─── Event ────────────────────────────────────────────────────────────────────

export type EventWithMeta = Event & {
  _count: { rsvps: number; memoryPosts: number };
  createdBy: Pick<User, "id" | "name" | "avatarUrl">;
};

export type EventSettings = {
  nominationsEnabled?: boolean;
  scheduleEnabled?: boolean;
  memoriesAutoApprove?: boolean;
  chatEnabled?: boolean;
  directoryEnabled?: boolean;
  inviteMode?: "OPEN" | "INVITE_ONLY" | "APPROVAL";
  allowGuestPlus1?: boolean;
  maxGuestsPerRsvp?: number;
  verifySchoolEmail?: boolean;
  schoolEmailDomain?: string;
  customQuestions?: CustomQuestion[];
};

export type CustomQuestion = {
  id: string;
  label: string;
  type: "TEXT" | "SELECT" | "BOOLEAN";
  options?: string[];
  required: boolean;
};

// ─── Attendee (RSVP-based) ────────────────────────────────────────────────────

/**
 * AttendeeRow — the shape returned by GET /api/events/[id]/memberships
 * and used in AttendeeTable + AttendeeDetailPanel.
 *
 * Built from RSVP model joined with user and attendeeProfile.
 */
export type AttendeeRow = {
  // Unique identifier for the row (used as React key)
  userId: string;
  rsvpId: string;

  // RSVP fields
  status: RSVPStatus;
  guestCount: number;
  guestNames: string[];
  dietaryRequirements: string[];
  mealChoice: string | null;
  customAnswers: Record<string, unknown>;
  attendeeNote: string | null;
  notes: string | null; // organizerNote stored on RSVP
  tableAssignment: string | null;

  // Consent
  consentEmail: boolean;
  consentSms: boolean;
  consentWhatsApp: boolean;

  // Timestamps
  submittedAt: Date;
  confirmedAt: Date | null;
  checkedInAt: Date | null;
  waitlistPosition: number | null;

  // User
  user: {
    name: string;
    email: string;
    avatarUrl: string | null;
    currentCity: string | null;
    currentJob: string | null;
    currentEmployer: string | null;
  };
};

export type AttendeeFilter = {
  status?: RSVPStatus[];
  search?: string;
  cursor?: string;
  limit?: number;
};

// ─── Memory ───────────────────────────────────────────────────────────────────

export type MemoryWithAuthor = {
  id: string;
  type: MemoryType;
  caption: string | null;
  mediaUrls: string[];
  videoEmbedUrl: string | null;
  yearContext: number | null;
  status: ContentStatus;
  createdAt: Date;
  author: Pick<User, "id" | "name" | "avatarUrl">;
  _count: { reactions: number; comments: number };
  tags: Array<{
    id: string;
    taggedUser: Pick<User, "id" | "name" | "avatarUrl">;
    status: ContentStatus;
  }>;
};

// ─── Chat ─────────────────────────────────────────────────────────────────────

export type ChatMessageWithAuthor = {
  id: string;
  roomId: string;
  userId: string; // normalized from authorId
  content: string;
  mediaUrl: string | null;
  replyToId: string | null;
  isDeleted: boolean;
  deletedAt: Date | null;
  deletedById: string | null;
  editedAt: Date | null;
  editedContent: string | null;
  isPinned: boolean;
  pinnedAt: Date | null;
  pinnedById: string | null;
  createdAt: Date;
  user: Pick<User, "id" | "name" | "avatarUrl">;
  reactions: Array<{ emoji: string; userId: string }>;
  replyTo?:
    | {
        id: string;
        content: string;
        isDeleted: boolean;
        user: Pick<User, "name">;
      }
    | null;
};

// ─── Notification ─────────────────────────────────────────────────────────────

export type NotificationPayload =
  | { type: "RSVP_CONFIRMED"; userName: string; eventTitle: string; eventId: string }
  | { type: "MEMORY_TAGGED"; uploaderName: string; memoryId: string; eventTitle: string }
  | { type: "NOMINATION_RECEIVED"; categoryTitle: string; eventTitle: string; nominationId: string }
  | { type: "WAITLIST_PROMOTED"; eventTitle: string; eventId: string }
  | { type: "PAYMENT_RECEIVED"; amount: number; currency: string; eventTitle: string }
  | { type: "TAG_APPROVAL_NEEDED"; memoryId: string; tagId: string; uploaderName: string };

export type TypedNotification = Omit<Notification, "payload"> & {
  payload: NotificationPayload;
};

// ─── Dashboard stats ──────────────────────────────────────────────────────────

export type EventDashboardStats = {
  totalRsvps: number;
  confirmedCount: number;
  declinedCount: number;
  pendingCount: number;
  waitlistCount: number;
  checkedInCount: number;
  totalRevenueCents: number;
  pageViews: number;
  rsvpTrend: Array<{ date: string; count: number }>;
};

// ─── Invite ───────────────────────────────────────────────────────────────────

export type InviteWithStats = {
  id: string;
  token: string;
  email: string | null;
  phone: string | null;
  channel: string;
  status: string;
  sentAt: Date;
  openedAt: Date | null;
  rsvpdAt: Date | null;
  invitedBy: Pick<User, "name" | "avatarUrl">;
};

// ─── Committee ────────────────────────────────────────────────────────────────

export type CommitteeMemberWithUser = CommitteeMember & {
  user: Pick<User, "id" | "name" | "email" | "avatarUrl">;
};

// ─── Re-exports from Prisma ───────────────────────────────────────────────────

export type {
  RSVPStatus,
  MembershipRole,
  EventStatus,
  MemoryType,
  ContentStatus,
  BroadcastChannel,
};
