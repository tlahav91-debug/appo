"use client";

import Link from "next/link";
import { Users, UserCheck, UserX, Clock, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import type { DashboardData } from "@/lib/services/dashboard.service";

// ─── Shared funnel bar ────────────────────────────────────────────────────────

function FunnelBar({
  label,
  count,
  total,
  color,
  subLabel,
}: {
  label: string;
  count: number;
  total: number;
  color: string;
  subLabel?: string;
}) {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-slate-600">{label}</span>
        <span className="text-xs font-bold text-slate-900">
          {count.toLocaleString()}
          <span className="ml-1 font-normal text-slate-400">({pct}%)</span>
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
        <div
          className={cn("h-full rounded-full transition-all duration-500", color)}
          style={{ width: `${pct}%` }}
          role="progressbar"
          aria-valuenow={pct}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label={`${label}: ${pct}%`}
        />
      </div>
      {subLabel && (
        <p className="text-[10px] text-slate-400">{subLabel}</p>
      )}
    </div>
  );
}

// ─── RSVP Funnel ─────────────────────────────────────────────────────────────

interface RsvpFunnelCardProps {
  rsvp: DashboardData["rsvp"];
  capacity: number | null;
}

export function RsvpFunnelCard({ rsvp, capacity }: RsvpFunnelCardProps) {
  const total = rsvp.total;

  return (
    <div className="flex flex-col gap-5 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-900">RSVP breakdown</h3>
        <Link
          href="attendees"
          className="flex items-center gap-1 text-xs text-blue-600 hover:underline"
        >
          View all <ArrowRight className="h-3 w-3" />
        </Link>
      </div>

      {total === 0 ? (
        <div className="flex flex-col items-center gap-2 py-6 text-center">
          <Users className="h-8 w-8 text-slate-200" />
          <p className="text-sm text-slate-400">No RSVPs yet</p>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          <FunnelBar
            label="Confirmed"
            count={rsvp.confirmed}
            total={total}
            color="bg-emerald-400"
            subLabel={rsvp.checkedIn > 0 ? `${rsvp.checkedIn} checked in` : undefined}
          />
          <FunnelBar
            label="Pending"
            count={rsvp.pending}
            total={total}
            color="bg-blue-400"
          />
          <FunnelBar
            label="Declined"
            count={rsvp.declined}
            total={total}
            color="bg-slate-300"
          />
          {rsvp.waitlisted > 0 && (
            <FunnelBar
              label="Waitlisted"
              count={rsvp.waitlisted}
              total={total}
              color="bg-blue-300"
            />
          )}
        </div>
      )}

      {/* Capacity progress */}
      {capacity && (
        <div className="border-t border-border pt-3">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-500">Capacity</span>
            <span className={cn(
              "font-semibold",
              (rsvp.capacityPct ?? 0) >= 90 ? "text-blue-600" : "text-slate-700"
            )}>
              {rsvp.confirmed}/{capacity}
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
            <div
              className={cn(
                "h-full rounded-full transition-all",
                (rsvp.capacityPct ?? 0) >= 90 ? "bg-blue-400" : "bg-emerald-400"
              )}
              style={{ width: `${Math.min(100, rsvp.capacityPct ?? 0)}%` }}
            />
          </div>
          <p className="mt-1 text-[10px] text-slate-400">
            {(rsvp.capacityPct ?? 0) >= 90
              ? "⚠️ Near capacity — consider closing or promoting waitlist"
              : `${capacity - rsvp.confirmed} spots remaining`}
          </p>
        </div>
      )}
    </div>
  );
}

// ─── Invite Funnel ────────────────────────────────────────────────────────────

interface InviteFunnelCardProps {
  invites: DashboardData["invites"];
}

export function InviteFunnelCard({ invites }: InviteFunnelCardProps) {
  const steps = [
    { label: "Sent",      count: invites.sent,      color: "bg-blue-300" },
    { label: "Delivered", count: invites.delivered,  color: "bg-blue-400" },
    { label: "Opened",    count: invites.opened,     color: "bg-violet-400" },
    { label: "RSVP'd",   count: invites.rsvpd,      color: "bg-emerald-400" },
  ];
  const total = invites.total;

  return (
    <div className="flex flex-col gap-5 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-900">Invite funnel</h3>
        <Link
          href="invites"
          className="flex items-center gap-1 text-xs text-blue-600 hover:underline"
        >
          Manage <ArrowRight className="h-3 w-3" />
        </Link>
      </div>

      {total === 0 ? (
        <div className="flex flex-col items-center gap-2 py-6 text-center">
          <Users className="h-8 w-8 text-slate-200" />
          <p className="text-sm text-slate-400">No invites sent yet</p>
          <Link href="invites" className="text-xs text-blue-600 hover:underline">
            Send your first invite →
          </Link>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {steps.map((step) => (
            <FunnelBar
              key={step.label}
              label={step.label}
              count={step.count}
              total={total}
              color={step.color}
            />
          ))}
        </div>
      )}

      {/* Conversion summary */}
      {total > 0 && (
        <div className="border-t border-border pt-3 flex items-center justify-between">
          <span className="text-xs text-slate-500">Overall conversion</span>
          <span className="text-sm font-bold text-emerald-600">
            {invites.conversionRate}%
          </span>
        </div>
      )}
    </div>
  );
}
