"use client";

import { Users, UserCheck, DollarSign, Send, Clock, AlertCircle } from "lucide-react";
import { formatCurrency, cn } from "@/lib/utils";
import type { DashboardData } from "@/lib/services/dashboard.service";

interface DashboardKpiRowProps {
  rsvp: DashboardData["rsvp"];
  payments: DashboardData["payments"];
  invites: DashboardData["invites"];
  event: DashboardData["event"];
}

interface KpiCardProps {
  label: string;
  value: string | number;
  sub: string;
  icon: React.ElementType;
  iconBg: string;
  iconColor: string;
  badge?: { label: string; variant: "success" | "warning" | "info" };
  trend?: { value: number; label: string };
  href?: string;
}

function KpiCard({ label, value, sub, icon: Icon, iconBg, iconColor, badge, trend }: KpiCardProps) {
  return (
    <div className="relative flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 shadow-sm transition-shadow hover:shadow-md">
      <div className="flex items-start justify-between">
        <div className={cn("flex h-10 w-10 items-center justify-center rounded-xl", iconBg)}>
          <Icon className={cn("h-5 w-5", iconColor)} />
        </div>
        {badge && (
          <span className={cn(
            "rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide",
            badge.variant === "success" && "bg-emerald-100 text-emerald-700",
            badge.variant === "warning" && "bg-blue-100 text-blue-700",
            badge.variant === "info" && "bg-blue-100 text-blue-700",
          )}>
            {badge.label}
          </span>
        )}
      </div>

      <div className="space-y-0.5">
        <p className="font-display text-3xl font-bold tracking-tight text-slate-900">
          {value}
        </p>
        <p className="text-xs font-medium uppercase tracking-wider text-slate-400">{label}</p>
      </div>

      <p className="text-xs text-slate-500">{sub}</p>

      {trend && (
        <div className={cn(
          "flex items-center gap-1 text-xs font-medium",
          trend.value >= 0 ? "text-emerald-600" : "text-red-500"
        )}>
          <span>{trend.value >= 0 ? "↑" : "↓"}</span>
          <span>{Math.abs(trend.value)}% {trend.label}</span>
        </div>
      )}
    </div>
  );
}

export function DashboardKpiRow({ rsvp, payments, invites, event }: DashboardKpiRowProps) {
  const daysUntil = Math.floor((event.startAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
  const isUpcoming = daysUntil > 0;

  const cards: KpiCardProps[] = [
    {
      label: "Confirmed",
      value: rsvp.confirmed.toLocaleString(),
      sub: rsvp.capacity
        ? `of ${event.capacity?.toLocaleString()} capacity · ${rsvp.capacityPct}% full`
        : `${rsvp.declined} declined · ${rsvp.waitlisted} waitlisted`,
      icon: UserCheck,
      iconBg: "bg-emerald-50",
      iconColor: "text-emerald-500",
      badge: rsvp.capacityPct !== null && rsvp.capacityPct >= 90
        ? { label: "Near capacity", variant: "warning" }
        : rsvp.confirmed > 0
        ? { label: "Live", variant: "success" }
        : undefined,
    },
    {
      label: "Total RSVPs",
      value: rsvp.total.toLocaleString(),
      sub: `${rsvp.conversionRate}% confirmation rate · ${rsvp.pending} undecided`,
      icon: Users,
      iconBg: "bg-blue-50",
      iconColor: "text-blue-500",
      badge: rsvp.pending > 0
        ? { label: `${rsvp.pending} pending`, variant: "info" }
        : undefined,
    },
    {
      label: "Invites",
      value: invites.total.toLocaleString(),
      sub: `${invites.conversionRate}% conversion · ${invites.opened} opened`,
      icon: Send,
      iconBg: "bg-violet-50",
      iconColor: "text-violet-500",
    },
    {
      label: payments.enabled ? "Revenue" : "Event Date",
      value: payments.enabled
        ? formatCurrency(payments.totalRevenueCents, payments.currency)
        : isUpcoming
        ? `${daysUntil}d`
        : "Happened",
      sub: payments.enabled
        ? `${payments.paidCount} paid · ${payments.pendingCount} pending`
        : isUpcoming
        ? `${event.schoolName} · ${new Date(event.startAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`
        : `${event.schoolName} · Class of ${event.graduationYear}`,
      icon: payments.enabled ? DollarSign : Clock,
      iconBg: payments.enabled ? "bg-blue-50" : "bg-slate-100",
      iconColor: payments.enabled ? "text-blue-500" : "text-slate-500",
      badge: !isUpcoming
        ? { label: "Past", variant: "info" }
        : daysUntil <= 3
        ? { label: "Soon!", variant: "warning" }
        : undefined,
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
      {cards.map((card) => (
        <KpiCard key={card.label} {...card} />
      ))}
    </div>
  );
}
