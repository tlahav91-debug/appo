"use client";

import { useState } from "react";
import { GraduationCap, Edit3, Check, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { DashboardData } from "@/lib/services/dashboard.service";

interface CohortCoverageCardProps {
  cohort: DashboardData["cohort"];
  eventId: string;
}

export function CohortCoverageCard({ cohort, eventId }: CohortCoverageCardProps) {
  const [editing, setEditing] = useState(false);
  const [inputValue, setInputValue] = useState(
    cohort.estimatedClassSize?.toString() ?? ""
  );
  const [savedSize, setSavedSize] = useState(cohort.estimatedClassSize);
  const [isSaving, setIsSaving] = useState(false);

  const classSize = savedSize;
  const coveragePct =
    classSize && classSize > 0
      ? Math.min(100, Math.round((cohort.confirmedCount / classSize) * 100))
      : null;

  const getCoverageLabel = (pct: number) => {
    if (pct >= 80) return { label: "Excellent!", color: "text-emerald-600" };
    if (pct >= 50) return { label: "Good progress", color: "text-blue-600" };
    if (pct >= 25) return { label: "Building momentum", color: "text-blue-600" };
    return { label: "Just getting started", color: "text-slate-500" };
  };

  async function handleSave() {
    const n = parseInt(inputValue);
    if (isNaN(n) || n < 1) return;
    setIsSaving(true);
    try {
      const res = await fetch(`/api/events/${eventId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          settings: { classSize: n },
        }),
      });
      if (!res.ok) throw new Error("Failed to save");
      setSavedSize(n);
      setEditing(false);
    } catch {
      toast.error("Failed to save class size");
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50">
            <GraduationCap className="h-4 w-4 text-blue-500" />
          </div>
          <h3 className="text-sm font-semibold text-slate-900">Class coverage</h3>
        </div>
        <span className="text-xs text-slate-400">Class of {cohort.graduationYear}</span>
      </div>

      {/* Coverage visualization */}
      {classSize ? (
        <>
          <div className="flex items-end gap-3">
            <div>
              <p className="font-display text-4xl font-bold text-slate-900">
                {coveragePct !== null ? `${coveragePct}%` : "—"}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                {cohort.confirmedCount} of ~{classSize.toLocaleString()} classmates
              </p>
            </div>
            {coveragePct !== null && (
              <p className={cn("text-xs font-semibold mb-1", getCoverageLabel(coveragePct).color)}>
                {getCoverageLabel(coveragePct).label}
              </p>
            )}
          </div>

          {/* Visual bar */}
          <div className="space-y-1">
            <div className="h-3 w-full overflow-hidden rounded-full bg-slate-100">
              <div
                className="h-full rounded-full bg-blue-400 transition-all duration-700"
                style={{ width: `${coveragePct ?? 0}%` }}
              />
            </div>
            {/* Milestone markers */}
            <div className="relative h-3">
              {[25, 50, 75].map((milestone) => (
                <div
                  key={milestone}
                  className="absolute top-0 -translate-x-1/2"
                  style={{ left: `${milestone}%` }}
                >
                  <div className="h-2 w-px bg-slate-200" />
                  <p className="text-[9px] text-slate-300 -translate-x-1/2">{milestone}%</p>
                </div>
              ))}
            </div>
          </div>

          {/* Edit class size */}
          {editing ? (
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSave();
                  if (e.key === "Escape") setEditing(false);
                }}
                className="flex-1 rounded-lg border border-blue-300 bg-blue-50 px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Estimated class size"
                min={1}
                autoFocus
              />
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500 text-white hover:bg-emerald-600"
                aria-label="Save"
              >
                <Check className="h-4 w-4" />
              </button>
              <button
                onClick={() => setEditing(false)}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-border text-slate-400 hover:text-slate-600"
                aria-label="Cancel"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setEditing(true)}
              className="flex items-center gap-1.5 self-start text-xs text-slate-400 hover:text-blue-600 transition-colors"
            >
              <Edit3 className="h-3 w-3" />
              Adjust class size estimate
            </button>
          )}
        </>
      ) : (
        /* Empty state — prompt to set class size */
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-3 rounded-xl bg-slate-50 border border-border px-4 py-3">
            <Users className="h-5 w-5 text-slate-300 shrink-0" />
            <p className="text-xs text-slate-500">
              Set your estimated class size to track how many classmates you've reached.
            </p>
          </div>
          {editing ? (
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSave();
                  if (e.key === "Escape") setEditing(false);
                }}
                className="flex-1 rounded-lg border border-blue-300 bg-blue-50 px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g. 250"
                min={1}
                autoFocus
              />
              <button
                onClick={handleSave}
                disabled={isSaving || !inputValue}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500 text-white hover:bg-emerald-600 disabled:opacity-50"
                aria-label="Save"
              >
                <Check className="h-4 w-4" />
              </button>
              <button
                onClick={() => setEditing(false)}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-border text-slate-400 hover:text-slate-600"
                aria-label="Cancel"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setEditing(true)}
              className="self-start rounded-lg border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-medium text-blue-700 hover:bg-blue-100 transition-colors"
            >
              + Set class size
            </button>
          )}
          <p className="text-xs text-slate-400">
            {cohort.confirmedCount} confirmed so far from {cohort.schoolName} · {cohort.graduationYear}
          </p>
        </div>
      )}
    </div>
  );
}
