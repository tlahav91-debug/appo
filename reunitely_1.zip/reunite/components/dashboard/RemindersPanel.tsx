"use client";

import Link from "next/link";
import {
  AlertTriangle, ArrowRight, CreditCard, Users, Clock,
  Trophy, Calendar, Image, ChevronDown, ChevronUp, X,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import type { DashboardData } from "@/lib/services/dashboard.service";

interface RemindersPanelProps {
  reminders: DashboardData["reminders"];
  eventId: string;
}

const TYPE_CONFIG: Record<string, { icon: React.ElementType; iconColor: string }> = {
  uncollected_payment: { icon: CreditCard,     iconColor: "text-red-500" },
  pending_rsvp:        { icon: Users,          iconColor: "text-blue-500" },
  waitlist_promote:    { icon: Users,          iconColor: "text-blue-500" },
  nominations_open:    { icon: Trophy,         iconColor: "text-violet-500" },
  event_soon:          { icon: Calendar,       iconColor: "text-red-500" },
  memories_pending:    { icon: Image,          iconColor: "text-blue-500" },
};

const PRIORITY_STYLES = {
  high:   "border-red-200 bg-red-50",
  medium: "border-blue-200 bg-blue-50",
  low:    "border-slate-200 bg-slate-50",
};

const PRIORITY_DOT = {
  high:   "bg-red-400",
  medium: "bg-blue-400",
  low:    "bg-slate-300",
};

export function RemindersPanel({ reminders, eventId }: RemindersPanelProps) {
  const [expanded, setExpanded] = useState(true);
  const [dismissed, setDismissed] = useState<Set<number>>(new Set());

  const visible = reminders.filter((_, i) => !dismissed.has(i));
  const highCount = visible.filter((r) => r.priority === "high").length;

  if (visible.length === 0) return null;

  return (
    <div className={cn(
      "rounded-2xl border shadow-sm overflow-hidden",
      highCount > 0 ? "border-red-200" : "border-blue-200"
    )}>
      {/* Header */}
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className={cn(
          "flex w-full items-center justify-between px-5 py-3.5 text-left transition-colors",
          highCount > 0 ? "bg-red-50 hover:bg-red-100/60" : "bg-blue-50 hover:bg-blue-100/60"
        )}
      >
        <div className="flex items-center gap-2">
          <AlertTriangle className={cn("h-4 w-4", highCount > 0 ? "text-red-500" : "text-blue-500")} />
          <span className={cn("text-sm font-semibold", highCount > 0 ? "text-red-800" : "text-blue-800")}>
            {visible.length} action{visible.length !== 1 ? "s" : ""} needed
          </span>
          {highCount > 0 && (
            <span className="rounded-full bg-red-400 px-2 py-0.5 text-[10px] font-bold text-white">
              {highCount} high priority
            </span>
          )}
        </div>
        {expanded ? (
          <ChevronUp className="h-4 w-4 text-slate-400" />
        ) : (
          <ChevronDown className="h-4 w-4 text-slate-400" />
        )}
      </button>

      {/* Reminders list */}
      {expanded && (
        <div className="divide-y divide-border bg-card">
          {visible.map((reminder, originalIdx) => {
            const cfg = TYPE_CONFIG[reminder.type] ?? { icon: AlertTriangle, iconColor: "text-slate-500" };
            const Icon = cfg.icon;
            const absIdx = reminders.indexOf(reminder);

            return (
              <div
                key={`${reminder.type}-${originalIdx}`}
                className={cn("flex items-start gap-4 px-5 py-4")}
              >
                {/* Priority dot + icon */}
                <div className="flex shrink-0 flex-col items-center gap-1.5 pt-0.5">
                  <span className={cn("h-2 w-2 rounded-full", PRIORITY_DOT[reminder.priority])} />
                  <Icon className={cn("h-4 w-4", cfg.iconColor)} />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-900">{reminder.title}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{reminder.description}</p>
                </div>

                {/* Action link */}
                <div className="flex items-center gap-2 shrink-0">
                  <Link
                    href={reminder.actionHref}
                    className="flex items-center gap-1 rounded-lg border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-medium text-blue-700 hover:bg-blue-100 transition-colors"
                  >
                    Fix it <ArrowRight className="h-3 w-3" />
                  </Link>
                  <button
                    onClick={() => setDismissed((s) => new Set(s).add(absIdx))}
                    className="flex h-7 w-7 items-center justify-center rounded-lg text-slate-300 hover:text-slate-500 hover:bg-slate-100 transition-colors"
                    aria-label="Dismiss"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
