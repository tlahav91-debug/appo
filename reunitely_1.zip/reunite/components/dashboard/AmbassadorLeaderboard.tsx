"use client";

import Link from "next/link";
import { ArrowRight, Medal, TrendingUp } from "lucide-react";
import { Avatar } from "@/components/shared/Avatar";
import { cn } from "@/lib/utils";
import type { DashboardData } from "@/lib/services/dashboard.service";

interface AmbassadorLeaderboardProps {
  ambassadors: DashboardData["ambassadors"];
  eventId: string;
}

const RANK_STYLES = [
  { bg: "bg-blue-100",   text: "text-blue-700",   medal: "🥇" },
  { bg: "bg-slate-100",   text: "text-slate-600",   medal: "🥈" },
  { bg: "bg-orange-100",  text: "text-orange-700",  medal: "🥉" },
];

export function AmbassadorLeaderboard({ ambassadors, eventId }: AmbassadorLeaderboardProps) {
  if (ambassadors.length === 0) return null;

  const maxRsvps = ambassadors[0]?.rsvpsGenerated ?? 1;

  return (
    <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50">
            <Medal className="h-4 w-4 text-blue-500" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Class ambassadors</h3>
            <p className="text-[10px] text-slate-400">Top referrers by RSVPs generated</p>
          </div>
        </div>
        <Link
          href={`invites`}
          className="flex items-center gap-1 text-xs text-blue-600 hover:underline"
        >
          All links <ArrowRight className="h-3 w-3" />
        </Link>
      </div>

      <div className="flex flex-col gap-3">
        {ambassadors.map((ambassador, i) => {
          const rankStyle = RANK_STYLES[i];
          const barWidth = Math.round((ambassador.rsvpsGenerated / maxRsvps) * 100);

          return (
            <div key={ambassador.userId} className="flex items-center gap-3">
              {/* Rank badge */}
              <div className={cn(
                "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-sm",
                rankStyle ? rankStyle.bg : "bg-slate-50"
              )}>
                {rankStyle ? (
                  <span className="text-base leading-none" aria-label={`Rank ${i + 1}`}>
                    {rankStyle.medal}
                  </span>
                ) : (
                  <span className={cn("text-xs font-bold text-slate-500")}>
                    {i + 1}
                  </span>
                )}
              </div>

              {/* Avatar + name */}
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <Avatar name={ambassador.name} src={ambassador.avatarUrl} size="xs" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-slate-900 truncate">{ambassador.name}</p>
                  {ambassador.label && (
                    <p className="text-[10px] text-slate-400 truncate">{ambassador.label}</p>
                  )}
                  {/* Mini progress bar */}
                  <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-blue-400"
                      style={{ width: `${barWidth}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Count */}
              <div className="text-right shrink-0">
                <p className="text-sm font-bold text-slate-900">
                  {ambassador.rsvpsGenerated}
                </p>
                <p className="text-[10px] text-slate-400">RSVP{ambassador.rsvpsGenerated !== 1 ? "s" : ""}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="border-t border-border pt-3 flex items-center gap-2 text-xs text-slate-400">
        <TrendingUp className="h-3.5 w-3.5" />
        <span>Ambassadors earn referral credit when classmates RSVP via their link</span>
      </div>
    </div>
  );
}
