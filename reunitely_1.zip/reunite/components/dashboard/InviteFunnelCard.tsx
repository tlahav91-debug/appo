"use client";

import Link from "next/link";
import { ArrowRight, Send } from "lucide-react";
import { cn } from "@/lib/utils";
import type { DashboardData } from "@/lib/services/dashboard.service";

interface InviteFunnelCardProps {
  invites: DashboardData["invites"];
}

function FunnelBar({
  label,
  count,
  total,
  color,
}: {
  label: string;
  count: number;
  total: number;
  color: string;
}) {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-slate-600">{label}</span>
        <span className="text-xs font-bold text-slate-900">
          {count.toLocaleString()}
          <span className="ml-1 font-normal text-slate-400">({pct}%)</span>
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
        <div
          className={cn("h-full rounded-full transition-all duration-500", color)}
          style={{ width: `${pct}%` }}
          role="progressbar"
          aria-valuenow={pct}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label={`${label}: ${pct}%`}
        />
      </div>
    </div>
  );
}

export function InviteFunnelCard({ invites }: InviteFunnelCardProps) {
  const total = invites.total;
  const steps = [
    { label: "Sent",      count: invites.sent,      color: "bg-blue-300" },
    { label: "Delivered", count: invites.delivered,  color: "bg-blue-400" },
    { label: "Opened",    count: invites.opened,     color: "bg-violet-400" },
    { label: "RSVP'd",   count: invites.rsvpd,      color: "bg-emerald-400" },
  ];

  return (
    <div className="flex flex-col gap-5 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-900">Invite funnel</h3>
        <Link
          href="invites"
          className="flex items-center gap-1 text-xs text-blue-600 hover:underline"
        >
          Manage <ArrowRight className="h-3 w-3" />
        </Link>
      </div>

      {total === 0 ? (
        <div className="flex flex-col items-center gap-2 py-6 text-center">
          <Send className="h-8 w-8 text-slate-200" />
          <p className="text-sm text-slate-400">No invites sent yet</p>
          <Link href="invites" className="text-xs text-blue-600 hover:underline">
            Send your first invite →
          </Link>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {steps.map((step) => (
            <FunnelBar
              key={step.label}
              label={step.label}
              count={step.count}
              total={total}
              color={step.color}
            />
          ))}
        </div>
      )}

      {total > 0 && (
        <div className="border-t border-border pt-3 flex items-center justify-between">
          <span className="text-xs text-slate-500">Overall conversion</span>
          <span className="text-sm font-bold text-emerald-600">
            {invites.conversionRate}%
          </span>
        </div>
      )}
    </div>
  );
}
