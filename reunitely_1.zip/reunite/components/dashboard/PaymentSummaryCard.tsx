"use client";

import Link from "next/link";
import { ArrowRight, DollarSign, AlertCircle, CheckCircle2, RotateCcw } from "lucide-react";
import { formatCurrency, cn } from "@/lib/utils";
import type { DashboardData } from "@/lib/services/dashboard.service";

// ─── Payment Summary Card ─────────────────────────────────────────────────────

interface PaymentSummaryCardProps {
  payments: DashboardData["payments"];
  eventId: string;
}

export function PaymentSummaryCard({ payments, eventId }: PaymentSummaryCardProps) {
  const totalOrders = payments.paidCount + payments.pendingCount + payments.refundedCount;

  return (
    <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50">
            <DollarSign className="h-4 w-4 text-blue-500" />
          </div>
          <h3 className="text-sm font-semibold text-slate-900">Payments</h3>
        </div>
        <Link
          href={`payments`}
          className="flex items-center gap-1 text-xs text-blue-600 hover:underline"
        >
          View all <ArrowRight className="h-3 w-3" />
        </Link>
      </div>

      <div className="space-y-1">
        <p className="font-display text-3xl font-bold text-slate-900">
          {formatCurrency(payments.totalRevenueCents, payments.currency)}
        </p>
        <p className="text-xs text-slate-400">total revenue collected</p>
      </div>

      <div className="flex flex-col gap-2">
        <PaymentStatusRow
          icon={CheckCircle2}
          iconColor="text-emerald-500"
          label="Paid"
          count={payments.paidCount}
          total={totalOrders}
          barColor="bg-emerald-400"
        />
        {payments.pendingCount > 0 && (
          <PaymentStatusRow
            icon={AlertCircle}
            iconColor="text-blue-500"
            label="Pending payment"
            count={payments.pendingCount}
            total={totalOrders}
            barColor="bg-blue-400"
            highlight
          />
        )}
        {payments.refundedCount > 0 && (
          <PaymentStatusRow
            icon={RotateCcw}
            iconColor="text-slate-400"
            label="Refunded"
            count={payments.refundedCount}
            total={totalOrders}
            barColor="bg-slate-300"
          />
        )}
      </div>

      {payments.pendingCount > 0 && (
        <div className="rounded-lg bg-blue-50 border border-blue-200 px-3 py-2 text-xs text-blue-800">
          <span className="font-semibold">{payments.pendingCount}</span> attendee
          {payments.pendingCount !== 1 ? "s" : ""} still need to complete payment
        </div>
      )}
    </div>
  );
}

function PaymentStatusRow({
  icon: Icon,
  iconColor,
  label,
  count,
  total,
  barColor,
  highlight,
}: {
  icon: React.ElementType;
  iconColor: string;
  label: string;
  count: number;
  total: number;
  barColor: string;
  highlight?: boolean;
}) {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Icon className={cn("h-3.5 w-3.5", iconColor)} />
          <span className={cn("text-xs", highlight ? "font-semibold text-blue-700" : "text-slate-600")}>
            {label}
          </span>
        </div>
        <span className="text-xs font-bold text-slate-900">
          {count} <span className="font-normal text-slate-400">({pct}%)</span>
        </span>
      </div>
      <div className="h-1.5 w-full rounded-full bg-slate-100">
        <div
          className={cn("h-full rounded-full", barColor)}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
