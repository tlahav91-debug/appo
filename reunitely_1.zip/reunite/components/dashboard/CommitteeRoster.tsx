"use client";

import Link from "next/link";
import { Users, ArrowRight, Crown, Shield, User } from "lucide-react";
import { Avatar } from "@/components/shared/Avatar";
import { cn } from "@/lib/utils";
import type { DashboardData } from "@/lib/services/dashboard.service";

interface CommitteeRosterProps {
  members: DashboardData["committee"];
  eventId: string;
  isOrganizer: boolean;
}

const ROLE_CONFIG: Record<string, { label: string; icon: React.ElementType; color: string; bg: string }> = {
  ORGANIZER:     { label: "Organizer",     icon: Crown,  color: "text-blue-700", bg: "bg-blue-100" },
  CO_ORGANIZER:  { label: "Co-organizer",  icon: Shield, color: "text-blue-700",  bg: "bg-blue-100" },
  COMMITTEE:     { label: "Committee",     icon: User,   color: "text-slate-600", bg: "bg-slate-100" },
};

export function CommitteeRoster({ members, eventId, isOrganizer }: CommitteeRosterProps) {
  return (
    <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-slate-400" />
          <h3 className="text-sm font-semibold text-slate-900">
            Committee
            <span className="ml-2 text-xs font-normal text-slate-400">
              {members.length}
            </span>
          </h3>
        </div>
        {isOrganizer && (
          <Link
            href={`settings`}
            className="flex items-center gap-1 text-xs text-blue-600 hover:underline"
          >
            Manage <ArrowRight className="h-3 w-3" />
          </Link>
        )}
      </div>

      <div className="flex flex-col gap-2">
        {members.map((member) => {
          const roleConfig = ROLE_CONFIG[member.role] ?? ROLE_CONFIG["COMMITTEE"]!;
          const RoleIcon = roleConfig.icon;

          return (
            <div
              key={member.userId}
              className="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-slate-50 transition-colors"
            >
              <Avatar name={member.name} src={member.avatarUrl} size="sm" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900 truncate">{member.name}</p>
                {member.title && (
                  <p className="text-xs text-slate-400 truncate">{member.title}</p>
                )}
              </div>
              <span className={cn(
                "flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-semibold shrink-0",
                roleConfig.bg, roleConfig.color
              )}>
                <RoleIcon className="h-3 w-3" />
                {roleConfig.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
