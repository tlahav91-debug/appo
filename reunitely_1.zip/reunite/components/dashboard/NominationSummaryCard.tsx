"use client";

import Link from "next/link";
import { ArrowRight, Trophy, Vote, Eye, Lock } from "lucide-react";
import { cn } from "@/lib/utils";
import type { DashboardData } from "@/lib/services/dashboard.service";

interface NominationSummaryCardProps {
  nominations: DashboardData["nominations"];
  eventId: string;
}

const VOTING_STATUS_CONFIG: Record<string, { label: string; className: string; icon: React.ElementType }> = {
  DRAFT:             { label: "Draft",    className: "bg-slate-100 text-slate-500", icon: Lock },
  OPEN:              { label: "Voting open", className: "bg-emerald-100 text-emerald-700", icon: Vote },
  CLOSED:            { label: "Closed",   className: "bg-blue-100 text-blue-700", icon: Lock },
  RESULTS_REVEALED:  { label: "Revealed", className: "bg-violet-100 text-violet-700", icon: Eye },
};

export function NominationSummaryCard({ nominations, eventId }: NominationSummaryCardProps) {
  const openCount = nominations.categories.filter(c => c.votingStatus === "OPEN").length;
  const revealedCount = nominations.categories.filter(c => c.votingStatus === "RESULTS_REVEALED").length;

  return (
    <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-violet-50">
            <Trophy className="h-4 w-4 text-violet-500" />
          </div>
          <h3 className="text-sm font-semibold text-slate-900">Nominations</h3>
        </div>
        <Link
          href={`nominations`}
          className="flex items-center gap-1 text-xs text-blue-600 hover:underline"
        >
          Manage <ArrowRight className="h-3 w-3" />
        </Link>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Categories", value: nominations.categoryCount, color: "text-violet-600" },
          { label: "Nominations", value: nominations.nominationCount, color: "text-slate-900" },
          { label: "Votes cast", value: nominations.voteCount, color: "text-slate-900" },
        ].map(({ label, value, color }) => (
          <div key={label} className="text-center">
            <p className={cn("font-display text-2xl font-bold", color)}>{value}</p>
            <p className="text-[10px] text-slate-400 mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Category list */}
      {nominations.categories.length > 0 ? (
        <div className="flex flex-col gap-2 max-h-48 overflow-y-auto">
          {nominations.categories.slice(0, 6).map((cat) => {
            const cfg = VOTING_STATUS_CONFIG[cat.votingStatus] ?? VOTING_STATUS_CONFIG["DRAFT"]!;
            const StatusIcon = cfg.icon;
            return (
              <div key={cat.id} className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  {cat.emoji && <span className="text-base" aria-hidden>{cat.emoji}</span>}
                  <span className="text-sm text-slate-700 truncate">{cat.title}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {cat.voteCount > 0 && (
                    <span className="text-xs text-slate-400">{cat.voteCount}v</span>
                  )}
                  <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium", cfg.className)}>
                    <StatusIcon className="h-2.5 w-2.5" />
                    {cfg.label}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-2 py-4 text-center">
          <Trophy className="h-6 w-6 text-slate-200" />
          <p className="text-xs text-slate-400">No categories yet</p>
          <Link href={`nominations`} className="text-xs text-blue-600 hover:underline">
            Create first category →
          </Link>
        </div>
      )}

      {openCount > 0 && (
        <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-3 py-2 text-xs text-emerald-800">
          🗳️ <span className="font-semibold">{openCount}</span> categor{openCount !== 1 ? "ies" : "y"} with voting open
        </div>
      )}
    </div>
  );
}
