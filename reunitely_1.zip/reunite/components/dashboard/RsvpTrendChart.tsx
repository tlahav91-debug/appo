"use client";

import { useMemo } from "react";
import { cn } from "@/lib/utils";
import type { DashboardData } from "@/lib/services/dashboard.service";

interface RsvpTrendChartProps {
  trend: DashboardData["rsvp"]["trend"];
  confirmedCount: number;
}

export function RsvpTrendChart({ trend, confirmedCount }: RsvpTrendChartProps) {
  const max = useMemo(() => Math.max(...trend.map((d) => d.count), 1), [trend]);
  const total = useMemo(() => trend.reduce((s, d) => s + d.count, 0), [trend]);

  // Determine x-axis label frequency
  const labelEvery = trend.length > 10 ? 3 : 2;

  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
      <div className="mb-5 flex items-start justify-between">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">RSVPs this period</h3>
          <p className="mt-0.5 text-xs text-slate-400">Confirmed responses — last 14 days</p>
        </div>
        <div className="text-right">
          <p className="font-display text-2xl font-bold text-slate-900">+{total}</p>
          <p className="text-xs text-slate-400">new this period</p>
        </div>
      </div>

      {/* Chart */}
      <div
        className="flex items-end gap-1.5"
        style={{ height: 80 }}
        role="img"
        aria-label={`RSVP trend: ${total} new RSVPs over the last 14 days`}
      >
        {trend.map(({ date, count }, i) => {
          const heightPct = max > 0 ? (count / max) * 100 : 0;
          const isToday = i === trend.length - 1;
          const shortDate = new Date(date + "T12:00:00Z").toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            timeZone: "UTC",
          });
          const showLabel = i % labelEvery === 0 || isToday;

          return (
            <div
              key={date}
              className="group relative flex flex-1 flex-col items-center gap-1"
            >
              {/* Bar */}
              <div
                className="relative w-full flex items-end justify-center"
                style={{ height: 64 }}
              >
                <div
                  className={cn(
                    "w-full rounded-t-sm transition-all duration-300",
                    count === 0
                      ? "bg-slate-100"
                      : isToday
                      ? "bg-blue-400"
                      : "bg-blue-200 group-hover:bg-blue-300"
                  )}
                  style={{ height: `${Math.max(heightPct, count > 0 ? 6 : 2)}%` }}
                />
                {/* Tooltip */}
                {count > 0 && (
                  <div className="absolute bottom-full mb-1 hidden group-hover:flex">
                    <span className="whitespace-nowrap rounded bg-slate-900 px-2 py-1 text-[10px] font-medium text-white shadow-lg">
                      {count} RSVP{count !== 1 ? "s" : ""} · {shortDate}
                    </span>
                  </div>
                )}
              </div>

              {/* X-axis label */}
              {showLabel && (
                <span className="text-[9px] text-slate-400 whitespace-nowrap">
                  {isToday
                    ? "Today"
                    : new Date(date + "T12:00:00Z").toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        timeZone: "UTC",
                      })}
                </span>
              )}
              {!showLabel && <span className="text-[9px] text-transparent">·</span>}
            </div>
          );
        })}
      </div>

      {/* Summary row */}
      <div className="mt-3 flex items-center gap-4 border-t border-border pt-3">
        <div className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-blue-400" />
          <span className="text-xs text-slate-500">Today</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-blue-200" />
          <span className="text-xs text-slate-500">Previous days</span>
        </div>
        <div className="ml-auto text-xs text-slate-400">
          {confirmedCount} total confirmed
        </div>
      </div>
    </div>
  );
}
