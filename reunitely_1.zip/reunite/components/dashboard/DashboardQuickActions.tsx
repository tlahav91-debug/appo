"use client";

import Link from "next/link";
import {
  Globe, Send, Download, Users, QrCode, Megaphone,
  Settings, Eye, Copy, Check, Loader2, ArrowUpRight,
  UserPlus, BarChart3,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { EventStatus } from "@prisma/client";

interface DashboardQuickActionsProps {
  eventId: string;
  eventSlug: string;
  eventStatus: EventStatus;
  isOrganizer: boolean;
  rsvpCount: number;
  hasStripeConnect: boolean;
}

interface ActionItem {
  label: string;
  description: string;
  icon: React.ElementType;
  href?: string;
  onClick?: () => void;
  variant: "primary" | "secondary" | "ghost";
  badge?: string;
  condition?: boolean;
}

export function DashboardQuickActions({
  eventId,
  eventSlug,
  eventStatus,
  isOrganizer,
  rsvpCount,
  hasStripeConnect,
}: DashboardQuickActionsProps) {
  const [copied, setCopied] = useState(false);
  const [exporting, setExporting] = useState(false);

  // Build event URL — falls back to empty string during SSR, populated on client
  const eventUrl = typeof window !== "undefined"
    ? `${window.location.origin}/events/${eventSlug}`
    : `/events/${eventSlug}`;
  const isPublished = eventStatus === "PUBLISHED";
  const isDraft = eventStatus === "DRAFT";

  async function copyEventLink() {
    try {
      await navigator.clipboard.writeText(eventUrl);
      setCopied(true);
      toast.success("Event link copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Failed to copy link");
    }
  }

  async function exportAttendees() {
    setExporting(true);
    try {
      window.open(`/api/events/${eventId}/memberships/export`, "_blank");
    } finally {
      setTimeout(() => setExporting(false), 1500);
    }
  }

  const primaryActions: ActionItem[] = [
    // Draft: publish is the primary CTA
    {
      label: "Publish event",
      description: "Make it live for attendees",
      icon: Globe,
      href: `settings`,
      variant: "primary",
      condition: isDraft && isOrganizer,
    },
    // Published: invite people
    {
      label: "Invite classmates",
      description: "Send email or SMS invites",
      icon: UserPlus,
      href: `invites`,
      variant: "primary",
      badge: rsvpCount === 0 ? "Do this first" : undefined,
      condition: isPublished,
    },
  ].filter(a => a.condition !== false);

  const secondaryActions: ActionItem[] = [
    {
      label: "Send message",
      description: "Email or SMS all attendees",
      icon: Megaphone,
      href: `messages`,
      variant: "secondary",
      condition: rsvpCount > 0,
    },
    {
      label: "View event page",
      description: "See it as attendees do",
      icon: Eye,
      href: `/events/${eventSlug}`,
      variant: "secondary",
      condition: isPublished,
    },
    {
      label: copied ? "Copied!" : "Copy event link",
      description: "Share via any channel",
      icon: copied ? Check : Copy,
      onClick: copyEventLink,
      variant: "secondary",
      condition: isPublished,
    },
    {
      label: exporting ? "Downloading…" : "Export attendees",
      description: "CSV with all RSVP data",
      icon: exporting ? Loader2 : Download,
      onClick: exportAttendees,
      variant: "secondary",
      condition: rsvpCount > 0,
    },
    {
      label: "View attendance",
      description: "Check in and manage RSVPs",
      icon: Users,
      href: `attendees`,
      variant: "secondary",
    },
    {
      label: "Event settings",
      description: "Capacity, tickets, details",
      icon: Settings,
      href: `settings`,
      variant: "ghost",
      condition: isOrganizer,
    },
  ].filter(a => a.condition !== false);

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <h3 className="text-sm font-semibold text-slate-900">Quick actions</h3>

      {/* Primary actions */}
      {primaryActions.map((action) => {
        const Icon = action.icon;
        const content = (
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-500">
              <Icon className="h-4 w-4 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white flex items-center gap-2">
                {action.label}
                {action.badge && (
                  <span className="rounded-full bg-white/20 px-2 py-0.5 text-[10px] font-bold">
                    {action.badge}
                  </span>
                )}
              </p>
              <p className="text-xs text-blue-100">{action.description}</p>
            </div>
            <ArrowUpRight className="h-4 w-4 text-blue-100 shrink-0" />
          </div>
        );

        return action.href ? (
          <Link
            key={action.label}
            href={action.href}
            className="flex items-center gap-3 rounded-xl bg-blue-500 px-4 py-3 hover:bg-blue-700 transition-colors"
          >
            {content}
          </Link>
        ) : (
          <button
            key={action.label}
            type="button"
            onClick={action.onClick}
            className="flex items-center gap-3 rounded-xl bg-blue-500 px-4 py-3 hover:bg-blue-700 transition-colors text-left"
          >
            {content}
          </button>
        );
      })}

      {/* Secondary actions grid */}
      <div className="grid grid-cols-1 gap-1.5">
        {secondaryActions.map((action) => {
          const Icon = action.icon;
          const className = cn(
            "flex items-center gap-3 rounded-xl border px-4 py-3 transition-colors text-left",
            "border-border bg-white hover:bg-slate-50 hover:border-blue-200",
          );
          const inner = (
            <>
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100">
                <Icon className={cn("h-4 w-4 text-slate-500", action.icon === Loader2 && "animate-spin")} />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-slate-800">{action.label}</p>
                <p className="text-xs text-slate-400">{action.description}</p>
              </div>
            </>
          );

          return action.href ? (
            <Link key={action.label} href={action.href} className={className}>
              {inner}
            </Link>
          ) : (
            <button
              key={action.label}
              type="button"
              onClick={action.onClick}
              className={className}
            >
              {inner}
            </button>
          );
        })}
      </div>
    </div>
  );
}
