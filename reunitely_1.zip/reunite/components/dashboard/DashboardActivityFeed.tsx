"use client";

import Link from "next/link";
import { Activity, ArrowRight } from "lucide-react";
import { Avatar } from "@/components/shared/Avatar";
import { formatRelativeTime } from "@/lib/utils";
import type { DashboardData } from "@/lib/services/dashboard.service";

interface DashboardActivityFeedProps {
  activities: DashboardData["recentActivity"];
  eventId: string;
}

const ACTION_DESCRIPTIONS: Record<string, string> = {
  RSVP_CREATED:         "RSVP'd to the event",
  RSVP_UPDATED:         "updated their RSVP",
  RSVP_CANCELLED:       "cancelled their RSVP",
  INVITE_SENT:          "sent invitations",
  INVITE_RESENT:        "resent an invitation",
  ATTENDEE_CHECKED_IN:  "checked in an attendee",
  BROADCAST_SENT:       "sent a broadcast message",
  MEMORY_APPROVED:      "approved a memory",
  MEMORY_REJECTED:      "rejected a memory",
  MEMORY_REPORTED:      "reported a memory",
  RESULTS_REVEALED:     "revealed nomination results",
  NOMINATION_CREATED:   "created a nomination category",
  VOTE_CAST:            "cast a vote",
  PAYMENT_MANUALLY_MARKED: "manually marked payment",
  DATA_EXPORTED:        "exported attendee data",
  EVENT_PUBLISHED:      "published the event",
  EVENT_UPDATED:        "updated event details",
  ACCOUNT_DELETED:      "deleted their account",
  COMMITTEE_ADDED:      "added a committee member",
  COMMITTEE_REMOVED:    "removed a committee member",
};

function describeAction(action: string): string {
  return ACTION_DESCRIPTIONS[action] ?? action.toLowerCase().replace(/_/g, " ");
}

export function DashboardActivityFeed({ activities, eventId }: DashboardActivityFeedProps) {
  return (
    <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-slate-400" />
          <h3 className="text-sm font-semibold text-slate-900">Recent activity</h3>
        </div>
      </div>

      {activities.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-6 text-center">
          <Activity className="h-8 w-8 text-slate-200" />
          <p className="text-sm text-slate-400">Activity will appear here</p>
          <p className="text-xs text-slate-300">as attendees join and interact</p>
        </div>
      ) : (
        <div className="flex flex-col gap-0">
          {activities.map((activity, i) => (
            <div
              key={activity.id}
              className="flex items-start gap-3 py-3 border-b border-border last:border-0"
            >
              {/* Avatar with vertical connector line */}
              <div className="relative flex flex-col items-center shrink-0">
                <Avatar
                  name={activity.actorName}
                  src={activity.actorAvatar}
                  size="xs"
                />
                {i < activities.length - 1 && (
                  <div className="mt-1 h-full w-px bg-slate-100 absolute top-6 left-1/2 -translate-x-1/2" />
                )}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0 pb-0.5">
                <p className="text-xs text-slate-700 leading-snug">
                  <span className="font-semibold text-slate-900">
                    {activity.actorName}
                  </span>{" "}
                  {describeAction(activity.action)}
                </p>
                <p className="mt-0.5 text-[11px] text-slate-400">
                  {formatRelativeTime(activity.createdAt)}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
