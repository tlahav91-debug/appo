"use client";

import { useTransition } from "react";
import { CheckCircle, XCircle, AlertTriangle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/shared/Avatar";
import { toast } from "sonner";
import { approveMemoryAction, rejectMemoryAction } from "@/lib/actions/event.actions";
import { formatRelativeTime } from "@/lib/utils";
import { useRouter } from "next/navigation";

interface ModerationItem {
  id: string;
  type: string;
  caption: string | null;
  authorName: string;
  authorEmail: string;
  authorAvatar: string | null;
  eventTitle: string;
  eventSlug: string;
  createdAt: string;
  reportCount: number;
  isFlagged: boolean;
}

interface AdminModerationQueueProps {
  pendingMemories: ModerationItem[];
  flaggedMemories: ModerationItem[];
}

export function AdminModerationQueue({
  pendingMemories,
  flaggedMemories,
}: AdminModerationQueueProps) {
  const allItems = [...pendingMemories, ...flaggedMemories];

  if (allItems.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <CheckCircle className="h-10 w-10 text-emerald-400 mb-3" />
        <p className="font-semibold text-slate-900">Queue is clear</p>
        <p className="text-sm text-slate-400 mt-1">No content awaiting moderation.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {allItems.map((item) => (
        <ModerationCard key={item.id} item={item} />
      ))}
    </div>
  );
}

function ModerationCard({ item }: { item: ModerationItem }) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  function handleApprove() {
    startTransition(async () => {
      const result = await approveMemoryAction(item.id);
      if (result.success) {
        toast.success("Memory approved");
        router.refresh();
      } else {
        toast.error(result.error);
      }
    });
  }

  function handleReject() {
    startTransition(async () => {
      const result = await rejectMemoryAction(item.id, "Rejected by platform moderator");
      if (result.success) {
        toast.success("Memory rejected");
        router.refresh();
      } else {
        toast.error(result.error);
      }
    });
  }

  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-start gap-4">
        {/* Author */}
        <Avatar name={item.authorName} src={item.authorAvatar} size="sm" className="mt-0.5 shrink-0" />

        <div className="flex-1 min-w-0">
          {/* Meta */}
          <div className="flex items-center gap-2 flex-wrap mb-1.5">
            {item.isFlagged && (
              <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-semibold text-red-700">
                <AlertTriangle className="h-3 w-3" />
                {item.reportCount} report{item.reportCount !== 1 ? "s" : ""}
              </span>
            )}
            {!item.isFlagged && (
              <span className="rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-semibold text-blue-700">
                Pending
              </span>
            )}
            <span className="text-xs text-slate-500">
              <span className="font-medium text-slate-700">{item.authorName}</span>
              {" · "}
              <a
                href={`/events/${item.eventSlug}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                {item.eventTitle}
              </a>
              {" · "}
              {formatRelativeTime(new Date(item.createdAt))}
            </span>
          </div>

          {/* Content preview */}
          {item.caption && (
            <p className="text-sm text-slate-700 line-clamp-3 mb-3">
              {item.caption}
            </p>
          )}

          {/* Actions */}
          <div className="flex gap-2">
            {!item.isFlagged && (
              <Button
                size="sm"
                className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
                onClick={handleApprove}
                disabled={isPending}
              >
                {isPending ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <CheckCircle className="h-3.5 w-3.5" />
                )}
                Approve
              </Button>
            )}
            <Button
              size="sm"
              variant="outline"
              className="gap-1.5 border-red-200 text-red-600 hover:bg-red-50"
              onClick={handleReject}
              disabled={isPending}
            >
              {isPending ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <XCircle className="h-3.5 w-3.5" />
              )}
              {item.isFlagged ? "Remove" : "Reject"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
