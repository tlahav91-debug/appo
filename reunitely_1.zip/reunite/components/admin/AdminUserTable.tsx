"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Search, ShieldAlert, Shield, User, Loader2, ChevronDown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar } from "@/components/shared/Avatar";
import { toast } from "sonner";
import { cn, formatRelativeTime } from "@/lib/utils";

interface AdminUser {
  id: string;
  name: string;
  email: string;
  avatarUrl: string | null;
  platformRole: "USER" | "MODERATOR" | "SUPER_ADMIN";
  lastActiveAt: string | null;
  loginCount: number;
  deletedAt: string | null;
  _count: { rsvps: number };
}

async function fetchUsers(search: string): Promise<AdminUser[]> {
  const params = new URLSearchParams({ search, limit: "50" });
  const res = await fetch(`/api/admin/users?${params}`);
  if (!res.ok) throw new Error("Failed to fetch users");
  return (await res.json()).data ?? [];
}

async function setUserRole(
  userId: string,
  platformRole: "USER" | "MODERATOR" | "SUPER_ADMIN",
  reason?: string
): Promise<void> {
  const res = await fetch(`/api/admin/users/${userId}/role`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ platformRole, reason }),
  });
  if (!res.ok) {
    const json = await res.json().catch(() => ({}));
    throw new Error(json.error?.message ?? "Failed to update role");
  }
}

interface AdminUserTableProps {
  canPromote: boolean; // only SUPER_ADMIN can change roles
}

export function AdminUserTable({ canPromote }: AdminUserTableProps) {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  // Simple debounce
  const handleSearch = (val: string) => {
    setSearch(val);
    clearTimeout((handleSearch as { t?: ReturnType<typeof setTimeout> }).t);
    (handleSearch as { t?: ReturnType<typeof setTimeout> }).t = setTimeout(
      () => setDebouncedSearch(val),
      300
    );
  };

  const { data: users = [], isLoading } = useQuery({
    queryKey: ["admin-users", debouncedSearch],
    queryFn: () => fetchUsers(debouncedSearch),
    staleTime: 30_000,
  });

  const roleMutation = useMutation({
    mutationFn: ({
      userId,
      role,
    }: {
      userId: string;
      role: "USER" | "MODERATOR" | "SUPER_ADMIN";
    }) => setUserRole(userId, role, "Admin panel action"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
      toast.success("Platform role updated. User's JWT will reflect the change on next request.");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const roleConfig = {
    USER: { label: "User", icon: User, className: "text-slate-500" },
    MODERATOR: { label: "Moderator", icon: Shield, className: "text-violet-600" },
    SUPER_ADMIN: { label: "Super Admin", icon: ShieldAlert, className: "text-red-600" },
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <Input
          placeholder="Search by name or email…"
          value={search}
          onChange={(e) => handleSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-xl border border-border bg-card">
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="h-6 w-6 animate-spin text-slate-300" />
          </div>
        ) : (
          <table className="w-full" aria-label="Platform users">
            <thead>
              <tr className="border-b border-border bg-slate-50">
                {["User", "Platform Role", "Last Active", "RSVPs", ""].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {users.map((user) => {
                const roleCfg = roleConfig[user.platformRole];
                const RoleIcon = roleCfg.icon;
                return (
                  <tr
                    key={user.id}
                    className={cn(
                      "hover:bg-slate-50/50",
                      user.deletedAt && "opacity-50"
                    )}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar name={user.name} src={user.avatarUrl} size="sm" />
                        <div>
                          <p className="text-sm font-medium text-slate-900">
                            {user.name}
                            {user.deletedAt && (
                              <span className="ml-2 text-xs text-slate-400">(deleted)</span>
                            )}
                          </p>
                          <p className="text-xs text-slate-400">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={cn("flex items-center gap-1.5 text-sm font-medium", roleCfg.className)}>
                        <RoleIcon className="h-3.5 w-3.5" />
                        {roleCfg.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-400">
                      {user.lastActiveAt
                        ? formatRelativeTime(new Date(user.lastActiveAt))
                        : "Never"}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600">
                      {user._count.rsvps}
                    </td>
                    <td className="px-4 py-3">
                      {canPromote && !user.deletedAt && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="gap-1 h-7 text-xs"
                              disabled={roleMutation.isPending}
                            >
                              Set Role
                              <ChevronDown className="h-3 w-3" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-44">
                            {(["USER", "MODERATOR", "SUPER_ADMIN"] as const).map(
                              (role) => (
                                <DropdownMenuItem
                                  key={role}
                                  disabled={user.platformRole === role}
                                  onClick={() =>
                                    roleMutation.mutate({ userId: user.id, role })
                                  }
                                  className={cn(
                                    "gap-2",
                                    user.platformRole === role &&
                                      "font-semibold text-blue-600"
                                  )}
                                >
                                  {React.createElement(roleConfig[role].icon, {
                                    className: "h-3.5 w-3.5",
                                  })}
                                  {roleConfig[role].label}
                                  {user.platformRole === role && " (current)"}
                                </DropdownMenuItem>
                              )
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </td>
                  </tr>
                );
              })}
              {!isLoading && users.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-sm text-slate-400">
                    No users found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// Fix missing React import for createElement
import React from "react";
