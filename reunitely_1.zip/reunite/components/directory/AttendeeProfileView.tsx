"use client";

import Link from "next/link";
import {
  MapPin, Briefcase, Quote, Sparkles, Mail, Linkedin,
  Instagram, Globe, MessageCircle, ArrowLeft, Share2, User,
} from "lucide-react";
import { Avatar } from "@/components/shared/Avatar";
import { AttendeeBadge } from "@/components/directory/AttendeeBadge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { DirectoryAttendee } from "@/lib/services/directory.service";

interface AttendeeProfileViewProps {
  attendee: DirectoryAttendee & {
    twitterHandle?: string | null;
    facebookUrl?: string | null;
  };
  eventSlug: string;
  eventTitle: string;
  schoolName: string;
  graduationYear: number;
  isOwnProfile: boolean;
  viewerIsAttendee: boolean;
}

export function AttendeeProfileView({
  attendee,
  eventSlug,
  eventTitle,
  schoolName,
  graduationYear,
  isOwnProfile,
  viewerIsAttendee,
}: AttendeeProfileViewProps) {
  const location = [attendee.currentCity, attendee.currentCountry]
    .filter(Boolean)
    .join(", ");

  const hasSocial =
    attendee.linkedinUrl || attendee.instagramHandle;

  async function handleShare() {
    const url = window.location.href;
    if (navigator.share) {
      await navigator.share({
        title: `${attendee.name} at ${eventTitle}`,
        url,
      }).catch(() => {});
    } else {
      await navigator.clipboard.writeText(url);
    }
  }

  return (
    <div className="max-w-2xl mx-auto flex flex-col gap-6 pb-16">
      {/* Back nav */}
      <div className="flex items-center justify-between">
        <Link
          href={`/events/${eventSlug}/attendees`}
          className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-blue-600 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to directory
        </Link>
        <button
          onClick={handleShare}
          className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-600 transition-colors"
          aria-label="Share profile"
        >
          <Share2 className="h-4 w-4" />
        </button>
      </div>

      {/* Hero card */}
      <div className="relative overflow-hidden rounded-3xl border border-border bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-8 shadow-sm">
        {/* Decorative blobs */}
        <div
          aria-hidden
          className="absolute -right-12 -top-12 h-48 w-48 rounded-full bg-blue-100/60 blur-3xl"
        />
        <div
          aria-hidden
          className="absolute -left-8 bottom-0 h-32 w-32 rounded-full bg-orange-100/40 blur-2xl"
        />

        <div className="relative flex flex-col sm:flex-row items-start gap-6">
          {/* Avatar */}
          <div className="relative shrink-0">
            <Avatar
              name={attendee.name}
              src={attendee.avatarUrl}
              size="xl"
              className="ring-4 ring-white shadow-lg"
            />
            {isOwnProfile && (
              <Link
                href="/dashboard/profile"
                className="absolute -bottom-1 -right-1 flex h-7 w-7 items-center justify-center rounded-full bg-blue-500 shadow-md hover:bg-blue-700 transition-colors"
                title="Edit profile"
              >
                <span className="text-white text-xs">✎</span>
              </Link>
            )}
          </div>

          {/* Name + meta */}
          <div className="flex-1 min-w-0">
            <h1 className="font-display text-2xl font-bold text-slate-900 leading-tight">
              {attendee.name}
            </h1>

            {/* Job/location */}
            <div className="mt-2 flex flex-wrap gap-3 text-sm text-slate-600">
              {attendee.currentJob && (
                <span className="flex items-center gap-1.5">
                  <Briefcase className="h-3.5 w-3.5 text-blue-500" />
                  {[attendee.currentJob, attendee.currentEmployer]
                    .filter(Boolean)
                    .join(" at ")}
                </span>
              )}
              {location && (
                <span className="flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5 text-blue-500" />
                  {location}
                </span>
              )}
            </div>

            {/* Badges */}
            {attendee.badges.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {attendee.badges.map((badge) => (
                  <AttendeeBadge key={badge.type} badge={badge} size="md" />
                ))}
              </div>
            )}

            {/* Event context */}
            <p className="mt-3 text-xs text-slate-400">
              {schoolName} · Class of {graduationYear}
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="relative mt-6 flex flex-wrap gap-2">
          {isOwnProfile ? (
            <Button asChild variant="outline" size="sm" className="gap-2">
              <Link href="/dashboard/profile">
                <User className="h-3.5 w-3.5" />
                Edit My Profile
              </Link>
            </Button>
          ) : attendee.allowDirectMessages ? (
            <Button asChild variant="outline" size="sm" className="gap-2">
              <Link href={`/events/${eventSlug}?tab=chat`}>
                <MessageCircle className="h-3.5 w-3.5" />
                Message
              </Link>
            </Button>
          ) : null}

          {hasSocial && (
            <div className="flex items-center gap-2">
              {attendee.linkedinUrl && (
                <a
                  href={attendee.linkedinUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-white text-slate-500 hover:text-blue-600 hover:border-blue-200 transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="h-4 w-4" />
                </a>
              )}
              {attendee.instagramHandle && (
                <a
                  href={`https://instagram.com/${attendee.instagramHandle}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-white text-slate-500 hover:text-pink-600 hover:border-pink-200 transition-colors"
                  aria-label="Instagram"
                >
                  <Instagram className="h-4 w-4" />
                </a>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bio */}
      {attendee.bio && (
        <ProfileSection icon={<Quote className="h-4 w-4" />} title="About">
          <p className="text-sm leading-relaxed text-slate-700">{attendee.bio}</p>
        </ProfileSection>
      )}

      {/* Fun fact */}
      {attendee.funFact && (
        <ProfileSection icon={<Sparkles className="h-4 w-4 text-blue-500" />} title="Fun Fact">
          <div className="rounded-xl bg-blue-50 border border-blue-200 px-4 py-3">
            <p className="text-sm text-blue-800 italic">"{attendee.funFact}"</p>
          </div>
        </ProfileSection>
      )}

      {/* Favorite school memory */}
      {attendee.favoriteMemory && (
        <ProfileSection
          icon={<span className="text-base" aria-hidden>🎓</span>}
          title={`Favorite memory from ${schoolName}`}
        >
          <div className="rounded-xl bg-slate-50 border border-border px-4 py-3">
            <p className="text-sm leading-relaxed text-slate-700 italic">
              "{attendee.favoriteMemory}"
            </p>
          </div>
        </ProfileSection>
      )}

      {/* Travel badge callout */}
      {attendee.transportMode === "FLYING" && (
        <div className="flex items-center gap-3 rounded-xl border border-blue-200 bg-blue-50 px-4 py-3">
          <span className="text-2xl" aria-hidden>✈️</span>
          <p className="text-sm text-blue-800">
            <strong>{attendee.name.split(" ")[0]}</strong> is flying in for
            the reunion. Say hi when they arrive!
          </p>
        </div>
      )}

      {/* Empty state for own profile */}
      {isOwnProfile &&
        !attendee.bio &&
        !attendee.funFact &&
        !attendee.favoriteMemory && (
          <div className="rounded-2xl border border-dashed border-blue-300 bg-blue-50 p-6 text-center">
            <p className="text-2xl mb-2" aria-hidden>✨</p>
            <p className="text-sm font-semibold text-blue-900 mb-1">
              Your profile is pretty bare!
            </p>
            <p className="text-xs text-blue-700 mb-4">
              Add a bio, fun fact, or your favorite school memory to help
              classmates remember you.
            </p>
            <Button asChild size="sm" className="gap-2">
              <Link href="/dashboard/profile">Complete My Profile</Link>
            </Button>
          </div>
        )}

      {/* Back link */}
      <div className="text-center">
        <Link
          href={`/events/${eventSlug}/attendees`}
          className="text-sm text-slate-400 hover:text-blue-600 transition-colors"
        >
          ← See all attendees
        </Link>
      </div>
    </div>
  );
}

function ProfileSection({
  icon,
  title,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <span className="text-slate-400">{icon}</span>
        <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
          {title}
        </h2>
      </div>
      {children}
    </div>
  );
}
