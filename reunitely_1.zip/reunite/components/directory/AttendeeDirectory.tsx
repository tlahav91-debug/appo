"use client";

import { useState, useCallback, useEffect } from "react";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { Search, SlidersHorizontal, Grid3X3, List, Users, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { AttendeeCard, AttendeeCardCompact } from "@/components/directory/AttendeeCard";
import { EmptyState } from "@/components/shared/EmptyState";
import { AttendeeBadge } from "@/components/directory/AttendeeBadge";
import { cn } from "@/lib/utils";
import { makeBadge as makeBadgeService, type DirectoryAttendee, type AttendeeBadgeType } from "@/lib/services/directory.service";
import Link from "next/link";

const BADGE_FILTERS: AttendeeBadgeType[] = [
  "FOUNDING_ORGANIZER",
  "CLASS_AMBASSADOR",
  "TEACHER",
  "FLYING_IN",
  "VIP",
  "COMMITTEE",
];

type ViewMode = "grid" | "list";

interface AttendeeDirectoryProps {
  initialAttendees: DirectoryAttendee[];
  total: number;
  eventSlug: string;
  eventId: string;
  viewerUserId: string | null;
  viewerIsAttendee: boolean;
  cities: string[];
  initialSearch?: string;
  initialBadge?: string;
}

export function AttendeeDirectory({
  initialAttendees,
  total,
  eventSlug,
  eventId,
  viewerUserId,
  viewerIsAttendee,
  cities,
  initialSearch = "",
  initialBadge = "",
}: AttendeeDirectoryProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [search, setSearch] = useState(initialSearch);
  const [badgeFilter, setBadgeFilter] = useState<AttendeeBadgeType | "">(
    initialBadge as AttendeeBadgeType | ""
  );
  const [cityFilter, setCityFilter] = useState("");
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [showFilters, setShowFilters] = useState(false);

  const [attendees, setAttendees] = useState(initialAttendees);
  const [isLoading, setIsLoading] = useState(false);
  const [cursor, setCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(initialAttendees.length < total);
  const [filteredTotal, setFilteredTotal] = useState(total);
  const [debounceTimer, setDebounceTimer] = useState<ReturnType<typeof setTimeout> | null>(null);

  // Sync search/badge to URL params
  function updateUrl(newSearch: string, newBadge: string) {
    const params = new URLSearchParams(searchParams.toString());
    if (newSearch) params.set("search", newSearch);
    else params.delete("search");
    if (newBadge) params.set("badge", newBadge);
    else params.delete("badge");
    router.replace(`${pathname}?${params.toString()}`, { scroll: false });
  }

  async function fetchAttendees(opts: {
    search?: string;
    badge?: string;
    city?: string;
    append?: boolean;
    afterCursor?: string;
  }) {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (opts.search) params.set("search", opts.search);
      if (opts.badge) params.set("badge", opts.badge);
      if (opts.city) params.set("city", opts.city);
      if (opts.afterCursor) params.set("cursor", opts.afterCursor);

      const res = await fetch(`/api/events/${eventId}/directory?${params}`);
      if (!res.ok) throw new Error("Failed to fetch");

      const json = await res.json();
      const data = json.data as {
        attendees: DirectoryAttendee[];
        total: number;
        nextCursor: string | null;
      };

      if (opts.append) {
        setAttendees((prev) => [...prev, ...data.attendees]);
      } else {
        setAttendees(data.attendees);
        setFilteredTotal(data.total);
      }
      setCursor(data.nextCursor);
      setHasMore(!!data.nextCursor);
    } catch {
      // silent fail — keep showing old results
    } finally {
      setIsLoading(false);
    }
  }

  function handleSearch(val: string) {
    setSearch(val);
    if (debounceTimer) clearTimeout(debounceTimer);
    const t = setTimeout(() => {
      fetchAttendees({ search: val, badge: badgeFilter, city: cityFilter });
      updateUrl(val, badgeFilter);
    }, 350);
    setDebounceTimer(t);
  }

  function handleBadgeFilter(badge: AttendeeBadgeType | "") {
    const newBadge = badge === badgeFilter ? "" : badge;
    setBadgeFilter(newBadge);
    fetchAttendees({ search, badge: newBadge, city: cityFilter });
    updateUrl(search, newBadge);
  }

  function handleCityFilter(city: string) {
    const newCity = city === cityFilter ? "" : city;
    setCityFilter(newCity);
    fetchAttendees({ search, badge: badgeFilter, city: newCity });
  }

  function handleLoadMore() {
    if (cursor) {
      fetchAttendees({
        search,
        badge: badgeFilter,
        city: cityFilter,
        append: true,
        afterCursor: cursor,
      });
    }
  }

  const hasFilters = search || badgeFilter || cityFilter;

  return (
    <div className="flex flex-col gap-5">
      {/* Stats bar */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <p className="text-sm text-slate-500">
          <span className="font-semibold text-slate-900">
            {filteredTotal.toLocaleString()}
          </span>{" "}
          attendee{filteredTotal !== 1 ? "s" : ""}
          {hasFilters && (
            <span className="text-slate-400"> (filtered)</span>
          )}
        </p>
        <div className="flex items-center gap-2">
          {/* View mode toggle */}
          <div className="flex rounded-lg border border-border overflow-hidden">
            <button
              type="button"
              onClick={() => setViewMode("grid")}
              className={cn(
                "flex h-8 w-8 items-center justify-center transition-colors",
                viewMode === "grid"
                  ? "bg-blue-50 text-blue-600"
                  : "text-slate-400 hover:text-slate-600"
              )}
              aria-label="Grid view"
            >
              <Grid3X3 className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode("list")}
              className={cn(
                "flex h-8 w-8 items-center justify-center transition-colors border-l border-border",
                viewMode === "list"
                  ? "bg-blue-50 text-blue-600"
                  : "text-slate-400 hover:text-slate-600"
              )}
              aria-label="List view"
            >
              <List className="h-3.5 w-3.5" />
            </button>
          </div>

          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            onClick={() => setShowFilters((v) => !v)}
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
            Filters
            {(badgeFilter || cityFilter) && (
              <span className="ml-1 flex h-4 w-4 items-center justify-center rounded-full bg-blue-500 text-[10px] font-bold text-white">
                {(badgeFilter ? 1 : 0) + (cityFilter ? 1 : 0)}
              </span>
            )}
          </Button>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <Input
          placeholder="Search by name…"
          value={search}
          onChange={(e) => handleSearch(e.target.value)}
          className="pl-10 bg-white h-11 text-sm rounded-xl border-border"
        />
        {search && (
          <button
            onClick={() => handleSearch("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            aria-label="Clear search"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Filter panel */}
      {showFilters && (
        <div className="rounded-2xl border border-border bg-card p-5 flex flex-col gap-4">
          {/* Badge filters */}
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Filter by badge
            </p>
            <div className="flex flex-wrap gap-2">
              {BADGE_FILTERS.map((badgeType) => {
                const badge = makeBadgeService(badgeType);
                const active = badgeFilter === badgeType;
                return (
                  <button
                    key={badgeType}
                    type="button"
                    onClick={() => handleBadgeFilter(badgeType)}
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-all",
                      active
                        ? `${badge.color} ${badge.textColor} border-transparent`
                        : "border-border text-slate-600 hover:border-blue-300 bg-white"
                    )}
                  >
                    <span aria-hidden>{badge.emoji}</span>
                    {badge.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* City filters */}
          {cities.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                Filter by city
              </p>
              <div className="flex flex-wrap gap-2">
                {cities.slice(0, 12).map((city) => (
                  <button
                    key={city}
                    type="button"
                    onClick={() => handleCityFilter(city)}
                    className={cn(
                      "rounded-full border px-3 py-1 text-xs font-medium transition-all",
                      cityFilter === city
                        ? "border-blue-600 bg-blue-50 text-blue-700"
                        : "border-border text-slate-600 hover:border-blue-300 bg-white"
                    )}
                  >
                    {city}
                  </button>
                ))}
              </div>
            </div>
          )}

          {(badgeFilter || cityFilter) && (
            <button
              onClick={() => {
                setBadgeFilter("");
                setCityFilter("");
                fetchAttendees({ search });
              }}
              className="self-start text-xs text-slate-400 hover:text-blue-600 transition-colors"
            >
              × Clear filters
            </button>
          )}
        </div>
      )}

      {/* Attendee grid/list */}
      {attendees.length === 0 && !isLoading ? (
        <EmptyState
          icon={<Users className="h-8 w-8" />}
          title={
            hasFilters
              ? "No attendees match"
              : viewerIsAttendee
              ? "Be the first to fill out your profile"
              : "RSVP to see who's coming"
          }
          description={
            hasFilters
              ? "Try adjusting your search or filters."
              : viewerIsAttendee
              ? "Complete your profile so classmates can find you."
              : "Once you RSVP, you'll be able to see and connect with other attendees."
          }
          action={
            viewerIsAttendee && !hasFilters
              ? { label: "Update My Profile", href: "/dashboard/profile" }
              : undefined
          }
          size="lg"
        />
      ) : viewMode === "grid" ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {attendees.map((attendee) => (
            <AttendeeCard
              key={attendee.userId}
              attendee={attendee}
              eventSlug={eventSlug}
              isOwnProfile={attendee.userId === viewerUserId}
            />
          ))}
          {isLoading &&
            Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="h-48 animate-pulse rounded-2xl bg-slate-100"
              />
            ))}
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {attendees.map((attendee) => (
            <AttendeeCardCompact
              key={attendee.userId}
              attendee={attendee}
              eventSlug={eventSlug}
            />
          ))}
        </div>
      )}

      {/* Load more */}
      {hasMore && !isLoading && (
        <div className="flex justify-center pt-2">
          <Button
            variant="outline"
            onClick={handleLoadMore}
            className="gap-2"
          >
            Load more
          </Button>
        </div>
      )}

      {/* Nominate CTA */}
      {viewerIsAttendee && (
        <div className="mt-4 rounded-2xl border border-dashed border-blue-300 bg-blue-50 px-5 py-4 flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-blue-900">
              Missing a classmate?
            </p>
            <p className="text-xs text-blue-700 mt-0.5">
              Nominate them — we'll help track them down and send an invite.
            </p>
          </div>
          <Link
            href={`/events/${eventSlug}/nominate`}
            className="shrink-0 rounded-lg bg-blue-500 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 transition-colors"
          >
            Nominate
          </Link>
        </div>
      )}
    </div>
  );
}
