"use client";

import { cn } from "@/lib/utils";
import type { AttendeeBadge as AttendeeBadgeType } from "@/lib/services/directory.service";

interface AttendeeBadgeProps {
  badge: AttendeeBadgeType;
  size?: "sm" | "md";
  className?: string;
}

export function AttendeeBadge({ badge, size = "sm", className }: AttendeeBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full font-medium",
        badge.color,
        badge.textColor,
        size === "sm" ? "px-2 py-0.5 text-[10px]" : "px-2.5 py-1 text-xs",
        className
      )}
      title={badge.label}
    >
      <span aria-hidden className={size === "sm" ? "text-[11px]" : "text-sm"}>
        {badge.emoji}
      </span>
      {badge.label}
    </span>
  );
}

// Stacked badge list — shows up to maxVisible, then "+N more"
export function AttendeeBadgeList({
  badges,
  maxVisible = 3,
  size = "sm",
  className,
}: {
  badges: AttendeeBadgeType[];
  maxVisible?: number;
  size?: "sm" | "md";
  className?: string;
}) {
  if (badges.length === 0) return null;

  const visible = badges.slice(0, maxVisible);
  const hidden = badges.length - maxVisible;

  return (
    <div className={cn("flex flex-wrap gap-1", className)}>
      {visible.map((badge) => (
        <AttendeeBadge key={badge.type} badge={badge} size={size} />
      ))}
      {hidden > 0 && (
        <span className="inline-flex items-center rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-500">
          +{hidden}
        </span>
      )}
    </div>
  );
}
