"use client";

import Link from "next/link";
import { MapPin, Briefcase, MessageCircle } from "lucide-react";
import { Avatar } from "@/components/shared/Avatar";
import { AttendeeBadgeList } from "@/components/directory/AttendeeBadge";
import { cn } from "@/lib/utils";
import type { DirectoryAttendee } from "@/lib/services/directory.service";

interface AttendeeCardProps {
  attendee: DirectoryAttendee;
  eventSlug: string;
  /** If viewer = profile owner, show "Edit profile" instead of "Message" */
  isOwnProfile?: boolean;
  className?: string;
}

export function AttendeeCard({
  attendee,
  eventSlug,
  isOwnProfile = false,
  className,
}: AttendeeCardProps) {
  const locationParts = [attendee.currentCity, attendee.currentCountry]
    .filter(Boolean);
  const location = locationParts.join(", ");

  const jobLine = [attendee.currentJob, attendee.currentEmployer]
    .filter(Boolean)
    .join(" at ");

  return (
    <Link
      href={`/events/${eventSlug}/attendees/${attendee.userId}`}
      className={cn(
        "group flex flex-col gap-3.5 rounded-2xl border border-border bg-card p-5",
        "transition-all duration-200 hover:shadow-md hover:border-blue-200 hover:-translate-y-0.5",
        className
      )}
      aria-label={`View ${attendee.name}'s profile`}
    >
      {/* Avatar + name row */}
      <div className="flex items-start gap-3">
        <div className="relative shrink-0">
          <Avatar
            name={attendee.name}
            src={attendee.avatarUrl}
            size="lg"
            className="ring-2 ring-white shadow-sm"
          />
          {/* Tiny flying indicator */}
          {attendee.transportMode === "FLYING" && (
            <span
              className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-blue-100 text-[10px] shadow-sm border border-white"
              title="Flying in"
              aria-label="Flying in"
            >
              ✈️
            </span>
          )}
        </div>
        <div className="flex-1 min-w-0 pt-0.5">
          <p className="text-sm font-semibold text-slate-900 truncate group-hover:text-blue-700 transition-colors">
            {attendee.name}
          </p>
          {jobLine && (
            <div className="flex items-center gap-1 mt-0.5">
              <Briefcase className="h-3 w-3 text-slate-400 shrink-0" />
              <p className="text-xs text-slate-500 truncate">{jobLine}</p>
            </div>
          )}
          {location && (
            <div className="flex items-center gap-1 mt-0.5">
              <MapPin className="h-3 w-3 text-slate-400 shrink-0" />
              <p className="text-xs text-slate-400 truncate">{location}</p>
            </div>
          )}
        </div>
      </div>

      {/* Bio snippet */}
      {attendee.bio && (
        <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
          {attendee.bio}
        </p>
      )}

      {/* Fun fact — only shown if no bio */}
      {!attendee.bio && attendee.funFact && (
        <p className="text-xs text-slate-500 italic line-clamp-2">
          "{attendee.funFact}"
        </p>
      )}

      {/* Badges */}
      {attendee.badges.length > 0 && (
        <AttendeeBadgeList badges={attendee.badges} maxVisible={3} />
      )}

      {/* Footer */}
      <div className="flex items-center justify-between mt-auto pt-1">
        <span className="text-[10px] text-slate-300 group-hover:text-blue-300 transition-colors">
          View profile →
        </span>
        {attendee.allowDirectMessages && !isOwnProfile && (
          <span className="flex items-center gap-1 text-[10px] text-slate-400">
            <MessageCircle className="h-3 w-3" />
            DMs open
          </span>
        )}
        {isOwnProfile && (
          <span className="text-[10px] font-medium text-blue-600">
            Your profile
          </span>
        )}
      </div>
    </Link>
  );
}

// Compact list-mode card variant
export function AttendeeCardCompact({
  attendee,
  eventSlug,
  className,
}: {
  attendee: DirectoryAttendee;
  eventSlug: string;
  className?: string;
}) {
  const location = [attendee.currentCity, attendee.currentCountry]
    .filter(Boolean)
    .join(", ");

  return (
    <Link
      href={`/events/${eventSlug}/attendees/${attendee.userId}`}
      className={cn(
        "flex items-center gap-3 rounded-xl border border-border bg-card px-4 py-3",
        "transition-all hover:shadow-sm hover:border-blue-200",
        className
      )}
    >
      <Avatar
        name={attendee.name}
        src={attendee.avatarUrl}
        size="sm"
        className="shrink-0"
      />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-slate-900 truncate">
          {attendee.name}
        </p>
        {(location || attendee.currentJob) && (
          <p className="text-xs text-slate-400 truncate">
            {[attendee.currentJob, location].filter(Boolean).join(" · ")}
          </p>
        )}
      </div>
      {attendee.badges.length > 0 && (
        <AttendeeBadgeList
          badges={attendee.badges}
          maxVisible={1}
          className="shrink-0"
        />
      )}
    </Link>
  );
}
