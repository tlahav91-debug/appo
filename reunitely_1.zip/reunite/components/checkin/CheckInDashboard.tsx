"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import {
  Search, QrCode, UserCheck, UserX, Users, Loader2, CheckCircle,
  AlertTriangle, ChevronDown, RefreshCcw, Smartphone, X, Camera,
  Wifi, WifiOff, RotateCcw,
} from "lucide-react";
import { Avatar } from "@/components/shared/Avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn, formatRelativeTime } from "@/lib/utils";
import { toast } from "sonner";
import {
  useAttendees,
  useCheckIn,
  useUndoCheckIn,
  useQrCheckIn,
  useCheckInStats,
} from "@/hooks/useAttendees";
import type { AttendeeRow } from "@/types";

// ─── Types ────────────────────────────────────────────────────────────────────

type CheckInMode = "list" | "qr";
type LastResult = {
  name: string;
  guestCount: number;
  ticketCode: string | null;
  alreadyCheckedIn: boolean;
  timestamp: Date;
};

// ─── Main Dashboard ───────────────────────────────────────────────────────────

export function CheckInDashboard({
  eventId,
  eventTitle,
}: {
  eventId: string;
  eventTitle: string;
}) {
  const [mode, setMode] = useState<CheckInMode>("list");
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [filter, setFilter] = useState<"ALL" | "CHECKED_IN" | "PENDING">("ALL");
  const [lastResult, setLastResult] = useState<LastResult | null>(null);

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 200);
    return () => clearTimeout(t);
  }, [search]);

  const statusFilter =
    filter === "CHECKED_IN"
      ? ["CHECKED_IN" as const]
      : filter === "PENDING"
      ? ["CONFIRMED" as const]
      : undefined;

  const { data: attendees = [], isLoading, refetch } = useAttendees(eventId, {
    search: debouncedSearch || undefined,
    status: statusFilter,
    limit: 100,
  });

  const { data: stats, refetch: refetchStats } = useCheckInStats(eventId);
  const checkIn = useCheckIn(eventId);
  const undoCheckIn = useUndoCheckIn(eventId);
  const qrCheckIn = useQrCheckIn(eventId);

  // Online/offline detection
  const [isOnline, setIsOnline] = useState(true);
  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    setIsOnline(navigator.onLine);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  async function handleCheckIn(attendee: AttendeeRow) {
    try {
      const result = await checkIn.mutateAsync(attendee.userId);
      refetchStats();
      setLastResult({
        name: attendee.user.name,
        guestCount: attendee.guestCount,
        ticketCode: null,
        alreadyCheckedIn: false,
        timestamp: new Date(),
      });
    } catch (err) {
      // Toast handled in mutation
    }
  }

  async function handleQrResult(payload: string) {
    try {
      const result = await qrCheckIn.mutateAsync(payload);
      refetchStats();
      setLastResult({
        name: result.attendeeName,
        guestCount: result.guestCount,
        ticketCode: result.ticketCode,
        alreadyCheckedIn: result.alreadyCheckedIn,
        timestamp: new Date(),
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "QR check-in failed";
      toast.error(msg);
    }
  }

  return (
    <div className="flex flex-col gap-0 min-h-screen bg-slate-50">
      {/* ── Header bar ──────────────────────────────────────────────────────── */}
      <header className="sticky top-0 z-30 border-b border-border bg-white shadow-sm">
        <div className="flex items-center gap-3 px-4 py-3">
          <div className="flex-1 min-w-0">
            <p className="text-xs text-slate-400 truncate">Event day · {eventTitle}</p>
            <div className="flex items-center gap-2 mt-0.5">
              {isOnline ? (
                <Wifi className="h-3.5 w-3.5 text-emerald-500" />
              ) : (
                <WifiOff className="h-3.5 w-3.5 text-red-400" />
              )}
              <span className="text-xs text-slate-500">
                {isOnline ? "Online" : "Offline — check-ins may not save"}
              </span>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => { refetch(); refetchStats(); }}
            className="h-8 w-8 shrink-0"
            title="Refresh"
          >
            <RefreshCcw className="h-3.5 w-3.5" />
          </Button>
        </div>

        {/* Stats bar */}
        {stats && (
          <div className="grid grid-cols-3 divide-x divide-border border-t border-border">
            {[
              { label: "Confirmed", value: stats.confirmed, color: "text-slate-900" },
              { label: "Checked in", value: stats.checkedIn, color: "text-emerald-600" },
              { label: "Remaining", value: stats.remaining, color: "text-blue-600" },
            ].map((s) => (
              <div key={s.label} className="flex flex-col items-center py-2.5">
                <p className={cn("text-xl font-bold tabular-nums", s.color)}>
                  {s.value}
                </p>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">
                  {s.label}
                </p>
              </div>
            ))}
          </div>
        )}

        {/* Progress bar */}
        {stats && stats.confirmed > 0 && (
          <div className="h-1 bg-slate-100">
            <div
              className="h-full bg-emerald-500 transition-all duration-500"
              style={{ width: `${stats.percentCheckedIn}%` }}
            />
          </div>
        )}
      </header>

      {/* ── Last check-in result ─────────────────────────────────────────────── */}
      {lastResult && (
        <div
          className={cn(
            "mx-4 mt-4 flex items-start gap-3 rounded-2xl border px-4 py-3 shadow-sm",
            lastResult.alreadyCheckedIn
              ? "border-blue-300 bg-blue-50"
              : "border-emerald-300 bg-emerald-50"
          )}
        >
          <div
            className={cn(
              "flex h-8 w-8 shrink-0 items-center justify-center rounded-full",
              lastResult.alreadyCheckedIn ? "bg-blue-100" : "bg-emerald-100"
            )}
          >
            {lastResult.alreadyCheckedIn ? (
              <AlertTriangle className="h-4 w-4 text-blue-600" />
            ) : (
              <CheckCircle className="h-4 w-4 text-emerald-600" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p
              className={cn(
                "text-sm font-semibold",
                lastResult.alreadyCheckedIn
                  ? "text-blue-900"
                  : "text-emerald-900"
              )}
            >
              {lastResult.alreadyCheckedIn
                ? "Already checked in!"
                : `✓ ${lastResult.name}`}
            </p>
            <div className="flex flex-wrap gap-2 mt-0.5">
              {lastResult.guestCount > 0 && (
                <span className="text-xs text-slate-600 flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  +{lastResult.guestCount} guest
                  {lastResult.guestCount > 1 ? "s" : ""}
                </span>
              )}
              {lastResult.ticketCode && (
                <span className="font-mono text-xs text-slate-500">
                  {lastResult.ticketCode}
                </span>
              )}
            </div>
          </div>
          <button
            onClick={() => setLastResult(null)}
            className="shrink-0 text-slate-400 hover:text-slate-600"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* ── Mode toggle ─────────────────────────────────────────────────────── */}
      <div className="flex gap-2 px-4 pt-4 pb-2">
        <button
          onClick={() => setMode("list")}
          className={cn(
            "flex flex-1 items-center justify-center gap-2 rounded-xl border py-2.5 text-sm font-medium transition-all",
            mode === "list"
              ? "border-blue-400 bg-blue-50 text-blue-700"
              : "border-border bg-white text-slate-600 hover:border-blue-300"
          )}
        >
          <Search className="h-4 w-4" />
          Manual / Search
        </button>
        <button
          onClick={() => setMode("qr")}
          className={cn(
            "flex flex-1 items-center justify-center gap-2 rounded-xl border py-2.5 text-sm font-medium transition-all",
            mode === "qr"
              ? "border-blue-400 bg-blue-50 text-blue-700"
              : "border-border bg-white text-slate-600 hover:border-blue-300"
          )}
        >
          <QrCode className="h-4 w-4" />
          QR Scan
        </button>
      </div>

      {/* ── QR scanner mode ─────────────────────────────────────────────────── */}
      {mode === "qr" && (
        <QrScannerPanel
          onScan={handleQrResult}
          isProcessing={qrCheckIn.isPending}
        />
      )}

      {/* ── List mode ───────────────────────────────────────────────────────── */}
      {mode === "list" && (
        <div className="flex flex-col gap-3 px-4 pb-8">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              placeholder="Search by name or email…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-11 pl-10 text-sm rounded-xl border-border bg-white"
              autoComplete="off"
              autoCorrect="off"
              spellCheck={false}
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Status filter chips */}
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
            {(["ALL", "PENDING", "CHECKED_IN"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={cn(
                  "shrink-0 rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all",
                  filter === f
                    ? "border-blue-600 bg-blue-500 text-white"
                    : "border-border bg-white text-slate-600 hover:border-blue-300"
                )}
              >
                {f === "ALL" ? "All" : f === "PENDING" ? "Not checked in" : "Checked in"}
              </button>
            ))}
          </div>

          {/* Attendee list */}
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-slate-300" />
            </div>
          ) : attendees.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center">
              <Users className="h-8 w-8 text-slate-300" />
              <p className="text-sm text-slate-400">
                {search ? `No results for "${search}"` : "No attendees found"}
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {attendees.map((attendee) => (
                <AttendeeCheckInRow
                  key={attendee.userId}
                  attendee={attendee}
                  onCheckIn={() => handleCheckIn(attendee)}
                  onUndo={() => undoCheckIn.mutate(attendee.userId)}
                  isChecking={
                    checkIn.isPending && checkIn.variables === attendee.userId
                  }
                  isUndoing={
                    undoCheckIn.isPending &&
                    undoCheckIn.variables === attendee.userId
                  }
                />
              ))}
              {attendees.length >= 100 && (
                <p className="text-center text-xs text-slate-400 py-2">
                  Showing first 100 results. Use search to narrow down.
                </p>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Attendee row ─────────────────────────────────────────────────────────────

function AttendeeCheckInRow({
  attendee,
  onCheckIn,
  onUndo,
  isChecking,
  isUndoing,
}: {
  attendee: AttendeeRow;
  onCheckIn: () => void;
  onUndo: () => void;
  isChecking: boolean;
  isUndoing: boolean;
}) {
  const isCheckedIn = !!attendee.checkedInAt;
  const [showGuests, setShowGuests] = useState(false);

  return (
    <div
      className={cn(
        "rounded-2xl border bg-white transition-all",
        isCheckedIn
          ? "border-emerald-200 bg-emerald-50/30"
          : "border-border shadow-sm"
      )}
    >
      <div className="flex items-center gap-3 px-4 py-3">
        {/* Avatar + check indicator */}
        <div className="relative shrink-0">
          <Avatar
            name={attendee.user.name}
            src={attendee.user.avatarUrl}
            size="md"
          />
          {isCheckedIn && (
            <div className="absolute -bottom-0.5 -right-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 ring-2 ring-white">
              <CheckCircle className="h-3 w-3 text-white" />
            </div>
          )}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="text-sm font-semibold text-slate-900 truncate">
              {attendee.user.name}
            </p>
            {attendee.guestCount > 0 && (
              <button
                onClick={() => setShowGuests((v) => !v)}
                className="flex items-center gap-0.5 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-600 hover:bg-slate-200 transition-colors"
              >
                <Users className="h-2.5 w-2.5" />
                +{attendee.guestCount}
              </button>
            )}
          </div>
          {isCheckedIn && attendee.checkedInAt ? (
            <p className="text-xs text-emerald-600 mt-0.5">
              Checked in {formatRelativeTime(new Date(attendee.checkedInAt))}
            </p>
          ) : (
            <p className="text-xs text-slate-400 truncate">
              {attendee.user.email}
            </p>
          )}
        </div>

        {/* Action */}
        {isCheckedIn ? (
          <button
            onClick={onUndo}
            disabled={isUndoing}
            className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs text-slate-500 hover:border-red-300 hover:text-red-500 transition-colors disabled:opacity-50"
            title="Undo check-in"
          >
            {isUndoing ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <RotateCcw className="h-3.5 w-3.5" />
            )}
          </button>
        ) : (
          <button
            onClick={onCheckIn}
            disabled={isChecking}
            className={cn(
              "flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition-all",
              isChecking
                ? "bg-slate-100 text-slate-400"
                : "bg-blue-500 text-white shadow-sm hover:bg-blue-700 active:scale-95"
            )}
          >
            {isChecking ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <UserCheck className="h-4 w-4" />
            )}
            Check in
          </button>
        )}
      </div>

      {/* Guest names accordion */}
      {showGuests && attendee.guestNames.length > 0 && (
        <div className="border-t border-slate-100 px-4 pb-3 pt-2">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
            Guests
          </p>
          <div className="flex flex-col gap-1">
            {attendee.guestNames.map((name, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-slate-600">
                <div className="h-5 w-5 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-500 shrink-0">
                  {i + 1}
                </div>
                {name || `Guest ${i + 1}`}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── QR Scanner Panel ─────────────────────────────────────────────────────────

function QrScannerPanel({
  onScan,
  isProcessing,
}: {
  onScan: (payload: string) => void;
  isProcessing: boolean;
}) {
  const [manualEntry, setManualEntry] = useState("");
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [scanning, setScanning] = useState(false);

  // Start camera
  useEffect(() => {
    let cancelled = false;
    async function startCamera() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
        });
        if (cancelled) { stream.getTracks().forEach((t) => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
        setScanning(true);
      } catch (err) {
        if (!cancelled) {
          setCameraError(
            "Camera access denied. Use manual entry below, or allow camera access and refresh."
          );
        }
      }
    }
    startCamera();
    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  // QR decode loop using BarcodeDetector API (supported in Chrome/Android)
  useEffect(() => {
    if (!scanning || !videoRef.current) return;

    const BarcodeDetector = (window as unknown as { BarcodeDetector?: new (opts: object) => { detect: (img: HTMLVideoElement) => Promise<Array<{ rawValue: string }>> } }).BarcodeDetector;
    if (!BarcodeDetector) return; // fallback to manual entry

    const detector = new BarcodeDetector({ formats: ["qr_code"] });
    let active = true;
    let lastPayload = "";

    async function scan() {
      if (!active || !videoRef.current || isProcessing) return;
      try {
        const results = await detector.detect(videoRef.current);
        if (results.length > 0 && results[0]!.rawValue !== lastPayload) {
          lastPayload = results[0]!.rawValue;
          onScan(lastPayload);
          // Brief cooldown to prevent double-scan
          await new Promise((r) => setTimeout(r, 2000));
          lastPayload = "";
        }
      } catch {
        // ignore decode errors
      }
      if (active) requestAnimationFrame(scan);
    }
    requestAnimationFrame(scan);

    return () => { active = false; };
  }, [scanning, isProcessing, onScan]);

  function handleManualSubmit() {
    const trimmed = manualEntry.trim();
    if (!trimmed) return;
    onScan(trimmed);
    setManualEntry("");
  }

  return (
    <div className="flex flex-col gap-4 px-4 pb-8">
      {/* Camera viewport */}
      <div className="relative overflow-hidden rounded-2xl bg-black aspect-square max-h-[65vw] mx-auto w-full">
        {cameraError ? (
          <div className="flex flex-col items-center justify-center h-full gap-3 p-6 text-center">
            <Camera className="h-10 w-10 text-slate-500" />
            <p className="text-sm text-slate-400">{cameraError}</p>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              className="h-full w-full object-cover"
              muted
              playsInline
            />
            {/* Scan overlay */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative h-48 w-48">
                {/* Corner brackets */}
                {[
                  "top-0 left-0 border-t-4 border-l-4 rounded-tl-xl",
                  "top-0 right-0 border-t-4 border-r-4 rounded-tr-xl",
                  "bottom-0 left-0 border-b-4 border-l-4 rounded-bl-xl",
                  "bottom-0 right-0 border-b-4 border-r-4 rounded-br-xl",
                ].map((cls) => (
                  <div
                    key={cls}
                    className={`absolute h-10 w-10 border-blue-400 ${cls}`}
                  />
                ))}
              </div>
            </div>
            {isProcessing && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                <Loader2 className="h-8 w-8 animate-spin text-white" />
              </div>
            )}
            {scanning && !isProcessing && (
              <div className="absolute bottom-3 left-0 right-0 flex justify-center">
                <div className="rounded-full bg-black/60 px-3 py-1 text-xs text-white">
                  Point at attendee's QR code
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Manual entry fallback */}
      <div className="flex flex-col gap-2">
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 text-center">
          Or enter ticket code manually
        </p>
        <div className="flex gap-2">
          <Input
            placeholder="RUN-XXXXX-XXXXX"
            value={manualEntry}
            onChange={(e) => setManualEntry(e.target.value.toUpperCase())}
            onKeyDown={(e) => e.key === "Enter" && handleManualSubmit()}
            className="font-mono text-sm uppercase"
            autoComplete="off"
          />
          <Button
            onClick={handleManualSubmit}
            disabled={!manualEntry.trim() || isProcessing}
            className="shrink-0 bg-blue-500 hover:bg-blue-700"
          >
            {isProcessing ? <Loader2 className="h-4 w-4 animate-spin" /> : "Go"}
          </Button>
        </div>
      </div>

      {/* Offline strategy note */}
      <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-4">
        <p className="text-xs font-semibold text-slate-600 mb-1">📶 Offline strategy</p>
        <p className="text-xs text-slate-500 leading-relaxed">
          If connectivity is lost, ticket codes can still be visually verified against
          attendee printouts. QR payloads contain a HMAC signature for offline validation —
          scan even without internet and sync later when reconnected.
        </p>
      </div>
    </div>
  );
}
