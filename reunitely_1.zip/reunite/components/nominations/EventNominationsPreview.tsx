import { db } from "@/lib/db";
import { EmptyState } from "@/components/shared/EmptyState";
import { Trophy } from "lucide-react";
import { Avatar } from "@/components/shared/Avatar";

interface EventNominationsPreviewProps {
  eventId: string;
}

export async function EventNominationsPreview({
  eventId,
}: EventNominationsPreviewProps) {
  const categories = await db.nominationCategory.findMany({
    where: { eventId },
    include: {
      nominations: {
        where: { status: "ACCEPTED" },
        include: {
          nominee: {
            select: { id: true, name: true, avatarUrl: true },
          },
        },
      },
      _count: { select: { votes: true } },
    },
    orderBy: { id: "asc" },
    take: 6,
  });

  if (categories.length === 0) {
    return (
      <EmptyState
        icon={<Trophy className="h-8 w-8" />}
        title="Nominations coming soon"
        description="The organizer hasn't opened nominations yet. Check back later!"
        size="md"
      />
    );
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {categories.map((category) => {
        const isRevealed = !!category.resultsRevealedAt;
        const isVotingOpen =
          category.votingOpenAt &&
          new Date(category.votingOpenAt) <= new Date() &&
          (!category.votingClosedAt ||
            new Date(category.votingClosedAt) > new Date());

        return (
          <div
            key={category.id}
            className="rounded-xl border border-border bg-card p-5"
          >
            <div className="mb-3 flex items-center gap-2">
              <Trophy className="h-4 w-4 text-blue-500" />
              <h3 className="font-semibold text-slate-900 text-sm">
                {category.title}
              </h3>
            </div>

            {category.description && (
              <p className="mb-3 text-xs text-slate-500">
                {category.description}
              </p>
            )}

            {/* Nominees */}
            {category.nominations.length > 0 ? (
              <div className="flex flex-col gap-2">
                {category.nominations.slice(0, 3).map((nomination) => (
                  <div
                    key={nomination.id}
                    className="flex items-center gap-2"
                  >
                    <Avatar
                      name={nomination.nominee.name}
                      src={nomination.nominee.avatarUrl}
                      size="xs"
                    />
                    <span className="text-sm text-slate-700">
                      {nomination.nominee.name}
                    </span>
                    {isRevealed && (
                      <span className="ml-auto text-xs text-blue-600 font-semibold">
                        👑
                      </span>
                    )}
                  </div>
                ))}
                {category.nominations.length > 3 && (
                  <p className="text-xs text-slate-400">
                    +{category.nominations.length - 3} more nominees
                  </p>
                )}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">
                No nominees yet
              </p>
            )}

            {/* Status pill */}
            <div className="mt-3">
              {isRevealed ? (
                <span className="inline-flex items-center rounded-full bg-blue-50 px-2 py-0.5 text-[11px] font-medium text-blue-700">
                  Results revealed
                </span>
              ) : isVotingOpen ? (
                <span className="inline-flex items-center rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-medium text-emerald-700">
                  Voting open
                </span>
              ) : (
                <span className="inline-flex items-center rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-500">
                  {category._count.votes} vote{category._count.votes !== 1 ? "s" : ""}
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
