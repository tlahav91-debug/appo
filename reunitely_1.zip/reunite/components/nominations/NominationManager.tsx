"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Trophy, Plus, Eye, Lock, Unlock, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState } from "@/components/shared/EmptyState";
import { Avatar } from "@/components/shared/Avatar";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Category {
  id: string;
  title: string;
  description: string | null;
  votingOpenAt: string | null;
  votingClosedAt: string | null;
  resultsRevealedAt: string | null;
  nominations: Array<{
    id: string;
    status: "PENDING" | "ACCEPTED" | "DECLINED";
    nominee: { id: string; name: string; avatarUrl: string | null };
    _count?: { votes: number };
  }>;
  _count: { votes: number };
}

async function fetchCategories(eventId: string): Promise<Category[]> {
  const res = await fetch(`/api/events/${eventId}/nominations/categories`);
  if (!res.ok) throw new Error("Failed to load categories");
  return (await res.json()).data ?? [];
}

export function NominationManager({ eventId }: { eventId: string }) {
  const queryClient = useQueryClient();
  const [createOpen, setCreateOpen] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const { data: categories = [], isLoading } = useQuery<Category[]>({
    queryKey: ["nomination-categories", eventId],
    queryFn: () => fetchCategories(eventId),
  });

  const revealMutation = useMutation({
    mutationFn: async (categoryId: string) => {
      const res = await fetch(
        `/api/events/${eventId}/nominations/categories/${categoryId}/reveal`,
        { method: "POST" }
      );
      if (!res.ok) throw new Error("Failed to reveal results");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["nomination-categories", eventId],
      });
      toast.success("Results revealed!");
    },
    onError: () => toast.error("Failed to reveal results"),
  });

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-20 animate-pulse rounded-xl bg-slate-100" />
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Toolbar */}
      <div className="flex justify-end">
        <Button
          size="sm"
          className="gap-2"
          onClick={() => setCreateOpen(true)}
        >
          <Plus className="h-4 w-4" />
          Add Category
        </Button>
      </div>

      {categories.length === 0 ? (
        <EmptyState
          icon={<Trophy className="h-8 w-8" />}
          title="No nomination categories yet"
          description="Create categories like 'Best Glow-Up' or 'Most Likely to Be President' to engage your attendees."
          action={{ label: "Add First Category", onClick: () => setCreateOpen(true) }}
          size="lg"
        />
      ) : (
        <div className="flex flex-col gap-3">
          {categories.map((cat) => {
            const isExpanded = expandedId === cat.id;
            const acceptedNominees = cat.nominations.filter(
              (n) => n.status === "ACCEPTED"
            );
            const pendingNominees = cat.nominations.filter(
              (n) => n.status === "PENDING"
            );
            const isRevealed = !!cat.resultsRevealedAt;
            const votingOpen =
              cat.votingOpenAt &&
              new Date(cat.votingOpenAt) <= new Date() &&
              (!cat.votingClosedAt ||
                new Date(cat.votingClosedAt) > new Date());

            return (
              <div
                key={cat.id}
                className="rounded-xl border border-border bg-card shadow-card"
              >
                {/* Category header */}
                <button
                  type="button"
                  onClick={() =>
                    setExpandedId(isExpanded ? null : cat.id)
                  }
                  className="flex w-full items-center justify-between px-4 py-4 text-left"
                  aria-expanded={isExpanded}
                >
                  <div className="flex items-center gap-3">
                    <Trophy className="h-4 w-4 text-blue-500 shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-900">
                        {cat.title}
                      </p>
                      {cat.description && (
                        <p className="text-xs text-slate-500 mt-0.5">
                          {cat.description}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {/* Status chips */}
                    {isRevealed ? (
                      <span className="rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-semibold text-blue-700">
                        Results revealed
                      </span>
                    ) : votingOpen ? (
                      <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-700">
                        Voting open
                      </span>
                    ) : null}
                    <span className="text-xs text-slate-400">
                      {acceptedNominees.length} nominee
                      {acceptedNominees.length !== 1 ? "s" : ""} · {cat._count.votes} vote
                      {cat._count.votes !== 1 ? "s" : ""}
                    </span>
                    {isExpanded ? (
                      <ChevronUp className="h-4 w-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-slate-400" />
                    )}
                  </div>
                </button>

                {/* Expanded content */}
                {isExpanded && (
                  <div className="border-t border-border px-4 py-4 space-y-4">
                    {/* Nominees grid */}
                    {acceptedNominees.length > 0 ? (
                      <div>
                        <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
                          Accepted Nominees ({acceptedNominees.length})
                        </p>
                        <div className="flex flex-wrap gap-3">
                          {acceptedNominees.map((nom) => (
                            <div
                              key={nom.id}
                              className="flex items-center gap-2 rounded-lg border border-border bg-slate-50 px-3 py-2"
                            >
                              <Avatar
                                name={nom.nominee.name}
                                src={nom.nominee.avatarUrl}
                                size="xs"
                              />
                              <span className="text-sm text-slate-700">
                                {nom.nominee.name}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <p className="text-sm text-slate-400 italic">
                        No accepted nominees yet. Attendees can nominate their classmates.
                      </p>
                    )}

                    {pendingNominees.length > 0 && (
                      <p className="text-xs text-blue-600">
                        {pendingNominees.length} nomination
                        {pendingNominees.length !== 1 ? "s" : ""} pending
                        acceptance
                      </p>
                    )}

                    {/* Actions */}
                    <div className="flex flex-wrap gap-2 pt-1">
                      {!isRevealed && acceptedNominees.length > 0 && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-2"
                          onClick={() => revealMutation.mutate(cat.id)}
                          disabled={revealMutation.isPending}
                        >
                          {revealMutation.isPending ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <Eye className="h-3.5 w-3.5" />
                          )}
                          Reveal Results
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <CreateCategoryDialog
        eventId={eventId}
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        onCreated={() =>
          queryClient.invalidateQueries({
            queryKey: ["nomination-categories", eventId],
          })
        }
      />
    </div>
  );
}

// ─── CreateCategoryDialog ─────────────────────────────────────────────────────

function CreateCategoryDialog({
  eventId,
  open,
  onClose,
  onCreated,
}: {
  eventId: string;
  open: boolean;
  onClose: () => void;
  onCreated: () => void;
}) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  async function handleCreate() {
    if (!title.trim()) {
      toast.error("Category title is required");
      return;
    }
    setIsCreating(true);
    try {
      const res = await fetch(`/api/events/${eventId}/nominations/categories`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: title.trim(), description: description.trim() || undefined }),
      });
      if (!res.ok) throw new Error("Failed to create category");
      toast.success("Category created!");
      onCreated();
      onClose();
      setTitle("");
      setDescription("");
    } catch {
      toast.error("Failed to create category");
    } finally {
      setIsCreating(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>New Nomination Category</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-4 py-2">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cat-title">Category name *</Label>
            <Input
              id="cat-title"
              placeholder="e.g. Best Glow-Up"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              autoFocus
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cat-desc">Description (optional)</Label>
            <Input
              id="cat-desc"
              placeholder="e.g. Who has changed the most for the better?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" onClick={onClose} disabled={isCreating}>
              Cancel
            </Button>
            <Button
              onClick={handleCreate}
              disabled={isCreating || !title.trim()}
            >
              {isCreating ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Create Category
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
