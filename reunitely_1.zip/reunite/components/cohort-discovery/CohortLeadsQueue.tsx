"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  CheckCircle2, XCircle, AlertTriangle, Send, Search,
  ChevronDown, ChevronUp, Loader2, Users, Shield, Link,
  ArrowRight, MoreHorizontal, Copy, Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar } from "@/components/shared/Avatar";
import { EmptyState } from "@/components/shared/EmptyState";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { formatRelativeTime, cn } from "@/lib/utils";

// ─── Types ────────────────────────────────────────────────────────────────────

type LeadStatus = "PENDING" | "APPROVED" | "REJECTED" | "DUPLICATE" | "INVITED" | "RSVPD";

interface Lead {
  id: string;
  fullName: string;
  emailHint: string | null;
  phoneHint: string | null;
  socialHint: string | null;
  schoolConnection: string;
  graduationYear: number | null;
  knownSince: string | null;
  submitterNote: string | null;
  status: LeadStatus;
  confidenceScore: number;
  adminNote: string | null;
  rejectionReason: string | null;
  createdAt: string;
  reviewedAt: string | null;
  inviteId: string | null;
  submittedBy: { id: string; name: string; avatarUrl: string | null; email: string };
  reviewedBy: { name: string; avatarUrl: string | null } | null;
  duplicateOf: { id: string; fullName: string } | null;
}

interface LeadStats {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
  duplicate: number;
  invited: number;
  rsvpd: number;
}

// ─── Status config ────────────────────────────────────────────────────────────

const STATUS_CONFIG: Record<LeadStatus, { label: string; className: string; icon: React.ElementType }> = {
  PENDING:   { label: "Pending review", className: "bg-blue-50 text-blue-700 border-blue-200", icon: AlertTriangle },
  APPROVED:  { label: "Approved",       className: "bg-emerald-50 text-emerald-700 border-emerald-200", icon: CheckCircle2 },
  REJECTED:  { label: "Rejected",       className: "bg-red-50 text-red-600 border-red-200", icon: XCircle },
  DUPLICATE: { label: "Duplicate",      className: "bg-slate-100 text-slate-500 border-slate-200", icon: Copy },
  INVITED:   { label: "Invited",        className: "bg-blue-50 text-blue-700 border-blue-200", icon: Send },
  RSVPD:     { label: "RSVP'd",        className: "bg-violet-50 text-violet-700 border-violet-200", icon: CheckCircle2 },
};

// ─── Fetchers ─────────────────────────────────────────────────────────────────

async function fetchLeads(eventId: string, status?: string, search?: string): Promise<Lead[]> {
  const params = new URLSearchParams();
  if (status) params.set("status", status);
  if (search) params.set("search", search);
  const res = await fetch(`/api/events/${eventId}/cohort-leads?${params}`);
  if (!res.ok) throw new Error("Failed to load leads");
  return (await res.json()).data ?? [];
}

async function fetchStats(eventId: string): Promise<LeadStats> {
  const res = await fetch(`/api/events/${eventId}/cohort-leads?stats=1`);
  if (!res.ok) throw new Error("Failed to load stats");
  return (await res.json()).data;
}

async function reviewLead(
  eventId: string,
  leadId: string,
  data: { status: string; adminNote?: string; rejectionReason?: string }
) {
  const res = await fetch(`/api/events/${eventId}/cohort-leads/${leadId}/review`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const json = await res.json().catch(() => ({}));
    throw new Error(json.error?.message ?? "Failed to review lead");
  }
}

async function convertLead(eventId: string, leadId: string) {
  const res = await fetch(`/api/events/${eventId}/cohort-leads/${leadId}/convert`, {
    method: "POST",
  });
  if (!res.ok) {
    const json = await res.json().catch(() => ({}));
    throw new Error(json.error?.message ?? "Failed to convert lead");
  }
  return res.json();
}

async function bulkConvert(eventId: string) {
  const res = await fetch(`/api/events/${eventId}/cohort-leads/bulk/convert`, {
    method: "POST",
  });
  if (!res.ok) throw new Error("Bulk convert failed");
  return res.json();
}

// ─── Component ────────────────────────────────────────────────────────────────

export function CohortLeadsQueue({ eventId }: { eventId: string }) {
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<string>("PENDING");
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  const { data: stats } = useQuery<LeadStats>({
    queryKey: ["cohort-lead-stats", eventId],
    queryFn: () => fetchStats(eventId),
    staleTime: 30_000,
  });

  const { data: leads = [], isLoading } = useQuery<Lead[]>({
    queryKey: ["cohort-leads", eventId, statusFilter, debouncedSearch],
    queryFn: () => fetchLeads(eventId, statusFilter || undefined, debouncedSearch || undefined),
    staleTime: 15_000,
  });

  const reviewMutation = useMutation({
    mutationFn: ({ leadId, data }: { leadId: string; data: Parameters<typeof reviewLead>[2] }) =>
      reviewLead(eventId, leadId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cohort-leads", eventId] });
      queryClient.invalidateQueries({ queryKey: ["cohort-lead-stats", eventId] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const convertMutation = useMutation({
    mutationFn: (leadId: string) => convertLead(eventId, leadId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cohort-leads", eventId] });
      queryClient.invalidateQueries({ queryKey: ["cohort-lead-stats", eventId] });
      toast.success("Invite sent!");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const STATUS_FILTERS = [
    { label: "Pending", value: "PENDING", count: stats?.pending },
    { label: "Approved", value: "APPROVED", count: stats?.approved },
    { label: "Invited", value: "INVITED", count: stats?.invited },
    { label: "Rejected", value: "REJECTED", count: stats?.rejected },
    { label: "Duplicate", value: "DUPLICATE", count: stats?.duplicate },
    { label: "All", value: "", count: stats?.total },
  ];

  return (
    <div className="flex flex-col gap-5">
      {/* Stats summary */}
      {stats && stats.total > 0 && (
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
          {[
            { label: "Total", value: stats.total, color: "text-slate-900" },
            { label: "Pending", value: stats.pending, color: "text-blue-600" },
            { label: "Approved", value: stats.approved, color: "text-emerald-600" },
            { label: "Invited", value: stats.invited, color: "text-blue-600" },
            { label: "RSVP'd", value: stats.rsvpd, color: "text-violet-600" },
            { label: "Rejected", value: stats.rejected, color: "text-slate-400" },
          ].map(({ label, value, color }) => (
            <div key={label} className="rounded-xl border border-border bg-card p-3 text-center">
              <p className={cn("font-display text-2xl font-bold", color)}>{value}</p>
              <p className="text-[10px] text-slate-400 mt-0.5">{label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Bulk convert */}
      {(stats?.approved ?? 0) > 0 && (
        <div className="flex items-center justify-between rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3">
          <div className="flex items-center gap-2">
            <Send className="h-4 w-4 text-emerald-600" />
            <span className="text-sm font-medium text-emerald-800">
              {stats!.approved} approved lead{stats!.approved !== 1 ? "s" : ""} ready to invite
            </span>
          </div>
          <Button
            size="sm"
            className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white shrink-0"
            onClick={() => {
              bulkConvert(eventId)
                .then((res) => {
                  queryClient.invalidateQueries({ queryKey: ["cohort-leads", eventId] });
                  queryClient.invalidateQueries({ queryKey: ["cohort-lead-stats", eventId] });
                  toast.success(`${res.data?.converted ?? 0} invite${res.data?.converted !== 1 ? "s" : ""} sent`);
                })
                .catch(() => toast.error("Bulk convert failed"));
            }}
          >
            Send all invites
            <ArrowRight className="h-3.5 w-3.5" />
          </Button>
        </div>
      )}

      {/* Filters + search */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <Input
            placeholder="Search by name or email…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              clearTimeout((window as any).__leadSearchTimer);
              (window as any).__leadSearchTimer = setTimeout(
                () => setDebouncedSearch(e.target.value),
                300
              );
            }}
            className="pl-9"
          />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {STATUS_FILTERS.map(({ label, value, count }) => (
            <button
              key={value || "all"}
              type="button"
              onClick={() => setStatusFilter(value)}
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                statusFilter === value
                  ? "border-blue-600 bg-blue-50 text-blue-700"
                  : "border-border text-slate-600 hover:border-blue-300"
              )}
            >
              {label}
              {count !== undefined && count > 0 && (
                <span className="ml-1.5 rounded-full bg-slate-200 px-1.5 py-0.5 text-[10px]">
                  {count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Lead list */}
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-slate-300" />
        </div>
      ) : leads.length === 0 ? (
        <EmptyState
          icon={<Users className="h-8 w-8" />}
          title={
            statusFilter === "PENDING"
              ? "No nominations pending"
              : `No ${statusFilter.toLowerCase()} nominations`
          }
          description={
            statusFilter === "PENDING"
              ? "When attendees nominate missing classmates, they'll appear here for review."
              : "Change the filter to see other nominations."
          }
          size="md"
        />
      ) : (
        <div className="flex flex-col gap-3">
          {leads.map((lead) => (
            <LeadCard
              key={lead.id}
              lead={lead}
              eventId={eventId}
              onApprove={(note) =>
                reviewMutation.mutate({ leadId: lead.id, data: { status: "APPROVED", adminNote: note } })
              }
              onReject={(reason, note) =>
                reviewMutation.mutate({
                  leadId: lead.id,
                  data: { status: "REJECTED", rejectionReason: reason, adminNote: note },
                })
              }
              onMarkDuplicate={() =>
                reviewMutation.mutate({
                  leadId: lead.id,
                  data: { status: "DUPLICATE", adminNote: "Marked as duplicate" },
                })
              }
              onConvert={() => convertMutation.mutate(lead.id)}
              isReviewing={reviewMutation.isPending && reviewMutation.variables?.leadId === lead.id}
              isConverting={convertMutation.isPending && convertMutation.variables === lead.id}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Lead card ────────────────────────────────────────────────────────────────

function LeadCard({
  lead,
  eventId,
  onApprove,
  onReject,
  onMarkDuplicate,
  onConvert,
  isReviewing,
  isConverting,
}: {
  lead: Lead;
  eventId: string;
  onApprove: (note?: string) => void;
  onReject: (reason: string, note?: string) => void;
  onMarkDuplicate: () => void;
  onConvert: () => void;
  isReviewing: boolean;
  isConverting: boolean;
}) {
  const [expanded, setExpanded] = useState(lead.status === "PENDING");
  const [rejectReason, setRejectReason] = useState("");
  const [adminNote, setAdminNote] = useState(lead.adminNote ?? "");
  const [showRejectForm, setShowRejectForm] = useState(false);

  const statusCfg = STATUS_CONFIG[lead.status];
  const StatusIcon = statusCfg.icon;
  const hasContact = lead.emailHint || lead.phoneHint;
  const isPending = lead.status === "PENDING";
  const isApproved = lead.status === "APPROVED";

  return (
    <div className={cn(
      "overflow-hidden rounded-2xl border bg-card transition-shadow",
      isPending ? "border-blue-200 shadow-sm shadow-blue-50" : "border-border"
    )}>
      {/* Header — always visible */}
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="flex w-full items-center gap-4 p-4 text-left hover:bg-slate-50/60 transition-colors"
      >
        <Avatar name={lead.fullName} size="md" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-sm font-semibold text-slate-900">{lead.fullName}</p>
            <span className={cn(
              "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold",
              statusCfg.className
            )}>
              <StatusIcon className="h-3 w-3" />
              {statusCfg.label}
            </span>
            {/* Confidence score */}
            <span className="text-[10px] text-slate-400">
              {lead.confidenceScore}% confidence
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Nominated by {lead.submittedBy.name} · {formatRelativeTime(new Date(lead.createdAt))}
            {lead.graduationYear && ` · Class of ${lead.graduationYear}`}
          </p>
        </div>
        {expanded ? (
          <ChevronUp className="h-4 w-4 text-slate-400 shrink-0" />
        ) : (
          <ChevronDown className="h-4 w-4 text-slate-400 shrink-0" />
        )}
      </button>

      {/* Expanded body */}
      {expanded && (
        <div className="border-t border-border px-5 pb-5 pt-4 flex flex-col gap-4">
          {/* School connection */}
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">
              School connection
            </p>
            <p className="text-sm text-slate-700 bg-slate-50 rounded-lg px-3 py-2 border border-border">
              {lead.schoolConnection}
            </p>
            {lead.knownSince && (
              <p className="text-xs text-slate-400 mt-1">Known since: {lead.knownSince}</p>
            )}
          </div>

          {/* Contact info — organizer only */}
          <div className="rounded-xl border border-blue-200 bg-blue-50 p-3">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="h-3.5 w-3.5 text-blue-500" />
              <span className="text-xs font-semibold text-blue-700 uppercase tracking-wide">
                Contact info (private)
              </span>
            </div>
            <div className="space-y-1 text-sm">
              {lead.emailHint ? (
                <div className="flex items-center gap-2">
                  <span className="text-blue-600 text-xs font-medium w-12">Email</span>
                  <span className="text-blue-800 font-mono text-xs">{lead.emailHint}</span>
                </div>
              ) : (
                <p className="text-[11px] text-blue-500 italic">No email provided</p>
              )}
              {lead.phoneHint && (
                <div className="flex items-center gap-2">
                  <span className="text-blue-600 text-xs font-medium w-12">Phone</span>
                  <span className="text-blue-800 font-mono text-xs">{lead.phoneHint}</span>
                </div>
              )}
              {lead.socialHint && (
                <div className="flex items-center gap-2">
                  <span className="text-blue-600 text-xs font-medium w-12">Social</span>
                  <a
                    href={lead.socialHint}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-700 text-xs hover:underline truncate max-w-[220px]"
                  >
                    {lead.socialHint}
                  </a>
                </div>
              )}
              {!hasContact && !lead.socialHint && (
                <p className="text-[11px] text-blue-600 italic">
                  ⚠️ No contact info — cannot invite without adding email or phone.
                </p>
              )}
            </div>
          </div>

          {/* Submitter note */}
          {lead.submitterNote && (
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">
                Note from submitter
              </p>
              <p className="text-sm text-slate-600 italic">"{lead.submitterNote}"</p>
            </div>
          )}

          {/* Duplicate warning */}
          {lead.duplicateOf && (
            <div className="rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-xs text-blue-800">
              ⚠️ May be duplicate of:{" "}
              <span className="font-semibold">{lead.duplicateOf.fullName}</span>
            </div>
          )}

          {/* Admin note */}
          {lead.adminNote && (
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">
                Admin note
              </p>
              <p className="text-sm text-slate-600">{lead.adminNote}</p>
            </div>
          )}

          {/* Rejection reason */}
          {lead.rejectionReason && (
            <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-800">
              Rejected: {lead.rejectionReason}
            </div>
          )}

          {/* Actions */}
          {isPending && !showRejectForm && (
            <div className="flex flex-wrap gap-2 pt-1">
              <Button
                size="sm"
                className="gap-2"
                onClick={() => onApprove(adminNote || undefined)}
                disabled={isReviewing}
              >
                {isReviewing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                Approve
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="gap-2 text-red-600 border-red-200 hover:bg-red-50"
                onClick={() => setShowRejectForm(true)}
              >
                <XCircle className="h-3.5 w-3.5" />
                Reject
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="gap-2 text-slate-500"
                onClick={onMarkDuplicate}
                disabled={isReviewing}
              >
                <Copy className="h-3.5 w-3.5" />
                Duplicate
              </Button>
            </div>
          )}

          {/* Reject form */}
          {isPending && showRejectForm && (
            <div className="flex flex-col gap-3 rounded-xl border border-red-200 bg-red-50 p-4">
              <p className="text-sm font-semibold text-red-800">Reason for rejection</p>
              <Input
                placeholder="e.g. Insufficient school connection info, looks like spam"
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="bg-white border-red-200"
                autoFocus
              />
              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="gap-2 bg-red-600 hover:bg-red-700 text-white"
                  disabled={!rejectReason.trim() || isReviewing}
                  onClick={() => {
                    onReject(rejectReason);
                    setShowRejectForm(false);
                  }}
                >
                  Confirm rejection
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShowRejectForm(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}

          {/* Convert to invite */}
          {isApproved && !lead.inviteId && (
            <div className="flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 p-3">
              <div className="flex-1 text-sm text-emerald-800">
                {hasContact
                  ? "Ready to invite — send a personal invite now."
                  : "Approved, but no contact info. Add email/phone to invite."}
              </div>
              {hasContact && (
                <Button
                  size="sm"
                  className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white shrink-0"
                  onClick={onConvert}
                  disabled={isConverting}
                >
                  {isConverting ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Send className="h-3.5 w-3.5" />
                  )}
                  Send invite
                </Button>
              )}
            </div>
          )}

          {lead.inviteId && (
            <div className="flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-xs text-blue-700">
              <Send className="h-3.5 w-3.5" />
              Invite sent
            </div>
          )}
        </div>
      )}
    </div>
  );
}
