"use client";

import { useState, useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form, FormField, FormItem, FormLabel, FormControl, FormDescription, FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  UserPlus, CheckCircle2, AlertCircle, Shield, ArrowRight,
  ChevronLeft, Loader2, Eye, Lock,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const schema = z.object({
  fullName: z.string().min(2, "Full name is required").max(120).trim(),
  emailHint: z.string().email("Must be a valid email").optional().or(z.literal("")),
  phoneHint: z.string().max(30).optional().or(z.literal("")),
  socialHint: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  schoolConnection: z
    .string()
    .min(10, "Please tell us how you know this person from school (at least 10 characters)")
    .max(500)
    .trim(),
  graduationYear: z.coerce.number().int().min(1950).max(2100).optional(),
  knownSince: z.string().max(100).optional().or(z.literal("")),
  submitterNote: z.string().max(500).optional().or(z.literal("")),
  consentGiven: z.literal(true, {
    errorMap: () => ({
      message: "You must confirm before submitting.",
    }),
  }),
});

type FormData = z.infer<typeof schema>;

type Step = 1 | 2 | 3 | "done";

interface NominateClassmateFormProps {
  eventId: string;
  eventTitle: string;
  graduationYear: number;
  schoolName: string;
  remainingLeads: number;
}

export function NominateClassmateForm({
  eventId,
  eventTitle,
  graduationYear,
  schoolName,
  remainingLeads,
}: NominateClassmateFormProps) {
  const [step, setStep] = useState<Step>(1);
  const [isPending, startTransition] = useTransition();
  const [submittedName, setSubmittedName] = useState("");
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);

  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      fullName: "",
      emailHint: "",
      phoneHint: "",
      socialHint: "",
      schoolConnection: "",
      graduationYear,
      knownSince: "",
      submitterNote: "",
    },
    mode: "onTouched",
  });

  // Step-specific fields for validation
  const STEP_FIELDS: Record<number, (keyof FormData)[]> = {
    1: ["fullName", "schoolConnection", "graduationYear", "knownSince"],
    2: ["emailHint", "phoneHint", "socialHint", "submitterNote"],
    3: ["consentGiven"],
  };

  async function goNext() {
    const fields = STEP_FIELDS[step as number] ?? [];
    const valid = await form.trigger(fields);
    if (!valid) return;
    setStep((s) => (typeof s === "number" ? (s + 1) as Step : s));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function goBack() {
    setStep((s) => (typeof s === "number" && s > 1 ? (s - 1) as Step : s));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleSubmit(data: FormData) {
    startTransition(async () => {
      const res = await fetch(`/api/events/${eventId}/cohort-leads`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...data,
          emailHint: data.emailHint || undefined,
          phoneHint: data.phoneHint || undefined,
          socialHint: data.socialHint || undefined,
          knownSince: data.knownSince || undefined,
          submitterNote: data.submitterNote || undefined,
        }),
      });

      const json = await res.json();

      if (!res.ok) {
        const msg = json.error?.message ?? "Something went wrong. Please try again.";
        if (msg.includes("RATE_LIMIT")) {
          toast.error("You've reached the limit of 5 leads per event.");
        } else {
          toast.error(msg);
        }
        return;
      }

      if (json.data?.duplicateWarning) {
        setDuplicateWarning(
          "This person may have already been nominated. The organizer will review."
        );
      }

      setSubmittedName(data.fullName);
      setStep("done");
    });
  }

  const onSubmit = form.handleSubmit(handleSubmit);

  if (remainingLeads === 0) {
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center">
        <AlertCircle className="mx-auto h-10 w-10 text-blue-500 mb-3" />
        <h2 className="font-display text-xl font-bold text-slate-900 mb-2">
          Limit reached
        </h2>
        <p className="text-sm text-slate-500">
          You've submitted 5 classmate nominations for this event — the maximum allowed.
          Contact the organizer if you need to add more.
        </p>
      </div>
    );
  }

  if (step === "done") {
    return (
      <div className="flex flex-col items-center gap-6 py-4 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100">
          <CheckCircle2 className="h-10 w-10 text-emerald-500" />
        </div>
        <div>
          <h2 className="font-display text-2xl font-bold text-slate-900">
            Nomination submitted!
          </h2>
          <p className="mt-2 text-sm text-slate-500 max-w-xs mx-auto">
            The organizer will review your nomination for{" "}
            <strong className="text-slate-700">{submittedName}</strong> and reach
            out to invite them.
          </p>
        </div>

        {duplicateWarning && (
          <div className="rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">
            <AlertCircle className="inline h-4 w-4 mr-1" />
            {duplicateWarning}
          </div>
        )}

        <div className="rounded-xl border border-border bg-slate-50 px-5 py-4 text-sm text-slate-600 max-w-sm w-full text-left">
          <p className="font-semibold text-slate-800 mb-1">What happens next?</p>
          <ol className="space-y-1 list-decimal list-inside text-slate-500">
            <li>Organizer reviews the nomination</li>
            <li>If approved, they'll send a personal invite</li>
            <li>
              {submittedName.split(" ")[0]} can RSVP via the invite link
            </li>
          </ol>
        </div>

        <div className="flex flex-col gap-2 w-full max-w-xs">
          {remainingLeads > 1 && (
            <Button
              onClick={() => {
                form.reset();
                setStep(1);
                setDuplicateWarning(null);
              }}
              variant="outline"
              className="w-full"
            >
              Nominate another classmate
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <Form {...form}>
      <div className="flex flex-col gap-5">
        {/* Header */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-100">
              <UserPlus className="h-5 w-5 text-blue-600" />
            </div>
            <h1 className="font-display text-xl font-bold text-slate-900">
              Nominate a classmate
            </h1>
          </div>
          <p className="text-sm text-slate-500">
            Know someone who should be at{" "}
            <span className="font-medium text-slate-700">{eventTitle}</span>?
            Help us find them.
          </p>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <Lock className="h-3.5 w-3.5" />
            <span>Contact info is private — only organizers can see it</span>
          </div>
        </div>

        {/* Step progress */}
        <div className="flex gap-1.5">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={cn(
                "h-1.5 flex-1 rounded-full transition-colors",
                (step as number) >= s ? "bg-blue-500" : "bg-slate-200"
              )}
            />
          ))}
        </div>
        <p className="text-xs text-slate-400 -mt-2">
          Step {step} of 3 —{" "}
          {step === 1
            ? "Who is this classmate?"
            : step === 2
            ? "How can we reach them?"
            : "Confirm & submit"}
        </p>

        {/* Card */}
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          {/* ── Step 1: Identity + Connection ──────────────────────── */}
          {step === 1 && (
            <div className="flex flex-col gap-5 p-6">
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Full name <span className="text-red-400">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Sarah Chen" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="graduationYear"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Graduation year</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min={1950}
                        max={2100}
                        placeholder={graduationYear.toString()}
                        {...field}
                        value={field.value ?? ""}
                        onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                      />
                    </FormControl>
                    <FormDescription>
                      Confirm or correct their graduation year from {schoolName}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="knownSince"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Known since</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g. 9th grade, primary school, math class"
                        {...field}
                        value={field.value ?? ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="schoolConnection"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      How do you know them from school?{" "}
                      <span className="text-red-400">*</span>
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="e.g. We were in the same homeroom class for three years. She sat next to me in Mrs. Johnson's English class."
                        rows={3}
                        className="resize-none"
                        maxLength={500}
                        {...field}
                      />
                    </FormControl>
                    <div className="flex justify-end">
                      <span className="text-xs text-slate-400">
                        {field.value.length}/500
                      </span>
                    </div>
                    <FormDescription>
                      This helps the organizer verify the connection and builds
                      trust with the invitee.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}

          {/* ── Step 2: Contact info ──────────────────────────────── */}
          {step === 2 && (
            <div className="flex flex-col gap-5 p-6">
              <div className="rounded-xl bg-blue-50 border border-blue-200 px-4 py-3 flex gap-3">
                <Eye className="h-5 w-5 text-blue-500 shrink-0 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="font-semibold mb-0.5">Privacy notice</p>
                  <p>
                    This information is only used to send an invitation. It is
                    visible only to event organizers — never to other attendees.
                    If you're unsure, leave fields blank.
                  </p>
                </div>
              </div>

              <FormField
                control={form.control}
                name="emailHint"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email address (optional)</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="sarah.chen@example.com"
                        {...field}
                        value={field.value ?? ""}
                      />
                    </FormControl>
                    <FormDescription>
                      Only provide if you have this person's permission or it's
                      publicly known (e.g. their professional email).
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phoneHint"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone number (optional)</FormLabel>
                    <FormControl>
                      <Input
                        type="tel"
                        placeholder="+1 212 555 1234"
                        {...field}
                        value={field.value ?? ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="socialHint"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>LinkedIn or Facebook URL (optional)</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="https://linkedin.com/in/sarahchen"
                        {...field}
                        value={field.value ?? ""}
                      />
                    </FormControl>
                    <FormDescription>
                      A public profile link can help the organizer verify identity.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="submitterNote"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Note to organizer (optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Anything else the organizer should know — why you're nominating them, best way to reach them, etc."
                        rows={2}
                        className="resize-none"
                        maxLength={500}
                        {...field}
                        value={field.value ?? ""}
                      />
                    </FormControl>
                    <div className="flex justify-end">
                      <span className="text-xs text-slate-400">
                        {(field.value ?? "").length}/500
                      </span>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}

          {/* ── Step 3: Consent + review ──────────────────────────── */}
          {step === 3 && (
            <div className="flex flex-col gap-5 p-6">
              {/* Summary */}
              <div className="rounded-xl border border-border bg-slate-50 p-4 space-y-2 text-sm">
                <p className="font-semibold text-slate-800 text-xs uppercase tracking-wide">
                  Summary
                </p>
                <div className="flex justify-between">
                  <span className="text-slate-500">Name</span>
                  <span className="font-medium text-slate-900">
                    {form.watch("fullName")}
                  </span>
                </div>
                {form.watch("emailHint") && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">Email</span>
                    <span className="font-medium text-slate-900 truncate max-w-[60%] text-right">
                      {form.watch("emailHint")}
                    </span>
                  </div>
                )}
                {form.watch("phoneHint") && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">Phone</span>
                    <span className="font-medium text-slate-900">
                      {form.watch("phoneHint")}
                    </span>
                  </div>
                )}
              </div>

              {/* Consent */}
              <div className="rounded-xl border border-border bg-card p-4">
                <h3 className="text-sm font-semibold text-slate-900 mb-3 flex items-center gap-2">
                  <Shield className="h-4 w-4 text-blue-500" />
                  Before you submit
                </h3>
                <FormField
                  control={form.control}
                  name="consentGiven"
                  render={({ field }) => (
                    <FormItem>
                      <label className="flex items-start gap-3 cursor-pointer">
                        <FormControl>
                          <Checkbox
                            checked={field.value ?? false}
                            onCheckedChange={field.onChange}
                            className="mt-0.5"
                          />
                        </FormControl>
                        <span className="text-sm text-slate-700">
                          I confirm that:
                          <ul className="mt-1.5 list-disc list-inside space-y-1 text-slate-600">
                            <li>
                              I genuinely know this person from{" "}
                              <strong>{schoolName}</strong>
                            </li>
                            <li>
                              Any contact info I've provided is accurate to the best
                              of my knowledge
                            </li>
                            <li>
                              I understand this information will only be used to
                              send a reunion invitation
                            </li>
                            <li>
                              I'm not providing information about someone who would
                              not want to be contacted
                            </li>
                          </ul>
                        </span>
                      </label>
                      <FormMessage className="mt-2" />
                    </FormItem>
                  )}
                />
              </div>

              <p className="text-xs text-slate-400">
                Nominations are reviewed by organizers before anyone is contacted.
                Repeated misuse of this feature may result in your RSVP being
                cancelled.
              </p>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          {typeof step === "number" && step > 1 ? (
            <Button
              type="button"
              variant="ghost"
              onClick={goBack}
              disabled={isPending}
              className="gap-1.5 text-slate-600"
            >
              <ChevronLeft className="h-4 w-4" />
              Back
            </Button>
          ) : (
            <div />
          )}

          {step === 3 ? (
            <Button
              type="button"
              onClick={onSubmit}
              disabled={isPending}
              className="gap-2 min-w-40"
              size="lg"
            >
              {isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Submitting…
                </>
              ) : (
                <>
                  Submit nomination
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          ) : (
            <Button
              type="button"
              onClick={goNext}
              size="lg"
              className="gap-2 min-w-28"
            >
              Continue
              <ArrowRight className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Remaining leads indicator */}
        {remainingLeads <= 3 && (
          <p className="text-center text-xs text-slate-400">
            {remainingLeads - (step === "done" ? 1 : 0)} nomination
            {remainingLeads !== 1 ? "s" : ""} remaining
          </p>
        )}
      </div>
    </Form>
  );
}
