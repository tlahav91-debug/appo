"use client";

import { Calendar, Clock, MapPin, Video } from "lucide-react";
import { formatEventDate, formatEventTime } from "@/lib/utils";

interface RSVPEventHeaderProps {
  event: {
    title: string;
    startAt: Date;
    endAt: Date | null;
    timezone: string;
    venueName: string | null;
    venueAddress: string | null;
  };
}

export function RSVPEventHeader({ event }: RSVPEventHeaderProps) {
  const isVirtual = !event.venueName;

  return (
    <div className="rounded-xl border border-border bg-card px-5 py-4">
      <h1 className="font-display text-lg font-bold text-slate-900 leading-snug">
        {event.title}
      </h1>
      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1.5 text-sm text-slate-500">
        <span className="flex items-center gap-1.5">
          <Calendar className="h-3.5 w-3.5 text-blue-500 shrink-0" />
          {formatEventDate(event.startAt, event.timezone)}
        </span>
        <span className="flex items-center gap-1.5">
          <Clock className="h-3.5 w-3.5 text-blue-500 shrink-0" />
          {formatEventTime(event.startAt, event.timezone)}
        </span>
        {event.venueName && (
          <span className="flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5 text-blue-500 shrink-0" />
            {event.venueName}
          </span>
        )}
        {isVirtual && (
          <span className="flex items-center gap-1.5">
            <Video className="h-3.5 w-3.5 text-blue-500 shrink-0" />
            Virtual event
          </span>
        )}
      </div>
    </div>
  );
}
