"use client";

import type { UseFormReturn } from "react-hook-form";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import {
  CreditCard,
  Eye,
  EyeOff,
  Lock,
  User,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import type { FullRsvpInput } from "@/schemas/rsvp";
import { cn, formatCurrency } from "@/lib/utils";
import { useState } from "react";

interface Ticket {
  id: string;
  name: string;
  price: number;
  currency: string;
  description: string | null;
}

interface RSVPStepConsentProps {
  form: UseFormReturn<FullRsvpInput>;
  isUpdate: boolean;
  currentUserProfile?: {
    currentCity: string | null;
    currentJob: string | null;
    currentEmployer: string | null;
    bio: string | null;
    showInDirectory: boolean;
    showCurrentJob: boolean;
    showCurrentCity: boolean;
    allowDirectMessages: boolean;
    allowNominations: boolean;
    profileVisibleTo: string;
  } | null;
  ticketingEnabled: boolean;
  tickets: Ticket[];
}

const VISIBILITY_OPTIONS = [
  {
    value: "EVENT_ATTENDEES" as const,
    label: "All attendees",
    description: "Confirmed attendees can see your profile",
    icon: Eye,
  },
  {
    value: "ORGANIZERS_ONLY" as const,
    label: "Organizers only",
    description: "Only the organizing committee",
    icon: User,
  },
  {
    value: "NOBODY" as const,
    label: "Private",
    description: "Hidden from the attendee directory",
    icon: Lock,
  },
] as const;

export function RSVPStepConsent({
  form,
  isUpdate,
  currentUserProfile,
  ticketingEnabled,
  tickets,
}: RSVPStepConsentProps) {
  const updateProfile = form.watch("updateProfile");
  const profileVisibleTo = form.watch("profileVisibleTo");
  const showInDirectory = form.watch("showInDirectory");
  const status = form.watch("status");
  const isConfirmed = status === "CONFIRMED";
  const [profileExpanded, setProfileExpanded] = useState(false);

  const primaryTicket = tickets[0];
  const showPaymentSummary =
    isConfirmed && ticketingEnabled && primaryTicket && primaryTicket.price > 0;

  return (
    <div className="flex flex-col gap-7 p-6">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          {isUpdate ? "Update your preferences" : "Almost done!"}
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          {showPaymentSummary
            ? "Review your ticket details and confirm how you'd like to appear to classmates."
            : "Let classmates know you're here and how they can reach you."}
        </p>
      </div>

      {/* ── Payment summary ──────────────────────────────────────────────── */}
      {showPaymentSummary && primaryTicket && (
        <section className="rounded-xl border border-blue-200 bg-blue-50 p-5">
          <div className="flex items-center gap-2 mb-3">
            <CreditCard className="h-4 w-4 text-blue-600" />
            <h3 className="text-sm font-semibold text-blue-900">
              Ticket summary
            </h3>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-800">
                {primaryTicket.name}
              </p>
              {primaryTicket.description && (
                <p className="text-xs text-blue-600 mt-0.5">
                  {primaryTicket.description}
                </p>
              )}
            </div>
            <p className="text-lg font-bold text-blue-900">
              {formatCurrency(primaryTicket.price, primaryTicket.currency)}
            </p>
          </div>
          <p className="mt-3 text-xs text-blue-700">
            You'll be taken to a secure Stripe checkout page after confirming
            your RSVP.
          </p>
        </section>
      )}

      {/* ── Profile update (collapsible) ─────────────────────────────────── */}
      {isConfirmed && (
        <section className="rounded-xl border border-border overflow-hidden">
          <button
            type="button"
            onClick={() => setProfileExpanded((p) => !p)}
            className="flex w-full items-center justify-between px-4 py-3.5 text-left hover:bg-slate-50 transition-colors"
          >
            <div>
              <p className="text-sm font-semibold text-slate-900">
                Update your profile
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                {currentUserProfile?.currentCity
                  ? `Currently: ${currentUserProfile.currentCity}${currentUserProfile.currentJob ? ` · ${currentUserProfile.currentJob}` : ""}`
                  : "Tell classmates what you've been up to"}
              </p>
            </div>
            {profileExpanded ? (
              <ChevronUp className="h-4 w-4 text-slate-400 shrink-0" />
            ) : (
              <ChevronDown className="h-4 w-4 text-slate-400 shrink-0" />
            )}
          </button>

          {profileExpanded && (
            <div className="border-t border-border px-4 pb-4 pt-3 flex flex-col gap-4">
              <FormField
                control={form.control}
                name="updateProfile"
                render={({ field }) => (
                  <FormItem className="flex items-center gap-3">
                    <FormControl>
                      <Checkbox
                        checked={field.value ?? false}
                        onCheckedChange={field.onChange}
                        aria-label="Save profile changes"
                      />
                    </FormControl>
                    <FormLabel className="text-sm font-medium cursor-pointer">
                      Save changes to my profile
                    </FormLabel>
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="currentCity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs text-slate-500">
                        Current city
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="San Francisco"
                          className="text-sm"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => {
                            field.onChange(e);
                            form.setValue("updateProfile", true);
                          }}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="currentJob"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs text-slate-500">
                        Job title
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Software Engineer"
                          className="text-sm"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => {
                            field.onChange(e);
                            form.setValue("updateProfile", true);
                          }}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="currentEmployer"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-slate-500">
                      Employer
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Acme Corp"
                        className="text-sm"
                        {...field}
                        value={field.value ?? ""}
                        onChange={(e) => {
                          field.onChange(e);
                          form.setValue("updateProfile", true);
                        }}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-slate-500">
                      Brief bio{" "}
                      <span className="text-slate-400">(optional)</span>
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="A quick intro for your classmates"
                        rows={2}
                        className="resize-none text-sm"
                        maxLength={280}
                        {...field}
                        value={field.value ?? ""}
                        onChange={(e) => {
                          field.onChange(e);
                          form.setValue("updateProfile", true);
                        }}
                      />
                    </FormControl>
                    <div className="flex justify-end">
                      <span className="text-xs text-slate-400">
                        {(field.value ?? "").length}/280
                      </span>
                    </div>
                  </FormItem>
                )}
              />
            </div>
          )}
        </section>
      )}

      {/* ── Privacy preferences ──────────────────────────────────────────── */}
      {isConfirmed && (
        <section className="flex flex-col gap-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Who can see your profile?
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Controls how you appear in the attendee directory.
            </p>
          </div>

          <FormField
            control={form.control}
            name="profileVisibleTo"
            render={({ field }) => (
              <FormItem>
                <div className="flex flex-col gap-2" role="radiogroup">
                  {VISIBILITY_OPTIONS.map((opt) => {
                    const Icon = opt.icon;
                    const isSelected = field.value === opt.value;
                    return (
                      <button
                        key={opt.value}
                        type="button"
                        role="radio"
                        aria-checked={isSelected}
                        onClick={() => field.onChange(opt.value)}
                        className={cn(
                          "flex items-center gap-3 rounded-xl border-2 px-4 py-3 text-left transition-all",
                          isSelected
                            ? "border-blue-600 bg-blue-50"
                            : "border-border hover:border-blue-300"
                        )}
                      >
                        <Icon
                          className={cn(
                            "h-4 w-4 shrink-0",
                            isSelected ? "text-blue-600" : "text-slate-400"
                          )}
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-slate-900">
                            {opt.label}
                          </p>
                          <p className="text-xs text-slate-500">
                            {opt.description}
                          </p>
                        </div>
                        <div
                          className={cn(
                            "h-4 w-4 shrink-0 rounded-full border-2",
                            isSelected
                              ? "border-blue-600 bg-blue-500"
                              : "border-slate-300"
                          )}
                        />
                      </button>
                    );
                  })}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Fine-grained controls — only when visible to some people */}
          {profileVisibleTo !== "NOBODY" && (
            <div className="rounded-xl border border-border divide-y divide-border overflow-hidden">
              {[
                {
                  name: "showCurrentJob" as const,
                  label: "Show job title",
                },
                {
                  name: "showCurrentCity" as const,
                  label: "Show current city",
                },
                {
                  name: "allowDirectMessages" as const,
                  label: "Allow direct messages",
                },
                {
                  name: "allowNominations" as const,
                  label: "Allow classmates to nominate me",
                },
              ].map(({ name, label }) => (
                <FormField
                  key={name}
                  control={form.control}
                  name={name}
                  render={({ field }) => (
                    <FormItem className="flex items-center justify-between gap-4 px-4 py-3">
                      <FormLabel className="text-sm text-slate-700 cursor-pointer">
                        {label}
                      </FormLabel>
                      <FormControl>
                        <Switch
                          checked={field.value as boolean}
                          onCheckedChange={field.onChange}
                          aria-label={label}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              ))}
            </div>
          )}
        </section>
      )}

      {/* ── Communication consent ─────────────────────────────────────────── */}
      <section className="flex flex-col gap-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">
            Communication preferences
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            How can the organizer contact you about this event?
          </p>
        </div>

        {/* Email consent — required */}
        <FormField
          control={form.control}
          name="consentEmail"
          render={({ field }) => (
            <FormItem>
              <label className="flex cursor-pointer items-start gap-3 rounded-xl border-2 border-border bg-card p-4 transition-all hover:border-blue-300 has-[:checked]:border-blue-600 has-[:checked]:bg-blue-50">
                <FormControl>
                  <Checkbox
                    checked={field.value ?? false}
                    onCheckedChange={field.onChange}
                    className="mt-0.5"
                    aria-required
                  />
                </FormControl>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-slate-900">
                      Email updates
                    </p>
                    <span className="rounded bg-blue-100 px-1.5 py-0.5 text-[10px] font-bold text-blue-700">
                      REQUIRED
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Receive confirmation, reminders, and event updates via
                    email.
                  </p>
                </div>
              </label>
              <FormMessage className="ml-4" />
            </FormItem>
          )}
        />

        {/* SMS consent — optional */}
        <FormField
          control={form.control}
          name="consentSms"
          render={({ field }) => (
            <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-blue-300 has-[:checked]:border-blue-600 has-[:checked]:bg-blue-50">
              <Checkbox
                checked={field.value ?? false}
                onCheckedChange={field.onChange}
                className="mt-0.5"
              />
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-900">
                  SMS reminders{" "}
                  <span className="font-normal text-slate-400">(optional)</span>
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Text message reminders before the event. Standard rates apply.
                </p>
              </div>
            </label>
          )}
        />

        {/* WhatsApp consent — optional */}
        <FormField
          control={form.control}
          name="consentWhatsApp"
          render={({ field }) => (
            <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-blue-300 has-[:checked]:border-blue-600 has-[:checked]:bg-blue-50">
              <Checkbox
                checked={field.value ?? false}
                onCheckedChange={field.onChange}
                className="mt-0.5"
              />
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-900">
                  WhatsApp updates{" "}
                  <span className="font-normal text-slate-400">(optional)</span>
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Group updates via WhatsApp if the organizer uses it.
                </p>
              </div>
            </label>
          )}
        />

        {/* Photo tagging consent */}
        <FormField
          control={form.control}
          name="consentPhotoTagging"
          render={({ field }) => (
            <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-blue-300 has-[:checked]:border-blue-600 has-[:checked]:bg-blue-50">
              <Checkbox
                checked={field.value ?? true}
                onCheckedChange={field.onChange}
                className="mt-0.5"
              />
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-900">
                  Allow photo tagging{" "}
                  <span className="font-normal text-slate-400">(optional)</span>
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Classmates can tag you in memories they share. You'll be
                  notified and can remove tags at any time.
                </p>
              </div>
            </label>
          )}
        />

        {/* GDPR notice */}
        <p className="text-xs text-slate-400 pt-1">
          Your information is only shared with the event organizer and
          confirmed attendees (per your privacy settings above). You can change
          or revoke consent at any time from your profile.{" "}
          <a href="/privacy" className="underline hover:text-slate-600">
            Privacy policy
          </a>
        </p>
      </section>
    </div>
  );
}
