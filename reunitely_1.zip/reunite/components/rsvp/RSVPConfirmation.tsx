"use client";

import Link from "next/link";
import {
  CheckCircle,
  Clock,
  HeartCrack,
  CalendarPlus,
  Share2,
  ArrowLeft,
  Edit3,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { getEventUrl } from "@/lib/utils";
import { cn } from "@/lib/utils";

interface ConfirmationEvent {
  id: string;
  title: string;
  slug: string;
  startAt: Date;
  timezone: string;
}

interface RSVPConfirmationProps {
  event: ConfirmationEvent;
  status: "CONFIRMED" | "PENDING" | "DECLINED" | "WAITLISTED";
  isWaitlisted?: boolean;
  waitlistPosition?: number | null;
  isExisting?: boolean; // true = showing confirmation for already-RSVPd state
}

const CONFIRMATION_CONFIG = {
  CONFIRMED: {
    emoji: "🎉",
    bgColor: "bg-emerald-100",
    iconColor: "text-emerald-500",
    icon: CheckCircle,
    title: "You're in!",
    description: "Your RSVP is confirmed. See you there!",
    badgeColor: "bg-emerald-100 text-emerald-700",
    badgeLabel: "Confirmed",
  },
  PENDING: {
    emoji: "🤔",
    bgColor: "bg-blue-100",
    iconColor: "text-blue-500",
    icon: Clock,
    title: "Marked as 'Maybe'",
    description:
      "We'll hold your spot. You can confirm or decline any time before the event.",
    badgeColor: "bg-blue-100 text-blue-700",
    badgeLabel: "Maybe",
  },
  WAITLISTED: {
    emoji: "🙏",
    bgColor: "bg-blue-100",
    iconColor: "text-blue-500",
    icon: Users,
    title: "You're on the waitlist",
    description:
      "The event is at capacity, but you're on the list. We'll email you if a spot opens up.",
    badgeColor: "bg-blue-100 text-blue-700",
    badgeLabel: "Waitlisted",
  },
  DECLINED: {
    emoji: "😔",
    bgColor: "bg-slate-100",
    iconColor: "text-slate-400",
    icon: HeartCrack,
    title: "Sorry you can't make it",
    description:
      "We've noted your response. Hope to see you at a future event!",
    badgeColor: "bg-slate-100 text-slate-600",
    badgeLabel: "Declined",
  },
} as const;

export function RSVPConfirmation({
  event,
  status,
  isWaitlisted = false,
  waitlistPosition = null,
  isExisting = false,
}: RSVPConfirmationProps) {
  const effectiveStatus: keyof typeof CONFIRMATION_CONFIG =
    isWaitlisted ? "WAITLISTED" : status;

  const config = CONFIRMATION_CONFIG[effectiveStatus];
  const IconComponent = config.icon;
  const eventUrl = getEventUrl(event.slug);

  // Build Google Calendar URL
  const startIso = new Date(event.startAt)
    .toISOString()
    .replace(/[-:]/g, "")
    .split(".")[0] + "Z";
  const googleCalUrl =
    `https://calendar.google.com/calendar/render?action=TEMPLATE` +
    `&text=${encodeURIComponent(event.title)}` +
    `&dates=${startIso}/${startIso}` +
    `&details=${encodeURIComponent("View event: " + eventUrl)}`;
  const icsUrl = `/api/events/${event.id}/calendar.ics`;

  const showCalendarLinks =
    effectiveStatus === "CONFIRMED" || effectiveStatus === "WAITLISTED" || effectiveStatus === "PENDING";
  const showShare = effectiveStatus !== "DECLINED";

  return (
    <div className="flex flex-col items-center gap-6 py-2 text-center">
      {/* Status icon */}
      <div
        className={cn(
          "flex h-20 w-20 items-center justify-center rounded-full",
          config.bgColor
        )}
        aria-hidden
      >
        <IconComponent
          className={cn("h-10 w-10", config.iconColor)}
          strokeWidth={1.5}
        />
      </div>

      {/* Status badge */}
      <div>
        <span
          className={cn(
            "inline-block rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wide mb-3",
            config.badgeColor
          )}
        >
          {config.badgeLabel}
        </span>
        <h2 className="font-display text-2xl font-bold text-slate-900">
          {config.title}
        </h2>
        <p className="mt-2 text-sm text-slate-500 max-w-xs">{config.description}</p>
      </div>

      {/* Waitlist position */}
      {effectiveStatus === "WAITLISTED" && waitlistPosition && (
        <div className="rounded-xl border border-blue-200 bg-blue-50 px-5 py-3 w-full max-w-xs">
          <p className="text-sm font-semibold text-blue-800">
            You're #{waitlistPosition} on the waitlist
          </p>
          <p className="text-xs text-blue-600 mt-0.5">
            We'll email you at your registered address as soon as a spot opens.
          </p>
        </div>
      )}

      {/* Event card */}
      <div className="w-full rounded-xl border border-border bg-card p-4 text-left">
        <p className="text-xs text-slate-400 mb-1">Event</p>
        <p className="font-semibold text-slate-900 truncate">{event.title}</p>
        <p className="text-sm text-slate-500 mt-0.5">
          {new Intl.DateTimeFormat("en-US", {
            weekday: "long",
            month: "long",
            day: "numeric",
            year: "numeric",
            timeZone: event.timezone,
          }).format(new Date(event.startAt))}
        </p>
      </div>

      {/* Calendar links */}
      {showCalendarLinks && (
        <div className="flex flex-col gap-2 w-full">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Add to calendar
          </p>
          <div className="flex flex-col gap-2 sm:flex-row sm:justify-center">
            <Button
              variant="outline"
              size="sm"
              className="gap-2"
              asChild
            >
              <a href={googleCalUrl} target="_blank" rel="noopener noreferrer">
                <CalendarPlus className="h-4 w-4" />
                Google Calendar
              </a>
            </Button>
            <Button variant="outline" size="sm" className="gap-2" asChild>
              <a href={icsUrl} download>
                <CalendarPlus className="h-4 w-4" />
                Apple / Outlook (.ics)
              </a>
            </Button>
          </div>
        </div>
      )}

      {/* Share */}
      {showShare && (
        <div className="flex flex-col items-center gap-2 w-full">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Know someone who'd love to come?
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            <Button variant="outline" size="sm" className="gap-1.5" asChild>
              <a
                href={`https://wa.me/?text=${encodeURIComponent(`Join me at ${event.title}! RSVP here: ${eventUrl}`)}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Share2 className="h-3.5 w-3.5 text-emerald-500" />
                Share on WhatsApp
              </a>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" asChild>
              <a
                href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(eventUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Share2 className="h-3.5 w-3.5 text-blue-500" />
                Facebook
              </a>
            </Button>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex flex-col gap-2 w-full pt-2">
        <Button asChild variant="default">
          <Link href={`/events/${event.slug}`}>View event page</Link>
        </Button>
        {isExisting && effectiveStatus !== "DECLINED" && (
          <Button asChild variant="outline">
            <Link href={`/events/${event.slug}/rsvp`}>
              <Edit3 className="mr-2 h-4 w-4" />
              Update my RSVP
            </Link>
          </Button>
        )}
        {effectiveStatus === "DECLINED" && (
          <Button asChild variant="ghost" className="text-slate-500">
            <Link href={`/events/${event.slug}/rsvp`}>
              Changed your mind? RSVP now
            </Link>
          </Button>
        )}
      </div>
    </div>
  );
}
