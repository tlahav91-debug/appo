"use client";

import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface RSVPProgressDotsProps {
  currentStep: number;
  totalSteps: number;
  labels: string[];
}

export function RSVPProgressDots({
  currentStep,
  totalSteps,
  labels,
}: RSVPProgressDotsProps) {
  return (
    <nav aria-label="RSVP progress" className="flex items-center justify-center gap-0">
      {Array.from({ length: totalSteps }, (_, i) => {
        const step = i + 1;
        const isComplete = step < currentStep;
        const isCurrent = step === currentStep;

        return (
          <div key={step} className="flex items-center">
            {/* Connector before */}
            {i > 0 && (
              <div
                className={cn(
                  "h-px w-8 sm:w-12 transition-colors duration-300",
                  isComplete ? "bg-blue-500" : "bg-slate-200"
                )}
              />
            )}

            {/* Dot */}
            <div className="flex flex-col items-center gap-1">
              <div
                className={cn(
                  "flex h-7 w-7 items-center justify-center rounded-full border-2 text-xs font-bold transition-all duration-200",
                  isComplete
                    ? "border-blue-600 bg-blue-500 text-white"
                    : isCurrent
                    ? "border-blue-600 bg-white text-blue-600 shadow-sm shadow-blue-100"
                    : "border-slate-200 bg-white text-slate-400"
                )}
                aria-current={isCurrent ? "step" : undefined}
              >
                {isComplete ? (
                  <Check className="h-3.5 w-3.5" />
                ) : (
                  step
                )}
              </div>
              <span
                className={cn(
                  "text-[10px] font-medium whitespace-nowrap",
                  isCurrent ? "text-blue-700" : isComplete ? "text-slate-400" : "text-slate-300"
                )}
              >
                {labels[i]}
              </span>
            </div>
          </div>
        );
      })}
    </nav>
  );
}
