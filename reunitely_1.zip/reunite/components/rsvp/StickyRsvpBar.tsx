import Link from "next/link";
import { Button } from "@/components/ui/button";
import { formatShortDate } from "@/lib/utils";
import type { PublicEvent } from "@/lib/services/event.service";

interface StickyRsvpBarProps {
  event: PublicEvent;
}

export function StickyRsvpBar({ event }: StickyRsvpBarProps) {
  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-30 border-t border-border bg-card/95 px-4 py-3 backdrop-blur-sm pb-safe md:hidden"
      aria-label="RSVP action bar"
    >
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-slate-900">
            {event.title}
          </p>
          <p className="text-xs text-slate-500">
            {formatShortDate(event.startAt)}
          </p>
        </div>
        <Button asChild size="sm" className="shrink-0">
          <Link href={`/events/${event.slug}/rsvp`}>RSVP Now</Link>
        </Button>
      </div>
    </div>
  );
}
