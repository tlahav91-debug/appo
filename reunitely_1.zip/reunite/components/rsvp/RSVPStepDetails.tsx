"use client";

import { useEffect } from "react";
import type { UseFormReturn } from "react-hook-form";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Minus, Plus, X, UserPlus } from "lucide-react";
import type { FullRsvpInput } from "@/schemas/rsvp";
import { DIETARY_OPTIONS, TRANSPORT_OPTIONS } from "@/schemas/rsvp";
import { cn } from "@/lib/utils";

interface CustomQuestion {
  id: string;
  label: string;
  type: "TEXT" | "SELECT" | "BOOLEAN";
  options?: string[];
  required: boolean;
}

interface RSVPStepDetailsProps {
  form: UseFormReturn<FullRsvpInput>;
  allowGuests: boolean;
  maxGuests: number;
  customQuestions: CustomQuestion[];
  isVirtual?: boolean;
}

export function RSVPStepDetails({
  form,
  allowGuests,
  maxGuests,
  customQuestions,
  isVirtual = false,
}: RSVPStepDetailsProps) {
  const bringGuest = form.watch("bringGuest");
  const guestCount = form.watch("guestCount") ?? 0;
  const guests = form.watch("guests") ?? [];
  const dietaryReqs = form.watch("dietaryRequirements") ?? [];
  const hasAccessibility = form.watch("hasAccessibilityNeeds");
  const transportMode = form.watch("transportationMode");
  const status = form.watch("status");

  // Sync guest array length with guestCount
  useEffect(() => {
    const current = form.getValues("guests") ?? [];
    if (bringGuest && guestCount > 0) {
      const needed = guestCount - current.length;
      if (needed > 0) {
        form.setValue("guests", [
          ...current,
          ...Array.from({ length: needed }, () => ({
            name: "",
            dietaryRequirements: [],
            accessibilityNeeds: "",
          })),
        ]);
      } else if (needed < 0) {
        form.setValue("guests", current.slice(0, guestCount));
      }
    } else {
      form.setValue("guests", []);
    }
  }, [bringGuest, guestCount, form]);

  function toggleDietary(value: string) {
    const current = form.getValues("dietaryRequirements") ?? [];
    if (value === "NONE") {
      form.setValue("dietaryRequirements", ["NONE"]);
      return;
    }
    const withoutNone = current.filter((d) => d !== "NONE");
    if (withoutNone.includes(value)) {
      form.setValue(
        "dietaryRequirements",
        withoutNone.filter((d) => d !== value)
      );
    } else {
      form.setValue("dietaryRequirements", [...withoutNone, value]);
    }
  }

  const isConfirmed = status === "CONFIRMED";

  return (
    <div className="flex flex-col gap-7 p-6">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          A few details
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          Help the organizer prepare for your attendance.
        </p>
      </div>

      {/* ── Guests / +1 ────────────────────────────────────────────────────── */}
      {allowGuests && isConfirmed && (
        <section className="flex flex-col gap-4">
          <FormField
            control={form.control}
            name="bringGuest"
            render={({ field }) => (
              <FormItem className="flex items-center justify-between gap-4 rounded-xl border border-border px-4 py-3.5">
                <div className="flex items-center gap-3">
                  <UserPlus className="h-4 w-4 text-blue-500 shrink-0" />
                  <div>
                    <FormLabel className="text-sm font-semibold">
                      Bring a guest?
                    </FormLabel>
                    <FormDescription className="mt-0 text-xs">
                      You can bring up to {maxGuests} guest
                      {maxGuests !== 1 ? "s" : ""}
                    </FormDescription>
                  </div>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value ?? false}
                    onCheckedChange={field.onChange}
                    aria-label="Bring a guest"
                  />
                </FormControl>
              </FormItem>
            )}
          />

          {bringGuest && (
            <div className="flex flex-col gap-3 pl-2">
              {/* Guest count stepper */}
              <FormField
                control={form.control}
                name="guestCount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Number of guests</FormLabel>
                    <div className="flex items-center gap-4">
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="h-9 w-9 shrink-0"
                        onClick={() =>
                          field.onChange(Math.max(1, (field.value ?? 1) - 1))
                        }
                        disabled={(field.value ?? 1) <= 1}
                        aria-label="Remove guest"
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span
                        className="w-8 text-center text-lg font-bold text-slate-900"
                        aria-live="polite"
                        aria-label={`${field.value ?? 1} guest`}
                      >
                        {field.value ?? 1}
                      </span>
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="h-9 w-9 shrink-0"
                        onClick={() =>
                          field.onChange(
                            Math.min(maxGuests, (field.value ?? 1) + 1)
                          )
                        }
                        disabled={(field.value ?? 1) >= maxGuests}
                        aria-label="Add guest"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Guest name fields */}
              {Array.from({ length: guestCount }).map((_, i) => (
                <FormField
                  key={i}
                  control={form.control}
                  name={`guests.${i}.name`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm">
                        Guest {i + 1} name
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Full name"
                          {...field}
                          value={field.value ?? ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              ))}
            </div>
          )}
        </section>
      )}

      {/* ── Dietary requirements ────────────────────────────────────────── */}
      {isConfirmed && (
        <section className="flex flex-col gap-3">
          <FormLabel className="text-sm font-semibold">
            Dietary requirements
          </FormLabel>
          <div
            className="grid grid-cols-2 gap-2 sm:grid-cols-3"
            role="group"
            aria-label="Dietary requirements"
          >
            {DIETARY_OPTIONS.map((opt) => {
              const isSelected = dietaryReqs.includes(opt.value);
              return (
                <button
                  key={opt.value}
                  type="button"
                  aria-pressed={isSelected}
                  onClick={() => toggleDietary(opt.value)}
                  className={cn(
                    "flex items-center gap-2 rounded-lg border px-3 py-2.5 text-left text-sm transition-all",
                    isSelected
                      ? "border-blue-600 bg-blue-50 text-blue-800"
                      : "border-border text-slate-600 hover:border-blue-300 hover:bg-blue-50/40"
                  )}
                >
                  <span className="text-base" aria-hidden>
                    {opt.emoji}
                  </span>
                  <span className="font-medium leading-tight">{opt.label}</span>
                </button>
              );
            })}
          </div>

          {/* Free-text notes — show if "Other" selected or any restriction set */}
          {(dietaryReqs.includes("OTHER") ||
            (dietaryReqs.length > 0 && !dietaryReqs.includes("NONE"))) && (
            <FormField
              control={form.control}
              name="dietaryNotes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-slate-500">
                    Additional notes (optional)
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="e.g. severe tree nut allergy, low-sodium diet..."
                      rows={2}
                      className="resize-none text-sm"
                      maxLength={300}
                      {...field}
                      value={field.value ?? ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
        </section>
      )}

      {/* ── Accessibility ───────────────────────────────────────────────── */}
      {isConfirmed && (
        <section className="flex flex-col gap-3">
          <FormField
            control={form.control}
            name="hasAccessibilityNeeds"
            render={({ field }) => (
              <FormItem className="flex items-center justify-between gap-4 rounded-xl border border-border px-4 py-3.5">
                <div>
                  <FormLabel className="text-sm font-semibold">
                    Accessibility needs
                  </FormLabel>
                  <FormDescription className="mt-0 text-xs">
                    Wheelchair access, hearing loop, seating, etc.
                  </FormDescription>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value ?? false}
                    onCheckedChange={field.onChange}
                    aria-label="I have accessibility needs"
                  />
                </FormControl>
              </FormItem>
            )}
          />

          {hasAccessibility && (
            <FormField
              control={form.control}
              name="accessibilityNeeds"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Textarea
                      placeholder="Please describe what you need so the organizer can arrange it for you."
                      rows={3}
                      className="resize-none"
                      maxLength={500}
                      {...field}
                      value={field.value ?? ""}
                    />
                  </FormControl>
                  <div className="flex justify-end">
                    <span className="text-xs text-slate-400">
                      {(field.value ?? "").length}/500
                    </span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
        </section>
      )}

      {/* ── Transportation ──────────────────────────────────────────────── */}
      {isConfirmed && !isVirtual && (
        <section className="flex flex-col gap-3">
          <FormLabel className="text-sm font-semibold">
            How are you getting there?
          </FormLabel>
          <div
            className="grid grid-cols-2 gap-2 sm:grid-cols-3"
            role="group"
            aria-label="Transportation method"
          >
            {TRANSPORT_OPTIONS.map((opt) => {
              const isSelected = transportMode === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  aria-pressed={isSelected}
                  onClick={() =>
                    form.setValue(
                      "transportationMode",
                      isSelected ? "" : opt.value
                    )
                  }
                  className={cn(
                    "flex items-center gap-2 rounded-lg border px-3 py-2.5 text-sm transition-all",
                    isSelected
                      ? "border-blue-600 bg-blue-50 text-blue-800"
                      : "border-border text-slate-600 hover:border-blue-300 hover:bg-blue-50/40"
                  )}
                >
                  <span className="text-base" aria-hidden>
                    {opt.emoji}
                  </span>
                  <span className="font-medium leading-tight">{opt.label}</span>
                </button>
              );
            })}
          </div>

          {/* Flying — arrival city */}
          {transportMode === "FLYING" && (
            <FormField
              control={form.control}
              name="arrivalCity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-slate-500">
                    Flying from (city)
                  </FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g. New York, London"
                      className="max-w-xs"
                      {...field}
                      value={field.value ?? ""}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          )}

          {/* Offering ride — seat count */}
          {transportMode === "OFFERING_RIDE" && (
            <FormField
              control={form.control}
              name="offeringSeats"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-slate-500">
                    How many seats can you offer?
                  </FormLabel>
                  <div className="flex items-center gap-3">
                    {[1, 2, 3, 4, 5, 6].map((n) => (
                      <button
                        key={n}
                        type="button"
                        onClick={() => field.onChange(n)}
                        className={cn(
                          "h-9 w-9 rounded-full border text-sm font-medium transition-all",
                          field.value === n
                            ? "border-blue-600 bg-blue-500 text-white"
                            : "border-border text-slate-600 hover:border-blue-300"
                        )}
                      >
                        {n}
                      </button>
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          {/* Transportation notes */}
          {(transportMode === "NEED_RIDE" ||
            transportMode === "OFFERING_RIDE" ||
            transportMode === "FLYING") && (
            <FormField
              control={form.control}
              name="transportationNotes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-slate-500">
                    {transportMode === "NEED_RIDE"
                      ? "Where are you coming from? (optional)"
                      : transportMode === "OFFERING_RIDE"
                      ? "Where can you pick up from? (optional)"
                      : "Any notes about your travel? (optional)"}
                  </FormLabel>
                  <FormControl>
                    <Input
                      placeholder={
                        transportMode === "NEED_RIDE"
                          ? "e.g. Oakland area"
                          : transportMode === "OFFERING_RIDE"
                          ? "e.g. Downtown SF, Union Square area"
                          : "e.g. Arriving Friday evening"
                      }
                      {...field}
                      value={field.value ?? ""}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          )}
        </section>
      )}

      {/* ── Custom event questions ──────────────────────────────────────── */}
      {customQuestions.length > 0 && (
        <section className="flex flex-col gap-4">
          <p className="text-sm font-semibold text-slate-900">
            A few questions from the organizer
          </p>
          {customQuestions.map((q) => (
            <FormField
              key={q.id}
              control={form.control}
              name={`customAnswers.${q.id}`}
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm">
                    {q.label}
                    {q.required && (
                      <span className="ml-1 text-destructive" aria-hidden>
                        *
                      </span>
                    )}
                  </FormLabel>
                  <FormControl>
                    {q.type === "BOOLEAN" ? (
                      <div className="flex gap-3">
                        {["Yes", "No"].map((opt) => (
                          <button
                            key={opt}
                            type="button"
                            onClick={() => field.onChange(opt)}
                            className={cn(
                              "rounded-lg border px-4 py-2 text-sm font-medium transition-all",
                              field.value === opt
                                ? "border-blue-600 bg-blue-50 text-blue-800"
                                : "border-border text-slate-600 hover:border-blue-300"
                            )}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    ) : q.type === "SELECT" && q.options ? (
                      <div className="flex flex-wrap gap-2" role="group">
                        {q.options.map((opt) => (
                          <button
                            key={opt}
                            type="button"
                            onClick={() => field.onChange(opt)}
                            className={cn(
                              "rounded-full border px-3 py-1.5 text-sm font-medium transition-all",
                              field.value === opt
                                ? "border-blue-600 bg-blue-50 text-blue-800"
                                : "border-border text-slate-600 hover:border-blue-300"
                            )}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    ) : (
                      <Input
                        placeholder="Your answer"
                        {...field}
                        value={field.value ?? ""}
                      />
                    )}
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          ))}
        </section>
      )}

      {/* ── Personal note to organizer ──────────────────────────────────── */}
      <FormField
        control={form.control}
        name="attendeeNote"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="text-sm font-semibold">
              Message to organizer{" "}
              <span className="font-normal text-slate-400">(optional)</span>
            </FormLabel>
            <FormControl>
              <Textarea
                placeholder="Anything the organizer should know — excited to see everyone, or other notes."
                rows={2}
                className="resize-none text-sm"
                maxLength={500}
                {...field}
                value={field.value ?? ""}
              />
            </FormControl>
            <div className="flex justify-end">
              <span className="text-xs text-slate-400">
                {(field.value ?? "").length}/500
              </span>
            </div>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
}
