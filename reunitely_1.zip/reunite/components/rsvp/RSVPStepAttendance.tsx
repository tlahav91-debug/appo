"use client";

import type { UseFormReturn } from "react-hook-form";
import { FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Check } from "lucide-react";
import type { FullRsvpInput } from "@/schemas/rsvp";
import { cn } from "@/lib/utils";

const STATUS_OPTIONS = [
  {
    value: "CONFIRMED" as const,
    emoji: "🎉",
    label: "Yes, I'm attending!",
    sublabel: "Count me in — I'll be there.",
    color: "emerald",
  },
  {
    value: "PENDING" as const,
    emoji: "🤔",
    label: "Maybe",
    sublabel: "I'm interested but not sure yet.",
    color: "blue",
  },
  {
    value: "DECLINED" as const,
    emoji: "😔",
    label: "Can't make it",
    sublabel: "I won't be able to attend.",
    color: "slate",
  },
] as const;

interface RSVPStepAttendanceProps {
  form: UseFormReturn<FullRsvpInput>;
  eventTitle: string;
  isReopenEdit?: boolean;
}

export function RSVPStepAttendance({
  form,
  eventTitle,
  isReopenEdit = false,
}: RSVPStepAttendanceProps) {
  const selected = form.watch("status");

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          {isReopenEdit ? "Update your RSVP" : "Will you be attending?"}
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          {isReopenEdit
            ? "You've already RSVP'd. You can update your response below."
            : "Let the organizer know if you're coming."}
        </p>
      </div>

      <FormField
        control={form.control}
        name="status"
        render={({ field }) => (
          <FormItem>
            <div
              className="flex flex-col gap-2.5"
              role="radiogroup"
              aria-label="Will you attend?"
            >
              {STATUS_OPTIONS.map((opt) => {
                const isSelected = selected === opt.value;

                const ringColors: Record<string, string> = {
                  emerald: "border-emerald-500 bg-emerald-50",
                  blue: "border-blue-600 bg-blue-50",
                  slate: "border-slate-400 bg-slate-50",
                };
                const checkColors: Record<string, string> = {
                  emerald: "bg-emerald-500",
                  blue: "bg-blue-500",
                  slate: "bg-slate-500",
                };

                return (
                  <button
                    key={opt.value}
                    type="button"
                    role="radio"
                    aria-checked={isSelected}
                    onClick={() => field.onChange(opt.value)}
                    className={cn(
                      "flex w-full items-center gap-4 rounded-xl border-2 px-5 py-4 text-left transition-all duration-150",
                      "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                      "hover:border-slate-300 active:scale-[0.99]",
                      isSelected
                        ? ringColors[opt.color]
                        : "border-border bg-card"
                    )}
                  >
                    {/* Emoji */}
                    <span className="text-2xl select-none" aria-hidden>
                      {opt.emoji}
                    </span>

                    {/* Labels */}
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-slate-900">
                        {opt.label}
                      </p>
                      <p className="text-sm text-slate-500 mt-0.5">
                        {opt.sublabel}
                      </p>
                    </div>

                    {/* Radio indicator */}
                    <div
                      className={cn(
                        "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 transition-all",
                        isSelected
                          ? cn("border-transparent", checkColors[opt.color])
                          : "border-slate-300 bg-white"
                      )}
                    >
                      {isSelected && (
                        <Check className="h-3 w-3 text-white" strokeWidth={3} />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Declining — brief note */}
      {selected === "DECLINED" && (
        <div className="rounded-lg bg-slate-50 border border-slate-200 px-4 py-3 text-sm text-slate-600">
          <p className="font-medium">Continuing will send your response.</p>
          <p className="mt-0.5 text-slate-500">
            The organizer will see that you can't make it. You can always change
            your mind later.
          </p>
        </div>
      )}

      {selected === "PENDING" && (
        <div className="rounded-lg bg-blue-50 border border-blue-200 px-4 py-3 text-sm text-blue-800">
          <p className="font-medium">No problem — we'll hold your spot.</p>
          <p className="mt-0.5">
            You can confirm or decline anytime before the event. The organizer
            will see you're interested.
          </p>
        </div>
      )}
    </div>
  );
}
