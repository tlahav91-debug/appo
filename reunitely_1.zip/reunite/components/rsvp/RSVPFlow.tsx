"use client";

import { useState, useTransition, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { ChevronLeft, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  fullRsvpSchema,
  RSVP_DEFAULTS,
  RSVP_STEP_FIELDS,
  type FullRsvpInput,
} from "@/schemas/rsvp";
import { submitRsvpAction } from "@/lib/actions/rsvp.actions";
import { RSVPStepAttendance } from "@/components/rsvp/RSVPStepAttendance";
import { RSVPStepDetails } from "@/components/rsvp/RSVPStepDetails";
import { RSVPStepConsent } from "@/components/rsvp/RSVPStepConsent";
import { RSVPConfirmation } from "@/components/rsvp/RSVPConfirmation";
import { RSVPProgressDots } from "@/components/rsvp/RSVPProgressDots";
import { RSVPEventHeader } from "@/components/rsvp/RSVPEventHeader";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface RSVPFlowEvent {
  id: string;
  title: string;
  slug: string;
  startAt: Date;
  endAt: Date | null;
  timezone: string;
  venueName: string | null;
  venueAddress: string | null;
  ticketingEnabled: boolean;
  stripeAccountId: string | null;
  settings: {
    allowGuestPlus1?: boolean;
    maxGuestsPerRsvp?: number;
    customQuestions?: Array<{
      id: string;
      label: string;
      type: "TEXT" | "SELECT" | "BOOLEAN";
      options?: string[];
      required: boolean;
    }>;
    requireApproval?: boolean;
    verifySchoolEmail?: boolean;
  };
}

interface RSVPFlowProps {
  event: RSVPFlowEvent;
  tickets: Array<{
    id: string;
    name: string;
    description: string | null;
    price: number;
    currency: string;
    capacity: number | null;
    soldCount: number;
  }>;
  inviteToken?: string;
  existingRsvp?: {
    status: string;
    guestCount: number;
    dietaryRequirements: string[];
    customAnswers: Record<string, string>;
    attendeeNote: string | null;
    consentEmail: boolean;
    consentSms: boolean;
    consentWhatsApp: boolean;
  } | null;
  currentUserProfile?: {
    currentCity: string | null;
    currentJob: string | null;
    currentEmployer: string | null;
    bio: string | null;
    showInDirectory: boolean;
    showCurrentJob: boolean;
    showCurrentCity: boolean;
    allowDirectMessages: boolean;
    allowNominations: boolean;
    profileVisibleTo: string;
  } | null;
}

// ─── Step definitions ─────────────────────────────────────────────────────────

type FlowStep = 1 | 2 | 3 | "confirmed" | "declined";

// ─── Component ────────────────────────────────────────────────────────────────

export function RSVPFlow({
  event,
  tickets,
  inviteToken,
  existingRsvp,
  currentUserProfile,
}: RSVPFlowProps) {
  const [currentStep, setCurrentStep] = useState<FlowStep>(() => {
    // If already confirmed/waitlisted, go straight to confirmation
    if (
      existingRsvp &&
      (existingRsvp.status === "CONFIRMED" ||
        existingRsvp.status === "WAITLISTED" ||
        existingRsvp.status === "PENDING")
    ) {
      return "confirmed";
    }
    return 1;
  });

  const [submitResult, setSubmitResult] = useState<{
    status: "CONFIRMED" | "PENDING" | "DECLINED" | "WAITLISTED";
    isWaitlisted: boolean;
    waitlistPosition: number | null;
    requiresPayment: boolean;
  } | null>(null);

  const [isSubmitting, startTransition] = useTransition();

  // Pre-fill from existing RSVP or user profile
  const form = useForm<FullRsvpInput>({
    resolver: zodResolver(fullRsvpSchema),
    defaultValues: {
      ...RSVP_DEFAULTS,
      // Pre-fill attendance from existing
      status: existingRsvp
        ? (existingRsvp.status === "CONFIRMED"
          ? "CONFIRMED"
          : existingRsvp.status === "DECLINED"
          ? "DECLINED"
          : "PENDING")
        : "CONFIRMED",
      // Pre-fill logistics from existing RSVP
      ...(existingRsvp && {
        guestCount: existingRsvp.guestCount,
        bringGuest: existingRsvp.guestCount > 0,
        dietaryRequirements: existingRsvp.dietaryRequirements.filter(
          (d) => !d.startsWith("Note:")
        ),
        dietaryNotes:
          existingRsvp.dietaryRequirements
            .find((d) => d.startsWith("Note:"))
            ?.replace("Note: ", "") ?? "",
        accessibilityNeeds:
          (existingRsvp.customAnswers["_accessibility"] as string) ?? "",
        hasAccessibilityNeeds: !!existingRsvp.customAnswers["_accessibility"],
        transportationMode:
          (existingRsvp.customAnswers["_transport_mode"] as FullRsvpInput["transportationMode"]) ?? "",
        transportationNotes:
          (existingRsvp.customAnswers["_transport_notes"] as string) ?? "",
        attendeeNote: existingRsvp.attendeeNote ?? "",
        customAnswers: Object.fromEntries(
          Object.entries(existingRsvp.customAnswers).filter(
            ([k]) => !k.startsWith("_")
          )
        ),
        consentEmail: existingRsvp.consentEmail,
        consentSms: existingRsvp.consentSms,
        consentWhatsApp: existingRsvp.consentWhatsApp,
      }),
      // Pre-fill from user profile
      ...(currentUserProfile && {
        currentCity: currentUserProfile.currentCity ?? "",
        currentJob: currentUserProfile.currentJob ?? "",
        currentEmployer: currentUserProfile.currentEmployer ?? "",
        bio: currentUserProfile.bio ?? "",
        showInDirectory: currentUserProfile.showInDirectory,
        showCurrentJob: currentUserProfile.showCurrentJob,
        showCurrentCity: currentUserProfile.showCurrentCity,
        allowDirectMessages: currentUserProfile.allowDirectMessages,
        allowNominations: currentUserProfile.allowNominations,
        profileVisibleTo: currentUserProfile.profileVisibleTo as FullRsvpInput["profileVisibleTo"],
      }),
    },
    mode: "onTouched",
  });

  const selectedStatus = form.watch("status");
  const settings = event.settings;
  const maxGuests = settings.maxGuestsPerRsvp ?? 1;
  const allowGuests = settings.allowGuestPlus1 !== false;
  const customQuestions = settings.customQuestions ?? [];

  // ── Navigation ──────────────────────────────────────────────────────────

  async function goToNextStep() {
    if (typeof currentStep !== "number") return;

    // Declined = skip straight to submit
    if (currentStep === 1 && selectedStatus === "DECLINED") {
      handleSubmit({ ...form.getValues(), status: "DECLINED" });
      return;
    }

    const fields = RSVP_STEP_FIELDS[currentStep] ?? [];
    if (fields.length > 0) {
      const valid = await form.trigger(fields as Array<keyof FullRsvpInput>);
      if (!valid) {
        // Scroll to first error
        const firstError = Object.keys(form.formState.errors)[0];
        if (firstError) {
          document
            .querySelector(`[name="${firstError}"]`)
            ?.scrollIntoView({ behavior: "smooth", block: "center" });
        }
        return;
      }
    }

    setCurrentStep((prev) =>
      typeof prev === "number" ? (Math.min(3, prev + 1) as FlowStep) : prev
    );
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function goToPrevStep() {
    setCurrentStep((prev) =>
      typeof prev === "number" ? (Math.max(1, prev - 1) as FlowStep) : prev
    );
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // ── Submit ──────────────────────────────────────────────────────────────

  function handleSubmit(data?: FullRsvpInput) {
    const formData = data ?? form.getValues();

    startTransition(async () => {
      const result = await submitRsvpAction(event.id, formData, inviteToken);

      if (!result.success) {
        if (result.code === "EVENT_FULL") {
          toast.error("This event has reached capacity.");
        } else if (result.code === "WAITLIST_FULL") {
          toast.error("The waitlist is also full. Contact the organizer.");
        } else {
          toast.error(result.error ?? "Something went wrong. Please try again.");
        }
        return;
      }

      setSubmitResult({
        status: result.data.status,
        isWaitlisted: result.data.isWaitlisted,
        waitlistPosition: result.data.waitlistPosition,
        requiresPayment: result.data.requiresPayment,
      });

      // Payment redirect
      if (result.data.requiresPayment) {
        try {
          const primaryTicket = tickets[0];
          if (!primaryTicket) {
            toast.error("No ticket available. Contact the organizer.");
            return;
          }
          const checkoutRes = await fetch(`/api/events/${event.id}/checkout`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              lineItems: [{ ticketId: primaryTicket.id, quantity: 1 }],
            }),
          });
          const checkoutJson = await checkoutRes.json();
          if (checkoutJson.data?.url) {
            window.location.href = checkoutJson.data.url;
            return;
          }
        } catch {
          toast.error("RSVP saved, but couldn't redirect to payment. Please try again.");
        }
      }

      setCurrentStep(
        result.data.status === "DECLINED" ? "declined" : "confirmed"
      );
    });
  }

  const onFinalSubmit = form.handleSubmit(handleSubmit);

  // ── Render ──────────────────────────────────────────────────────────────

  if (currentStep === "confirmed" || currentStep === "declined") {
    return (
      <RSVPConfirmation
        event={event}
        status={submitResult?.status ?? (existingRsvp?.status as "CONFIRMED") ?? "CONFIRMED"}
        isWaitlisted={submitResult?.isWaitlisted ?? false}
        waitlistPosition={submitResult?.waitlistPosition ?? null}
        isExisting={!submitResult}
      />
    );
  }

  const isLastStep = currentStep === 3;

  return (
    <Form {...form}>
      <div className="flex flex-col gap-5">
        {/* Event header */}
        <RSVPEventHeader event={event} />

        {/* Progress indicator — only for steps 1-3 */}
        {selectedStatus !== "DECLINED" && (
          <RSVPProgressDots
            currentStep={currentStep}
            totalSteps={3}
            labels={["Attendance", "Details", "Finish"]}
          />
        )}

        {/* Step content */}
        <div className="rounded-2xl border border-border bg-card shadow-card overflow-hidden">
          {currentStep === 1 && (
            <RSVPStepAttendance
              form={form}
              eventTitle={event.title}
              isReopenEdit={!!existingRsvp}
            />
          )}
          {currentStep === 2 && (
            <RSVPStepDetails
              form={form}
              allowGuests={allowGuests}
              maxGuests={maxGuests}
              customQuestions={customQuestions}
              isVirtual={!event.venueName}
            />
          )}
          {currentStep === 3 && (
            <RSVPStepConsent
              form={form}
              isUpdate={!!existingRsvp}
              currentUserProfile={currentUserProfile}
              ticketingEnabled={event.ticketingEnabled}
              tickets={tickets}
            />
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between gap-3">
          {currentStep > 1 ? (
            <Button
              type="button"
              variant="ghost"
              onClick={goToPrevStep}
              disabled={isSubmitting}
              className="gap-1.5 text-slate-600"
            >
              <ChevronLeft className="h-4 w-4" />
              Back
            </Button>
          ) : (
            <div />
          )}

          {isLastStep ? (
            <Button
              type="button"
              onClick={onFinalSubmit}
              disabled={isSubmitting}
              className="min-w-44 gap-2"
              size="lg"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Saving…
                </>
              ) : event.ticketingEnabled && selectedStatus === "CONFIRMED" ? (
                "Confirm & Pay →"
              ) : existingRsvp ? (
                "Update RSVP"
              ) : (
                "Confirm RSVP"
              )}
            </Button>
          ) : (
            <Button
              type="button"
              onClick={goToNextStep}
              disabled={isSubmitting}
              className="min-w-32"
              size="lg"
            >
              Continue →
            </Button>
          )}
        </div>
      </div>
    </Form>
  );
}
