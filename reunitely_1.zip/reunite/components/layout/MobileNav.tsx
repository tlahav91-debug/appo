"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Calendar, User, CreditCard, Shield } from "lucide-react";
import { cn } from "@/lib/utils";

interface MobileNavProps {
  isModerator?: boolean;
}

export function MobileNav({ isModerator = false }: MobileNavProps) {
  const pathname = usePathname();

  const navItems = [
    { href: "/dashboard/events", icon: Calendar, label: "Events" },
    { href: "/dashboard/profile", icon: User, label: "Profile" },
    { href: "/dashboard/billing", icon: CreditCard, label: "Billing" },
    ...(isModerator
      ? [{ href: "/admin/events", icon: Shield, label: "Admin" }]
      : []),
  ];

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 flex h-16 items-center justify-around border-t border-border bg-card pb-safe md:hidden"
      aria-label="Mobile navigation"
    >
      {navItems.map((item) => {
        const active = pathname.startsWith(item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex flex-col items-center gap-1 px-3 py-2 text-xs font-medium transition-colors",
              active ? "text-blue-600" : "text-slate-500"
            )}
            aria-current={active ? "page" : undefined}
          >
            <item.icon
              className={cn("h-5 w-5", active ? "text-blue-600" : "text-slate-400")}
            />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
