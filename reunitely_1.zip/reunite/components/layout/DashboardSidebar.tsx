"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Calendar,
  User,
  CreditCard,
  Globe,
  Shield,
  ShieldAlert,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/shared/Avatar";

interface DashboardSidebarProps {
  isSuperAdmin: boolean;
  isModerator: boolean;
  isVerifiedHost: boolean;
  userName: string;
  userAvatar: string | null;
}

// ─── Nav structure ────────────────────────────────────────────────────────────

const BASE_NAV = [
  { href: "/dashboard/events", icon: Calendar, label: "My Events" },
  { href: "/dashboard/profile", icon: User, label: "Profile" },
  { href: "/dashboard/billing", icon: CreditCard, label: "Billing" },
];

export function DashboardSidebar({
  isSuperAdmin,
  isModerator,
  isVerifiedHost,
  userName,
  userAvatar,
}: DashboardSidebarProps) {
  const pathname = usePathname();

  // Moderators and super-admins see admin nav
  const showAdminNav = isModerator;

  return (
    <aside
      className="hidden w-60 shrink-0 flex-col border-r border-border bg-card md:flex"
      aria-label="Main navigation"
    >
      {/* Logo */}
      <div className="flex h-16 items-center border-b border-border px-6">
        <Link
          href="/dashboard/events"
          className="font-display text-xl font-bold text-slate-900"
        >
          <span className="text-blue-500">Re</span>Unite
        </Link>
        {isSuperAdmin && (
          <span className="ml-2 rounded bg-red-100 px-1.5 py-0.5 text-[10px] font-bold text-red-700 uppercase tracking-wide">
            Admin
          </span>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex flex-1 flex-col gap-0.5 overflow-y-auto p-3 scrollbar-thin">
        {/* Main section */}
        <NavSection>
          {BASE_NAV.map((item) => (
            <SidebarLink
              key={item.href}
              href={item.href}
              icon={item.icon}
              label={item.label}
              active={pathname.startsWith(item.href)}
            />
          ))}
        </NavSection>

        {/* Admin section — only for moderators/super-admins */}
        {showAdminNav && (
          <NavSection label="Platform">
            <SidebarLink
              href="/admin/events"
              icon={Shield}
              label="All Events"
              active={pathname.startsWith("/admin/events")}
            />
            <SidebarLink
              href="/admin/users"
              icon={User}
              label="Users"
              active={pathname.startsWith("/admin/users")}
            />
            {isSuperAdmin && (
              <SidebarLink
                href="/admin/moderation"
                icon={ShieldAlert}
                label="Moderation"
                active={pathname.startsWith("/admin/moderation")}
              />
            )}
          </NavSection>
        )}
      </nav>

      {/* User section + view site */}
      <div className="border-t border-border p-3 flex flex-col gap-1">
        <a
          href="/"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2.5 rounded-md px-3 py-2 text-sm text-slate-500 hover:bg-slate-50 hover:text-slate-700 transition-colors"
        >
          <Globe className="h-4 w-4" />
          View Public Site
        </a>
        {/* User identity strip */}
        <div className="flex items-center gap-2.5 px-3 py-2 rounded-md bg-slate-50">
          <Avatar name={userName} src={userAvatar} size="xs" />
          <span className="text-xs font-medium text-slate-700 truncate">
            {userName}
          </span>
          {isSuperAdmin && (
            <ShieldAlert className="h-3.5 w-3.5 text-red-500 ml-auto shrink-0" />
          )}
        </div>
      </div>
    </aside>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function NavSection({
  label,
  children,
}: {
  label?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-0.5">
      {label && (
        <p className="px-3 pt-3 pb-1 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
          {label}
        </p>
      )}
      {children}
    </div>
  );
}

function SidebarLink({
  href,
  icon: Icon,
  label,
  active,
}: {
  href: string;
  icon: React.ElementType;
  label: string;
  active: boolean;
}) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
        active
          ? "bg-blue-50 text-blue-700"
          : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
      )}
      aria-current={active ? "page" : undefined}
    >
      <Icon className={cn("h-4 w-4 shrink-0", active ? "text-blue-600" : "")} />
      {label}
    </Link>
  );
}
