"use client";

import { UserButton } from "@clerk/nextjs";
import { Shield } from "lucide-react";
import { NotificationBell } from "@/components/shared/NotificationBell";
import { cn } from "@/lib/utils";

interface DashboardTopbarProps {
  userName: string;
  userAvatar: string | null;
  platformRole: "USER" | "MODERATOR" | "SUPER_ADMIN";
}

export function DashboardTopbar({
  userName,
  platformRole,
}: DashboardTopbarProps) {
  const isElevated = platformRole !== "USER";

  return (
    <header className="flex h-16 shrink-0 items-center justify-between border-b border-border bg-card px-4 md:px-6">
      {/* Left: platform role badge (shows for elevated roles only) */}
      <div className="flex items-center gap-2">
        {isElevated && (
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold",
              platformRole === "SUPER_ADMIN"
                ? "bg-red-100 text-red-700"
                : "bg-violet-100 text-violet-700"
            )}
          >
            <Shield className="h-3 w-3" />
            {platformRole === "SUPER_ADMIN" ? "Super Admin" : "Moderator"}
          </span>
        )}
      </div>

      {/* Right: notifications + user button */}
      <div className="flex items-center gap-3">
        <NotificationBell />
        <UserButton
          afterSignOutUrl="/"
          appearance={{
            elements: {
              avatarBox: "h-8 w-8",
              userButtonPopoverCard:
                "shadow-card-lg border border-border rounded-xl",
            },
          }}
        />
      </div>
    </header>
  );
}
