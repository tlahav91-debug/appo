"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Ticket, Users, Heart, Tag, ChevronRight, Loader2, CheckCircle,
  AlertCircle, Plus, Minus, CreditCard, Lock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatCurrency, cn } from "@/lib/utils";
import { toast } from "sonner";

interface TicketOption {
  id: string;
  name: string;
  description: string | null;
  price: number;     // cents
  currency: string;
  capacity: number | null;
  soldCount: number;
  maxPerOrder: number;
  type: string;
  earlyBirdPrice?: number | null;
  earlyBirdDeadline?: string | null;
  couponCode?: string | null;
}

interface TicketPurchaseFlowProps {
  eventId: string;
  eventSlug: string;
  tickets: TicketOption[];
  allowPlusOne: boolean;
  maxGuests: number;
}

export function TicketPurchaseFlow({
  eventId,
  eventSlug,
  tickets,
  allowPlusOne,
  maxGuests,
}: TicketPurchaseFlowProps) {
  const router = useRouter();

  // Selected quantities per ticket
  const [quantities, setQuantities] = useState<Record<string, number>>(
    Object.fromEntries(tickets.map((t) => [t.id, 0]))
  );
  const [guestCount, setGuestCount] = useState(0);
  const [donationCents, setDonationCents] = useState(0);
  const [couponCode, setCouponCode] = useState("");
  const [showCoupon, setShowCoupon] = useState(false);
  const [showDonation, setShowDonation] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const primaryTickets = tickets.filter((t) => t.type !== "DONATION");
  const currency = tickets[0]?.currency ?? "USD";

  function setQty(ticketId: string, delta: number) {
    const ticket = tickets.find((t) => t.id === ticketId)!;
    const current = quantities[ticketId] ?? 0;
    const available =
      ticket.capacity !== null
        ? ticket.capacity - ticket.soldCount
        : Infinity;
    const newQty = Math.max(0, Math.min(current + delta, ticket.maxPerOrder, available));
    setQuantities((prev) => ({ ...prev, [ticketId]: newQty }));
  }

  const totalTicketCents = primaryTickets.reduce(
    (sum, t) => sum + (quantities[t.id] ?? 0) * t.price,
    0
  );
  const totalCents = totalTicketCents + donationCents;
  const totalQty = Object.values(quantities).reduce((s, q) => s + q, 0);
  const isFree = totalCents === 0 && totalQty > 0;

  const lineItems = Object.entries(quantities)
    .filter(([, qty]) => qty > 0)
    .map(([ticketId, quantity]) => ({ ticketId, quantity }));

  async function handleCheckout() {
    if (lineItems.length === 0) {
      toast.error("Select at least one ticket");
      return;
    }
    setIsLoading(true);

    try {
      const res = await fetch(`/api/events/${eventId}/checkout`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lineItems,
          donationCents,
          couponCode: couponCode.trim() || undefined,
          guestCount,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error?.message ?? "Checkout failed");
      }

      if (data.data.free) {
        // Free event — direct redirect
        router.push(data.data.redirectUrl);
      } else {
        // Redirect to Stripe Checkout
        router.push(data.data.url);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Checkout failed");
      setIsLoading(false);
    }
  }

  return (
    <div className="flex flex-col gap-5">
      {/* Ticket options */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500">
          Select tickets
        </h3>
        {primaryTickets.map((ticket) => {
          const qty = quantities[ticket.id] ?? 0;
          const remaining =
            ticket.capacity !== null ? ticket.capacity - ticket.soldCount : null;
          const isSoldOut = remaining !== null && remaining <= 0;
          const isEarlyBird =
            ticket.earlyBirdPrice != null &&
            ticket.earlyBirdDeadline != null &&
            new Date(ticket.earlyBirdDeadline) > new Date();
          const displayPrice = isEarlyBird
            ? ticket.earlyBirdPrice!
            : ticket.price;

          return (
            <div
              key={ticket.id}
              className={cn(
                "rounded-xl border bg-card p-4 transition-all",
                qty > 0
                  ? "border-blue-400 shadow-sm bg-blue-50/30"
                  : isSoldOut
                  ? "border-border opacity-60"
                  : "border-border hover:border-blue-300"
              )}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-slate-900">{ticket.name}</p>
                    {isSoldOut && (
                      <span className="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-semibold text-red-600">
                        SOLD OUT
                      </span>
                    )}
                    {isEarlyBird && (
                      <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-700">
                        EARLY BIRD
                      </span>
                    )}
                    {remaining !== null && remaining <= 5 && !isSoldOut && (
                      <span className="text-[11px] text-orange-600 font-medium">
                        Only {remaining} left
                      </span>
                    )}
                  </div>
                  {ticket.description && (
                    <p className="mt-0.5 text-xs text-slate-500">{ticket.description}</p>
                  )}
                  <p className="mt-1.5 text-lg font-bold text-slate-900">
                    {displayPrice === 0
                      ? "Free"
                      : formatCurrency(displayPrice, ticket.currency)}
                    {isEarlyBird && ticket.price > displayPrice && (
                      <span className="ml-2 text-sm text-slate-400 line-through">
                        {formatCurrency(ticket.price, ticket.currency)}
                      </span>
                    )}
                  </p>
                </div>

                {/* Quantity stepper */}
                {!isSoldOut && (
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => setQty(ticket.id, -1)}
                      disabled={qty === 0}
                      className="flex h-8 w-8 items-center justify-center rounded-lg border border-border text-slate-500 hover:border-blue-400 hover:text-blue-600 disabled:opacity-40 transition-colors"
                    >
                      <Minus className="h-3.5 w-3.5" />
                    </button>
                    <span className="w-6 text-center text-sm font-semibold text-slate-900">
                      {qty}
                    </span>
                    <button
                      type="button"
                      onClick={() => setQty(ticket.id, 1)}
                      disabled={
                        qty >= ticket.maxPerOrder ||
                        (remaining !== null && qty >= remaining)
                      }
                      className="flex h-8 w-8 items-center justify-center rounded-lg border border-border text-slate-500 hover:border-blue-400 hover:text-blue-600 disabled:opacity-40 transition-colors"
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Plus one */}
      {allowPlusOne && totalQty > 0 && (
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-slate-400" />
              <div>
                <p className="text-sm font-medium text-slate-900">Bring a guest?</p>
                <p className="text-xs text-slate-400">
                  Add up to {maxGuests} guest{maxGuests !== 1 ? "s" : ""}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setGuestCount(Math.max(0, guestCount - 1))}
                disabled={guestCount === 0}
                className="flex h-7 w-7 items-center justify-center rounded-lg border border-border text-slate-500 hover:border-blue-400 disabled:opacity-40 transition-colors"
              >
                <Minus className="h-3 w-3" />
              </button>
              <span className="w-5 text-center text-sm font-semibold">{guestCount}</span>
              <button
                type="button"
                onClick={() => setGuestCount(Math.min(maxGuests, guestCount + 1))}
                disabled={guestCount >= maxGuests}
                className="flex h-7 w-7 items-center justify-center rounded-lg border border-border text-slate-500 hover:border-blue-400 disabled:opacity-40 transition-colors"
              >
                <Plus className="h-3 w-3" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add-ons: donation */}
      {totalQty > 0 && (
        <div className="rounded-xl border border-border bg-card p-4">
          {!showDonation ? (
            <button
              type="button"
              onClick={() => setShowDonation(true)}
              className="flex w-full items-center gap-2 text-sm text-slate-500 hover:text-blue-600 transition-colors"
            >
              <Heart className="h-4 w-4" />
              Add a donation to help cover costs (optional)
              <ChevronRight className="h-4 w-4 ml-auto" />
            </button>
          ) : (
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Heart className="h-4 w-4 text-pink-500" />
                <p className="text-sm font-medium text-slate-900">Add a donation</p>
              </div>
              <div className="flex gap-2">
                {[5, 10, 25, 50].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setDonationCents(donationCents === amt * 100 ? 0 : amt * 100)}
                    className={cn(
                      "flex-1 rounded-lg border py-2 text-sm font-medium transition-all",
                      donationCents === amt * 100
                        ? "border-pink-400 bg-pink-50 text-pink-700"
                        : "border-border text-slate-600 hover:border-pink-300"
                    )}
                  >
                    ${amt}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-500">Or enter amount:</span>
                <Input
                  type="number"
                  min={0}
                  max={1000}
                  placeholder="0"
                  className="h-8 w-24 text-sm"
                  onChange={(e) => setDonationCents(Math.round((parseFloat(e.target.value) || 0) * 100))}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Coupon code */}
      {totalQty > 0 && totalCents > 0 && (
        <div>
          {!showCoupon ? (
            <button
              type="button"
              onClick={() => setShowCoupon(true)}
              className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-blue-600 transition-colors"
            >
              <Tag className="h-3.5 w-3.5" />
              Have a coupon code?
            </button>
          ) : (
            <div className="flex gap-2">
              <Input
                placeholder="Enter code"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                className="text-sm font-mono"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCouponCode("")}
                className="shrink-0"
              >
                Clear
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Order summary */}
      {totalQty > 0 && (
        <div className="rounded-xl border border-blue-200 bg-blue-50 p-4 flex flex-col gap-2">
          <p className="text-xs font-semibold uppercase tracking-wider text-blue-700">
            Order summary
          </p>
          {primaryTickets
            .filter((t) => (quantities[t.id] ?? 0) > 0)
            .map((t) => (
              <div key={t.id} className="flex items-center justify-between text-sm">
                <span className="text-slate-700">
                  {t.name} × {quantities[t.id]}
                </span>
                <span className="font-medium text-slate-900">
                  {t.price === 0
                    ? "Free"
                    : formatCurrency(t.price * (quantities[t.id] ?? 0), t.currency)}
                </span>
              </div>
            ))}
          {guestCount > 0 && (
            <div className="flex items-center justify-between text-sm text-slate-600">
              <span>
                Guest{guestCount > 1 ? "s" : ""} (+{guestCount})
              </span>
              <span className="text-slate-400">Included</span>
            </div>
          )}
          {donationCents > 0 && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-700">Donation 💛</span>
              <span className="font-medium">{formatCurrency(donationCents, currency)}</span>
            </div>
          )}
          <div className="border-t border-blue-200 pt-2 flex items-center justify-between">
            <span className="font-semibold text-slate-900">Total</span>
            <span className="text-lg font-bold text-slate-900">
              {isFree ? "Free" : formatCurrency(totalCents, currency)}
            </span>
          </div>
        </div>
      )}

      {/* CTA */}
      <Button
        onClick={handleCheckout}
        disabled={totalQty === 0 || isLoading}
        className={cn(
          "w-full gap-2 py-6 text-base font-semibold",
          totalQty > 0
            ? "bg-blue-500 hover:bg-blue-700"
            : "bg-slate-200 text-slate-400"
        )}
      >
        {isLoading ? (
          <Loader2 className="h-5 w-5 animate-spin" />
        ) : isFree ? (
          <>
            <CheckCircle className="h-5 w-5" />
            Confirm — Free Event
          </>
        ) : (
          <>
            <CreditCard className="h-5 w-5" />
            {totalQty === 0 ? "Select a ticket" : `Checkout — ${formatCurrency(totalCents, currency)}`}
          </>
        )}
      </Button>

      {!isFree && totalQty > 0 && (
        <p className="flex items-center justify-center gap-1.5 text-xs text-slate-400">
          <Lock className="h-3 w-3" />
          Secured by Stripe. You'll be redirected to complete payment.
        </p>
      )}
    </div>
  );
}
