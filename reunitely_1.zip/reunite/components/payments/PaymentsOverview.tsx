import { db } from "@/lib/db";
import { formatCurrency, formatShortDate } from "@/lib/utils";
import { DollarSign, CreditCard, RefreshCcw, TrendingUp } from "lucide-react";
import { EmptyState } from "@/components/shared/EmptyState";
import { cn } from "@/lib/utils";

// ─── PaymentsOverview ─────────────────────────────────────────────────────────

export async function PaymentsOverview({ eventId }: { eventId: string }) {
  const [paid, refunded] = await Promise.all([
    db.payment.findMany({
      where: { eventId, status: "PAID" },
      select: { totalAmountCents: true, currency: true },
    }),
    db.payment.count({ where: { eventId, status: "REFUNDED" } }),
  ]);

  const totalRevenue = paid.reduce((sum, p) => sum + p.totalAmountCents, 0);
  const currency = paid[0]?.currency ?? "USD";
  const paidCount = paid.length;

  const stats = [
    {
      label: "Total Revenue",
      value: formatCurrency(totalRevenue, currency),
      icon: DollarSign,
      color: "text-emerald-600",
      bg: "bg-emerald-50",
    },
    {
      label: "Paid Orders",
      value: paidCount.toString(),
      icon: CreditCard,
      color: "text-blue-600",
      bg: "bg-blue-50",
    },
    {
      label: "Refunds",
      value: refunded.toString(),
      icon: RefreshCcw,
      color: "text-blue-600",
      bg: "bg-blue-50",
    },
    {
      label: "Avg. Order",
      value:
        paidCount > 0
          ? formatCurrency(totalRevenue / paidCount, currency)
          : "—",
      icon: TrendingUp,
      color: "text-violet-600",
      bg: "bg-violet-50",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="flex flex-col gap-3 rounded-xl border border-border bg-card p-5 shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wider text-slate-500">
              {stat.label}
            </span>
            <div className={cn("rounded-lg p-1.5", stat.bg)}>
              <stat.icon className={cn("h-4 w-4", stat.color)} />
            </div>
          </div>
          <p className="font-display text-2xl font-bold text-slate-900">
            {stat.value}
          </p>
        </div>
      ))}
    </div>
  );
}

// ─── OrdersTable ─────────────────────────────────────────────────────────────

export async function OrdersTable({ eventId }: { eventId: string }) {
  const payments = await db.payment.findMany({
    where: { eventId },
    include: {
      user: { select: { name: true, email: true } },
      ticket: { select: { name: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 200,
  });

  if (payments.length === 0) {
    return (
      <EmptyState
        icon={<CreditCard className="h-8 w-8" />}
        title="No payments yet"
        description="Payments will appear here once attendees purchase tickets."
        size="md"
      />
    );
  }

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm">
      <div className="border-b border-border bg-slate-50 px-4 py-3 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-700">
          All Payments ({payments.length})
        </h3>
        <span className="text-xs text-slate-400">
          {payments.filter((p) => p.status === "PAID").length} paid
          {" · "}
          {payments.filter((p) => p.status === "REFUNDED" || p.status === "PARTIALLY_REFUNDED").length} refunded
        </span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full" aria-label="Payments table">
          <thead>
            <tr className="border-b border-border">
              {["Attendee", "Ticket", "Amount", "Code", "Status", "Date", ""].map((h) => (
                <th
                  key={h}
                  className={cn(
                    "px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500",
                    h === "Ticket" && "hidden sm:table-cell",
                    h === "Code" && "hidden md:table-cell",
                    h === "Date" && "hidden lg:table-cell"
                  )}
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {payments.map((payment) => (
              <tr key={payment.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-4 py-3">
                  <p className="text-sm font-medium text-slate-900">
                    {payment.user.name}
                  </p>
                  <p className="text-xs text-slate-400">{payment.user.email}</p>
                </td>
                <td className="hidden px-4 py-3 text-sm text-slate-600 sm:table-cell">
                  {payment.ticket.name}
                  {payment.quantity > 1 && (
                    <span className="ml-1 text-slate-400">× {payment.quantity}</span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <p className="text-sm font-semibold text-slate-900">
                    {formatCurrency(payment.totalAmountCents, payment.currency)}
                  </p>
                  {payment.refundedAmountCents > 0 && (
                    <p className="text-[11px] text-red-500">
                      −{formatCurrency(payment.refundedAmountCents, payment.currency)} refunded
                    </p>
                  )}
                </td>
                <td className="hidden px-4 py-3 md:table-cell">
                  {payment.ticketCode ? (
                    <span className="font-mono text-xs font-semibold text-blue-700 bg-blue-50 rounded px-1.5 py-0.5">
                      {payment.ticketCode}
                    </span>
                  ) : (
                    <span className="text-xs text-slate-300">—</span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <PaymentStatusBadge status={payment.status} />
                </td>
                <td className="hidden px-4 py-3 text-xs text-slate-400 lg:table-cell">
                  {payment.paidAt
                    ? formatShortDate(payment.paidAt)
                    : formatShortDate(payment.createdAt)}
                </td>
                <td className="px-4 py-3">
                  {payment.status === "PAID" && (
                    <RefundButton paymentId={payment.id} />
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function PaymentStatusBadge({ status }: { status: string }) {
  const config: Record<string, string> = {
    PAID:     "bg-emerald-50 text-emerald-700 border-emerald-200",
    PENDING:  "bg-blue-50 text-blue-700 border-blue-200",
    REFUNDED: "bg-slate-100 text-slate-500 border-slate-200",
    FAILED:   "bg-red-50 text-red-600 border-red-200",
  };
  const label: Record<string, string> = {
    PAID: "Paid", PENDING: "Pending", REFUNDED: "Refunded", FAILED: "Failed",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium",
        config[status] ?? "bg-slate-100 text-slate-500 border-slate-200"
      )}
    >
      {label[status] ?? status}
    </span>
  );
}

// ─── RefundButton ─────────────────────────────────────────────────────────────
// Rendered as a link — actual dialog lives in PaymentsPageClient (client component)
// to avoid making this server component a client component.

function RefundButton({ paymentId }: { paymentId: string }) {
  return (
    <a
      href={`?refund=${paymentId}`}
      className="text-xs text-red-400 hover:text-red-600 font-medium transition-colors"
    >
      Refund
    </a>
  );
}
