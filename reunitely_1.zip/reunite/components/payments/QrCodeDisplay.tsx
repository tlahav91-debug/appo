"use client";

import { useEffect, useRef } from "react";

interface QrCodeDisplayProps {
  payload: string;
  size?: number;
  className?: string;
}

export function QrCodeDisplay({ payload, size = 200, className }: QrCodeDisplayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    let cancelled = false;

    async function drawQr() {
      if (!canvasRef.current) return;

      try {
        // Dynamic import to keep QR lib out of the main bundle
        const QRCode = await import("qrcode");
        if (cancelled || !canvasRef.current) return;

        await QRCode.toCanvas(canvasRef.current, payload, {
          width: size,
          margin: 2,
          color: {
            dark: "#1e293b",   // slate-800
            light: "#ffffff",
          },
          errorCorrectionLevel: "M",
        });
      } catch (err) {
        console.error("QR generation failed:", err);
        // Fallback: render payload as text
        if (canvasRef.current && !cancelled) {
          const ctx = canvasRef.current.getContext("2d");
          if (ctx) {
            canvasRef.current.width = size;
            canvasRef.current.height = size;
            ctx.fillStyle = "#f8fafc";
            ctx.fillRect(0, 0, size, size);
            ctx.fillStyle = "#1e293b";
            ctx.font = "12px monospace";
            ctx.textAlign = "center";
            ctx.fillText("QR unavailable", size / 2, size / 2);
          }
        }
      }
    }

    drawQr();
    return () => { cancelled = true; };
  }, [payload, size]);

  return (
    <div className={`rounded-2xl bg-white p-3 shadow-sm border border-slate-100 ${className ?? ""}`}>
      <canvas
        ref={canvasRef}
        width={size}
        height={size}
        className="rounded-xl block"
        aria-label="Ticket QR code"
        role="img"
      />
    </div>
  );
}
