"use client";

import { useState } from "react";
import { ExternalLink, CheckCircle, AlertCircle, Loader2, CreditCard } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface StripeConnectCardProps {
  eventId: string;
  stripeAccountId: string | null;
  ticketingEnabled: boolean;
}

export function StripeConnectCard({
  eventId,
  stripeAccountId,
  ticketingEnabled,
}: StripeConnectCardProps) {
  const [isConnecting, setIsConnecting] = useState(false);

  if (!ticketingEnabled) {
    return (
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center gap-3 text-slate-500">
          <CreditCard className="h-5 w-5" />
          <div>
            <p className="text-sm font-medium text-slate-700">
              Ticketing not enabled
            </p>
            <p className="text-xs mt-0.5">
              Enable paid tickets in{" "}
              <a
                href={`/dashboard/events/${eventId}/settings`}
                className="text-blue-600 hover:underline"
              >
                Settings
              </a>{" "}
              to accept payments.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (stripeAccountId) {
    return (
      <div className="flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 p-5">
        <CheckCircle className="h-5 w-5 text-emerald-600 shrink-0" />
        <div>
          <p className="text-sm font-medium text-emerald-800">
            Stripe connected
          </p>
          <p className="text-xs text-emerald-700 mt-0.5">
            Payments are being processed and will be paid out to your Stripe account.
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="ml-auto shrink-0 gap-1.5 border-emerald-300 text-emerald-700 hover:bg-emerald-100"
          asChild
        >
          <a
            href="https://dashboard.stripe.com"
            target="_blank"
            rel="noopener noreferrer"
          >
            Stripe Dashboard
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </Button>
      </div>
    );
  }

  async function handleConnect() {
    setIsConnecting(true);
    try {
      const res = await fetch(`/api/events/${eventId}/stripe/connect`, {
        method: "POST",
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error?.message ?? "Failed to start Stripe connect");
      if (json.data?.url) {
        window.location.href = json.data.url;
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to connect Stripe");
      setIsConnecting(false);
    }
  }

  return (
    <div className="flex items-center gap-3 rounded-xl border border-blue-200 bg-blue-50 p-5">
      <AlertCircle className="h-5 w-5 text-blue-600 shrink-0" />
      <div className="flex-1">
        <p className="text-sm font-medium text-blue-800">
          Connect Stripe to accept payments
        </p>
        <p className="text-xs text-blue-700 mt-0.5">
          You need a Stripe account to collect ticket payments. Takes about 5 minutes.
        </p>
      </div>
      <Button
        size="sm"
        className="shrink-0 gap-2"
        onClick={handleConnect}
        disabled={isConnecting}
      >
        {isConnecting ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : null}
        Connect Stripe
      </Button>
    </div>
  );
}
