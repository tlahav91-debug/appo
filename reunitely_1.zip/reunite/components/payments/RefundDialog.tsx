"use client";

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Loader2, RefreshCcw, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/utils";

interface RefundDialogProps {
  paymentId: string;
  totalAmountCents: number;
  currency: string;
  attendeeName: string;
  open: boolean;
  onClose: () => void;
}

const REASONS = [
  { value: "ATTENDEE_REQUEST", label: "Attendee requested refund" },
  { value: "CANCELLED_EVENT", label: "Event was cancelled" },
  { value: "ORGANIZER_CANCELLED", label: "Organizer cancelled registration" },
  { value: "DUPLICATE", label: "Duplicate payment" },
  { value: "OTHER", label: "Other" },
];

export function RefundDialog({
  paymentId,
  totalAmountCents,
  currency,
  attendeeName,
  open,
  onClose,
}: RefundDialogProps) {
  const [reason, setReason] = useState("ATTENDEE_REQUEST");
  const [isPartial, setIsPartial] = useState(false);
  const [partialAmount, setPartialAmount] = useState("");
  const [note, setNote] = useState("");
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: async () => {
      const amountCents = isPartial
        ? Math.round(parseFloat(partialAmount) * 100)
        : undefined;

      const res = await fetch(`/api/payments/${paymentId}/refund`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason, amountCents, note: note || undefined }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error?.message ?? "Refund failed");
      }
      return res.json();
    },
    onSuccess: (data) => {
      const refundedStr = formatCurrency(data.data.amount, currency);
      toast.success(`Refund of ${refundedStr} issued to ${attendeeName}`);
      queryClient.invalidateQueries({ queryKey: ["payments"] });
      onClose();
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Refund failed"),
  });

  const maxAmount = totalAmountCents / 100;
  const partialAmountNum = parseFloat(partialAmount) || 0;
  const isValid =
    reason &&
    (!isPartial || (partialAmountNum > 0 && partialAmountNum <= maxAmount));

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <RefreshCcw className="h-4 w-4 text-slate-500" />
            Issue refund
          </DialogTitle>
          <DialogDescription>
            Refund for {attendeeName} · Total paid:{" "}
            <strong>{formatCurrency(totalAmountCents, currency)}</strong>
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-2">
          {/* Reason */}
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">Reason</Label>
            <select
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="h-9 rounded-lg border border-border bg-background px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-400"
            >
              {REASONS.map((r) => (
                <option key={r.value} value={r.value}>{r.label}</option>
              ))}
            </select>
          </div>

          {/* Full or partial */}
          <div className="flex flex-col gap-2">
            <Label className="text-xs">Refund amount</Label>
            <div className="flex gap-2">
              <button
                onClick={() => setIsPartial(false)}
                className={`flex-1 rounded-lg border py-2 text-sm font-medium transition-all ${
                  !isPartial
                    ? "border-blue-500 bg-blue-50 text-blue-700"
                    : "border-border text-slate-600 hover:border-blue-300"
                }`}
              >
                Full ({formatCurrency(totalAmountCents, currency)})
              </button>
              <button
                onClick={() => setIsPartial(true)}
                className={`flex-1 rounded-lg border py-2 text-sm font-medium transition-all ${
                  isPartial
                    ? "border-blue-500 bg-blue-50 text-blue-700"
                    : "border-border text-slate-600 hover:border-blue-300"
                }`}
              >
                Partial amount
              </button>
            </div>

            {isPartial && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-500">{currency}</span>
                <input
                  type="number"
                  min={0.01}
                  max={maxAmount}
                  step={0.01}
                  placeholder={`max ${maxAmount.toFixed(2)}`}
                  value={partialAmount}
                  onChange={(e) => setPartialAmount(e.target.value)}
                  className="flex-1 rounded-lg border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
              </div>
            )}
          </div>

          {/* Internal note */}
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">Internal note (optional)</Label>
            <input
              placeholder="Add context for your records..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="rounded-lg border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
          </div>

          {/* Warning */}
          <div className="flex items-start gap-2 rounded-xl bg-amber-50 border border-amber-200 p-3">
            <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800">
              Refunds are processed via Stripe and typically take 5–10 business days
              to appear on the attendee's statement. This action cannot be undone.
            </p>
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button
            onClick={() => mutation.mutate()}
            disabled={!isValid || mutation.isPending}
            className="flex-1 bg-red-500 hover:bg-red-600 gap-2"
          >
            {mutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCcw className="h-4 w-4" />
            )}
            {isPartial
              ? `Refund ${partialAmountNum > 0 ? formatCurrency(Math.round(partialAmountNum * 100), currency) : "..."}`
              : `Refund ${formatCurrency(totalAmountCents, currency)}`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
