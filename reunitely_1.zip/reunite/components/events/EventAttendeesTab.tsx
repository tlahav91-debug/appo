import Link from "next/link";
import { db } from "@/lib/db";
import { Avatar } from "@/components/shared/Avatar";
import { EmptyState } from "@/components/shared/EmptyState";
import { Users } from "lucide-react";
import { pluralize } from "@/lib/utils";
import { cn } from "@/lib/utils";

interface EventAttendeesTabProps {
  eventId: string;
  eventSlug: string;
}

export async function EventAttendeesTab({ eventId, eventSlug }: EventAttendeesTabProps) {
  // Only show attendees who have opted into the directory
  const rsvps = await db.rSVP.findMany({
    where: {
      eventId,
      status: "CONFIRMED",
      user: {
        attendeeProfile: {
          showInDirectory: true,
          profileVisibleTo: "EVENT_ATTENDEES",
        },
      },
    },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          avatarUrl: true,
          attendeeProfile: {
            select: {
              currentCity: true,
              currentJob: true,
              currentEmployer: true,
              showCurrentCity: true,
              showCurrentJob: true,
              bio: true,
            },
          },
        },
      },
    },
    orderBy: { submittedAt: "asc" },
    take: 48,
  });

  const totalConfirmed = await db.rSVP.count({
    where: { eventId, status: "CONFIRMED" },
  });

  // Count private attendees
  const hiddenCount = totalConfirmed - rsvps.length;

  if (rsvps.length === 0) {
    return (
      <EmptyState
        icon={<Users className="h-8 w-8" />}
        title="No public attendees yet"
        description={
          totalConfirmed > 0
            ? `${totalConfirmed} people are attending but have set their profile to private.`
            : "Be the first to RSVP and show your face!"
        }
        size="md"
      />
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <Link
          href={`/events/${eventSlug}/attendees`}
          className="text-xs font-medium text-blue-600 hover:underline"
        >
          Full directory →
        </Link>
        <p className="text-sm text-slate-500">
          <span className="font-semibold text-slate-900">
            {totalConfirmed.toLocaleString()}
          </span>{" "}
          confirmed
          {hiddenCount > 0 && (
            <span className="ml-1 text-slate-400">
              · {hiddenCount} private
            </span>
          )}
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {rsvps.map(({ user }) => {
          const profile = user.attendeeProfile;
          const showCity = profile?.showCurrentCity && profile?.currentCity;
          const showJob = profile?.showCurrentJob && profile?.currentJob;
          const locationLine = [
            showJob ? profile?.currentJob : null,
            showCity ? profile?.currentCity : null,
          ]
            .filter(Boolean)
            .join(" · ");

          return (
            <Link
              key={user.id}
              href={`/events/${eventSlug}/attendees/${user.id}`}
              className="flex items-start gap-3 rounded-xl border border-border bg-card p-4 hover:shadow-sm hover:border-blue-200 transition-all"
            >
              <Avatar
                name={user.name}
                src={user.avatarUrl}
                size="md"
                className="shrink-0"
              />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-slate-900 truncate hover:text-blue-700">
                  {user.name}
                </p>
                {locationLine && (
                  <p className="text-xs text-slate-400 truncate mt-0.5">
                    {locationLine}
                  </p>
                )}
                {profile?.bio && (
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                    {profile.bio}
                  </p>
                )}
              </div>
            </Link>
          );
        })}
      </div>

      {rsvps.length === 48 && (
        <p className="text-center text-xs text-slate-400">
          Showing 48 of {totalConfirmed} attendees
        </p>
      )}

      {/* Nominate a missing classmate */}
      <div className="rounded-xl border border-dashed border-blue-300 bg-blue-50 px-5 py-4 flex items-center justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-blue-900">
            Don't see someone you expected?
          </p>
          <p className="text-xs text-blue-700 mt-0.5">
            Nominate a missing classmate — we'll track them down.
          </p>
        </div>
        <Link
          href="nominate"
          className="shrink-0 flex items-center gap-1.5 rounded-lg bg-blue-500 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 transition-colors"
        >
          Nominate
        </Link>
      </div>
    </div>
  );
}
