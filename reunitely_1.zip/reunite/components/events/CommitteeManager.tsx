"use client";

import { useState, useTransition } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  UserPlus,
  Trash2,
  ShieldCheck,
  Shield,
  Loader2,
  ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Avatar } from "@/components/shared/Avatar";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { toast } from "sonner";
import {
  addCommitteeMemberAction,
} from "@/lib/actions/event.actions";
import { cn } from "@/lib/utils";

// ─── Types ────────────────────────────────────────────────────────────────────

interface CommitteeMemberRecord {
  id: string;
  role: "ORGANIZER" | "CO_ORGANIZER" | "COMMITTEE";
  title: string | null;
  canManageRsvps: boolean;
  canSendMessages: boolean;
  canModerateContent: boolean;
  canManageTickets: boolean;
  canViewPayments: boolean;
  canCheckIn: boolean;
  addedAt: string;
  user: { id: string; name: string; email: string; avatarUrl: string | null };
}

// ─── Fetcher ──────────────────────────────────────────────────────────────────

async function fetchCommittee(eventId: string): Promise<CommitteeMemberRecord[]> {
  const res = await fetch(`/api/events/${eventId}/committee`);
  if (!res.ok) throw new Error("Failed to load committee");
  return (await res.json()).data ?? [];
}

async function revokeCommitteeMember(
  eventId: string,
  memberId: string
): Promise<void> {
  const res = await fetch(`/api/events/${eventId}/committee/${memberId}`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error("Failed to remove member");
}

// ─── Main component ───────────────────────────────────────────────────────────

export function CommitteeManager({ eventId }: { eventId: string }) {
  const queryClient = useQueryClient();
  const [addOpen, setAddOpen] = useState(false);

  const { data: members = [], isLoading } = useQuery({
    queryKey: ["committee", eventId],
    queryFn: () => fetchCommittee(eventId),
    staleTime: 60_000,
  });

  async function handleRevoke(memberId: string) {
    try {
      await revokeCommitteeMember(eventId, memberId);
      queryClient.invalidateQueries({ queryKey: ["committee", eventId] });
      toast.success("Committee member removed");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to remove member");
    }
  }

  const roleIcon = (role: string) =>
    role === "CO_ORGANIZER" ? (
      <ShieldCheck className="h-3.5 w-3.5 text-blue-500" />
    ) : role === "ORGANIZER" ? (
      <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
    ) : (
      <Shield className="h-3.5 w-3.5 text-slate-400" />
    );

  return (
    <div className="flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">
            Organizing Committee
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage who can help run this event.
          </p>
        </div>
        <Button
          size="sm"
          variant="outline"
          className="gap-2"
          onClick={() => setAddOpen(true)}
        >
          <UserPlus className="h-4 w-4" />
          Add Member
        </Button>
      </div>

      {/* Members list */}
      {isLoading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-5 w-5 animate-spin text-slate-300" />
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {members.map((member) => (
            <div
              key={member.id}
              className="flex items-center justify-between rounded-xl border border-border bg-card p-4"
            >
              <div className="flex items-center gap-3 min-w-0">
                <Avatar
                  name={member.user.name}
                  src={member.user.avatarUrl}
                  size="sm"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    {roleIcon(member.role)}
                    <p className="text-sm font-medium text-slate-900 truncate">
                      {member.user.name}
                    </p>
                    {member.title && (
                      <span className="text-xs text-slate-400">
                        · {member.title}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 truncate">
                    {member.user.email}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 ml-4 shrink-0">
                {/* Permission pills */}
                <div className="hidden sm:flex gap-1 flex-wrap">
                  {member.canManageRsvps && (
                    <PermPill label="RSVPs" />
                  )}
                  {member.canSendMessages && (
                    <PermPill label="Messages" />
                  )}
                  {member.canModerateContent && (
                    <PermPill label="Moderate" />
                  )}
                  {member.canViewPayments && (
                    <PermPill label="Payments" />
                  )}
                  {member.canCheckIn && (
                    <PermPill label="Check-in" color="emerald" />
                  )}
                </div>

                {/* Cannot remove the lead organizer */}
                {member.role !== "ORGANIZER" && (
                  <ConfirmDialog
                    trigger={
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-slate-400 hover:text-red-500"
                        aria-label={`Remove ${member.user.name}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    }
                    title={`Remove ${member.user.name}?`}
                    description="They will lose access to the organizer dashboard for this event immediately."
                    confirmLabel="Remove"
                    onConfirm={() => handleRevoke(member.id)}
                  />
                )}
              </div>
            </div>
          ))}

          {members.length === 0 && (
            <p className="py-6 text-center text-sm text-slate-400">
              No committee members yet. Add someone to help organize this event.
            </p>
          )}
        </div>
      )}

      {/* Add member dialog */}
      <AddCommitteeMemberDialog
        eventId={eventId}
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onAdded={() => {
          queryClient.invalidateQueries({ queryKey: ["committee", eventId] });
          setAddOpen(false);
        }}
      />
    </div>
  );
}

// ─── Permission pill ──────────────────────────────────────────────────────────

function PermPill({
  label,
  color = "slate",
}: {
  label: string;
  color?: "slate" | "emerald";
}) {
  return (
    <span
      className={cn(
        "rounded-full px-2 py-0.5 text-[10px] font-medium",
        color === "emerald"
          ? "bg-emerald-50 text-emerald-700"
          : "bg-slate-100 text-slate-600"
      )}
    >
      {label}
    </span>
  );
}

// ─── Add member dialog ────────────────────────────────────────────────────────

const DEFAULT_PERMISSIONS = {
  canManageRsvps: false,
  canSendMessages: false,
  canModerateContent: false,
  canManageTickets: false,
  canViewPayments: false,
  canCheckIn: true,
};

const ROLE_PRESETS: Record<
  "CO_ORGANIZER" | "COMMITTEE",
  typeof DEFAULT_PERMISSIONS
> = {
  CO_ORGANIZER: {
    canManageRsvps: true,
    canSendMessages: true,
    canModerateContent: true,
    canManageTickets: false,
    canViewPayments: false,
    canCheckIn: true,
  },
  COMMITTEE: {
    canManageRsvps: false,
    canSendMessages: false,
    canModerateContent: false,
    canManageTickets: false,
    canViewPayments: false,
    canCheckIn: true,
  },
};

function AddCommitteeMemberDialog({
  eventId,
  open,
  onClose,
  onAdded,
}: {
  eventId: string;
  open: boolean;
  onClose: () => void;
  onAdded: () => void;
}) {
  const [isPending, startTransition] = useTransition();
  const [email, setEmail] = useState("");
  const [title, setTitle] = useState("");
  const [role, setRole] = useState<"CO_ORGANIZER" | "COMMITTEE">("CO_ORGANIZER");
  const [permissions, setPermissions] = useState(ROLE_PRESETS.CO_ORGANIZER);

  function applyPreset(newRole: "CO_ORGANIZER" | "COMMITTEE") {
    setRole(newRole);
    setPermissions(ROLE_PRESETS[newRole]);
  }

  function togglePerm(key: keyof typeof permissions) {
    setPermissions((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  function handleSubmit() {
    if (!email.trim()) {
      toast.error("Email address is required.");
      return;
    }

    startTransition(async () => {
      const result = await addCommitteeMemberAction({
        eventId,
        email: email.trim().toLowerCase(),
        role,
        title: title.trim() || undefined,
        permissions,
      });

      if (result.success) {
        toast.success(
          `${result.data.userName} added as ${role === "CO_ORGANIZER" ? "Co-organizer" : "Committee member"}`
        );
        setEmail("");
        setTitle("");
        onAdded();
      } else {
        toast.error(result.error);
      }
    });
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Add Committee Member</DialogTitle>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-2">
          {/* Email */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cm-email">Email address *</Label>
            <Input
              id="cm-email"
              type="email"
              placeholder="classmate@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoFocus
            />
            <p className="text-xs text-slate-400">
              They must already have a Reunitely account.
            </p>
          </div>

          {/* Title */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cm-title">Role title (optional)</Label>
            <Input
              id="cm-title"
              placeholder="e.g. Venue Coordinator, Treasurer"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          {/* Role preset */}
          <div className="flex flex-col gap-1.5">
            <Label>Access level</Label>
            <div className="flex gap-2">
              {(["CO_ORGANIZER", "COMMITTEE"] as const).map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => applyPreset(r)}
                  className={cn(
                    "flex-1 rounded-lg border py-2.5 text-sm font-medium transition-colors",
                    role === r
                      ? "border-blue-600 bg-blue-50 text-blue-700"
                      : "border-border text-slate-600 hover:bg-slate-50"
                  )}
                >
                  {r === "CO_ORGANIZER" ? "Co-organizer" : "Committee"}
                </button>
              ))}
            </div>
          </div>

          {/* Granular permissions */}
          <div className="rounded-xl border border-border p-4 flex flex-col gap-3">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Permissions
            </p>
            {(
              [
                { key: "canManageRsvps", label: "Manage RSVPs & invites" },
                { key: "canSendMessages", label: "Send broadcast messages" },
                { key: "canModerateContent", label: "Moderate memories & chat" },
                { key: "canViewPayments", label: "View payment data" },
                { key: "canCheckIn", label: "Check-in attendees" },
              ] as const
            ).map(({ key, label }) => (
              <div key={key} className="flex items-center justify-between gap-3">
                <span className="text-sm text-slate-700">{label}</span>
                <Switch
                  checked={permissions[key]}
                  onCheckedChange={() => togglePerm(key)}
                  aria-label={label}
                />
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-1">
            <Button variant="ghost" onClick={onClose} disabled={isPending}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={isPending || !email.trim()}>
              {isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Add Member
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
