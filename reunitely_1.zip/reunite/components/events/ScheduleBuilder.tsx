"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Plus, Clock, Trash2, GripVertical, Edit2, Check, X, Loader2,
  Music, Utensils, Mic, Users, Camera, MessageSquare, Star,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ─── Types ────────────────────────────────────────────────────────────────────

interface AgendaItem {
  id: string;
  time: string;        // "19:00"
  title: string;
  description?: string;
  durationMins: number;
  category: AgendaCategory;
  speaker?: string;
}

type AgendaCategory = "ceremony" | "meal" | "entertainment" | "speech" | "activity" | "photo" | "social" | "other";

const CATEGORY_CONFIG: Record<AgendaCategory, { label: string; icon: React.ElementType; color: string; bg: string }> = {
  ceremony:      { label: "Ceremony",      icon: Star,         color: "text-blue-700",    bg: "bg-blue-50" },
  meal:          { label: "Meal",          icon: Utensils,     color: "text-orange-700",  bg: "bg-orange-50" },
  entertainment: { label: "Entertainment", icon: Music,        color: "text-purple-700",  bg: "bg-purple-50" },
  speech:        { label: "Speech",        icon: Mic,          color: "text-red-700",     bg: "bg-red-50" },
  activity:      { label: "Activity",      icon: Users,        color: "text-emerald-700", bg: "bg-emerald-50" },
  photo:         { label: "Photo",         icon: Camera,       color: "text-pink-700",    bg: "bg-pink-50" },
  social:        { label: "Social",        icon: MessageSquare,color: "text-indigo-700",  bg: "bg-indigo-50" },
  other:         { label: "Other",         icon: Clock,        color: "text-slate-600",   bg: "bg-slate-100" },
};

// ─── Demo data (replaced by real API) ────────────────────────────────────────

const DEFAULT_ITEMS: AgendaItem[] = [
  { id: "1", time: "18:00", title: "Doors open & welcome drinks", description: "Registration desk open, name badges", durationMins: 60, category: "social" },
  { id: "2", time: "19:00", title: "Dinner service begins", description: "3-course dinner, vegetarian options available", durationMins: 90, category: "meal" },
  { id: "3", time: "20:00", title: "Welcome address", description: "Opening remarks from the organizing committee", durationMins: 15, category: "speech", speaker: "Jane Doe" },
  { id: "4", time: "20:15", title: "Nomination awards ceremony", description: "Most Changed, Most Successful, Most Likely to…", durationMins: 30, category: "ceremony" },
  { id: "5", time: "20:45", title: "Class photo", description: "Group photo outside the ballroom", durationMins: 15, category: "photo" },
  { id: "6", time: "21:00", title: "Live band & dancing", description: "DJ playing hits from our school years", durationMins: 120, category: "entertainment" },
  { id: "7", time: "23:00", title: "Last drinks & farewell", durationMins: 30, category: "social" },
];

// ─── Component ────────────────────────────────────────────────────────────────

export function ScheduleBuilder({ eventId }: { eventId: string }) {
  const [items, setItems] = useState<AgendaItem[]>(DEFAULT_ITEMS);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [addingNew, setAddingNew] = useState(false);
  const [dragOverId, setDragOverId] = useState<string | null>(null);
  const [dragItemId, setDragItemId] = useState<string | null>(null);

  // New item form state
  const [newItem, setNewItem] = useState<Partial<AgendaItem>>({
    category: "other",
    durationMins: 30,
  });

  function addItem() {
    if (!newItem.title?.trim() || !newItem.time) return;
    const item: AgendaItem = {
      id: Date.now().toString(),
      time: newItem.time!,
      title: newItem.title!.trim(),
      description: newItem.description?.trim(),
      durationMins: newItem.durationMins ?? 30,
      category: newItem.category ?? "other",
      speaker: newItem.speaker?.trim(),
    };
    setItems((prev) => [...prev, item].sort((a, b) => a.time.localeCompare(b.time)));
    setNewItem({ category: "other", durationMins: 30 });
    setAddingNew(false);
    toast.success("Agenda item added");
  }

  function deleteItem(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
    toast.success("Item removed");
  }

  function updateItem(id: string, updates: Partial<AgendaItem>) {
    setItems((prev) =>
      prev
        .map((i) => (i.id === id ? { ...i, ...updates } : i))
        .sort((a, b) => a.time.localeCompare(b.time))
    );
    setEditingId(null);
  }

  // Drag-and-drop reorder
  function handleDragStart(id: string) { setDragItemId(id); }
  function handleDragOver(e: React.DragEvent, id: string) {
    e.preventDefault();
    setDragOverId(id);
  }
  function handleDrop(targetId: string) {
    if (!dragItemId || dragItemId === targetId) { setDragOverId(null); return; }
    const from = items.findIndex((i) => i.id === dragItemId);
    const to = items.findIndex((i) => i.id === targetId);
    const reordered = [...items];
    const [moved] = reordered.splice(from, 1);
    reordered.splice(to, 0, moved!);
    setItems(reordered);
    setDragOverId(null);
    setDragItemId(null);
  }

  const totalDuration = items.reduce((s, i) => s + i.durationMins, 0);
  const totalHours = Math.floor(totalDuration / 60);
  const totalMins = totalDuration % 60;

  return (
    <div className="flex flex-col gap-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="text-sm text-slate-500">
            {items.length} item{items.length !== 1 ? "s" : ""} ·{" "}
            {totalHours > 0 && `${totalHours}h `}{totalMins > 0 && `${totalMins}min`} total
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => toast.info("Print view coming soon")}
            className="text-xs"
          >
            Print schedule
          </Button>
          <Button
            size="sm"
            onClick={() => setAddingNew(true)}
            className="gap-1.5 bg-blue-600 hover:bg-blue-700 text-xs"
          >
            <Plus className="h-3.5 w-3.5" />
            Add item
          </Button>
        </div>
      </div>

      {/* Category legend */}
      <div className="flex flex-wrap gap-2">
        {(Object.entries(CATEGORY_CONFIG) as [AgendaCategory, typeof CATEGORY_CONFIG[AgendaCategory]][]).map(([key, cfg]) => {
          const Icon = cfg.icon;
          return (
            <div key={key} className={cn("flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium", cfg.bg, cfg.color)}>
              <Icon className="h-3 w-3" />
              {cfg.label}
            </div>
          );
        })}
      </div>

      {/* Timeline */}
      <div className="relative">
        {/* Vertical line */}
        <div className="absolute left-[52px] top-0 bottom-0 w-px bg-slate-200" />

        <div className="flex flex-col gap-0">
          {items.map((item, idx) => (
            <AgendaRow
              key={item.id}
              item={item}
              isEditing={editingId === item.id}
              isDragOver={dragOverId === item.id}
              onEdit={() => setEditingId(item.id)}
              onDelete={() => deleteItem(item.id)}
              onUpdate={(updates) => updateItem(item.id, updates)}
              onCancelEdit={() => setEditingId(null)}
              onDragStart={() => handleDragStart(item.id)}
              onDragOver={(e) => handleDragOver(e, item.id)}
              onDrop={() => handleDrop(item.id)}
              onDragEnd={() => { setDragOverId(null); setDragItemId(null); }}
            />
          ))}
        </div>
      </div>

      {/* Add new item form */}
      {addingNew && (
        <div className="rounded-xl border border-blue-200 bg-blue-50 p-4 flex flex-col gap-3">
          <p className="text-sm font-semibold text-blue-900">New agenda item</p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Time</label>
              <Input
                type="time"
                value={newItem.time ?? ""}
                onChange={(e) => setNewItem((p) => ({ ...p, time: e.target.value }))}
                className="h-8 text-sm"
              />
            </div>
            <div className="flex flex-col gap-1 col-span-2">
              <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Title *</label>
              <Input
                placeholder="e.g. Welcome drinks"
                value={newItem.title ?? ""}
                onChange={(e) => setNewItem((p) => ({ ...p, title: e.target.value }))}
                className="h-8 text-sm"
                autoFocus
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Duration</label>
              <div className="flex items-center gap-1.5">
                <Input
                  type="number"
                  min={5}
                  max={480}
                  step={5}
                  value={newItem.durationMins ?? 30}
                  onChange={(e) => setNewItem((p) => ({ ...p, durationMins: parseInt(e.target.value) || 30 }))}
                  className="h-8 text-sm w-16"
                />
                <span className="text-xs text-slate-400">min</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Category</label>
              <select
                value={newItem.category ?? "other"}
                onChange={(e) => setNewItem((p) => ({ ...p, category: e.target.value as AgendaCategory }))}
                className="h-8 rounded-lg border border-border bg-white px-2 text-sm text-slate-700"
              >
                {Object.entries(CATEGORY_CONFIG).map(([key, cfg]) => (
                  <option key={key} value={key}>{cfg.label}</option>
                ))}
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Speaker (optional)</label>
              <Input
                placeholder="e.g. Jane Doe"
                value={newItem.speaker ?? ""}
                onChange={(e) => setNewItem((p) => ({ ...p, speaker: e.target.value }))}
                className="h-8 text-sm"
              />
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Notes (optional)</label>
            <Input
              placeholder="Add a short description"
              value={newItem.description ?? ""}
              onChange={(e) => setNewItem((p) => ({ ...p, description: e.target.value }))}
              className="h-8 text-sm"
            />
          </div>
          <div className="flex gap-2 pt-1">
            <Button size="sm" onClick={addItem} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
              <Check className="h-3.5 w-3.5" />
              Add
            </Button>
            <Button variant="outline" size="sm" onClick={() => setAddingNew(false)}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {items.length === 0 && !addingNew && (
        <div className="flex flex-col items-center gap-3 py-16 text-center">
          <Clock className="h-10 w-10 text-slate-200" />
          <p className="text-sm font-medium text-slate-600">No schedule yet</p>
          <p className="text-xs text-slate-400">Add agenda items to plan your event day.</p>
          <Button size="sm" onClick={() => setAddingNew(true)} className="mt-2 bg-blue-600 hover:bg-blue-700 gap-1.5">
            <Plus className="h-3.5 w-3.5" />
            Add first item
          </Button>
        </div>
      )}
    </div>
  );
}

// ─── Agenda Row ────────────────────────────────────────────────────────────────

function AgendaRow({
  item,
  isEditing,
  isDragOver,
  onEdit,
  onDelete,
  onUpdate,
  onCancelEdit,
  onDragStart,
  onDragOver,
  onDrop,
  onDragEnd,
}: {
  item: AgendaItem;
  isEditing: boolean;
  isDragOver: boolean;
  onEdit: () => void;
  onDelete: () => void;
  onUpdate: (updates: Partial<AgendaItem>) => void;
  onCancelEdit: () => void;
  onDragStart: () => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: () => void;
  onDragEnd: () => void;
}) {
  const cfg = CATEGORY_CONFIG[item.category];
  const Icon = cfg.icon;
  const [editState, setEditState] = useState({ ...item });

  const durationStr = item.durationMins >= 60
    ? `${Math.floor(item.durationMins / 60)}h${item.durationMins % 60 > 0 ? ` ${item.durationMins % 60}min` : ""}`
    : `${item.durationMins}min`;

  if (isEditing) {
    return (
      <div className="ml-16 mb-2 rounded-xl border border-blue-200 bg-blue-50 p-3 flex flex-col gap-2">
        <div className="flex gap-2">
          <Input
            type="time"
            value={editState.time}
            onChange={(e) => setEditState((p) => ({ ...p, time: e.target.value }))}
            className="h-7 text-xs w-24"
          />
          <Input
            value={editState.title}
            onChange={(e) => setEditState((p) => ({ ...p, title: e.target.value }))}
            className="h-7 text-xs flex-1"
          />
          <Input
            type="number"
            min={5}
            max={480}
            step={5}
            value={editState.durationMins}
            onChange={(e) => setEditState((p) => ({ ...p, durationMins: parseInt(e.target.value) || 30 }))}
            className="h-7 text-xs w-16"
          />
        </div>
        <div className="flex gap-2">
          <Button size="sm" onClick={() => onUpdate(editState)} className="h-7 text-xs bg-blue-600 hover:bg-blue-700 gap-1">
            <Check className="h-3 w-3" />
            Save
          </Button>
          <Button variant="outline" size="sm" onClick={onCancelEdit} className="h-7 text-xs">
            Cancel
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
      onDragEnd={onDragEnd}
      className={cn(
        "group flex items-start gap-0 transition-all",
        isDragOver && "opacity-50"
      )}
    >
      {/* Time column */}
      <div className="w-14 shrink-0 pt-3 text-right pr-3">
        <span className="text-xs font-mono text-slate-500">{item.time}</span>
      </div>

      {/* Dot on timeline */}
      <div className="relative flex flex-col items-center shrink-0 pt-3">
        <div className={cn("h-3.5 w-3.5 rounded-full border-2 border-white ring-2 ring-offset-0 z-10", cfg.bg, `ring-current ${cfg.color.replace('text-','ring-')}`)}>
          <Icon className="h-2 w-2 m-px" style={{ display: 'none' }} />
        </div>
      </div>

      {/* Content */}
      <div className={cn(
        "flex-1 ml-3 mb-4 rounded-xl border border-border bg-card p-3 transition-all group-hover:shadow-sm",
        isDragOver && "border-blue-300 bg-blue-50/30"
      )}>
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-semibold text-slate-900">{item.title}</span>
              <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium", cfg.bg, cfg.color)}>
                {cfg.label}
              </span>
              <span className="text-[11px] text-slate-400">{durationStr}</span>
            </div>
            {item.description && (
              <p className="text-xs text-slate-500 mt-0.5">{item.description}</p>
            )}
            {item.speaker && (
              <p className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                <Mic className="h-2.5 w-2.5" />
                {item.speaker}
              </p>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
            <button
              onClick={onEdit}
              className="rounded-md p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
            >
              <Edit2 className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={onDelete}
              className="rounded-md p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
            <div className="cursor-grab rounded-md p-1.5 text-slate-300 hover:text-slate-400">
              <GripVertical className="h-3.5 w-3.5" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
