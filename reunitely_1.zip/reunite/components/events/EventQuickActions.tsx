"use client";

import { useState } from "react";
import {
  Send,
  Download,
  Share2,
  Globe,
  Copy,
  Check,
  QrCode,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { getEventUrl } from "@/lib/utils";
import type { EventStatus } from "@prisma/client";
import Link from "next/link";

interface EventQuickActionsProps {
  eventId: string;
  eventStatus: EventStatus;
  eventSlug?: string;
}

export function EventQuickActions({
  eventId,
  eventStatus,
  eventSlug,
}: EventQuickActionsProps) {
  const [copied, setCopied] = useState(false);

  const eventUrl = eventSlug ? getEventUrl(eventSlug) : null;

  async function copyEventLink() {
    if (!eventUrl) return;
    await navigator.clipboard.writeText(eventUrl);
    setCopied(true);
    toast.success("Event link copied to clipboard");
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-700">
          Quick Actions
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-2">
        {/* Publish — only for drafts */}
        {eventStatus === "DRAFT" && (
          <Button
            asChild
            size="sm"
            className="w-full justify-start gap-2"
          >
            <Link href={`/dashboard/events/${eventId}/settings`}>
              <Globe className="h-4 w-4" />
              Publish Event
            </Link>
          </Button>
        )}

        {/* View public page */}
        {eventSlug && eventStatus === "PUBLISHED" && (
          <Button
            asChild
            variant="outline"
            size="sm"
            className="w-full justify-start gap-2"
          >
            <a href={eventUrl!} target="_blank" rel="noopener noreferrer">
              <Globe className="h-4 w-4" />
              View Public Page
            </a>
          </Button>
        )}

        {/* Copy invite link */}
        {eventSlug && (
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start gap-2"
            onClick={copyEventLink}
          >
            {copied ? (
              <Check className="h-4 w-4 text-emerald-500" />
            ) : (
              <Copy className="h-4 w-4" />
            )}
            {copied ? "Copied!" : "Copy Invite Link"}
          </Button>
        )}

        {/* Send reminder */}
        <Button
          asChild
          variant="outline"
          size="sm"
          className="w-full justify-start gap-2"
        >
          <Link href={`/dashboard/events/${eventId}/messages`}>
            <Send className="h-4 w-4" />
            Send Message
          </Link>
        </Button>

        {/* Export CSV */}
        <Button
          asChild
          variant="outline"
          size="sm"
          className="w-full justify-start gap-2"
        >
          <a href={`/api/events/${eventId}/memberships/export`} download>
            <Download className="h-4 w-4" />
            Export Attendees
          </a>
        </Button>
      </CardContent>
    </Card>
  );
}
