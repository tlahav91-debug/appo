"use client";

import type { UseFormReturn } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Loader2, Rocket, Edit2, CheckCircle, AlertCircle } from "lucide-react";
import type { WizardFormData } from "@/schemas/wizard";
import { WIZARD_STEPS } from "@/schemas/wizard";
import { cn, formatCurrency } from "@/lib/utils";

interface Props {
  form: UseFormReturn<WizardFormData>;
  onEditStep: (step: number) => void;
  onPublish: () => void;
  isPublishing: boolean;
}

export function WizardStep8Review({
  form,
  onEditStep,
  onPublish,
  isPublishing,
}: Props) {
  const values = form.getValues();
  const errors = form.formState.errors;

  // Check which steps have errors
  const stepHasErrors: Record<number, boolean> = {};
  const allFieldNames = Object.keys(errors) as (keyof WizardFormData)[];
  for (const field of allFieldNames) {
    if (field === "title" || field === "shortDescription" || field === "eventType" || field === "visibility") stepHasErrors[1] = true;
    if (field === "schoolName" || field === "graduationYear") stepHasErrors[2] = true;
    if (field === "startDate" || field === "startTime" || field === "timezone" || field === "venueName") stepHasErrors[3] = true;
    if (field === "primaryColor" || field === "accentColor") stepHasErrors[4] = true;
  }

  const hasErrors = Object.keys(stepHasErrors).length > 0;

  // Build review rows for each step
  const reviewSections = [
    {
      step: 1,
      title: "Event Info",
      rows: [
        { label: "Title", value: values.title || "—" },
        { label: "Type", value: values.eventType?.replace("_", " ") || "—" },
        { label: "Visibility", value: values.visibility || "—" },
        { label: "Tagline", value: values.shortDescription || "—" },
      ],
    },
    {
      step: 2,
      title: "School & Cohort",
      rows: [
        { label: "School", value: values.schoolName || "—" },
        { label: "Location", value: [values.schoolCity, values.schoolCountry].filter(Boolean).join(", ") || "—" },
        { label: "Graduation year", value: values.graduationYear?.toString() || "—" },
        { label: "Sections", value: values.classSections?.length ? values.classSections.join(", ") : "None" },
      ],
    },
    {
      step: 3,
      title: "Date & Venue",
      rows: [
        {
          label: "Date",
          value: values.startDate
            ? `${values.startDate} at ${values.startTime ?? "—"} (${values.timezone})`
            : "—",
        },
        {
          label: "End",
          value: values.endDate ? `${values.endDate} at ${values.endTime ?? "—"}` : "Not set",
        },
        { label: "Format", value: values.venueType || "—" },
        {
          label: values.venueType === "VIRTUAL" ? "Meeting link" : "Venue",
          value:
            values.venueType === "VIRTUAL"
              ? values.virtualLink || "—"
              : values.venueName || "—",
        },
      ],
    },
    {
      step: 4,
      title: "Branding",
      rows: [
        { label: "Cover photo", value: values.coverImageUrl ? "Uploaded ✓" : "None" },
        {
          label: "Colors",
          value: (
            <span className="flex items-center gap-1.5">
              <span
                className="inline-block h-4 w-4 rounded-full border border-white shadow-sm"
                style={{ backgroundColor: values.primaryColor ?? "#1E3A5F" }}
              />
              <span
                className="inline-block h-4 w-4 rounded-full border border-white shadow-sm"
                style={{ backgroundColor: values.accentColor ?? "#D4AF37" }}
              />
              {values.primaryColor} / {values.accentColor}
            </span>
          ),
        },
        { label: "Layout", value: values.headerLayout || "CENTERED" },
      ],
    },
    {
      step: 5,
      title: "RSVP & Tickets",
      rows: [
        {
          label: "Capacity",
          value: values.capacityUnlimited ? "Unlimited" : `${values.capacity ?? "—"} max`,
        },
        { label: "Waitlist", value: values.waitlistEnabled ? "Enabled" : "Disabled" },
        {
          label: "Ticketing",
          value: values.ticketingEnabled
            ? `${values.ticketName ?? "General Admission"} · $${values.ticketPrice ?? 0}`
            : "Free event",
        },
        {
          label: "Custom questions",
          value:
            values.customQuestions && values.customQuestions.length > 0
              ? `${values.customQuestions.length} question${values.customQuestions.length !== 1 ? "s" : ""}`
              : "None",
        },
      ],
    },
    {
      step: 6,
      title: "Invites & Access",
      rows: [
        { label: "RSVP mode", value: values.inviteMode?.replace("_", " ") || "OPEN" },
        {
          label: "Attendee invites",
          value: values.allowAttendeesInvite ? "Allowed" : "Organizer only",
        },
        {
          label: "School email",
          value: values.verifySchoolEmail ? `Required (${values.schoolEmailDomain || "any"})` : "Not required",
        },
      ],
    },
    {
      step: 7,
      title: "Features & Comms",
      rows: [
        {
          label: "Features",
          value: [
            values.chatEnabled && "Chat",
            values.memoriesEnabled && "Memories",
            values.nominationsEnabled && "Nominations",
            values.directoryEnabled && "Directory",
            values.scheduleEnabled && "Schedule",
          ]
            .filter(Boolean)
            .join(", ") || "None",
        },
        {
          label: "Reminders",
          value: values.sendEventReminder
            ? `${values.reminderDaysBefore} days before`
            : "Disabled",
        },
        {
          label: "SMS/WhatsApp",
          value:
            values.smsRemindersEnabled || values.whatsappRemindersEnabled
              ? "Enabled"
              : "Disabled",
        },
      ],
    },
  ];

  return (
    <div className="flex flex-col gap-7">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          Review & publish
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          Everything look right? You can edit all details after publishing.
        </p>
      </div>

      {/* Validation errors banner */}
      {hasErrors && (
        <div className="flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3.5">
          <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-red-800">
              Fix errors before publishing
            </p>
            <p className="text-xs text-red-600 mt-0.5">
              {Object.keys(stepHasErrors).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => onEditStep(Number(s))}
                  className="underline mr-2 hover:no-underline"
                >
                  Step {s}: {WIZARD_STEPS[Number(s) - 1]?.label}
                </button>
              ))}
            </p>
          </div>
        </div>
      )}

      {/* Cover preview */}
      {values.coverImageUrl && (
        <div className="relative aspect-[16/6] w-full overflow-hidden rounded-xl">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={values.coverImageUrl}
            alt="Event cover preview"
            className="h-full w-full object-cover"
          />
          <div
            className="absolute inset-0 flex items-end"
            style={{
              background: `linear-gradient(to top, ${values.primaryColor ?? "#1E3A5F"}CC, transparent)`,
            }}
          >
            <div className="p-6">
              <p className="font-display text-2xl font-bold text-white drop-shadow">
                {values.title || "Your Event Title"}
              </p>
              {values.shortDescription && (
                <p className="text-sm text-white/80 mt-1">{values.shortDescription}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Review sections */}
      <div className="flex flex-col gap-3">
        {reviewSections.map((section) => (
          <div
            key={section.step}
            className={cn(
              "rounded-xl border bg-card overflow-hidden",
              stepHasErrors[section.step]
                ? "border-red-200"
                : "border-border"
            )}
          >
            <div
              className={cn(
                "flex items-center justify-between px-4 py-2.5 border-b",
                stepHasErrors[section.step]
                  ? "bg-red-50 border-red-200"
                  : "bg-slate-50 border-border"
              )}
            >
              <div className="flex items-center gap-2">
                {stepHasErrors[section.step] ? (
                  <AlertCircle className="h-3.5 w-3.5 text-red-500" />
                ) : (
                  <CheckCircle className="h-3.5 w-3.5 text-emerald-500" />
                )}
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-600">
                  Step {section.step}: {section.title}
                </span>
              </div>
              <button
                type="button"
                onClick={() => onEditStep(section.step)}
                className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-700 hover:underline"
              >
                <Edit2 className="h-3 w-3" />
                Edit
              </button>
            </div>
            <div className="divide-y divide-border">
              {section.rows.map((row) => (
                <div
                  key={row.label}
                  className="flex items-center justify-between px-4 py-2.5 gap-4"
                >
                  <span className="text-xs text-slate-500 shrink-0">{row.label}</span>
                  <span className="text-xs font-medium text-slate-900 text-right truncate flex items-center gap-1">
                    {row.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Terms & publish */}
      <div className="rounded-xl border border-border bg-blue-50 p-5 flex flex-col gap-4">
        <div className="flex items-start gap-3">
          <Rocket className="h-5 w-5 text-blue-600 mt-0.5 shrink-0" />
          <div>
            <p className="text-sm font-semibold text-blue-900">
              Ready to go live?
            </p>
            <p className="text-xs text-blue-700 mt-1">
              Your event page will be{" "}
              {values.visibility === "PUBLIC"
                ? "publicly discoverable"
                : values.visibility === "PRIVATE"
                ? "accessible by invite link only"
                : "accessible via direct link"}
              . You can make changes at any time after publishing.
            </p>
          </div>
        </div>
        <Button
          type="button"
          onClick={onPublish}
          disabled={isPublishing || hasErrors}
          className="w-full h-12 text-base gap-2"
          size="lg"
        >
          {isPublishing ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              Publishing your event…
            </>
          ) : (
            <>
              <Rocket className="h-5 w-5" />
              Publish Event
            </>
          )}
        </Button>
        <p className="text-center text-xs text-blue-700">
          Your draft is saved automatically and won't be lost if you close this page.
        </p>
      </div>
    </div>
  );
}
