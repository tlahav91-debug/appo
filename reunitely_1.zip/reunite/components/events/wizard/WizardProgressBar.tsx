"use client";

import { Check, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatRelativeTime } from "@/lib/utils";

interface Step {
  id: number;
  label: string;
  description: string;
}

interface WizardProgressBarProps {
  currentStep: number;
  totalSteps: number;
  steps: readonly Step[];
  onStepClick: (step: number) => void;
  lastSavedAt: Date | null;
  isSaving: boolean;
}

export function WizardProgressBar({
  currentStep,
  totalSteps,
  steps,
  onStepClick,
  lastSavedAt,
  isSaving,
}: WizardProgressBarProps) {
  const progressPct = ((currentStep - 1) / (totalSteps - 1)) * 100;

  return (
    <div className="flex flex-col gap-3">
      {/* Mobile: compact bar with step count */}
      <div className="flex items-center justify-between sm:hidden">
        <span className="text-sm font-semibold text-slate-900">
          Step {currentStep} of {totalSteps}:{" "}
          <span className="text-blue-600">
            {steps[currentStep - 1]?.label}
          </span>
        </span>
        <SaveStatus isSaving={isSaving} lastSavedAt={lastSavedAt} />
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 sm:hidden">
        <div
          className="h-full rounded-full bg-blue-500 transition-all duration-500 ease-out"
          style={{ width: `${progressPct}%` }}
          role="progressbar"
          aria-valuenow={currentStep}
          aria-valuemin={1}
          aria-valuemax={totalSteps}
          aria-label={`Step ${currentStep} of ${totalSteps}`}
        />
      </div>

      {/* Desktop: step dots */}
      <div className="hidden sm:flex sm:flex-col sm:gap-2">
        <div className="flex items-center justify-between">
          <nav aria-label="Wizard progress" className="flex flex-1 items-center">
            {steps.map((step, index) => {
              const isComplete = step.id < currentStep;
              const isCurrent = step.id === currentStep;
              const isClickable = step.id < currentStep;

              return (
                <div key={step.id} className="flex flex-1 items-center">
                  {/* Connector line before */}
                  {index > 0 && (
                    <div
                      className={cn(
                        "h-0.5 flex-1 transition-colors duration-300",
                        isComplete ? "bg-blue-500" : "bg-slate-200"
                      )}
                    />
                  )}

                  {/* Step dot */}
                  <button
                    type="button"
                    onClick={() => isClickable && onStepClick(step.id)}
                    disabled={!isClickable}
                    aria-current={isCurrent ? "step" : undefined}
                    aria-label={`Step ${step.id}: ${step.label}${isComplete ? " (completed)" : ""}`}
                    className={cn(
                      "relative flex flex-col items-center gap-1 transition-all",
                      isClickable
                        ? "cursor-pointer"
                        : "cursor-default"
                    )}
                  >
                    {/* Circle */}
                    <div
                      className={cn(
                        "flex h-8 w-8 items-center justify-center rounded-full border-2 text-xs font-bold transition-all duration-200",
                        isComplete
                          ? "border-blue-600 bg-blue-500 text-white"
                          : isCurrent
                          ? "border-blue-600 bg-white text-blue-600 shadow-sm shadow-blue-200"
                          : "border-slate-200 bg-white text-slate-400"
                      )}
                    >
                      {isComplete ? (
                        <Check className="h-3.5 w-3.5" />
                      ) : (
                        step.id
                      )}
                    </div>
                    {/* Label — only show for current ±1 on small desktops */}
                    <span
                      className={cn(
                        "absolute top-9 whitespace-nowrap text-[10px] font-medium transition-colors",
                        isCurrent
                          ? "text-blue-700"
                          : isComplete
                          ? "text-slate-500"
                          : "text-slate-300"
                      )}
                    >
                      {step.label}
                    </span>
                  </button>

                  {/* Connector line after */}
                  {index < steps.length - 1 && (
                    <div
                      className={cn(
                        "h-0.5 flex-1 transition-colors duration-300",
                        step.id < currentStep ? "bg-blue-500" : "bg-slate-200"
                      )}
                    />
                  )}
                </div>
              );
            })}
          </nav>

          {/* Save status — right aligned */}
          <div className="ml-6 shrink-0">
            <SaveStatus isSaving={isSaving} lastSavedAt={lastSavedAt} />
          </div>
        </div>
        {/* Label row spacer */}
        <div className="h-4" />
      </div>
    </div>
  );
}

function SaveStatus({
  isSaving,
  lastSavedAt,
}: {
  isSaving: boolean;
  lastSavedAt: Date | null;
}) {
  return (
    <div className="flex items-center gap-1.5 text-xs text-slate-400">
      {isSaving ? (
        <>
          <Loader2 className="h-3 w-3 animate-spin" />
          <span>Saving…</span>
        </>
      ) : lastSavedAt ? (
        <>
          <div className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
          <span>
            Saved {formatRelativeTime(lastSavedAt)}
          </span>
        </>
      ) : (
        <>
          <div className="h-1.5 w-1.5 rounded-full bg-slate-200" />
          <span>Unsaved draft</span>
        </>
      )}
    </div>
  );
}
