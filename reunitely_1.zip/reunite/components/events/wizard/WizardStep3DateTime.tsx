"use client";

import type { UseFormReturn } from "react-hook-form";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import type { WizardFormData } from "@/schemas/wizard";
import { cn } from "@/lib/utils";
import { MapPin, Video, Layers } from "lucide-react";

const VENUE_TYPES = [
  { value: "PHYSICAL" as const, icon: MapPin, label: "In Person", description: "Physical venue" },
  { value: "VIRTUAL" as const, icon: Video, label: "Virtual", description: "Online only" },
  { value: "HYBRID" as const, icon: Layers, label: "Hybrid", description: "Both" },
] as const;

const COMMON_TIMEZONES = [
  { label: "Eastern (New York)", value: "America/New_York" },
  { label: "Central (Chicago)", value: "America/Chicago" },
  { label: "Mountain (Denver)", value: "America/Denver" },
  { label: "Pacific (Los Angeles)", value: "America/Los_Angeles" },
  { label: "Alaska (Anchorage)", value: "America/Anchorage" },
  { label: "Hawaii (Honolulu)", value: "Pacific/Honolulu" },
  { label: "London (UK)", value: "Europe/London" },
  { label: "Paris (Europe)", value: "Europe/Paris" },
  { label: "Dubai (UAE)", value: "Asia/Dubai" },
  { label: "Mumbai (India)", value: "Asia/Kolkata" },
  { label: "Singapore", value: "Asia/Singapore" },
  { label: "Tokyo (Japan)", value: "Asia/Tokyo" },
  { label: "Sydney (Australia)", value: "Australia/Sydney" },
];

interface Props {
  form: UseFormReturn<WizardFormData>;
}

export function WizardStep3DateTime({ form }: Props) {
  const venueType = form.watch("venueType");
  const isPhysical = venueType === "PHYSICAL" || venueType === "HYBRID";
  const isVirtual = venueType === "VIRTUAL" || venueType === "HYBRID";

  return (
    <div className="flex flex-col gap-7">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          Date, time & location
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          When and where is the reunion happening?
        </p>
      </div>

      {/* Venue type */}
      <FormField
        control={form.control}
        name="venueType"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Event format</FormLabel>
            <div className="grid grid-cols-3 gap-2" role="radiogroup">
              {VENUE_TYPES.map((opt) => {
                const Icon = opt.icon;
                const isSelected = field.value === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    role="radio"
                    aria-checked={isSelected}
                    onClick={() => field.onChange(opt.value)}
                    className={cn(
                      "flex flex-col items-center gap-2 rounded-xl border-2 p-4 text-center transition-all",
                      isSelected
                        ? "border-blue-600 bg-blue-50"
                        : "border-border hover:border-blue-300"
                    )}
                  >
                    <Icon className={cn("h-5 w-5", isSelected ? "text-blue-600" : "text-slate-400")} />
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{opt.label}</p>
                      <p className="text-xs text-slate-500">{opt.description}</p>
                    </div>
                  </button>
                );
              })}
            </div>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Dates */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <FormField
          control={form.control}
          name="startDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>
                Start date <span className="text-destructive">*</span>
              </FormLabel>
              <FormControl>
                <Input type="date" className="h-11" {...field} value={field.value ?? ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="startTime"
          render={({ field }) => (
            <FormItem>
              <FormLabel>
                Start time <span className="text-destructive">*</span>
              </FormLabel>
              <FormControl>
                <Input type="time" className="h-11" {...field} value={field.value ?? ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <FormField
          control={form.control}
          name="endDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>End date</FormLabel>
              <FormControl>
                <Input type="date" className="h-11" {...field} value={field.value ?? ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="endTime"
          render={({ field }) => (
            <FormItem>
              <FormLabel>End time</FormLabel>
              <FormControl>
                <Input type="time" className="h-11" {...field} value={field.value ?? ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      {/* Doors open time */}
      <FormField
        control={form.control}
        name="doorsOpenTime"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Doors / check-in opens</FormLabel>
            <FormControl>
              <Input
                type="time"
                className="h-11 max-w-xs"
                {...field}
                value={field.value ?? ""}
              />
            </FormControl>
            <FormDescription>
              Optional — shown on the event page and used for check-in window.
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Timezone */}
      <FormField
        control={form.control}
        name="timezone"
        render={({ field }) => (
          <FormItem>
            <FormLabel>
              Timezone <span className="text-destructive">*</span>
            </FormLabel>
            <FormControl>
              <div className="relative max-w-xs">
                <select
                  className="flex h-11 w-full appearance-none rounded-md border border-input bg-background px-3 py-2 pr-8 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  value={field.value}
                  onChange={(e) => field.onChange(e.target.value)}
                >
                  {COMMON_TIMEZONES.map((tz) => (
                    <option key={tz.value} value={tz.value}>
                      {tz.label}
                    </option>
                  ))}
                </select>
                <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 border-l-[5px] border-r-[5px] border-t-[6px] border-l-transparent border-r-transparent border-t-slate-400" />
              </div>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Physical venue */}
      {isPhysical && (
        <div className="flex flex-col gap-4 rounded-xl border border-border bg-slate-50 p-5">
          <p className="text-sm font-semibold text-slate-700 flex items-center gap-2">
            <MapPin className="h-4 w-4 text-blue-500" />
            Venue details
          </p>
          <FormField
            control={form.control}
            name="venueName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>
                  Venue name <span className="text-destructive">*</span>
                </FormLabel>
                <FormControl>
                  <Input
                    placeholder="e.g. The Grand Hyatt San Francisco"
                    className="bg-white"
                    {...field}
                    value={field.value ?? ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="venueAddress"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Street address</FormLabel>
                <FormControl>
                  <Input
                    placeholder="123 Main Street"
                    className="bg-white"
                    {...field}
                    value={field.value ?? ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <div className="grid grid-cols-2 gap-3">
            <FormField
              control={form.control}
              name="venueCity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>City</FormLabel>
                  <FormControl>
                    <Input className="bg-white" {...field} value={field.value ?? ""} />
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="venueState"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>State / Region</FormLabel>
                  <FormControl>
                    <Input placeholder="CA" className="bg-white" {...field} value={field.value ?? ""} />
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
        </div>
      )}

      {/* Virtual link */}
      {isVirtual && (
        <div className="flex flex-col gap-4 rounded-xl border border-border bg-slate-50 p-5">
          <p className="text-sm font-semibold text-slate-700 flex items-center gap-2">
            <Video className="h-4 w-4 text-blue-500" />
            Virtual meeting
          </p>
          <FormField
            control={form.control}
            name="virtualLink"
            render={({ field }) => (
              <FormItem>
                <FormLabel>
                  Meeting link <span className="text-destructive">*</span>
                </FormLabel>
                <FormControl>
                  <Input
                    placeholder="https://zoom.us/j/…"
                    className="bg-white"
                    {...field}
                    value={field.value ?? ""}
                  />
                </FormControl>
                <FormDescription>
                  Zoom, Google Meet, Teams, etc. Only confirmed attendees will see this.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="virtualPlatform"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Platform</FormLabel>
                <FormControl>
                  <div className="relative">
                    <select
                      className="flex h-10 w-full max-w-xs appearance-none rounded-md border border-input bg-white px-3 py-2 pr-8 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      value={field.value ?? ""}
                      onChange={(e) => field.onChange(e.target.value || undefined)}
                    >
                      <option value="">Select platform</option>
                      <option value="ZOOM">Zoom</option>
                      <option value="GOOGLE_MEET">Google Meet</option>
                      <option value="TEAMS">Microsoft Teams</option>
                      <option value="OTHER">Other</option>
                    </select>
                    <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 border-l-[5px] border-r-[5px] border-t-[6px] border-l-transparent border-r-transparent border-t-slate-400" />
                  </div>
                </FormControl>
              </FormItem>
            )}
          />
        </div>
      )}
    </div>
  );
}
