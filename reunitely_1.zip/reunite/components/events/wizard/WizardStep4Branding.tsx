"use client";

import { useState } from "react";
import type { UseFormReturn } from "react-hook-form";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import type { WizardFormData } from "@/schemas/wizard";
import { cn } from "@/lib/utils";
import { ImagePlus, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const PRESET_COLORS = [
  { name: "Navy & Gold", primary: "#1E3A5F", accent: "#D4AF37" },
  { name: "Forest & Cream", primary: "#2D5016", accent: "#F5E6C8" },
  { name: "Crimson & White", primary: "#9B1B1B", accent: "#F8F8F8" },
  { name: "Royal Blue & Silver", primary: "#1B3A8A", accent: "#C0C0C0" },
  { name: "Midnight & Amber", primary: "#0F172A", accent: "#2563EB" },
  { name: "Emerald & Gold", primary: "#065F46", accent: "#93C5FD" },
  { name: "Slate & Coral", primary: "#334155", accent: "#FB7185" },
  { name: "Custom", primary: "", accent: "" },
] as const;

const LAYOUT_OPTIONS = [
  {
    value: "CENTERED" as const,
    label: "Centered",
    preview: "Text centered below cover",
  },
  {
    value: "LEFT" as const,
    label: "Left-aligned",
    preview: "Text left-aligned",
  },
  {
    value: "FULL_BLEED" as const,
    label: "Full bleed",
    preview: "Text overlaid on cover",
  },
] as const;

interface Props {
  form: UseFormReturn<WizardFormData>;
  eventId?: string;
}

export function WizardStep4Branding({ form, eventId }: Props) {
  const [isUploading, setIsUploading] = useState(false);
  const [activePreset, setActivePreset] = useState<number | null>(0);
  const coverImageUrl = form.watch("coverImageUrl");

  async function handleCoverUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate before uploading
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      toast.error("Please upload a JPEG, PNG, or WebP image.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Image must be under 10 MB.");
      return;
    }

    setIsUploading(true);
    const localPreview = URL.createObjectURL(file);
    form.setValue("coverImageUrl", localPreview); // instant local preview

    try {
      // Get presigned URL
      const presignRes = await fetch("/api/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          folder: "events/covers",
          contentType: file.type,
          fileSize: file.size,
          fileExtension: file.name.split(".").pop()?.toLowerCase() ?? "jpg",
        }),
      });

      if (!presignRes.ok) {
        const json = await presignRes.json().catch(() => ({}));
        throw new Error(json.error?.message ?? "Failed to get upload URL");
      }

      const { data } = await presignRes.json();

      // Upload directly to S3/R2
      const uploadRes = await fetch(data.uploadUrl, {
        method: "PUT",
        body: file,
        headers: { "Content-Type": file.type },
      });

      if (!uploadRes.ok) throw new Error("Upload failed");

      form.setValue("coverImageUrl", data.publicUrl);
      toast.success("Cover photo uploaded");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
      form.setValue("coverImageUrl", "");
    } finally {
      setIsUploading(false);
    }
  }

  function applyPreset(index: number) {
    const preset = PRESET_COLORS[index];
    if (!preset || !preset.primary) return;
    setActivePreset(index);
    form.setValue("primaryColor", preset.primary);
    form.setValue("accentColor", preset.accent);
  }

  return (
    <div className="flex flex-col gap-7">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          Branding & look
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          Give your reunion page its visual identity.
        </p>
      </div>

      {/* Cover photo */}
      <FormField
        control={form.control}
        name="coverImageUrl"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Cover photo</FormLabel>
            <FormControl>
              <div>
                {coverImageUrl && !isUploading ? (
                  <div className="relative aspect-[16/7] w-full overflow-hidden rounded-xl border border-border bg-slate-100">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={coverImageUrl}
                      alt="Event cover"
                      className="h-full w-full object-cover"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-2 top-2 h-8 w-8 rounded-full bg-black/50 text-white hover:bg-black/70"
                      onClick={() => form.setValue("coverImageUrl", "")}
                      aria-label="Remove cover photo"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <label className="flex aspect-[16/7] w-full cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 transition-colors hover:border-blue-400 hover:bg-blue-50/50">
                    {isUploading ? (
                      <div className="flex flex-col items-center gap-2">
                        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                        <p className="text-sm text-slate-500">Uploading…</p>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <div className="rounded-full bg-slate-100 p-3">
                          <ImagePlus className="h-6 w-6 text-slate-400" />
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-medium text-slate-700">
                            Click to upload cover photo
                          </p>
                          <p className="text-xs text-slate-400 mt-0.5">
                            JPEG, PNG or WebP · Max 10 MB · 16:9 recommended
                          </p>
                        </div>
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="sr-only"
                      onChange={handleCoverUpload}
                      disabled={isUploading}
                    />
                  </label>
                )}
              </div>
            </FormControl>
            <FormDescription>
              Best size: 1200×630px. This appears on your event page, invite
              emails, and social shares.
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Color presets */}
      <div className="flex flex-col gap-3">
        <FormLabel>Color palette</FormLabel>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {PRESET_COLORS.filter((p) => p.primary).map((preset, i) => (
            <button
              key={i}
              type="button"
              onClick={() => applyPreset(i)}
              className={cn(
                "flex items-center gap-2 rounded-lg border-2 p-3 text-left transition-all",
                activePreset === i
                  ? "border-blue-600 bg-blue-50"
                  : "border-border hover:border-blue-300"
              )}
            >
              <div className="flex gap-1 shrink-0">
                <div
                  className="h-4 w-4 rounded-full border border-white/50 shadow-sm"
                  style={{ backgroundColor: preset.primary }}
                />
                <div
                  className="h-4 w-4 rounded-full border border-white/50 shadow-sm"
                  style={{ backgroundColor: preset.accent }}
                />
              </div>
              <span className="text-xs font-medium text-slate-700 truncate">
                {preset.name}
              </span>
            </button>
          ))}
        </div>

        {/* Custom color pickers */}
        <div className="grid grid-cols-2 gap-4 pt-2">
          <FormField
            control={form.control}
            name="primaryColor"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs">Primary color</FormLabel>
                <FormControl>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      className="h-10 w-10 cursor-pointer rounded-md border border-input p-0.5"
                      value={field.value ?? "#1E3A5F"}
                      onChange={(e) => {
                        field.onChange(e.target.value);
                        setActivePreset(null);
                      }}
                      aria-label="Pick primary color"
                    />
                    <input
                      type="text"
                      className="flex h-10 flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm font-mono uppercase"
                      value={field.value ?? "#1E3A5F"}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (/^#[0-9A-Fa-f]{0,6}$/.test(val)) {
                          field.onChange(val);
                          setActivePreset(null);
                        }
                      }}
                      maxLength={7}
                      placeholder="#1E3A5F"
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="accentColor"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs">Accent color</FormLabel>
                <FormControl>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      className="h-10 w-10 cursor-pointer rounded-md border border-input p-0.5"
                      value={field.value ?? "#D4AF37"}
                      onChange={(e) => {
                        field.onChange(e.target.value);
                        setActivePreset(null);
                      }}
                      aria-label="Pick accent color"
                    />
                    <input
                      type="text"
                      className="flex h-10 flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm font-mono uppercase"
                      value={field.value ?? "#D4AF37"}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (/^#[0-9A-Fa-f]{0,6}$/.test(val)) {
                          field.onChange(val);
                          setActivePreset(null);
                        }
                      }}
                      maxLength={7}
                      placeholder="#D4AF37"
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </div>

      {/* Header layout */}
      <FormField
        control={form.control}
        name="headerLayout"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Header layout</FormLabel>
            <div className="grid grid-cols-3 gap-2" role="radiogroup">
              {LAYOUT_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  role="radio"
                  aria-checked={field.value === opt.value}
                  onClick={() => field.onChange(opt.value)}
                  className={cn(
                    "flex flex-col items-center gap-2 rounded-xl border-2 p-3 text-center transition-all",
                    field.value === opt.value
                      ? "border-blue-600 bg-blue-50"
                      : "border-border hover:border-blue-300"
                  )}
                >
                  {/* Mini layout preview */}
                  <div className="w-full h-8 rounded bg-slate-200 overflow-hidden">
                    <div
                      className={cn(
                        "h-full w-full bg-slate-400/30",
                        opt.value === "CENTERED" && "flex items-end justify-center pb-0.5",
                        opt.value === "LEFT" && "flex items-end justify-start pl-1 pb-0.5",
                        opt.value === "FULL_BLEED" && "flex items-center justify-center"
                      )}
                    >
                      <div className="h-1 w-6 rounded bg-slate-600/50" />
                    </div>
                  </div>
                  <p className="text-xs font-medium text-slate-700">{opt.label}</p>
                </button>
              ))}
            </div>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Description */}
      <FormField
        control={form.control}
        name="descriptionText"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Event description</FormLabel>
            <FormControl>
              <Textarea
                placeholder="Tell your classmates what to expect — the schedule, dress code, what to bring, what's included, and anything else they'd want to know."
                rows={6}
                className="resize-none"
                maxLength={5000}
                {...field}
                value={field.value ?? ""}
              />
            </FormControl>
            <div className="flex items-center justify-between">
              <FormDescription>
                Rendered on your public event page. Markdown supported.
              </FormDescription>
              <span className="text-xs text-slate-400">
                {(field.value ?? "").length}/5000
              </span>
            </div>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
}
