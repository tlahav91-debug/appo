"use client";

import type { UseFormReturn } from "react-hook-form";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import type { WizardFormData } from "@/schemas/wizard";
import { Globe, Link2, Lock } from "lucide-react";

const EVENT_TYPES = [
  {
    value: "REUNION" as const,
    emoji: "🎓",
    label: "Class Reunion",
    description: "Full-class celebration",
  },
  {
    value: "MINI_REUNION" as const,
    emoji: "☕",
    label: "Mini Reunion",
    description: "Small group gathering",
  },
  {
    value: "VIRTUAL" as const,
    emoji: "💻",
    label: "Virtual",
    description: "Online-only event",
  },
  {
    value: "FUNDRAISER" as const,
    emoji: "💝",
    label: "Fundraiser",
    description: "Charitable event",
  },
] as const;

const VISIBILITY_OPTIONS = [
  {
    value: "PUBLIC" as const,
    icon: Globe,
    label: "Public",
    description: "Discoverable by anyone with the link or via search",
  },
  {
    value: "UNLISTED" as const,
    icon: Link2,
    label: "Unlisted",
    description: "Only accessible via direct link — not searchable",
  },
  {
    value: "PRIVATE" as const,
    icon: Lock,
    label: "Private",
    description: "Invite-only with an optional password",
  },
] as const;

interface Props {
  form: UseFormReturn<WizardFormData>;
}

export function WizardStep1BasicInfo({ form }: Props) {
  const visibility = form.watch("visibility");

  return (
    <div className="flex flex-col gap-7">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          Let's set up your reunion
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          Give your event a name and choose how visible it will be.
        </p>
      </div>

      {/* Event name */}
      <FormField
        control={form.control}
        name="title"
        render={({ field }) => (
          <FormItem>
            <FormLabel>
              Event name <span className="text-destructive">*</span>
            </FormLabel>
            <FormControl>
              <Input
                placeholder="e.g. Lincoln High Class of 2009 — 15-Year Reunion"
                className="text-base h-11"
                autoFocus
                {...field}
              />
            </FormControl>
            <div className="flex items-center justify-between">
              <FormMessage />
              <span className="ml-auto text-xs text-slate-400">
                {field.value?.length ?? 0}/120
              </span>
            </div>
          </FormItem>
        )}
      />

      {/* Short description */}
      <FormField
        control={form.control}
        name="shortDescription"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Tagline</FormLabel>
            <FormControl>
              <Textarea
                placeholder="A one-liner that appears on your event card, e.g. 'Fifteen years later, still the best class.'"
                rows={2}
                className="resize-none"
                maxLength={300}
                {...field}
                value={field.value ?? ""}
              />
            </FormControl>
            <div className="flex items-center justify-between">
              <FormDescription>
                Shown on the event card and in social shares.
              </FormDescription>
              <span className="text-xs text-slate-400">
                {(field.value ?? "").length}/300
              </span>
            </div>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Event type */}
      <FormField
        control={form.control}
        name="eventType"
        render={({ field }) => (
          <FormItem>
            <FormLabel>
              Event type <span className="text-destructive">*</span>
            </FormLabel>
            <div
              className="grid grid-cols-2 gap-2 sm:grid-cols-4"
              role="radiogroup"
              aria-label="Event type"
            >
              {EVENT_TYPES.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  role="radio"
                  aria-checked={field.value === opt.value}
                  onClick={() => field.onChange(opt.value)}
                  className={cn(
                    "flex flex-col items-center gap-2 rounded-xl border-2 p-4 text-center transition-all hover:border-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
                    field.value === opt.value
                      ? "border-blue-600 bg-blue-50"
                      : "border-border bg-card"
                  )}
                >
                  <span className="text-2xl" aria-hidden>
                    {opt.emoji}
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">
                      {opt.label}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {opt.description}
                    </p>
                  </div>
                </button>
              ))}
            </div>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Visibility */}
      <FormField
        control={form.control}
        name="visibility"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Who can see this event?</FormLabel>
            <div className="flex flex-col gap-2" role="radiogroup">
              {VISIBILITY_OPTIONS.map((opt) => {
                const Icon = opt.icon;
                const isSelected = field.value === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    role="radio"
                    aria-checked={isSelected}
                    onClick={() => field.onChange(opt.value)}
                    className={cn(
                      "flex items-center gap-4 rounded-xl border-2 px-4 py-3 text-left transition-all hover:border-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
                      isSelected
                        ? "border-blue-600 bg-blue-50"
                        : "border-border bg-card"
                    )}
                  >
                    <Icon
                      className={cn(
                        "h-5 w-5 shrink-0",
                        isSelected ? "text-blue-600" : "text-slate-400"
                      )}
                    />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-slate-900">
                        {opt.label}
                      </p>
                      <p className="text-xs text-slate-500">
                        {opt.description}
                      </p>
                    </div>
                    <div
                      className={cn(
                        "h-4 w-4 shrink-0 rounded-full border-2",
                        isSelected
                          ? "border-blue-600 bg-blue-500"
                          : "border-slate-300"
                      )}
                    >
                      {isSelected && (
                        <div className="h-full w-full scale-50 rounded-full bg-white" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Password field — only if PRIVATE */}
      {visibility === "PRIVATE" && (
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Event password</FormLabel>
              <FormControl>
                <Input
                  type="password"
                  placeholder="Optional password to access the event page"
                  {...field}
                  value={field.value ?? ""}
                />
              </FormControl>
              <FormDescription>
                Attendees will need this to view the event page. Leave blank to
                require only an invite link.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
      )}
    </div>
  );
}
