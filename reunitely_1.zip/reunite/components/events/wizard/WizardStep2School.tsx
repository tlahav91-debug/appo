"use client";

import { useState } from "react";
import type { UseFormReturn } from "react-hook-form";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { X, Plus } from "lucide-react";
import type { WizardFormData } from "@/schemas/wizard";
import { cn } from "@/lib/utils";

const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: CURRENT_YEAR - 1969 }, (_, i) => CURRENT_YEAR + 1 - i);

interface Props {
  form: UseFormReturn<WizardFormData>;
}

export function WizardStep2School({ form }: Props) {
  const [sectionInput, setSectionInput] = useState("");
  const classSections = form.watch("classSections") ?? [];
  const graduationYear = form.watch("graduationYear");

  function addSection() {
    const trimmed = sectionInput.trim();
    if (!trimmed || classSections.includes(trimmed) || classSections.length >= 10) return;
    form.setValue("classSections", [...classSections, trimmed]);
    setSectionInput("");
  }

  function removeSection(section: string) {
    form.setValue(
      "classSections",
      classSections.filter((s) => s !== section)
    );
  }

  function handleSectionKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      e.preventDefault();
      addSection();
    }
  }

  return (
    <div className="flex flex-col gap-7">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          School & cohort details
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          Help classmates know this is the right event.
        </p>
      </div>

      {/* School name */}
      <FormField
        control={form.control}
        name="schoolName"
        render={({ field }) => (
          <FormItem>
            <FormLabel>
              School name <span className="text-destructive">*</span>
            </FormLabel>
            <FormControl>
              <Input
                placeholder="e.g. Lincoln High School"
                className="text-base h-11"
                autoFocus
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Location */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <FormField
          control={form.control}
          name="schoolCity"
          render={({ field }) => (
            <FormItem>
              <FormLabel>City</FormLabel>
              <FormControl>
                <Input
                  placeholder="San Francisco"
                  {...field}
                  value={field.value ?? ""}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="schoolCountry"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Country</FormLabel>
              <FormControl>
                <Input placeholder="United States" {...field} value={field.value ?? ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      {/* Graduation year */}
      <FormField
        control={form.control}
        name="graduationYear"
        render={({ field }) => (
          <FormItem>
            <FormLabel>
              Graduation year <span className="text-destructive">*</span>
            </FormLabel>
            <FormControl>
              <div className="relative">
                <select
                  className="flex h-11 w-full appearance-none rounded-md border border-input bg-background px-3 py-2 pr-8 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  value={field.value ?? ""}
                  onChange={(e) => field.onChange(Number(e.target.value))}
                  aria-label="Graduation year"
                >
                  <option value="" disabled>
                    Select year
                  </option>
                  {YEARS.map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>
                <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 border-l-[5px] border-r-[5px] border-t-[6px] border-l-transparent border-r-transparent border-t-slate-400" />
              </div>
            </FormControl>
            {graduationYear && (
              <FormDescription>
                This will be the{" "}
                <strong>
                  {CURRENT_YEAR - graduationYear}-year reunion
                </strong>
                .
              </FormDescription>
            )}
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Which reunion */}
      <FormField
        control={form.control}
        name="reunionNumber"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Reunion milestone</FormLabel>
            <FormControl>
              <div className="flex flex-wrap gap-2" role="group" aria-label="Reunion milestones">
                {[5, 10, 15, 20, 25, 30, 40, 50].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() =>
                      field.onChange(field.value === n ? undefined : n)
                    }
                    className={cn(
                      "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
                      field.value === n
                        ? "border-blue-600 bg-blue-50 text-blue-700"
                        : "border-border text-slate-600 hover:border-blue-300"
                    )}
                  >
                    {n}-year
                  </button>
                ))}
              </div>
            </FormControl>
            <FormDescription>
              Optional — highlights the anniversary on your event page.
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Class sections */}
      <FormField
        control={form.control}
        name="classSections"
        render={() => (
          <FormItem>
            <FormLabel>Class sections or tracks</FormLabel>
            {classSections.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-2">
                {classSections.map((section) => (
                  <span
                    key={section}
                    className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-700"
                  >
                    {section}
                    <button
                      type="button"
                      onClick={() => removeSection(section)}
                      className="ml-0.5 rounded-full text-slate-400 hover:text-slate-700 focus-visible:outline-none"
                      aria-label={`Remove ${section}`}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
            <div className="flex gap-2">
              <FormControl>
                <Input
                  placeholder="e.g. Science Track, Section A"
                  value={sectionInput}
                  onChange={(e) => setSectionInput(e.target.value)}
                  onKeyDown={handleSectionKeyDown}
                  disabled={classSections.length >= 10}
                />
              </FormControl>
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={addSection}
                disabled={!sectionInput.trim() || classSections.length >= 10}
                aria-label="Add section"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <FormDescription>
              Optional — if your school had tracks or sections. Press Enter or
              click + to add.
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
}
