"use client";

import { useState } from "react";
import type { UseFormReturn } from "react-hook-form";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Plus, Trash2 } from "lucide-react";
import type { WizardFormData } from "@/schemas/wizard";
import { cn } from "@/lib/utils";

// ─── Shared FormRow ──────────────────────────────────────────────────────────

function ToggleRow({
  label,
  description,
  checked,
  onCheckedChange,
  children,
}: {
  label: string;
  description?: string;
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
  children?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-slate-900">{label}</p>
          {description && (
            <p className="text-xs text-slate-500 mt-0.5">{description}</p>
          )}
        </div>
        <Switch
          checked={checked}
          onCheckedChange={onCheckedChange}
          aria-label={label}
        />
      </div>
      {checked && children && (
        <div className="rounded-lg border border-border bg-slate-50 p-4">
          {children}
        </div>
      )}
    </div>
  );
}

// ─── Step 5: RSVP settings ───────────────────────────────────────────────────

interface StepProps {
  form: UseFormReturn<WizardFormData>;
}

export function WizardStep5Rsvp({ form }: StepProps) {
  const [customQInput, setCustomQInput] = useState("");
  const capacityUnlimited = form.watch("capacityUnlimited");
  const waitlistEnabled = form.watch("waitlistEnabled");
  const ticketingEnabled = form.watch("ticketingEnabled");
  const earlyBirdEnabled = form.watch("earlyBirdEnabled");
  const allowGuestPlus1 = form.watch("allowGuestPlus1");
  const customQuestions = form.watch("customQuestions") ?? [];

  function addQuestion() {
    const trimmed = customQInput.trim();
    if (!trimmed) return;
    const id = `q_${Date.now()}`;
    form.setValue("customQuestions", [
      ...customQuestions,
      { id, label: trimmed, type: "TEXT", required: false },
    ]);
    setCustomQInput("");
  }

  function removeQuestion(id: string) {
    form.setValue(
      "customQuestions",
      customQuestions.filter((q) => q.id !== id)
    );
  }

  return (
    <div className="flex flex-col gap-7">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          RSVP settings
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          Set capacity, manage the waitlist, and configure ticketing.
        </p>
      </div>

      {/* Capacity */}
      <div className="flex flex-col gap-4">
        <FormField
          control={form.control}
          name="capacityUnlimited"
          render={({ field }) => (
            <FormItem>
              <ToggleRow
                label="Unlimited capacity"
                description="No maximum attendee count"
                checked={field.value ?? true}
                onCheckedChange={(v) => {
                  field.onChange(v);
                  if (v) form.setValue("capacity", undefined);
                }}
              />
            </FormItem>
          )}
        />
        {!capacityUnlimited && (
          <FormField
            control={form.control}
            name="capacity"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Maximum attendees</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    min={1}
                    max={10000}
                    className="max-w-xs"
                    placeholder="e.g. 150"
                    {...field}
                    value={field.value ?? ""}
                    onChange={(e) =>
                      field.onChange(e.target.value ? Number(e.target.value) : undefined)
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
      </div>

      {/* Waitlist */}
      <div className="flex flex-col gap-3">
        <FormField
          control={form.control}
          name="waitlistEnabled"
          render={({ field }) => (
            <FormItem>
              <ToggleRow
                label="Enable waitlist"
                description="Automatically add people to a waitlist when capacity is reached"
                checked={field.value ?? true}
                onCheckedChange={field.onChange}
              >
                <FormField
                  control={form.control}
                  name="waitlistCapacity"
                  render={({ field: wf }) => (
                    <FormItem>
                      <FormLabel>Waitlist limit</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min={1}
                          max={500}
                          className="max-w-xs bg-white"
                          placeholder="Leave blank for unlimited"
                          {...wf}
                          value={wf.value ?? ""}
                          onChange={(e) =>
                            wf.onChange(e.target.value ? Number(e.target.value) : undefined)
                          }
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </ToggleRow>
            </FormItem>
          )}
        />
      </div>

      {/* RSVP deadline */}
      <FormField
        control={form.control}
        name="rsvpDeadline"
        render={({ field }) => (
          <FormItem>
            <FormLabel>RSVP deadline</FormLabel>
            <FormControl>
              <Input
                type="date"
                className="max-w-xs"
                {...field}
                value={field.value ?? ""}
              />
            </FormControl>
            <FormDescription>
              Optional — RSVPs close after this date.
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* Guests / +1s */}
      <div className="flex flex-col gap-3">
        <FormField
          control={form.control}
          name="allowGuestPlus1"
          render={({ field }) => (
            <FormItem>
              <ToggleRow
                label="Allow +1 guests"
                description="Attendees can bring additional guests"
                checked={field.value ?? true}
                onCheckedChange={field.onChange}
              >
                <FormField
                  control={form.control}
                  name="maxGuestsPerRsvp"
                  render={({ field: gf }) => (
                    <FormItem>
                      <FormLabel>Max guests per attendee</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min={1}
                          max={10}
                          className="max-w-xs bg-white"
                          {...gf}
                          value={gf.value ?? 1}
                          onChange={(e) => gf.onChange(Number(e.target.value))}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </ToggleRow>
            </FormItem>
          )}
        />
      </div>

      {/* Ticketing */}
      <div className="flex flex-col gap-3">
        <FormField
          control={form.control}
          name="ticketingEnabled"
          render={({ field }) => (
            <FormItem>
              <ToggleRow
                label="Paid tickets"
                description="Collect ticket payments via Stripe. You'll connect your Stripe account after publishing."
                checked={field.value ?? false}
                onCheckedChange={field.onChange}
              >
                <div className="flex flex-col gap-4">
                  <div className="grid grid-cols-2 gap-3">
                    <FormField
                      control={form.control}
                      name="ticketName"
                      render={({ field: tf }) => (
                        <FormItem>
                          <FormLabel>Ticket name</FormLabel>
                          <FormControl>
                            <Input className="bg-white" {...tf} value={tf.value ?? "General Admission"} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="ticketPrice"
                      render={({ field: tf }) => (
                        <FormItem>
                          <FormLabel>Price (USD)</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">$</span>
                              <Input
                                type="number"
                                min={0}
                                step="0.01"
                                className="pl-7 bg-white"
                                placeholder="99.00"
                                {...tf}
                                value={tf.value ?? ""}
                                onChange={(e) =>
                                  tf.onChange(e.target.value ? Number(e.target.value) : undefined)
                                }
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="ticketCapacity"
                    render={({ field: tf }) => (
                      <FormItem>
                        <FormLabel>Ticket inventory (optional)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min={1}
                            className="max-w-xs bg-white"
                            placeholder="Leave blank for unlimited"
                            {...tf}
                            value={tf.value ?? ""}
                            onChange={(e) =>
                              tf.onChange(e.target.value ? Number(e.target.value) : undefined)
                            }
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  {/* Early bird */}
                  <FormField
                    control={form.control}
                    name="earlyBirdEnabled"
                    render={({ field: ef }) => (
                      <ToggleRow
                        label="Early bird pricing"
                        description="Offer a discounted rate before a deadline"
                        checked={ef.value ?? false}
                        onCheckedChange={ef.onChange}
                      >
                        <div className="grid grid-cols-2 gap-3">
                          <FormField
                            control={form.control}
                            name="earlyBirdPrice"
                            render={({ field: ep }) => (
                              <FormItem>
                                <FormLabel>Early bird price ($)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">$</span>
                                    <Input
                                      type="number"
                                      min={0}
                                      step="0.01"
                                      className="pl-7 bg-white"
                                      placeholder="79.00"
                                      {...ep}
                                      value={ep.value ?? ""}
                                      onChange={(e) =>
                                        ep.onChange(e.target.value ? Number(e.target.value) : undefined)
                                      }
                                    />
                                  </div>
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="earlyBirdDeadline"
                            render={({ field: ed }) => (
                              <FormItem>
                                <FormLabel>Deadline</FormLabel>
                                <FormControl>
                                  <Input
                                    type="date"
                                    className="bg-white"
                                    {...ed}
                                    value={ed.value ?? ""}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        </div>
                      </ToggleRow>
                    )}
                  />
                </div>
              </ToggleRow>
            </FormItem>
          )}
        />
      </div>

      {/* Custom questions */}
      <div className="flex flex-col gap-3">
        <FormLabel>Custom RSVP questions</FormLabel>
        {customQuestions.map((q) => (
          <div
            key={q.id}
            className="flex items-center gap-2 rounded-lg border border-border bg-slate-50 px-3 py-2"
          >
            <p className="flex-1 text-sm text-slate-700 truncate">{q.label}</p>
            <span className="text-xs text-slate-400 shrink-0">{q.type.toLowerCase()}</span>
            <button
              type="button"
              onClick={() => removeQuestion(q.id)}
              className="text-slate-400 hover:text-red-500 transition-colors ml-1"
              aria-label={`Remove question: ${q.label}`}
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
        {customQuestions.length < 10 && (
          <div className="flex gap-2">
            <Input
              placeholder="e.g. Which table did you sit at in the cafeteria?"
              value={customQInput}
              onChange={(e) => setCustomQInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") { e.preventDefault(); addQuestion(); }
              }}
            />
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={addQuestion}
              disabled={!customQInput.trim()}
              aria-label="Add question"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        )}
        <p className="text-xs text-slate-400">
          {customQuestions.length}/10 questions · Shown on the RSVP form
        </p>
      </div>
    </div>
  );
}

// ─── Step 6: Invite settings ─────────────────────────────────────────────────

export function WizardStep6Invites({ form }: StepProps) {
  const verifySchoolEmail = form.watch("verifySchoolEmail");

  const INVITE_MODES = [
    {
      value: "OPEN" as const,
      label: "Open",
      description: "Anyone with the link can RSVP",
      emoji: "🔓",
    },
    {
      value: "INVITE_ONLY" as const,
      label: "Invite only",
      description: "Only people you personally invite",
      emoji: "✉️",
    },
    {
      value: "APPROVAL" as const,
      label: "Approval required",
      description: "You approve each RSVP manually",
      emoji: "✅",
    },
  ] as const;

  return (
    <div className="flex flex-col gap-7">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          Invite & access settings
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          Control who can RSVP and how classmates find your event.
        </p>
      </div>

      {/* RSVP mode */}
      <FormField
        control={form.control}
        name="inviteMode"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Who can RSVP?</FormLabel>
            <div className="flex flex-col gap-2" role="radiogroup">
              {INVITE_MODES.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  role="radio"
                  aria-checked={field.value === opt.value}
                  onClick={() => field.onChange(opt.value)}
                  className={cn(
                    "flex items-center gap-3 rounded-xl border-2 px-4 py-3 text-left transition-all",
                    field.value === opt.value
                      ? "border-blue-600 bg-blue-50"
                      : "border-border hover:border-blue-300"
                  )}
                >
                  <span className="text-xl">{opt.emoji}</span>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-slate-900">{opt.label}</p>
                    <p className="text-xs text-slate-500">{opt.description}</p>
                  </div>
                  <div
                    className={cn(
                      "h-4 w-4 shrink-0 rounded-full border-2",
                      field.value === opt.value
                        ? "border-blue-600 bg-blue-500"
                        : "border-slate-300"
                    )}
                  />
                </button>
              ))}
            </div>
          </FormItem>
        )}
      />

      {/* Allow attendees to invite */}
      <FormField
        control={form.control}
        name="allowAttendeesInvite"
        render={({ field }) => (
          <FormItem>
            <ToggleRow
              label="Attendees can invite others"
              description="Confirmed RSVPs get a personal referral link to share"
              checked={field.value ?? true}
              onCheckedChange={field.onChange}
            />
          </FormItem>
        )}
      />

      {/* Referral links */}
      <FormField
        control={form.control}
        name="referralLinksEnabled"
        render={({ field }) => (
          <FormItem>
            <ToggleRow
              label="Referral link tracking"
              description="Track how many RSVPs each person brings in"
              checked={field.value ?? true}
              onCheckedChange={field.onChange}
            />
          </FormItem>
        )}
      />

      {/* Show attendee count */}
      <FormField
        control={form.control}
        name="showAttendeeCount"
        render={({ field }) => (
          <FormItem>
            <ToggleRow
              label="Show confirmed count publicly"
              description="Display number of confirmed RSVPs on the event page"
              checked={field.value ?? true}
              onCheckedChange={field.onChange}
            />
          </FormItem>
        )}
      />

      {/* School email verification */}
      <FormField
        control={form.control}
        name="verifySchoolEmail"
        render={({ field }) => (
          <FormItem>
            <ToggleRow
              label="Require school email verification"
              description="Attendees must verify with a matching school email domain"
              checked={field.value ?? false}
              onCheckedChange={field.onChange}
            >
              <FormField
                control={form.control}
                name="schoolEmailDomain"
                render={({ field: sf }) => (
                  <FormItem>
                    <FormLabel>School email domain</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g. lincolnhs.edu"
                        className="bg-white"
                        {...sf}
                        value={sf.value ?? ""}
                      />
                    </FormControl>
                    <FormDescription>
                      Only addresses ending in this domain will be accepted.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </ToggleRow>
          </FormItem>
        )}
      />
    </div>
  );
}

// ─── Step 7: Messaging preferences ──────────────────────────────────────────

export function WizardStep7Messaging({ form }: StepProps) {
  const sendEventReminder = form.watch("sendEventReminder");

  return (
    <div className="flex flex-col gap-7">
      <div>
        <h2 className="font-display text-xl font-bold text-slate-900">
          Features & messaging
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          Choose which features to enable and how you'll communicate with attendees.
        </p>
      </div>

      {/* Feature toggles */}
      <div className="flex flex-col gap-0 divide-y divide-border rounded-xl border border-border overflow-hidden">
        {[
          {
            name: "chatEnabled" as const,
            label: "Chat rooms",
            description: "Real-time group chat for attendees",
          },
          {
            name: "memoriesEnabled" as const,
            label: "Memory wall",
            description: "Let attendees share photos and memories",
          },
          {
            name: "nominationsEnabled" as const,
            label: "Nominations & superlatives",
            description: "Class awards voting",
          },
          {
            name: "directoryEnabled" as const,
            label: "Attendee directory",
            description: "Public profile listing for all confirmed attendees",
          },
          {
            name: "scheduleEnabled" as const,
            label: "Event schedule",
            description: "Show an agenda / schedule on the event page",
          },
        ].map(({ name, label, description }) => (
          <FormField
            key={name}
            control={form.control}
            name={name}
            render={({ field }) => (
              <FormItem className="flex items-center justify-between gap-4 px-4 py-3.5">
                <div>
                  <FormLabel className="text-sm font-medium">{label}</FormLabel>
                  <FormDescription className="mt-0 text-xs">
                    {description}
                  </FormDescription>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value as boolean ?? false}
                    onCheckedChange={field.onChange}
                    aria-label={label}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        ))}
      </div>

      {/* Auto-approve memories */}
      <FormField
        control={form.control}
        name="memoriesAutoApprove"
        render={({ field }) => (
          <FormItem>
            <ToggleRow
              label="Auto-approve memories"
              description="Memories post immediately without organizer review. Not recommended."
              checked={field.value ?? false}
              onCheckedChange={field.onChange}
            />
          </FormItem>
        )}
      />

      {/* Email notifications */}
      <div className="flex flex-col gap-4">
        <h3 className="text-sm font-semibold text-slate-900">
          Automated emails to attendees
        </h3>

        <FormField
          control={form.control}
          name="sendRsvpConfirmation"
          render={({ field }) => (
            <FormItem>
              <ToggleRow
                label="RSVP confirmation email"
                description="Send a confirmation email when someone RSVPs"
                checked={field.value ?? true}
                onCheckedChange={field.onChange}
              />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="sendEventReminder"
          render={({ field }) => (
            <FormItem>
              <ToggleRow
                label="Event reminder email"
                description="Remind confirmed attendees before the event"
                checked={field.value ?? true}
                onCheckedChange={field.onChange}
              >
                <FormField
                  control={form.control}
                  name="reminderDaysBefore"
                  render={({ field: rf }) => (
                    <FormItem>
                      <FormLabel>Days before event</FormLabel>
                      <FormControl>
                        <div className="flex items-center gap-2">
                          <Input
                            type="number"
                            min={1}
                            max={30}
                            className="w-20 bg-white"
                            {...rf}
                            value={rf.value ?? 3}
                            onChange={(e) => rf.onChange(Number(e.target.value))}
                          />
                          <span className="text-sm text-slate-500">days before</span>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </ToggleRow>
            </FormItem>
          )}
        />
      </div>

      {/* SMS/WhatsApp */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-semibold text-slate-900">
          SMS & WhatsApp (requires consent)
        </h3>
        <FormField
          control={form.control}
          name="smsRemindersEnabled"
          render={({ field }) => (
            <FormItem>
              <ToggleRow
                label="SMS reminders"
                description="Text message reminders to attendees who consented"
                checked={field.value ?? false}
                onCheckedChange={field.onChange}
              />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="whatsappRemindersEnabled"
          render={({ field }) => (
            <FormItem>
              <ToggleRow
                label="WhatsApp reminders"
                description="WhatsApp messages to attendees who consented"
                checked={field.value ?? false}
                onCheckedChange={field.onChange}
              />
            </FormItem>
          )}
        />
      </div>

      {/* Organizer notification email */}
      <FormField
        control={form.control}
        name="notificationEmail"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Organizer notification email</FormLabel>
            <FormControl>
              <Input
                type="email"
                placeholder="you@example.com"
                className="max-w-sm"
                {...field}
                value={field.value ?? ""}
              />
            </FormControl>
            <FormDescription>
              Where to receive new RSVPs, messages, and system alerts. Defaults to your account email.
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
}
