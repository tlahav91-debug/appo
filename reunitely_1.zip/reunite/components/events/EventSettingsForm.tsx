"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Globe, Archive, Loader2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { toast } from "sonner";
import type { EventStatus } from "@prisma/client";
import { usePublishEvent, useArchiveEvent } from "@/hooks/useEvent";
import { CommitteeManager } from "@/components/events/CommitteeManager";

interface EventSettings {
  nominationsEnabled: boolean;
  scheduleEnabled: boolean;
  memoriesAutoApprove: boolean;
  chatEnabled: boolean;
  directoryEnabled: boolean;
}

interface EventSettingsFormProps {
  event: {
    id: string;
    slug: string;
    status: EventStatus;
    settings: EventSettings;
  };
}

export function EventSettingsForm({ event }: EventSettingsFormProps) {
  const router = useRouter();
  const [settings, setSettings] = useState<EventSettings>(event.settings);
  const [isSaving, setIsSaving] = useState(false);

  const publishMutation = usePublishEvent(event.id);
  const archiveMutation = useArchiveEvent(event.id);

  async function saveSettings() {
    setIsSaving(true);
    try {
      const res = await fetch(`/api/events/${event.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings }),
      });
      if (!res.ok) throw new Error("Save failed");
      toast.success("Settings saved");
    } catch {
      toast.error("Failed to save settings");
    } finally {
      setIsSaving(false);
    }
  }

  function toggle(key: keyof EventSettings) {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  const featureToggles: Array<{
    key: keyof EventSettings;
    label: string;
    description: string;
  }> = [
    {
      key: "chatEnabled",
      label: "Event Chat",
      description: "Allow confirmed attendees to chat before and during the event",
    },
    {
      key: "nominationsEnabled",
      label: "Nominations",
      description: 'Enable "Most Likely To" style voting categories',
    },
    {
      key: "scheduleEnabled",
      label: "Schedule",
      description: "Show event agenda on the public page",
    },
    {
      key: "directoryEnabled",
      label: "Attendee Directory",
      description: "Show public attendee profiles on the event page",
    },
    {
      key: "memoriesAutoApprove",
      label: "Auto-approve Memories",
      description:
        "Memories go live immediately without organizer review. Not recommended.",
    },
  ];

  return (
    <div className="flex flex-col gap-6 max-w-2xl">
      {/* Publish / status */}
      <div className="rounded-xl border border-border bg-card p-6">
        <h2 className="text-base font-semibold text-slate-900 mb-4">
          Event Status
        </h2>

        {event.status === "DRAFT" && (
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-slate-900">Publish Event</p>
              <p className="text-sm text-slate-500 mt-0.5">
                Make your event page live and visible to anyone with the link.
              </p>
            </div>
            <Button
              onClick={() => publishMutation.mutate()}
              disabled={publishMutation.isPending}
              className="shrink-0 gap-2"
            >
              {publishMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Globe className="h-4 w-4" />
              )}
              Publish
            </Button>
          </div>
        )}

        {event.status === "PUBLISHED" && (
          <div className="flex items-center gap-2 rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-3">
            <Globe className="h-4 w-4 text-emerald-600 shrink-0" />
            <div>
              <p className="text-sm font-medium text-emerald-800">
                Event is live
              </p>
              <a
                href={`/events/${event.slug}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-emerald-600 hover:underline"
              >
                View public page →
              </a>
            </div>
          </div>
        )}
      </div>

      {/* Feature toggles */}
      <div className="rounded-xl border border-border bg-card p-6">
        <h2 className="text-base font-semibold text-slate-900 mb-4">
          Features
        </h2>
        <div className="flex flex-col gap-0 divide-y divide-border">
          {featureToggles.map((feature) => (
            <div
              key={feature.key}
              className="flex items-center justify-between gap-4 py-4"
            >
              <div>
                <Label className="text-sm font-medium text-slate-900 cursor-pointer">
                  {feature.label}
                </Label>
                <p className="text-xs text-slate-500 mt-0.5">
                  {feature.description}
                </p>
              </div>
              <Switch
                checked={settings[feature.key]}
                onCheckedChange={() => toggle(feature.key)}
                aria-label={`Toggle ${feature.label}`}
              />
            </div>
          ))}
        </div>

        <div className="mt-4 flex justify-end">
          <Button onClick={saveSettings} disabled={isSaving} size="sm">
            {isSaving ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : null}
            Save Settings
          </Button>
        </div>
      </div>


      {/* Committee management */}
      <div className="rounded-xl border border-border bg-card p-6">
        <CommitteeManager eventId={event.id} />
      </div>

      {/* Danger zone */}
      <div className="rounded-xl border border-red-200 bg-card p-6">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="h-4 w-4 text-red-500" />
          <h2 className="text-base font-semibold text-red-700">Danger Zone</h2>
        </div>
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-slate-900">Archive Event</p>
            <p className="text-sm text-slate-500 mt-0.5">
              Hides the event from public search. RSVPs and data are preserved.
              This cannot be easily undone.
            </p>
          </div>
          <ConfirmDialog
            trigger={
              <Button
                variant="outline"
                size="sm"
                className="shrink-0 gap-2 border-red-300 text-red-600 hover:bg-red-50"
                disabled={
                  event.status === "ARCHIVED" || archiveMutation.isPending
                }
              >
                <Archive className="h-4 w-4" />
                Archive
              </Button>
            }
            title="Archive this event?"
            description="The event page will be hidden from public view. All attendee data, RSVPs, and memories are preserved. You can restore it by contacting support."
            confirmLabel="Archive Event"
            onConfirm={() => {
              archiveMutation.mutate();
              router.push("/dashboard/events");
            }}
          />
        </div>
      </div>
    </div>
  );
}
