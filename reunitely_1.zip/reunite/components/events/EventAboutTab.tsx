import { Avatar } from "@/components/shared/Avatar";
import { formatEventDate, formatEventTime, formatCurrency } from "@/lib/utils";
import { Calendar, Clock, MapPin, Ticket, User } from "lucide-react";
import { EmptyState } from "@/components/shared/EmptyState";
import { db } from "@/lib/db";

interface EventAboutTabEvent {
  id: string;
  title: string;
  description?: unknown;
  startAt: Date;
  endAt?: Date | null;
  timezone: string;
  venueName?: string | null;
  venueAddress?: string | null;
  createdBy?: { name: string; avatarUrl: string | null };
  settings?: unknown;
}

interface EventAboutTabProps {
  event: EventAboutTabEvent;
}

export async function EventAboutTab({ event }: EventAboutTabProps) {
  // Fetch tickets server-side
  const tickets = await db.ticket.findMany({
    where: {
      eventId: event.id,
      isVisible: true,
      isActive: true,
    },
    orderBy: { price: "asc" },
  });

  const settings = event.settings as {
    customQuestions?: Array<{ id: string; label: string }>;
  } | null;

  return (
    <div className="grid gap-8 md:grid-cols-3">
      {/* Main description */}
      <div className="md:col-span-2">
        <h2 className="mb-4 text-lg font-semibold text-slate-900">
          About this event
        </h2>

        {event.description ? (
          // Render Tiptap JSON as static HTML
          // In production use @tiptap/html generateHTML()
          <div
            className="prose prose-slate max-w-none text-slate-600"
            aria-label="Event description"
          >
            <p>
              {extractDescriptionText(
                event.description as Record<string, unknown>
              )}
            </p>
          </div>
        ) : (
          <p className="text-slate-500 italic">
            No description provided yet.
          </p>
        )}

        {/* Tickets */}
        {tickets.length > 0 && (
          <div className="mt-8">
            <h3 className="mb-3 text-base font-semibold text-slate-900">
              Tickets
            </h3>
            <div className="flex flex-col gap-3">
              {tickets.map((ticket) => (
                <div
                  key={ticket.id}
                  className="flex items-center justify-between rounded-lg border border-border bg-card p-4"
                >
                  <div className="flex items-center gap-3">
                    <Ticket className="h-4 w-4 text-blue-500" />
                    <div>
                      <p className="font-medium text-slate-900">
                        {ticket.name}
                      </p>
                      {ticket.description && (
                        <p className="text-sm text-slate-500">
                          {ticket.description}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-slate-900">
                      {ticket.price === 0
                        ? "Free"
                        : formatCurrency(ticket.price, ticket.currency)}
                    </p>
                    {ticket.capacity && (
                      <p className="text-xs text-slate-400">
                        {Math.max(0, ticket.capacity - ticket.soldCount)} left
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Sidebar: event details */}
      <div className="flex flex-col gap-6">
        {/* Event info card */}
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-slate-500">
            Event Details
          </h3>
          <div className="flex flex-col gap-3 text-sm text-slate-600">
            <div className="flex items-start gap-2.5">
              <Calendar className="mt-0.5 h-4 w-4 shrink-0 text-blue-500" />
              <span>{formatEventDate(event.startAt, event.timezone)}</span>
            </div>
            <div className="flex items-start gap-2.5">
              <Clock className="mt-0.5 h-4 w-4 shrink-0 text-blue-500" />
              <span>{formatEventTime(event.startAt, event.timezone)}</span>
            </div>
            {event.venueName && (
              <div className="flex items-start gap-2.5">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-blue-500" />
                <div>
                  <p className="font-medium text-slate-900">{event.venueName}</p>
                  {event.venueAddress && (
                    <a
                      href={`https://maps.google.com/?q=${encodeURIComponent(event.venueAddress)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      View on map
                    </a>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Organizer card */}
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-500">
            Organized by
          </h3>
          <div className="flex items-center gap-3">
            <Avatar
              name={event.createdBy.name}
              src={event.createdBy.avatarUrl}
              size="md"
            />
            <div>
              <p className="font-semibold text-slate-900">
                {event.createdBy.name}
              </p>
              <p className="text-xs text-slate-400">Event organizer</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function extractDescriptionText(json: Record<string, unknown>): string {
  try {
    const content = json.content as Array<{
      content?: Array<{ text?: string }>;
    }>;
    return content
      .flatMap((node) => node.content ?? [])
      .map((c) => c.text ?? "")
      .join(" ")
      .trim();
  } catch {
    return "";
  }
}
