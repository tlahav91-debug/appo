"use client";

import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter, useSearchParams } from "next/navigation";
import { toast } from "sonner";
import { Form } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Loader2, Save, Eye, Rocket } from "lucide-react";
import { WizardProgressBar } from "@/components/events/wizard/WizardProgressBar";
import { WizardStep1BasicInfo } from "@/components/events/wizard/WizardStep1BasicInfo";
import { WizardStep2School } from "@/components/events/wizard/WizardStep2School";
import { WizardStep3DateTime } from "@/components/events/wizard/WizardStep3DateTime";
import { WizardStep4Branding } from "@/components/events/wizard/WizardStep4Branding";
import { WizardStep5Rsvp } from "@/components/events/wizard/WizardStep5Rsvp";
import { WizardStep6Invites } from "@/components/events/wizard/WizardStep6Invites";
import { WizardStep7Messaging } from "@/components/events/wizard/WizardStep7Messaging";
import { WizardStep8Review } from "@/components/events/wizard/WizardStep8Review";
import { useUnsavedChangesWarning } from "@/hooks/useUnsavedChangesWarning";
import {
  wizardSchema,
  STEP_FIELDS,
  STEP_SCHEMAS,
  WIZARD_DEFAULTS,
  WIZARD_STEPS,
  type WizardFormData,
} from "@/schemas/wizard";
import {
  saveDraftAction,
  publishWizardAction,
} from "@/lib/actions/wizard.actions";

// ─── Constants ────────────────────────────────────────────────────────────────

const TOTAL_STEPS = 8;
const AUTOSAVE_DELAY_MS = 2500; // debounce after user stops typing

// ─── Component ────────────────────────────────────────────────────────────────

interface CreateEventWizardProps {
  initialStep?: number;
  initialEventId?: string;
  initialData?: Partial<WizardFormData>;
}

export function CreateEventWizard({
  initialStep = 1,
  initialEventId,
  initialData,
}: CreateEventWizardProps) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [currentStep, setCurrentStep] = useState(initialStep);
  const [eventId, setEventId] = useState<string | null>(
    initialEventId ?? searchParams.get("draft")
  );
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isPublishing, startPublish] = useTransition();
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const autosaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const hasUnsavedChanges = useRef(false);
  const [isDirty, setIsDirty] = useState(false);

  // Warn user before closing tab with unsaved changes
  useUnsavedChangesWarning(isDirty && !isPublishing);

  const form = useForm<WizardFormData>({
    resolver: zodResolver(wizardSchema),
    defaultValues: { ...WIZARD_DEFAULTS, ...initialData },
    mode: "onTouched",
  });

  // ── Autosave ──────────────────────────────────────────────────────────────

  const triggerAutosave = useCallback(async () => {
    if (!hasUnsavedChanges.current) return;
    const values = form.getValues();

    // Don't autosave if we don't have a title yet
    if (!values.title?.trim() && !eventId) return;

    setIsSaving(true);
    try {
      const result = await saveDraftAction(values, eventId ?? undefined);
      if (result.success) {
        if (!eventId) {
          // First save — update URL with draft ID without navigation
          setEventId(result.data.eventId);
          const params = new URLSearchParams(searchParams.toString());
          params.set("draft", result.data.eventId);
          params.set("step", String(currentStep));
          window.history.replaceState(null, "", `?${params.toString()}`);
        }
        setLastSavedAt(new Date());
        hasUnsavedChanges.current = false;
        setIsDirty(false);
      } else {
        // Silently fail autosave — don't interrupt the user
        console.error("[Autosave] Failed:", result.error);
      }
    } catch (err) {
      console.error("[Autosave] Error:", err);
    } finally {
      setIsSaving(false);
    }
  }, [eventId, currentStep, searchParams, form]);

  // Watch all form changes and debounce autosave
  useEffect(() => {
    const subscription = form.watch(() => {
      hasUnsavedChanges.current = true;
      setIsDirty(true);
      if (autosaveTimer.current) clearTimeout(autosaveTimer.current);
      autosaveTimer.current = setTimeout(triggerAutosave, AUTOSAVE_DELAY_MS);
    });
    return () => {
      subscription.unsubscribe();
      if (autosaveTimer.current) clearTimeout(autosaveTimer.current);
    };
  }, [form, triggerAutosave]);

  // Sync step to URL
  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("step", String(currentStep));
    if (eventId) params.set("draft", eventId);
    window.history.replaceState(null, "", `?${params.toString()}`);
  }, [currentStep, eventId, searchParams]);

  // ── Navigation ────────────────────────────────────────────────────────────

  async function goToStep(targetStep: number) {
    // Validate current step before moving forward
    if (targetStep > currentStep) {
      const fields = STEP_FIELDS[currentStep] ?? [];
      if (fields.length > 0) {
        const valid = await form.trigger(fields as Array<keyof WizardFormData>);
        if (!valid) {
          // Also try full step schema validation for cross-field rules
          const stepSchema = STEP_SCHEMAS[currentStep];
          if (stepSchema) {
            const values = form.getValues();
            const result = stepSchema.safeParse(values);
            if (!result.success) {
              result.error.errors.forEach((e) => {
                const path = e.path.join(".") as keyof WizardFormData;
                form.setError(path, { message: e.message });
              });
            }
          }
          toast.error("Please fix the errors before continuing.");
          return;
        }
      }
    }

    setCurrentStep(targetStep);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function handleSaveDraft() {
    if (autosaveTimer.current) clearTimeout(autosaveTimer.current);
    setIsSaving(true);
    try {
      const result = await saveDraftAction(form.getValues(), eventId ?? undefined);
      if (result.success) {
        if (!eventId) setEventId(result.data.eventId);
        setLastSavedAt(new Date());
        hasUnsavedChanges.current = false;
        toast.success("Draft saved");
      } else {
        toast.error(result.error);
      }
    } finally {
      setIsSaving(false);
    }
  }

  // ── Publish ───────────────────────────────────────────────────────────────

  function handlePublish() {
    // Clear pending autosave
    if (autosaveTimer.current) clearTimeout(autosaveTimer.current);

    startPublish(async () => {
      // Full form validation before publish
      const valid = await form.trigger();
      if (!valid) {
        // Jump to first step with errors
        for (let s = 1; s <= TOTAL_STEPS; s++) {
          const fields = STEP_FIELDS[s] ?? [];
          const hasError = fields.some(
            (f) => form.formState.errors[f as keyof WizardFormData]
          );
          if (hasError) {
            setCurrentStep(s);
            break;
          }
        }
        toast.error("Please fix all errors before publishing.");
        return;
      }

      // Ensure we have an eventId (save if needed)
      let currentEventId = eventId;
      if (!currentEventId) {
        const draftResult = await saveDraftAction(form.getValues());
        if (!draftResult.success) {
          toast.error(draftResult.error);
          return;
        }
        currentEventId = draftResult.data.eventId;
        setEventId(currentEventId);
      }

      const result = await publishWizardAction(form.getValues(), currentEventId);
      if (result.success) {
        router.push(`/dashboard/events/${result.data.eventId}/published?slug=${result.data.slug}`);
      } else {
        toast.error(result.error ?? "Failed to publish. Please try again.");
      }
    });
  }

  // ── Render ────────────────────────────────────────────────────────────────

  const stepComponents: Record<number, React.ReactNode> = {
    1: <WizardStep1BasicInfo form={form} />,
    2: <WizardStep2School form={form} />,
    3: <WizardStep3DateTime form={form} />,
    4: <WizardStep4Branding form={form} eventId={eventId ?? undefined} />,
    5: <WizardStep5Rsvp form={form} />,
    6: <WizardStep6Invites form={form} />,
    7: <WizardStep7Messaging form={form} />,
    8: (
      <WizardStep8Review
        form={form}
        onEditStep={setCurrentStep}
        onPublish={handlePublish}
        isPublishing={isPublishing}
      />
    ),
  };

  const isLastStep = currentStep === TOTAL_STEPS;
  const isFirstStep = currentStep === 1;

  return (
    <Form {...form}>
      <div className="flex flex-col gap-0">
        {/* Progress bar — sticky on mobile */}
        <div className="sticky top-0 z-20 bg-background pb-4 pt-2">
          <WizardProgressBar
            currentStep={currentStep}
            totalSteps={TOTAL_STEPS}
            steps={WIZARD_STEPS}
            onStepClick={(step) => {
              // Allow clicking back to previously completed steps
              if (step <= currentStep) goToStep(step);
            }}
            lastSavedAt={lastSavedAt}
            isSaving={isSaving}
          />
        </div>

        {/* Step content */}
        <div className="rounded-2xl border border-border bg-card shadow-card">
          <div className="p-5 sm:p-7">
            {stepComponents[currentStep]}
          </div>
        </div>

        {/* Navigation footer */}
        {currentStep < TOTAL_STEPS && (
          <div className="flex items-center justify-between pt-5">
            {/* Left: back + save draft */}
            <div className="flex items-center gap-2">
              {!isFirstStep && (
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => goToStep(currentStep - 1)}
                  className="gap-1.5"
                  disabled={isPublishing}
                >
                  <ChevronLeft className="h-4 w-4" />
                  Back
                </Button>
              )}
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleSaveDraft}
                disabled={isSaving || isPublishing}
                className="gap-1.5 text-slate-500 hover:text-slate-700"
              >
                {isSaving ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Save className="h-3.5 w-3.5" />
                )}
                <span className="hidden sm:inline">Save draft</span>
              </Button>
            </div>

            {/* Right: preview + continue */}
            <div className="flex items-center gap-2">
              {eventId && currentStep >= 4 && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="gap-1.5 hidden sm:flex"
                  onClick={() => window.open(`/events/preview/${eventId}`, "_blank")}
                >
                  <Eye className="h-3.5 w-3.5" />
                  Preview
                </Button>
              )}
              <Button
                type="button"
                onClick={() => goToStep(currentStep + 1)}
                disabled={isPublishing}
                className="gap-1.5 min-w-28"
              >
                Continue
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </Form>
  );
}
