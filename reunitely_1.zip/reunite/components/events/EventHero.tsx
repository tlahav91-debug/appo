import Image from "next/image";
import { Calendar, MapPin, Users, Clock, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShareMenu } from "@/components/shared/ShareMenu";
import { Avatar } from "@/components/shared/Avatar";
import { formatEventDate, formatEventTime, getEventUrl } from "@/lib/utils";
import Link from "next/link";
import { cn } from "@/lib/utils";
import type { EventStatus, EventVisibility } from "@prisma/client";

// Flexible prop shape — works for PublicEvent, draft previews, and organizer view
interface EventHeroEvent {
  id: string;
  title: string;
  slug: string;
  coverImageUrl?: string | null;
  startAt: Date;
  endAt?: Date | null;
  timezone: string;
  venueName?: string | null;
  venueAddress?: string | null;
  schoolName: string;
  graduationYear: number;
  status: EventStatus | string;
  visibility?: EventVisibility | string;
  ticketingEnabled?: boolean;
  createdBy?: { name: string; avatarUrl: string | null };
}

interface EventTheme {
  primaryColor: string;
  accentColor: string;
  headerLayout: string;
}

interface EventHeroProps {
  event: EventHeroEvent;
  theme?: EventTheme;
  confirmedCount?: number;
  isOrganizer?: boolean;
  isPreview?: boolean;
}

export function EventHero({
  event,
  theme,
  confirmedCount = 0,
  isOrganizer = false,
  isPreview = false,
}: EventHeroProps) {
  const eventUrl = getEventUrl(event.slug);

  const primaryColor = theme?.primaryColor ?? "#1E3A5F";
  const headerLayout = theme?.headerLayout ?? "centered";
  const isFullBleed = headerLayout === "full-bleed" || headerLayout === "FULL_BLEED";
  const isLeftAligned = headerLayout === "left" || headerLayout === "LEFT";

  return (
    <section aria-labelledby="event-title">
      {/* Cover image */}
      <div
        className={cn(
          "relative w-full overflow-hidden",
          isFullBleed ? "h-64 sm:h-80 md:h-96" : "h-48 sm:h-64 md:h-80"
        )}
        style={{ backgroundColor: `${primaryColor}22` }}
      >
        {event.coverImageUrl ? (
          <Image
            src={event.coverImageUrl}
            alt={`Cover photo for ${event.title}`}
            fill
            className="object-cover"
            priority
            sizes="100vw"
          />
        ) : (
          <div
            className="flex h-full w-full items-center justify-center"
            style={{
              background: `linear-gradient(135deg, ${primaryColor}33, ${primaryColor}66)`,
            }}
          >
            <span
              className="font-display text-4xl font-bold opacity-30"
              style={{ color: primaryColor }}
            >
              {event.schoolName}
            </span>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />

        {/* Cohort badge */}
        <div className="absolute left-4 top-4 flex gap-2">
          <Badge
            className="border-0 font-semibold text-xs"
            style={{ backgroundColor: primaryColor, color: "#fff" }}
          >
            Class of {event.graduationYear}
          </Badge>
          {(isPreview || event.status === "DRAFT") && (
            <Badge variant="outline" className="bg-blue-50 border-blue-300 text-blue-700 gap-1 text-xs">
              <Eye className="h-3 w-3" />
              {isPreview ? "Preview" : "Draft"}
            </Badge>
          )}
        </div>

        {/* Full-bleed title overlay */}
        {isFullBleed && (
          <div
            className={cn(
              "absolute bottom-0 w-full p-6 sm:p-8",
              isLeftAligned ? "text-left" : "text-center"
            )}
          >
            <h1
              id="event-title"
              className="font-display text-2xl font-bold text-white drop-shadow-lg sm:text-3xl"
            >
              {event.title}
            </h1>
          </div>
        )}
      </div>

      {/* Info card */}
      <div className="container">
        <div className="relative -mt-8 rounded-2xl border border-border bg-card p-6 shadow-card-lg sm:-mt-12 sm:p-8">
          <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
            {/* Left: title (unless full-bleed) + meta */}
            <div className="flex flex-col gap-4">
              {!isFullBleed && (
                <div>
                  <p className="text-sm font-medium text-slate-500">
                    {event.schoolName}
                  </p>
                  <h1
                    id="event-title"
                    className={cn(
                      "mt-1 font-display text-2xl font-bold text-slate-900 sm:text-3xl",
                      isLeftAligned ? "text-left" : ""
                    )}
                  >
                    {event.title}
                  </h1>
                </div>
              )}

              {/* Meta chips */}
              <div className="flex flex-wrap gap-3 text-sm text-slate-600">
                <div className="flex items-center gap-1.5">
                  <Calendar className="h-4 w-4 text-blue-500" />
                  <span>{formatEventDate(event.startAt, event.timezone)}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="h-4 w-4 text-blue-500" />
                  <span>{formatEventTime(event.startAt, event.timezone)}</span>
                </div>
                {event.venueName && (
                  <div className="flex items-center gap-1.5">
                    <MapPin className="h-4 w-4 text-blue-500" />
                    <span>{event.venueName}</span>
                    {event.venueAddress && !isPreview && (
                      <a
                        href={`https://maps.google.com/?q=${encodeURIComponent(event.venueAddress)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline"
                      >
                        (Map)
                      </a>
                    )}
                  </div>
                )}
                {confirmedCount > 0 && (
                  <div className="flex items-center gap-1.5">
                    <Users className="h-4 w-4 text-blue-500" />
                    <span>
                      <strong className="text-slate-900">{confirmedCount}</strong>{" "}
                      going
                    </span>
                  </div>
                )}
              </div>

              {/* Organizer */}
              {event.createdBy && (
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <Avatar
                    name={event.createdBy.name}
                    src={event.createdBy.avatarUrl}
                    size="xs"
                  />
                  <span>
                    Organized by{" "}
                    <span className="font-medium text-slate-700">
                      {event.createdBy.name}
                    </span>
                  </span>
                </div>
              )}
            </div>

            {/* Right: CTAs */}
            {!isPreview && (
              <div className="flex shrink-0 flex-col gap-3 sm:flex-row md:flex-col">
                {!isOrganizer && (
                  <Button asChild size="lg" className="w-full sm:w-auto md:w-48">
                    <Link href={`/events/${event.slug}/rsvp`}>RSVP Now</Link>
                  </Button>
                )}
                {isOrganizer && (
                  <Button asChild size="lg" variant="outline" className="w-full sm:w-auto md:w-48">
                    <Link href={`/dashboard/events/${event.id}/overview`}>
                      Manage Event
                    </Link>
                  </Button>
                )}
                <ShareMenu
                  url={eventUrl}
                  title={event.title}
                  description={`Join the ${event.schoolName} Class of ${event.graduationYear} reunion!`}
                  variant="outline"
                  size="default"
                />
              </div>
            )}

            {/* Preview CTAs */}
            {isPreview && (
              <div className="flex shrink-0 flex-col gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="opacity-50 cursor-not-allowed pointer-events-none"
                >
                  RSVP Now (preview)
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
