"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Users,
  Mail,
  Send,
  Image,
  Trophy,
  Calendar,
  CreditCard,
  Settings,
  MessageSquare,
  UserSearch,
} from "lucide-react";

interface NavPermissions {
  canViewAttendees: boolean;
  canCheckIn?: boolean;
  canViewInvites: boolean;
  canSendMessages: boolean;
  canModerateMemories: boolean;
  canManageNominations: boolean;
  canViewPayments: boolean;
  canManageSettings: boolean;
  canManageCohort: boolean;
}

interface EventManagementNavProps {
  eventId: string;
  permissions: NavPermissions;
}

export function EventManagementNav({
  eventId,
  permissions,
}: EventManagementNavProps) {
  const pathname = usePathname();

  // Build the visible nav items based on current user's permissions
  // Overview is always visible to anyone who reached this layout
  const navItems = [
    { segment: "overview", label: "Overview", icon: LayoutDashboard, always: true },
    { segment: "attendees", label: "Attendees", icon: Users, show: permissions.canViewAttendees },
    { segment: "check-in", label: "Check-in", icon: ScanLine, show: permissions.canCheckIn ?? permissions.canViewAttendees },
    { segment: "invites", label: "Invites", icon: Mail, show: permissions.canViewInvites },
    { segment: "messages", label: "Messages", icon: Send, show: permissions.canSendMessages },
    { segment: "memories", label: "Memories", icon: Image, show: permissions.canModerateMemories },
    { segment: "nominations", label: "Nominations", icon: Trophy, show: permissions.canManageNominations },
    { segment: "cohort", label: "Find Classmates", icon: UserSearch, show: permissions.canManageCohort },
    { segment: "schedule", label: "Schedule", icon: Calendar, always: true },
    { segment: "payments", label: "Payments", icon: CreditCard, show: permissions.canViewPayments },
    { segment: "settings", label: "Settings", icon: Settings, show: permissions.canManageSettings },
  ].filter((item) => item.always || item.show);

  return (
    <div className="-mx-4 overflow-x-auto md:-mx-6 lg:-mx-8">
      <nav
        className="flex min-w-max border-b border-border px-4 md:px-6 lg:px-8"
        aria-label="Event management sections"
        role="tablist"
      >
        {navItems.map((item) => {
          const href = `/dashboard/events/${eventId}/${item.segment}`;
          const active =
            pathname === href || pathname.startsWith(`${href}/`);

          return (
            <Link
              key={item.segment}
              href={href}
              role="tab"
              aria-selected={active}
              className={cn(
                "flex items-center gap-1.5 border-b-2 px-3 py-3 text-sm font-medium whitespace-nowrap transition-colors",
                active
                  ? "border-blue-600 text-blue-700"
                  : "border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700"
              )}
            >
              <item.icon className="h-3.5 w-3.5" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
