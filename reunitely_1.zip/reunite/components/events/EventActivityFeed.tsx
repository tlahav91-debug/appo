import { db } from "@/lib/db";
import { Avatar } from "@/components/shared/Avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatRelativeTime } from "@/lib/utils";
import { EmptyState } from "@/components/shared/EmptyState";
import { Activity } from "lucide-react";

interface EventActivityFeedProps {
  eventId: string;
}

export async function EventActivityFeed({ eventId }: EventActivityFeedProps) {
  const logs = await db.auditLog.findMany({
    where: { eventId },
    include: {
      actor: { select: { name: true, avatarUrl: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 15,
  });

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-700">
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        {logs.length === 0 ? (
          <EmptyState
            icon={<Activity className="h-5 w-5" />}
            title="No activity yet"
            description="Activity will appear here as attendees join and interact."
            size="sm"
          />
        ) : (
          <div className="flex flex-col gap-3">
            {logs.map((log) => (
              <div key={log.id} className="flex items-start gap-2.5">
                <Avatar
                  name={log.actor?.name ?? "System"}
                  src={log.actor?.avatarUrl}
                  size="xs"
                  className="mt-0.5 shrink-0"
                />
                <div className="min-w-0">
                  <p className="text-xs text-slate-700">
                    <strong className="font-medium">
                      {log.actor?.name ?? "System"}
                    </strong>{" "}
                    {getActivityDescription(log.action)}
                  </p>
                  <p className="mt-0.5 text-[11px] text-slate-400">
                    {formatRelativeTime(log.createdAt)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function getActivityDescription(action: string): string {
  const descriptions: Record<string, string> = {
    RSVP_CREATED: "RSVP'd to this event",
    RSVP_UPDATED: "updated their RSVP",
    RSVP_CANCELLED: "cancelled their RSVP",
    MEMORY_APPROVED: "approved a memory",
    MEMORY_REJECTED: "rejected a memory",
    MEMORY_REPORTED: "reported a memory",
    BROADCAST_SENT: "sent a broadcast message",
    INVITE_SENT: "sent invitations",
    ATTENDEE_CHECKED_IN: "checked in an attendee",
    EVENT_PUBLISHED: "published the event",
    EVENT_UPDATED: "updated event details",
    PAYMENT_MANUALLY_MARKED: "marked a payment as paid",
    RESULTS_REVEALED: "revealed nomination results",
    NOMINATION_CREATED: "created a nomination",
    VOTE_CAST: "cast a vote",
    DATA_EXPORTED: "exported attendee data",
  };
  return descriptions[action] ?? action.toLowerCase().replace(/_/g, " ");
}
