import Link from "next/link";
import {
  Calendar,
  Users,
  ChevronRight,
  PenLine,
  CalendarDays,
  Clock,
  CheckCircle2,
} from "lucide-react";
import { requireAuth } from "@/lib/auth/session";
import { EventStatusBadge } from "@/components/shared/StatusBadge";
import { EmptyState } from "@/components/shared/EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { formatShortDate, pluralize } from "@/lib/utils";
import { db } from "@/lib/db";
import { cn } from "@/lib/utils";

// ─── Data fetcher ──────────────────────────────────────────────────────────

async function getOrganizerEvents(userId: string) {
  // Get all events where user is a committee member (not revoked)
  const committee = await db.committeeMember.findMany({
    where: { userId, revokedAt: null },
    select: { eventId: true, role: true },
    orderBy: { addedAt: "desc" },
  });

  const eventIds = committee.map((c) => c.eventId);
  if (eventIds.length === 0) return { published: [], drafts: [] };

  const events = await db.event.findMany({
    where: {
      id: { in: eventIds },
      status: { not: "ARCHIVED" },
    },
    select: {
      id: true,
      title: true,
      slug: true,
      status: true,
      startAt: true,
      schoolName: true,
      graduationYear: true,
      coverImageUrl: true,
      updatedAt: true,
      _count: {
        select: {
          rsvps: { where: { status: "CONFIRMED" } },
        },
      },
    },
    orderBy: [{ status: "asc" }, { updatedAt: "desc" }],
  });

  const published = events.filter((e) => e.status !== "DRAFT");
  const drafts = events.filter((e) => e.status === "DRAFT");

  return { published, drafts };
}

// ─── Component ─────────────────────────────────────────────────────────────

export async function EventCardList() {
  const session = await requireAuth();
  const { published, drafts } = await getOrganizerEvents(session.user.id);

  const total = published.length + drafts.length;

  if (total === 0) {
    return (
      <EmptyState
        icon={<CalendarDays className="h-8 w-8" />}
        title="No events yet"
        description="Create your first reunion and invite your class. Takes about 5 minutes."
        action={{ label: "Create Your First Event", href: "/dashboard/events/new" }}
        size="lg"
      />
    );
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Draft events */}
      {drafts.length > 0 && (
        <section>
          <div className="mb-3 flex items-center gap-2">
            <PenLine className="h-4 w-4 text-slate-400" />
            <h2 className="text-sm font-semibold text-slate-600">
              Drafts ({drafts.length})
            </h2>
          </div>
          <div className="flex flex-col gap-2">
            {drafts.map((event) => (
              <DraftCard key={event.id} event={event} />
            ))}
          </div>
        </section>
      )}

      {/* Published / upcoming events */}
      {published.length > 0 && (
        <section>
          {drafts.length > 0 && (
            <div className="mb-3 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              <h2 className="text-sm font-semibold text-slate-600">
                Events ({published.length})
              </h2>
            </div>
          )}
          <div className="flex flex-col gap-3">
            {published.map((event) => (
              <PublishedCard key={event.id} event={event} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

// ─── Draft card ─────────────────────────────────────────────────────────────

function DraftCard({
  event,
}: {
  event: {
    id: string;
    title: string;
    schoolName: string;
    graduationYear: number;
    updatedAt: Date;
    status: string;
  };
}) {
  return (
    <div className="flex items-center justify-between rounded-xl border border-dashed border-slate-300 bg-slate-50 px-5 py-4">
      <div className="flex flex-col gap-1 min-w-0">
        <p className="text-sm font-semibold text-slate-800 truncate">
          {event.title || "Untitled Reunion"}
        </p>
        <div className="flex items-center gap-3 text-xs text-slate-400">
          <span>{event.schoolName} · {event.graduationYear}</span>
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Edited {formatShortDate(event.updatedAt)}
          </span>
        </div>
      </div>
      <Button asChild size="sm" variant="outline" className="ml-4 shrink-0 gap-1.5">
        <Link href={`/dashboard/events/new?draft=${event.id}`}>
          <PenLine className="h-3.5 w-3.5" />
          Resume
        </Link>
      </Button>
    </div>
  );
}

// ─── Published card ─────────────────────────────────────────────────────────

function PublishedCard({
  event,
}: {
  event: {
    id: string;
    title: string;
    slug: string;
    status: string;
    startAt: Date;
    schoolName: string;
    graduationYear: number;
    coverImageUrl: string | null;
    _count: { rsvps: number };
  };
}) {
  const isUpcoming = event.startAt > new Date();
  const isPast = !isUpcoming;

  return (
    <Link
      href={`/dashboard/events/${event.id}/overview`}
      className={cn(
        "group flex items-center gap-4 rounded-xl border bg-card px-5 py-4 shadow-card transition-all hover:shadow-card-hover",
        isPast ? "border-slate-200 opacity-75 hover:opacity-100" : "border-border"
      )}
    >
      {/* Cover thumbnail */}
      <div className="h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-blue-100">
        {event.coverImageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={event.coverImageUrl}
            alt=""
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center">
            <span className="font-display text-lg font-bold text-blue-300">
              {event.graduationYear.toString().slice(-2)}
            </span>
          </div>
        )}
      </div>

      {/* Details */}
      <div className="flex flex-col gap-1.5 flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <EventStatusBadge status={event.status} />
          <span className="text-xs text-slate-400 truncate">
            {event.schoolName} · {event.graduationYear}
          </span>
        </div>
        <h2 className="font-semibold text-slate-900 truncate group-hover:text-blue-700 transition-colors">
          {event.title}
        </h2>
        <div className="flex items-center gap-4 text-xs text-slate-500">
          <span className="flex items-center gap-1">
            <Calendar className="h-3.5 w-3.5" />
            {formatShortDate(event.startAt)}
          </span>
          <span className="flex items-center gap-1">
            <Users className="h-3.5 w-3.5" />
            {pluralize(event._count.rsvps, "confirmed")}
          </span>
        </div>
      </div>

      <ChevronRight className="h-5 w-5 shrink-0 text-slate-300 group-hover:text-blue-500 transition-colors" />
    </Link>
  );
}

// ─── Skeleton ──────────────────────────────────────────────────────────────

export function EventCardListSkeleton() {
  return (
    <div className="flex flex-col gap-3">
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 rounded-xl border border-border bg-card p-5">
          <Skeleton className="h-14 w-14 rounded-lg shrink-0" />
          <div className="flex flex-col gap-2 flex-1">
            <div className="flex gap-2">
              <Skeleton className="h-5 w-20 rounded-full" />
              <Skeleton className="h-5 w-32" />
            </div>
            <Skeleton className="h-5 w-64" />
            <div className="flex gap-4">
              <Skeleton className="h-4 w-28" />
              <Skeleton className="h-4 w-24" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
