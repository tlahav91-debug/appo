"use client";

import { Users, UserCheck, DollarSign, TrendingUp } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import type { EventStats } from "@/lib/services/event.service";

interface EventStatsCardsProps {
  eventId: string;
  initialData: EventStats;
}

export function EventStatsCards({ initialData }: EventStatsCardsProps) {
  const stats = initialData;

  const cards = [
    {
      label: "Total RSVPs",
      value: stats.totalRsvps,
      sub: `${stats.pendingCount} pending`,
      icon: Users,
      color: "text-blue-500",
      bg: "bg-blue-50",
    },
    {
      label: "Confirmed",
      value: stats.confirmedCount,
      sub: `${stats.checkedInCount} checked in`,
      icon: UserCheck,
      color: "text-emerald-500",
      bg: "bg-emerald-50",
    },
    {
      label: "Revenue",
      value: formatCurrency(stats.totalRevenueCents),
      sub: "from ticket sales",
      icon: DollarSign,
      color: "text-blue-500",
      bg: "bg-blue-50",
    },
    {
      label: "Page Views",
      value: stats.pageViews > 0 ? stats.pageViews.toLocaleString() : "—",
      sub: "event page visits",
      icon: TrendingUp,
      color: "text-violet-500",
      bg: "bg-violet-50",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      {cards.map((card) => (
        <div
          key={card.label}
          className="flex flex-col gap-3 rounded-xl border border-border bg-card p-5 shadow-card"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wider text-slate-500">
              {card.label}
            </span>
            <div className={`rounded-lg p-1.5 ${card.bg}`}>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </div>
          </div>
          <div>
            <p className="font-display text-2xl font-bold text-slate-900">
              {card.value}
            </p>
            <p className="mt-0.5 text-xs text-slate-400">{card.sub}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
