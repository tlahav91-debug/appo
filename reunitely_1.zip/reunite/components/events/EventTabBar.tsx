"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";

interface Tab {
  id: string;
  label: string;
  href: string;
}

interface EventTabBarProps {
  slug: string;
  activeTab: string;
  hasNominations?: boolean;
  hasSchedule?: boolean;
}

export function EventTabBar({
  slug,
  activeTab,
  hasNominations,
  hasSchedule,
}: EventTabBarProps) {
  const tabs: Tab[] = [
    { id: "about", label: "About", href: `/events/${slug}?tab=about` },
    { id: "attendees", label: "Attendees", href: `/events/${slug}?tab=attendees` },
    { id: "memories", label: "Memories", href: `/events/${slug}?tab=memories` },
    ...(hasNominations
      ? [{ id: "nominations", label: "Nominations", href: `/events/${slug}?tab=nominations` }]
      : []),
    ...(hasSchedule
      ? [{ id: "schedule", label: "Schedule", href: `/events/${slug}?tab=schedule` }]
      : []),
  ];

  return (
    <nav
      className="flex overflow-x-auto"
      role="tablist"
      aria-label="Event sections"
    >
      {tabs.map((tab) => (
        <Link
          key={tab.id}
          href={tab.href}
          role="tab"
          aria-selected={activeTab === tab.id}
          className={cn(
            "flex-shrink-0 border-b-2 px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap",
            activeTab === tab.id
              ? "border-blue-600 text-blue-700"
              : "border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700"
          )}
          scroll={false}
        >
          {tab.label}
        </Link>
      ))}
    </nav>
  );
}
