import { db } from "@/lib/db";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatShortDate } from "@/lib/utils";

interface EventRsvpChartProps {
  eventId: string;
}

// Server component — fetches RSVP trend data
// In production, render a client Chart.js or Recharts component
// For MVP: render a simple ASCII-style bar list as a server component

export async function EventRsvpChart({ eventId }: EventRsvpChartProps) {
  // Get last 14 days of RSVP activity
  const fourteenDaysAgo = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);

  const memberships = await db.rSVP.findMany({
    where: {
      eventId,
      submittedAt: { gte: fourteenDaysAgo },
    },
    select: { submittedAt: true, status: true },
    orderBy: { submittedAt: "asc" },
  });

  // Group by day
  const byDay: Record<string, number> = {};
  const today = new Date();
  for (let i = 13; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    byDay[formatShortDate(d)] = 0;
  }

  memberships.forEach((m) => {
    const day = formatShortDate(m.submittedAt);
    if (byDay[day] !== undefined) {
      byDay[day]!++;
    }
  });

  const entries = Object.entries(byDay);
  const max = Math.max(...entries.map(([, v]) => v), 1);

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-700">
          RSVPs — Last 14 Days
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div
          className="flex items-end gap-1 h-24"
          role="img"
          aria-label="RSVP trend over last 14 days"
        >
          {entries.map(([date, count]) => (
            <div
              key={date}
              className="flex flex-1 flex-col items-center gap-1"
              title={`${date}: ${count} RSVPs`}
            >
              <div
                className="w-full rounded-t-sm bg-blue-400 transition-all"
                style={{
                  height: `${Math.max((count / max) * 80, count > 0 ? 4 : 0)}px`,
                }}
              />
            </div>
          ))}
        </div>
        <div className="mt-2 flex justify-between text-[10px] text-slate-400">
          <span>{entries[0]?.[0]}</span>
          <span>{entries[entries.length - 1]?.[0]}</span>
        </div>
        {memberships.length === 0 && (
          <p className="mt-2 text-center text-xs text-slate-400">
            No RSVPs in the last 14 days
          </p>
        )}
      </CardContent>
    </Card>
  );
}
