"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Send, Mail, MessageSquare, Clock, CheckCircle, XCircle, Plus, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/shared/EmptyState";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { formatRelativeTime, cn } from "@/lib/utils";

// ─── BroadcastList ────────────────────────────────────────────────────────────

async function fetchBroadcasts(eventId: string) {
  const res = await fetch(`/api/events/${eventId}/broadcasts`);
  if (!res.ok) throw new Error("Failed to load broadcasts");
  return (await res.json()).data ?? [];
}

interface Broadcast {
  id: string;
  subject: string | null;
  channel: "EMAIL" | "SMS" | "WHATSAPP";
  status: "DRAFT" | "SENDING" | "SENT" | "FAILED";
  sentAt: string | null;
  recipientCount: number;
  createdAt: string;
}

export function BroadcastList({ eventId }: { eventId: string }) {
  const { data: broadcasts = [], isLoading } = useQuery<Broadcast[]>({
    queryKey: ["broadcasts", eventId],
    queryFn: () => fetchBroadcasts(eventId),
  });

  const channelIcon = (channel: string) => {
    switch (channel) {
      case "SMS": return <MessageSquare className="h-4 w-4 text-blue-500" />;
      case "WHATSAPP": return <MessageSquare className="h-4 w-4 text-emerald-500" />;
      default: return <Mail className="h-4 w-4 text-slate-500" />;
    }
  };

  const statusIcon = (status: string) => {
    switch (status) {
      case "SENT": return <CheckCircle className="h-4 w-4 text-emerald-500" />;
      case "FAILED": return <XCircle className="h-4 w-4 text-red-500" />;
      case "SENDING": return <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />;
      default: return <Clock className="h-4 w-4 text-slate-400" />;
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1,2,3].map(i => <div key={i} className="h-16 rounded-xl bg-slate-100 animate-pulse" />)}
      </div>
    );
  }

  if (broadcasts.length === 0) {
    return (
      <EmptyState
        icon={<Send className="h-8 w-8" />}
        title="No broadcasts yet"
        description="Send your first message to keep attendees in the loop."
        size="lg"
      />
    );
  }

  return (
    <div className="flex flex-col gap-2">
      {broadcasts.map((b) => (
        <div
          key={b.id}
          className="flex items-center gap-4 rounded-xl border border-border bg-card px-4 py-3.5"
        >
          {channelIcon(b.channel)}
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-900 truncate">
              {b.subject ?? `${b.channel} broadcast`}
            </p>
            <p className="text-xs text-slate-400 mt-0.5">
              {b.sentAt
                ? `Sent ${formatRelativeTime(new Date(b.sentAt))} · ${b.recipientCount} recipients`
                : `Created ${formatRelativeTime(new Date(b.createdAt))}`}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {statusIcon(b.status)}
            <span className={cn(
              "text-xs font-medium",
              b.status === "SENT" ? "text-emerald-600" :
              b.status === "FAILED" ? "text-red-500" :
              b.status === "SENDING" ? "text-blue-600" : "text-slate-400"
            )}>
              {b.status.charAt(0) + b.status.slice(1).toLowerCase()}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── NewBroadcastButton ───────────────────────────────────────────────────────

export function NewBroadcastButton({ eventId }: { eventId: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button onClick={() => setOpen(true)} size="sm" className="gap-2">
        <Plus className="h-4 w-4" />
        New Broadcast
      </Button>
      <BroadcastComposer eventId={eventId} open={open} onClose={() => setOpen(false)} />
    </>
  );
}

// ─── BroadcastComposer dialog ─────────────────────────────────────────────────

function BroadcastComposer({
  eventId,
  open,
  onClose,
}: {
  eventId: string;
  open: boolean;
  onClose: () => void;
}) {
  const queryClient = useQueryClient();
  const [channel, setChannel] = useState<"EMAIL" | "SMS" | "WHATSAPP">("EMAIL");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [isSending, setIsSending] = useState(false);

  const channels = [
    { value: "EMAIL" as const, label: "Email", icon: Mail },
    { value: "SMS" as const, label: "SMS", icon: MessageSquare },
    { value: "WHATSAPP" as const, label: "WhatsApp", icon: MessageSquare },
  ];

  async function handleSend() {
    if (!body.trim()) {
      toast.error("Message body is required");
      return;
    }
    setIsSending(true);
    try {
      // Create broadcast
      const createRes = await fetch(`/api/events/${eventId}/broadcasts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: channel === "EMAIL" ? subject : undefined,
          body: { type: "doc", content: [{ type: "paragraph", content: [{ type: "text", text: body }] }] },
          channel,
          audienceFilter: { statuses: ["CONFIRMED"] },
        }),
      });
      const createJson = await createRes.json();
      if (!createRes.ok) throw new Error(createJson.error?.message ?? "Failed");

      // Send it
      const sendRes = await fetch(`/api/broadcasts/${createJson.data.id}/send`, {
        method: "POST",
      });
      if (!sendRes.ok) throw new Error("Send failed");

      toast.success(`Broadcast sent to confirmed attendees`);
      queryClient.invalidateQueries({ queryKey: ["broadcasts", eventId] });
      onClose();
      setSubject("");
      setBody("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to send broadcast");
    } finally {
      setIsSending(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>New Broadcast</DialogTitle>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-2">
          {/* Channel selector */}
          <div className="flex flex-col gap-1.5">
            <Label>Channel</Label>
            <div className="flex gap-2">
              {channels.map((c) => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => setChannel(c.value)}
                  className={cn(
                    "flex flex-1 items-center justify-center gap-1.5 rounded-lg border py-2 text-sm font-medium transition-colors",
                    channel === c.value
                      ? "border-blue-600 bg-blue-50 text-blue-700"
                      : "border-border text-slate-600 hover:bg-slate-50"
                  )}
                >
                  <c.icon className="h-3.5 w-3.5" />
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Subject (email only) */}
          {channel === "EMAIL" && (
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="broadcast-subject">Subject line</Label>
              <Input
                id="broadcast-subject"
                placeholder="e.g. Reminder: Reunion is this weekend!"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
              />
            </div>
          )}

          {/* Body */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="broadcast-body">Message</Label>
            <Textarea
              id="broadcast-body"
              placeholder={
                channel === "EMAIL"
                  ? "Write your message to attendees…"
                  : channel === "SMS"
                  ? "SMS — keep it under 160 characters…"
                  : "WhatsApp message (uses pre-approved template format)…"
              }
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={5}
              className="resize-none"
            />
            {channel === "SMS" && (
              <p className={cn(
                "text-xs",
                body.length > 160 ? "text-red-500" : "text-slate-400"
              )}>
                {body.length}/160 characters
                {body.length > 160 && " — will be split into multiple SMS"}
              </p>
            )}
          </div>

          {/* Consent notice */}
          <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-800">
            This will be sent to <strong>confirmed attendees</strong> who have consented
            to receive {channel.toLowerCase()} communications. Consent is always respected.
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <Button variant="ghost" onClick={onClose} disabled={isSending}>
              Cancel
            </Button>
            <Button onClick={handleSend} disabled={isSending || !body.trim()} className="gap-2">
              {isSending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Sending…
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  Send Broadcast
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
