"use client";

import { useState, useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Send, Loader2, Mail, MessageSquare } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const broadcastSchema = z.object({
  subject: z.string().min(1, "Subject is required").max(200),
  body: z.string().min(1, "Message body is required").max(4000),
  channel: z.enum(["EMAIL", "SMS", "WHATSAPP"]),
  audienceStatuses: z
    .array(z.string())
    .min(1, "Select at least one audience group"),
});

type BroadcastFormData = z.infer<typeof broadcastSchema>;

const CHANNEL_OPTIONS = [
  { value: "EMAIL" as const, label: "Email", icon: Mail, description: "Sent to all consenting attendees" },
  { value: "SMS" as const, label: "SMS", icon: MessageSquare, description: "Only those who opted in to SMS" },
] as const;

const AUDIENCE_OPTIONS = [
  { value: "CONFIRMED", label: "Confirmed attendees" },
  { value: "PENDING", label: "Maybe / undecided" },
  { value: "WAITLISTED", label: "Waitlisted" },
] as const;

async function createBroadcast(eventId: string, data: BroadcastFormData) {
  const res = await fetch(`/api/events/${eventId}/broadcasts`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      subject: data.subject,
      body: { type: "doc", content: [{ type: "paragraph", content: [{ type: "text", text: data.body }] }] },
      channel: data.channel,
      audienceFilter: { statuses: data.audienceStatuses },
    }),
  });
  if (!res.ok) throw new Error("Failed to create broadcast");
  return res.json();
}

export function NewBroadcastButton({ eventId }: { eventId: string }) {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();

  const form = useForm<BroadcastFormData>({
    resolver: zodResolver(broadcastSchema),
    defaultValues: {
      subject: "",
      body: "",
      channel: "EMAIL",
      audienceStatuses: ["CONFIRMED"],
    },
  });

  function handleClose() {
    setOpen(false);
    form.reset();
  }

  function handleSubmit(data: BroadcastFormData) {
    startTransition(async () => {
      try {
        await createBroadcast(eventId, data);
        toast.success("Message sent to attendees");
        handleClose();
      } catch {
        toast.error("Failed to send message. Please try again.");
      }
    });
  }

  const channel = form.watch("channel");
  const audienceStatuses = form.watch("audienceStatuses");

  return (
    <>
      <Button onClick={() => setOpen(true)} className="gap-2">
        <Send className="h-4 w-4" />
        New Message
      </Button>

      <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="h-4 w-4 text-blue-500" />
              Send Message to Attendees
            </DialogTitle>
            <DialogDescription>
              Send an email or SMS to your attendees. Messages are sent
              immediately to all selected groups.
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <div className="flex flex-col gap-4 py-2">
              {/* Channel */}
              <FormField
                control={form.control}
                name="channel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Channel</FormLabel>
                    <div className="flex gap-2">
                      {CHANNEL_OPTIONS.map((opt) => (
                        <button
                          key={opt.value}
                          type="button"
                          onClick={() => field.onChange(opt.value)}
                          className={cn(
                            "flex-1 flex items-center gap-2 rounded-lg border-2 p-3 text-sm transition-all text-left",
                            field.value === opt.value
                              ? "border-blue-600 bg-blue-50 text-blue-800"
                              : "border-border text-slate-600 hover:border-blue-300"
                          )}
                        >
                          <opt.icon className="h-4 w-4 shrink-0" />
                          <div>
                            <p className="font-medium">{opt.label}</p>
                            <p className="text-xs text-slate-500 mt-0.5">{opt.description}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  </FormItem>
                )}
              />

              {/* Audience */}
              <FormField
                control={form.control}
                name="audienceStatuses"
                render={() => (
                  <FormItem>
                    <FormLabel className="text-sm">Send to</FormLabel>
                    <div className="flex flex-wrap gap-2">
                      {AUDIENCE_OPTIONS.map((opt) => {
                        const selected = audienceStatuses.includes(opt.value);
                        return (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() => {
                              const current = form.getValues("audienceStatuses");
                              form.setValue(
                                "audienceStatuses",
                                selected
                                  ? current.filter((s) => s !== opt.value)
                                  : [...current, opt.value]
                              );
                            }}
                            className={cn(
                              "rounded-full border px-3 py-1.5 text-sm font-medium transition-all",
                              selected
                                ? "border-blue-600 bg-blue-50 text-blue-700"
                                : "border-border text-slate-600 hover:border-blue-300"
                            )}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Subject — only for email */}
              {channel === "EMAIL" && (
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm">Subject line</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Important update about your reunion…"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {/* Body */}
              <FormField
                control={form.control}
                name="body"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Message</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder={
                          channel === "SMS"
                            ? "Keep it brief — SMS messages are limited to 160 characters"
                            : "Write your message to attendees…"
                        }
                        rows={4}
                        className="resize-none"
                        maxLength={channel === "SMS" ? 160 : 4000}
                        {...field}
                      />
                    </FormControl>
                    <div className="flex justify-end">
                      <span className="text-xs text-slate-400">
                        {field.value.length}/{channel === "SMS" ? 160 : 4000}
                      </span>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2 pt-1">
                <Button type="button" variant="ghost" onClick={handleClose} disabled={isPending}>
                  Cancel
                </Button>
                <Button
                  type="button"
                  onClick={form.handleSubmit(handleSubmit)}
                  disabled={isPending}
                  className="gap-2"
                >
                  {isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                  Send Message
                </Button>
              </div>
            </div>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
}
