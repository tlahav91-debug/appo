"use client";

import { useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Mail, MessageSquare, Bell, Send, Clock, CheckCircle, XCircle,
  Loader2, Eye, TestTube, Users, ChevronDown, ChevronRight,
  Smartphone, BarChart2, Plus, Calendar, AlertTriangle,
  Megaphone, X, ArrowLeft,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/shared/EmptyState";
import { cn, formatRelativeTime, formatShortDate } from "@/lib/utils";
import { toast } from "sonner";

// ─── Types ────────────────────────────────────────────────────────────────────

type Channel = "EMAIL" | "SMS" | "WHATSAPP" | "IN_APP";
type BroadcastStatus =
  | "DRAFT" | "SCHEDULED" | "SENDING" | "SENT" | "PARTIALLY_SENT" | "FAILED" | "CANCELLED";

interface Broadcast {
  id: string;
  subject: string | null;
  channel: Channel;
  status: BroadcastStatus;
  sentAt: string | null;
  scheduledAt: string | null;
  recipientCount: number;
  deliveredCount: number;
  failedCount: number;
  openedCount: number;
  createdAt: string;
}

interface Template {
  id: string;
  name: string;
  type: string;
  channel: Channel;
  subject: string | null;
  body: unknown;
  isBuiltIn: boolean;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const CHANNEL_CONFIG: Record<Channel, { label: string; icon: React.ElementType; color: string; bg: string }> = {
  EMAIL: { label: "Email", icon: Mail, color: "text-blue-600", bg: "bg-blue-50" },
  SMS: { label: "SMS", icon: Smartphone, color: "text-emerald-600", bg: "bg-emerald-50" },
  WHATSAPP: { label: "WhatsApp", icon: MessageSquare, color: "text-green-600", bg: "bg-green-50" },
  IN_APP: { label: "In-app", icon: Bell, color: "text-blue-600", bg: "bg-blue-50" },
};

const STATUS_CONFIG: Record<BroadcastStatus, { label: string; icon: React.ElementType; color: string }> = {
  DRAFT: { label: "Draft", icon: Clock, color: "text-slate-500" },
  SCHEDULED: { label: "Scheduled", icon: Calendar, color: "text-blue-500" },
  SENDING: { label: "Sending", icon: Loader2, color: "text-blue-500" },
  SENT: { label: "Sent", icon: CheckCircle, color: "text-emerald-500" },
  PARTIALLY_SENT: { label: "Partial", icon: AlertTriangle, color: "text-orange-500" },
  FAILED: { label: "Failed", icon: XCircle, color: "text-red-500" },
  CANCELLED: { label: "Cancelled", icon: X, color: "text-slate-400" },
};

const AUDIENCE_OPTIONS = [
  { value: "CONFIRMED", label: "Confirmed", description: "RSVPd yes" },
  { value: "PENDING", label: "Maybe", description: "Haven't replied" },
  { value: "WAITLISTED", label: "Waitlisted", description: "On the waitlist" },
];

const QUIET_HOUR_OPTIONS = [
  { label: "Off", value: null },
  { label: "10 PM – 8 AM", startHour: 22, endHour: 8 },
  { label: "11 PM – 7 AM", startHour: 23, endHour: 7 },
  { label: "9 PM – 9 AM", startHour: 21, endHour: 9 },
];

const MESSAGE_TYPE_OPTIONS = [
  { value: "INVITE", label: "Invitation", emoji: "✉️" },
  { value: "REMINDER", label: "Reminder", emoji: "🔔" },
  { value: "RSVP_FOLLOWUP", label: "RSVP follow-up", emoji: "👋" },
  { value: "PAYMENT_REMINDER", label: "Payment reminder", emoji: "💳" },
  { value: "ANNOUNCEMENT", label: "Announcement", emoji: "📢" },
  { value: "THANK_YOU", label: "Thank you", emoji: "💛" },
];

// ─── Fetchers ─────────────────────────────────────────────────────────────────

async function fetchBroadcasts(eventId: string): Promise<Broadcast[]> {
  const res = await fetch(`/api/events/${eventId}/broadcasts`);
  if (!res.ok) throw new Error("Failed to load");
  return (await res.json()).data ?? [];
}

async function fetchTemplates(eventId: string): Promise<Template[]> {
  const res = await fetch(`/api/events/${eventId}/message-templates`);
  if (!res.ok) return [];
  return (await res.json()).data ?? [];
}

async function createBroadcast(eventId: string, data: unknown): Promise<Broadcast> {
  const res = await fetch(`/api/events/${eventId}/broadcasts`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message ?? "Failed to create");
  }
  return (await res.json()).data;
}

async function sendBroadcast(id: string): Promise<void> {
  const res = await fetch(`/api/broadcasts/${id}/send`, { method: "POST" });
  if (!res.ok) throw new Error("Failed to send");
}

async function testSend(broadcastId: string, email: string): Promise<void> {
  const res = await fetch(`/api/broadcasts/${broadcastId}/test-send`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ recipientEmail: email }),
  });
  if (!res.ok) throw new Error("Test send failed");
}

// ─── Main component ───────────────────────────────────────────────────────────

export function MessagingCenter({ eventId }: { eventId: string }) {
  const [view, setView] = useState<"list" | "compose" | "stats">("list");
  const [selectedBroadcast, setSelectedBroadcast] = useState<Broadcast | null>(null);
  const queryClient = useQueryClient();

  const { data: broadcasts = [], isLoading } = useQuery({
    queryKey: ["broadcasts", eventId],
    queryFn: () => fetchBroadcasts(eventId),
    refetchInterval: 30_000,
  });

  const sendMutation = useMutation({
    mutationFn: sendBroadcast,
    onSuccess: () => {
      toast.success("Broadcast sent!");
      queryClient.invalidateQueries({ queryKey: ["broadcasts", eventId] });
      setView("list");
    },
    onError: (e) => toast.error(e.message),
  });

  if (view === "compose") {
    return (
      <ComposeView
        eventId={eventId}
        onBack={() => setView("list")}
        onSent={() => {
          queryClient.invalidateQueries({ queryKey: ["broadcasts", eventId] });
          setView("list");
        }}
      />
    );
  }

  if (view === "stats" && selectedBroadcast) {
    return (
      <StatsView
        broadcast={selectedBroadcast}
        onBack={() => { setSelectedBroadcast(null); setView("list"); }}
      />
    );
  }

  return (
    <div className="flex flex-col gap-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Messaging Center</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            {broadcasts.length} broadcast{broadcasts.length !== 1 ? "s" : ""}
          </p>
        </div>
        <Button
          onClick={() => setView("compose")}
          className="gap-2 bg-blue-500 hover:bg-blue-700"
          size="sm"
        >
          <Plus className="h-4 w-4" />
          New message
        </Button>
      </div>

      {/* Channel filter chips */}
      <ChannelOverview broadcasts={broadcasts} />

      {/* Broadcasts list */}
      {isLoading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-20 animate-pulse rounded-xl bg-slate-100" />
          ))}
        </div>
      ) : broadcasts.length === 0 ? (
        <EmptyState
          icon={<Megaphone className="h-8 w-8" />}
          title="No messages sent yet"
          description="Send your first broadcast to keep attendees informed."
          action={{ label: "Create message", href: "#" }}
          size="lg"
        />
      ) : (
        <div className="flex flex-col gap-2">
          {broadcasts.map((b) => (
            <BroadcastRow
              key={b.id}
              broadcast={b}
              onSend={() => sendMutation.mutate(b.id)}
              isSending={sendMutation.isPending && sendMutation.variables === b.id}
              onViewStats={() => { setSelectedBroadcast(b); setView("stats"); }}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Channel overview cards ───────────────────────────────────────────────────
function ChannelOverview({ broadcasts }: { broadcasts: Broadcast[] }) {
  const sent = broadcasts.filter((b) => b.status === "SENT" || b.status === "PARTIALLY_SENT");
  const byChannel = sent.reduce((acc, b) => {
    acc[b.channel] = (acc[b.channel] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {(["EMAIL", "SMS", "WHATSAPP", "IN_APP"] as Channel[]).map((ch) => {
        const cfg = CHANNEL_CONFIG[ch];
        const Icon = cfg.icon;
        const count = byChannel[ch] ?? 0;
        return (
          <div key={ch} className={cn("flex items-center gap-3 rounded-xl border border-border p-4", cfg.bg)}>
            <Icon className={cn("h-5 w-5 shrink-0", cfg.color)} />
            <div>
              <p className="text-xs text-slate-500">{cfg.label}</p>
              <p className={cn("text-lg font-bold", cfg.color)}>{count}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Broadcast row ────────────────────────────────────────────────────────────
function BroadcastRow({
  broadcast: b,
  onSend,
  isSending,
  onViewStats,
}: {
  broadcast: Broadcast;
  onSend: () => void;
  isSending: boolean;
  onViewStats: () => void;
}) {
  const chCfg = CHANNEL_CONFIG[b.channel];
  const stCfg = STATUS_CONFIG[b.status];
  const ChIcon = chCfg.icon;
  const StIcon = stCfg.icon;

  return (
    <div className="flex items-start gap-4 rounded-xl border border-border bg-card px-4 py-3.5 hover:shadow-sm transition-shadow">
      {/* Channel icon */}
      <div className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-lg mt-0.5", chCfg.bg)}>
        <ChIcon className={cn("h-4 w-4", chCfg.color)} />
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <p className="text-sm font-semibold text-slate-900 truncate">
            {b.subject ?? `${chCfg.label} broadcast`}
          </p>
          <div className={cn("flex items-center gap-1 shrink-0 text-xs font-medium", stCfg.color)}>
            <StIcon className={cn("h-3.5 w-3.5", b.status === "SENDING" && "animate-spin")} />
            {stCfg.label}
          </div>
        </div>
        <div className="mt-1 flex items-center gap-3 text-xs text-slate-400">
          {b.sentAt && <span>{formatRelativeTime(new Date(b.sentAt))}</span>}
          {b.scheduledAt && !b.sentAt && (
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {formatShortDate(new Date(b.scheduledAt))}
            </span>
          )}
          {b.recipientCount > 0 && (
            <span className="flex items-center gap-1">
              <Users className="h-3 w-3" />
              {b.recipientCount.toLocaleString()} recipients
            </span>
          )}
          {b.status === "SENT" && b.deliveredCount > 0 && (
            <span className="text-emerald-500">
              {Math.round((b.deliveredCount / b.recipientCount) * 100)}% delivered
            </span>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 shrink-0">
        {(b.status === "SENT" || b.status === "PARTIALLY_SENT") && (
          <Button variant="ghost" size="sm" onClick={onViewStats} className="gap-1.5 text-xs h-8">
            <BarChart2 className="h-3.5 w-3.5" />
            Stats
          </Button>
        )}
        {b.status === "DRAFT" && (
          <Button
            size="sm"
            onClick={onSend}
            disabled={isSending}
            className="gap-1.5 h-8 bg-blue-500 hover:bg-blue-700 text-xs"
          >
            {isSending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
            Send
          </Button>
        )}
      </div>
    </div>
  );
}

// ─── Compose view ─────────────────────────────────────────────────────────────
function ComposeView({
  eventId,
  onBack,
  onSent,
}: {
  eventId: string;
  onBack: () => void;
  onSent: () => void;
}) {
  const [channel, setChannel] = useState<Channel>("EMAIL");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [selectedStatuses, setSelectedStatuses] = useState(["CONFIRMED"]);
  const [scheduledAt, setScheduledAt] = useState("");
  const [quietHoursPreset, setQuietHoursPreset] = useState<number | null>(0);
  const [showPreview, setShowPreview] = useState(false);
  const [testEmail, setTestEmail] = useState("");
  const [showTestSend, setShowTestSend] = useState(false);
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [step, setStep] = useState<"compose" | "review">("compose");
  const queryClient = useQueryClient();

  const { data: templates = [] } = useQuery({
    queryKey: ["templates", eventId, channel],
    queryFn: () => fetchTemplates(eventId),
  });

  const filteredTemplates = templates.filter((t) => t.channel === channel);

  const createMutation = useMutation({
    mutationFn: (sendNow: boolean) => {
      const preset = QUIET_HOUR_OPTIONS[quietHoursPreset ?? 0];
      const body_json = { type: "doc", content: [{ type: "paragraph", content: [{ type: "text", text: body }] }] };
      return createBroadcast(eventId, {
        subject: channel === "EMAIL" ? subject : undefined,
        body: body_json,
        channel,
        audienceFilter: { statuses: selectedStatuses },
        scheduledAt: scheduledAt || undefined,
        quietHoursStart: preset && "startHour" in preset ? preset.startHour : undefined,
        quietHoursEnd: preset && "endHour" in preset ? preset.endHour : undefined,
      });
    },
    onSuccess: async (broadcast, sendNow) => {
      setCreatedId(broadcast.id);
      queryClient.invalidateQueries({ queryKey: ["broadcasts", eventId] });
      if (sendNow && !scheduledAt) {
        // Immediately send
        await sendBroadcast(broadcast.id);
        toast.success("Broadcast sent! 🎉");
        onSent();
      } else if (scheduledAt) {
        toast.success(`Broadcast scheduled for ${formatShortDate(new Date(scheduledAt))}`);
        onSent();
      } else {
        toast.success("Saved as draft");
        onSent();
      }
    },
    onError: (e) => toast.error(e.message),
  });

  const testMutation = useMutation({
    mutationFn: async () => {
      if (!createdId) {
        // Create draft first
        const preset = QUIET_HOUR_OPTIONS[quietHoursPreset ?? 0];
        const body_json = { type: "doc", content: [{ type: "paragraph", content: [{ type: "text", text: body }] }] };
        const draft = await createBroadcast(eventId, {
          subject: channel === "EMAIL" ? subject : undefined,
          body: body_json,
          channel,
          audienceFilter: { statuses: selectedStatuses },
        });
        setCreatedId(draft.id);
        await testSend(draft.id, testEmail);
      } else {
        await testSend(createdId, testEmail);
      }
    },
    onSuccess: () => {
      toast.success(`Test email sent to ${testEmail}`);
      setShowTestSend(false);
    },
    onError: (e) => toast.error(e.message),
  });

  function applyTemplate(template: Template) {
    if (template.subject) setSubject(template.subject);
    const bodyContent = typeof template.body === "string"
      ? template.body
      : (template.body as { content?: string })?.content ?? "";
    setBody(bodyContent);
  }

  const canSubmit = body.trim() && (channel !== "EMAIL" || subject.trim());

  return (
    <div className="flex flex-col gap-5">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="text-slate-400 hover:text-slate-600 transition-colors">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <h2 className="text-lg font-bold text-slate-900">Compose message</h2>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        {/* Main compose */}
        <div className="flex flex-col gap-5 lg:col-span-2">
          {/* Channel selector */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Channel
            </label>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {(["EMAIL", "SMS", "IN_APP", "WHATSAPP"] as Channel[]).map((ch) => {
                const cfg = CHANNEL_CONFIG[ch];
                const Icon = cfg.icon;
                const active = channel === ch;
                return (
                  <button
                    key={ch}
                    type="button"
                    onClick={() => setChannel(ch)}
                    className={cn(
                      "flex flex-col items-center gap-1.5 rounded-xl border p-3 text-sm transition-all",
                      active
                        ? `border-blue-400 ${cfg.bg} font-semibold ${cfg.color}`
                        : "border-border text-slate-600 hover:border-blue-200"
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    <span className="text-xs">{cfg.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Template picker */}
          {filteredTemplates.length > 0 && (
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Start from a template
              </label>
              <div className="grid gap-2 sm:grid-cols-2">
                {filteredTemplates.slice(0, 6).map((t) => {
                  const type = MESSAGE_TYPE_OPTIONS.find((o) => o.value === t.type);
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => applyTemplate(t)}
                      className="flex items-center gap-2.5 rounded-xl border border-border bg-card px-3 py-2.5 text-left text-sm hover:border-blue-300 hover:bg-blue-50 transition-all"
                    >
                      <span className="text-lg" aria-hidden>{type?.emoji ?? "✉️"}</span>
                      <div className="min-w-0">
                        <p className="font-medium text-slate-900 truncate">{t.name}</p>
                        {t.isBuiltIn && (
                          <p className="text-[10px] text-slate-400">Built-in template</p>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Subject (email only) */}
          {channel === "EMAIL" && (
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Subject line *
              </label>
              <Input
                placeholder="e.g. You're confirmed for the reunion! 🎓"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                maxLength={200}
                className="text-sm"
              />
              <p className="text-xs text-slate-400 text-right">{subject.length}/200</p>
            </div>
          )}

          {/* Body */}
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Message *
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowPreview((v) => !v)}
                  className={cn(
                    "flex items-center gap-1 text-xs transition-colors",
                    showPreview ? "text-blue-600" : "text-slate-400 hover:text-slate-600"
                  )}
                >
                  <Eye className="h-3.5 w-3.5" />
                  {showPreview ? "Edit" : "Preview"}
                </button>
              </div>
            </div>
            {showPreview ? (
              <div className="rounded-xl border border-border bg-white p-4 min-h-[180px] text-sm whitespace-pre-wrap text-slate-700 leading-relaxed">
                {body || <span className="text-slate-300 italic">Nothing to preview yet…</span>}
              </div>
            ) : (
              <>
                <Textarea
                  placeholder={
                    channel === "EMAIL"
                      ? "Hi {{recipientName}},\n\nWrite your message here…\n\n{{organizerName}}"
                      : "SMS: Keep it under 160 characters for best delivery. Reply STOP to opt out."
                  }
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  maxLength={channel === "EMAIL" ? 4000 : 1600}
                  rows={8}
                  className="resize-none text-sm font-mono"
                />
                <div className="flex items-center justify-between">
                  <p className="text-[10px] text-slate-400">
                    Variables: {"{{recipientName}}"} {"{{eventTitle}}"} {"{{eventDate}}"} {"{{eventUrl}}"}
                  </p>
                  <p className="text-xs text-slate-400">{body.length}/{channel === "EMAIL" ? "4000" : "1600"}</p>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Sidebar: audience + settings */}
        <div className="flex flex-col gap-5">
          {/* Audience */}
          <div className="rounded-xl border border-border bg-card p-4 flex flex-col gap-3">
            <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <Users className="h-4 w-4 text-slate-400" />
              Audience
            </h3>
            <div className="flex flex-col gap-2">
              {AUDIENCE_OPTIONS.map((opt) => (
                <label key={opt.value} className="flex items-start gap-2.5 cursor-pointer group">
                  <input
                    type="checkbox"
                    checked={selectedStatuses.includes(opt.value)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedStatuses((s) => [...s, opt.value]);
                      } else {
                        setSelectedStatuses((s) => s.filter((v) => v !== opt.value));
                      }
                    }}
                    className="mt-0.5 h-4 w-4 rounded border-border text-blue-500 focus:ring-blue-500"
                  />
                  <div>
                    <p className="text-sm font-medium text-slate-900">{opt.label}</p>
                    <p className="text-xs text-slate-400">{opt.description}</p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Scheduling */}
          <div className="rounded-xl border border-border bg-card p-4 flex flex-col gap-3">
            <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <Clock className="h-4 w-4 text-slate-400" />
              Timing
            </h3>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-slate-500">Schedule for later (optional)</label>
              <Input
                type="datetime-local"
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
                min={new Date().toISOString().slice(0, 16)}
                className="text-sm"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-slate-500">Quiet hours</label>
              <select
                value={String(quietHoursPreset)}
                onChange={(e) => setQuietHoursPreset(Number(e.target.value))}
                className="h-9 w-full rounded-lg border border-border bg-background px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {QUIET_HOUR_OPTIONS.map((opt, i) => (
                  <option key={i} value={i}>{opt.label}</option>
                ))}
              </select>
              <p className="text-[10px] text-slate-400">
                Messages won't send during quiet hours
              </p>
            </div>
          </div>

          {/* Test send */}
          <div className="rounded-xl border border-border bg-card p-4 flex flex-col gap-3">
            <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <TestTube className="h-4 w-4 text-slate-400" />
              Test send
            </h3>
            {showTestSend ? (
              <div className="flex flex-col gap-2">
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={testEmail}
                  onChange={(e) => setTestEmail(e.target.value)}
                  className="text-sm"
                />
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => setShowTestSend(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    size="sm"
                    className="flex-1 bg-blue-500 hover:bg-blue-700"
                    onClick={() => testMutation.mutate()}
                    disabled={!testEmail || testMutation.isPending}
                  >
                    {testMutation.isPending ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : "Send test"}
                  </Button>
                </div>
              </div>
            ) : (
              <Button
                variant="outline"
                size="sm"
                className="gap-2 w-full text-xs"
                onClick={() => setShowTestSend(true)}
                disabled={!canSubmit}
              >
                <TestTube className="h-3.5 w-3.5" />
                Send test to myself
              </Button>
            )}
          </div>

          {/* Send actions */}
          <div className="flex flex-col gap-2">
            <Button
              onClick={() => createMutation.mutate(true)}
              disabled={!canSubmit || createMutation.isPending}
              className="gap-2 bg-blue-500 hover:bg-blue-700 w-full"
            >
              {createMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : scheduledAt ? (
                <><Calendar className="h-4 w-4" /> Schedule</>
              ) : (
                <><Send className="h-4 w-4" /> Send now</>
              )}
            </Button>
            <Button
              variant="outline"
              onClick={() => createMutation.mutate(false)}
              disabled={!canSubmit || createMutation.isPending}
              className="w-full text-sm"
            >
              Save as draft
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Stats view ───────────────────────────────────────────────────────────────
function StatsView({
  broadcast,
  onBack,
}: {
  broadcast: Broadcast;
  onBack: () => void;
}) {
  const chCfg = CHANNEL_CONFIG[broadcast.channel];
  const ChIcon = chCfg.icon;

  const deliveryRate = broadcast.recipientCount > 0
    ? Math.round((broadcast.deliveredCount / broadcast.recipientCount) * 100)
    : 0;
  const openRate = broadcast.deliveredCount > 0
    ? Math.round((broadcast.openedCount / broadcast.deliveredCount) * 100)
    : 0;

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="text-slate-400 hover:text-slate-600">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="flex items-center gap-2">
          <div className={cn("flex h-8 w-8 items-center justify-center rounded-lg", chCfg.bg)}>
            <ChIcon className={cn("h-4 w-4", chCfg.color)} />
          </div>
          <h2 className="text-lg font-bold text-slate-900 truncate">
            {broadcast.subject ?? "Broadcast stats"}
          </h2>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "Sent", value: broadcast.recipientCount, color: "text-slate-900" },
          { label: "Delivered", value: `${deliveryRate}%`, sub: `${broadcast.deliveredCount} recipients`, color: "text-emerald-600" },
          { label: "Failed", value: broadcast.failedCount, color: broadcast.failedCount > 0 ? "text-red-500" : "text-slate-400" },
          { label: "Opened", value: `${openRate}%`, sub: `${broadcast.openedCount} opens`, color: "text-blue-600" },
        ].map((stat) => (
          <div key={stat.label} className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-slate-500">{stat.label}</p>
            <p className={cn("text-2xl font-bold mt-1", stat.color)}>{stat.value}</p>
            {stat.sub && <p className="text-[11px] text-slate-400 mt-0.5">{stat.sub}</p>}
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <h3 className="text-sm font-semibold text-slate-900 mb-4">Delivery timeline</h3>
        <div className="space-y-2">
          {[
            { label: "Created", time: broadcast.createdAt },
            ...(broadcast.sentAt ? [{ label: "Sent", time: broadcast.sentAt }] : []),
          ].map((ev) => (
            <div key={ev.label} className="flex items-center gap-3 text-sm">
              <div className="h-2 w-2 rounded-full bg-blue-400 shrink-0" />
              <span className="text-slate-600">{ev.label}</span>
              <span className="text-slate-400 text-xs ml-auto">
                {formatRelativeTime(new Date(ev.time))}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
