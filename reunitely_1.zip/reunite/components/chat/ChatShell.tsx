"use client";

import { useRef, useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import {
  Hash, Send, Loader2, ArrowLeft, Pin, MoreHorizontal,
  Trash2, Pencil, Flag, SmilePlus, Reply, ChevronUp,
  AlertCircle, Clock, Volume2, VolumeX, X, Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar } from "@/components/shared/Avatar";
import { EmptyState } from "@/components/shared/EmptyState";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useChat } from "@/hooks/useChat";
import { formatRelativeTime, cn } from "@/lib/utils";
import type { ChatMessageWithAuthor } from "@/types";
import { toast } from "sonner";
import Link from "next/link";

// ─── Room emoji map ────────────────────────────────────────────────────────────
const ROOM_EMOJI: Record<string, string> = {
  general: "💬",
  memories: "📸",
  logistics: "🗺️",
  rides: "🚗",
};

const QUICK_REACTIONS = ["❤️", "😂", "🥹", "🔥", "👏", "🎉"];

// ─── Types ────────────────────────────────────────────────────────────────────
interface Room {
  id: string;
  name: string;
  type: string;
  slug: string | null;
  description: string | null;
  slowModeSeconds?: number | null;
  isPinned?: boolean;
}

interface ChatShellProps {
  event: { id: string; title: string; slug: string };
  rooms: Room[];
  activeRoomId: string;
  currentUser: { id: string; name: string; avatarUrl: string | null };
  isOrganizer: boolean;
}

// ─── Main shell ───────────────────────────────────────────────────────────────
export function ChatShell({
  event,
  rooms,
  activeRoomId,
  currentUser,
  isOrganizer,
}: ChatShellProps) {
  const router = useRouter();
  const activeRoom = rooms.find((r) => r.id === activeRoomId);
  const [showRooms, setShowRooms] = useState(false); // mobile room drawer

  const {
    messages,
    isLoading,
    hasOlderMessages,
    isLoadingOlder,
    loadOlderMessages,
    pinnedMessages,
    sendMessage,
    isSending,
    sendError,
    deleteMessage,
    editMessage,
    addReaction,
    pinMessage,
    slowModeRemaining,
    bottomRef,
  } = useChat(activeRoomId, activeRoom?.slowModeSeconds);

  const [input, setInput] = useState("");
  const [replyTo, setReplyTo] = useState<ChatMessageWithAuthor | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");
  const [showPinnedBanner, setShowPinnedBanner] = useState(true);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [input]);

  // Reset state when switching rooms
  useEffect(() => {
    setInput("");
    setReplyTo(null);
    setEditingId(null);
    setShowPinnedBanner(true);
  }, [activeRoomId]);

  // Show send errors
  useEffect(() => {
    if (sendError) toast.error(sendError);
  }, [sendError]);

  async function handleSend() {
    const trimmed = input.trim();
    if (!trimmed || isSending || slowModeRemaining > 0) return;
    setInput("");
    setReplyTo(null);
    try {
      await sendMessage({ content: trimmed, replyToId: replyTo?.id });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to send";
      toast.error(msg);
      setInput(trimmed);
    }
  }

  async function handleEdit(messageId: string) {
    if (!editContent.trim()) return;
    try {
      await editMessage({ messageId, content: editContent.trim() });
      setEditingId(null);
    } catch {
      toast.error("Failed to edit message");
    }
  }

  function startEdit(msg: ChatMessageWithAuthor) {
    setEditingId(msg.id);
    setEditContent(msg.editedContent ?? msg.content);
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  const latestPinned = pinnedMessages[pinnedMessages.length - 1];

  return (
    <div className="flex h-screen flex-col bg-background">
      {/* ── Top bar ─────────────────────────────────────────────────────────── */}
      <header className="flex h-14 shrink-0 items-center gap-3 border-b border-border bg-card px-4 shadow-sm">
        <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" asChild>
          <Link href={`/events/${event.slug}`} aria-label="Back to event">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>

        {/* Mobile room selector */}
        <button
          onClick={() => setShowRooms(true)}
          className="flex min-w-0 flex-1 items-center gap-2 text-left md:hidden"
        >
          <span className="text-lg" aria-hidden>
            {ROOM_EMOJI[activeRoom?.slug ?? ""] ?? "💬"}
          </span>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-slate-900 truncate">{event.title}</p>
            <p className="text-xs text-blue-600 font-medium truncate flex items-center gap-1">
              <Hash className="h-3 w-3" />
              {activeRoom?.name ?? "general"}
            </p>
          </div>
        </button>

        {/* Desktop room name */}
        <div className="hidden min-w-0 flex-1 md:block">
          <p className="text-sm font-semibold text-slate-900">{event.title}</p>
          <p className="text-xs text-slate-400 flex items-center gap-1">
            <span aria-hidden>{ROOM_EMOJI[activeRoom?.slug ?? ""] ?? "💬"}</span>
            {activeRoom?.name ?? "general"}
            {activeRoom?.description && (
              <span className="text-slate-300 ml-1">— {activeRoom.description}</span>
            )}
          </p>
        </div>

        {/* Slow mode badge */}
        {activeRoom?.slowModeSeconds && (
          <div className="flex items-center gap-1 rounded-full bg-blue-50 border border-blue-200 px-2.5 py-1 text-xs font-medium text-blue-700">
            <Clock className="h-3 w-3" />
            Slow mode
          </div>
        )}
      </header>

      {/* ── Pinned message banner ──────────────────────────────────────────── */}
      {latestPinned && showPinnedBanner && (
        <div className="flex items-center gap-3 border-b border-blue-200 bg-blue-50 px-4 py-2.5">
          <Pin className="h-3.5 w-3.5 shrink-0 text-blue-500" />
          <p className="flex-1 truncate text-xs text-blue-800">
            <span className="font-semibold">Pinned:</span>{" "}
            {latestPinned.editedContent ?? latestPinned.content}
          </p>
          <button
            onClick={() => setShowPinnedBanner(false)}
            className="text-blue-400 hover:text-blue-600"
            aria-label="Dismiss"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* ── Room list sidebar (desktop) ─────────────────────────────────── */}
        <aside className="hidden w-52 shrink-0 flex-col border-r border-border bg-card md:flex">
          <div className="px-3 py-4">
            <p className="mb-2 px-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
              Rooms
            </p>
            {rooms.map((room) => {
              const isActive = room.id === activeRoomId;
              const emoji = ROOM_EMOJI[room.slug ?? ""] ?? "💬";
              return (
                <button
                  key={room.id}
                  onClick={() =>
                    router.push(`/chat/${event.id}?room=${room.id}`, { scroll: false })
                  }
                  className={cn(
                    "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-sm transition-colors",
                    isActive
                      ? "bg-blue-50 font-semibold text-blue-700"
                      : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                  )}
                >
                  <span className="text-base shrink-0" aria-hidden>{emoji}</span>
                  <span className="truncate">{room.name}</span>
                  {room.slowModeSeconds && (
                    <Clock className="h-3 w-3 shrink-0 ml-auto text-slate-300" />
                  )}
                </button>
              );
            })}
          </div>

          {isOrganizer && (
            <div className="mt-auto border-t border-border p-3">
              <p className="text-[10px] text-slate-400 text-center">
                Organizer controls in dashboard
              </p>
            </div>
          )}
        </aside>

        {/* ── Mobile room drawer ──────────────────────────────────────────── */}
        {showRooms && (
          <div className="fixed inset-0 z-50 md:hidden">
            <div
              className="absolute inset-0 bg-black/40"
              onClick={() => setShowRooms(false)}
            />
            <div className="absolute inset-y-0 left-0 w-64 bg-card shadow-xl">
              <div className="flex items-center justify-between border-b border-border px-4 py-3">
                <p className="font-semibold text-slate-900">Rooms</p>
                <button onClick={() => setShowRooms(false)}>
                  <X className="h-4 w-4 text-slate-400" />
                </button>
              </div>
              <div className="p-3">
                {rooms.map((room) => {
                  const emoji = ROOM_EMOJI[room.slug ?? ""] ?? "💬";
                  return (
                    <button
                      key={room.id}
                      onClick={() => {
                        router.push(`/chat/${event.id}?room=${room.id}`, { scroll: false });
                        setShowRooms(false);
                      }}
                      className={cn(
                        "flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-left text-sm transition-colors",
                        room.id === activeRoomId
                          ? "bg-blue-50 font-semibold text-blue-700"
                          : "text-slate-600 hover:bg-slate-50"
                      )}
                    >
                      <span className="text-base" aria-hidden>{emoji}</span>
                      <div className="min-w-0">
                        <p className="font-medium truncate">{room.name}</p>
                        {room.description && (
                          <p className="text-[11px] text-slate-400 truncate">
                            {room.description}
                          </p>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ── Message area ───────────────────────────────────────────────── */}
        <div className="flex flex-1 flex-col overflow-hidden">
          {/* Message list */}
          <div className="flex flex-1 flex-col-reverse overflow-y-auto px-4 py-3 gap-0.5">
            <div ref={bottomRef} />

            {isLoading ? (
              <div className="flex items-center justify-center py-16">
                <Loader2 className="h-6 w-6 animate-spin text-slate-300" />
              </div>
            ) : messages.length === 0 ? (
              <div className="flex flex-1 items-center justify-center">
                <EmptyState
                  icon={<span className="text-3xl">{ROOM_EMOJI[activeRoom?.slug ?? ""] ?? "💬"}</span>}
                  title={`Welcome to #${activeRoom?.name ?? "general"}!`}
                  description={
                    activeRoom?.description ?? "Start the conversation — say hello!"
                  }
                  size="md"
                />
              </div>
            ) : (
              <>
                {hasOlderMessages && (
                  <div className="flex justify-center py-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="gap-1.5 text-xs text-slate-400 hover:text-blue-600"
                      onClick={loadOlderMessages}
                      disabled={isLoadingOlder}
                    >
                      {isLoadingOlder ? (
                        <Loader2 className="h-3 w-3 animate-spin" />
                      ) : (
                        <ChevronUp className="h-3 w-3" />
                      )}
                      Load older messages
                    </Button>
                  </div>
                )}

                {messages.map((msg, i) => {
                  const isOwn = msg.userId === currentUser.id;
                  const prevMsg = messages[i - 1];
                  const grouped =
                    prevMsg &&
                    prevMsg.userId === msg.userId &&
                    new Date(msg.createdAt).getTime() -
                      new Date(prevMsg.createdAt).getTime() <
                      5 * 60 * 1000; // 5-min grouping

                  if (editingId === msg.id) {
                    return (
                      <EditableMessage
                        key={msg.id}
                        content={editContent}
                        onChange={setEditContent}
                        onSave={() => handleEdit(msg.id)}
                        onCancel={() => setEditingId(null)}
                      />
                    );
                  }

                  return (
                    <MessageRow
                      key={msg.id}
                      message={msg}
                      isOwn={isOwn}
                      grouped={!!grouped}
                      isOrganizer={isOrganizer}
                      currentUserId={currentUser.id}
                      onReply={() => setReplyTo(msg)}
                      onDelete={() => deleteMessage(msg.id)}
                      onEdit={() => startEdit(msg)}
                      onReact={(emoji) => addReaction({ messageId: msg.id, emoji })}
                      onPin={(pinned) => pinMessage({ messageId: msg.id, pinned })}
                    />
                  );
                })}
              </>
            )}
          </div>

          {/* ── Reply preview ─────────────────────────────────────────────── */}
          {replyTo && (
            <div className="mx-4 mb-1 flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2">
              <Reply className="h-3.5 w-3.5 shrink-0 text-blue-500" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-blue-800">
                  Replying to {replyTo.user.name}
                </p>
                <p className="truncate text-xs text-blue-700 opacity-75">
                  {replyTo.editedContent ?? replyTo.content}
                </p>
              </div>
              <button
                onClick={() => setReplyTo(null)}
                className="text-blue-400 hover:text-blue-600"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {/* ── Input bar ─────────────────────────────────────────────────── */}
          <div className="border-t border-border bg-card px-4 py-3 pb-safe">
            {slowModeRemaining > 0 ? (
              <div className="flex items-center justify-center gap-2 rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-700">
                <Clock className="h-4 w-4 shrink-0" />
                <span>
                  Slow mode — wait{" "}
                  <strong>{slowModeRemaining}s</strong> before sending
                </span>
              </div>
            ) : (
              <div className="flex items-end gap-2 rounded-xl border border-border bg-background px-3 py-2 focus-within:border-blue-300 focus-within:ring-1 focus-within:ring-blue-200 transition-all">
                <Textarea
                  ref={textareaRef}
                  placeholder={`Message #${activeRoom?.name ?? "general"}…`}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  rows={1}
                  maxLength={4000}
                  className="min-h-0 flex-1 resize-none border-0 bg-transparent p-0 text-sm shadow-none focus-visible:ring-0"
                  aria-label="Message input"
                />
                <Button
                  size="icon"
                  className="h-8 w-8 shrink-0 bg-blue-500 hover:bg-blue-700 disabled:opacity-40"
                  onClick={handleSend}
                  disabled={!input.trim() || isSending}
                  aria-label="Send message"
                >
                  {isSending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </div>
            )}
            <p className="mt-1 text-center text-[10px] text-slate-300">
              Enter to send · Shift+Enter for new line
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Message row ──────────────────────────────────────────────────────────────
function MessageRow({
  message,
  isOwn,
  grouped,
  isOrganizer,
  currentUserId,
  onReply,
  onDelete,
  onEdit,
  onReact,
  onPin,
}: {
  message: ChatMessageWithAuthor;
  isOwn: boolean;
  grouped: boolean;
  isOrganizer: boolean;
  currentUserId: string;
  onReply: () => void;
  onDelete: () => void;
  onEdit: () => void;
  onReact: (emoji: string) => void;
  onPin: (pinned: boolean) => void;
}) {
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  if (message.isDeleted) {
    return (
      <div className={cn("flex items-center gap-2 px-2 py-0.5", grouped && "mt-0")}>
        {!grouped && <div className="w-8 shrink-0" />}
        {grouped && <div className="w-8 shrink-0" />}
        <span className="text-xs italic text-slate-300">[Message deleted]</span>
      </div>
    );
  }

  // Group reactions by emoji
  const reactionGroups = message.reactions.reduce(
    (acc, r) => {
      if (!acc[r.emoji]) acc[r.emoji] = { count: 0, mine: false };
      acc[r.emoji]!.count++;
      if (r.userId === currentUserId) acc[r.emoji]!.mine = true;
      return acc;
    },
    {} as Record<string, { count: number; mine: boolean }>
  );

  return (
    <div
      className={cn(
        "group relative flex items-start gap-2 rounded-lg px-2 py-1 transition-colors hover:bg-slate-50/70",
        grouped ? "mt-0" : "mt-3"
      )}
    >
      {/* Avatar column */}
      <div className="w-8 shrink-0 pt-0.5">
        {!grouped ? (
          <Avatar
            name={message.user.name}
            src={message.user.avatarUrl}
            size="sm"
          />
        ) : null}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        {!grouped && (
          <div className="flex items-baseline gap-2 mb-0.5">
            <span className="text-sm font-semibold text-slate-900">
              {message.user.name}
            </span>
            <span className="text-[11px] text-slate-400">
              {formatRelativeTime(new Date(message.createdAt))}
            </span>
            {message.editedAt && (
              <span className="text-[10px] text-slate-300 italic">(edited)</span>
            )}
            {message.isPinned && (
              <span className="flex items-center gap-0.5 text-[10px] text-blue-500">
                <Pin className="h-2.5 w-2.5" /> pinned
              </span>
            )}
          </div>
        )}

        {/* Reply quote */}
        {message.replyTo && !message.replyTo.isDeleted && (
          <div className="mb-1.5 flex items-start gap-1.5 rounded-md border-l-2 border-slate-300 bg-slate-50 px-2.5 py-1.5 text-xs">
            <span className="font-semibold text-slate-600 shrink-0">
              {(message.replyTo as unknown as { user: { name: string } }).user?.name}:
            </span>
            <span className="text-slate-500 line-clamp-1">
              {message.replyTo.content}
            </span>
          </div>
        )}

        {/* Message text */}
        <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-wrap break-words">
          {message.editedContent ?? message.content}
        </p>

        {/* Reactions */}
        {Object.keys(reactionGroups).length > 0 && (
          <div className="mt-1.5 flex flex-wrap gap-1">
            {Object.entries(reactionGroups).map(([emoji, { count, mine }]) => (
              <button
                key={emoji}
                onClick={() => onReact(emoji)}
                className={cn(
                  "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs transition-colors",
                  mine
                    ? "border-blue-300 bg-blue-50 text-blue-700"
                    : "border-border bg-white text-slate-600 hover:border-blue-300"
                )}
              >
                {emoji} <span>{count}</span>
              </button>
            ))}
            <button
              onClick={() => setShowEmojiPicker((v) => !v)}
              className="inline-flex h-6 w-6 items-center justify-center rounded-full border border-dashed border-slate-300 text-xs text-slate-400 hover:border-blue-400 hover:text-blue-500 transition-colors"
              aria-label="Add reaction"
            >
              +
            </button>
          </div>
        )}
      </div>

      {/* Hover actions */}
      <div
        className={cn(
          "absolute right-2 top-1 flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
        )}
      >
        {/* Quick reactions */}
        <div className="relative">
          <button
            onClick={() => setShowEmojiPicker((v) => !v)}
            className="flex h-7 w-7 items-center justify-center rounded text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
            aria-label="React"
          >
            <SmilePlus className="h-3.5 w-3.5" />
          </button>
          {showEmojiPicker && (
            <div className="absolute bottom-full right-0 mb-1 flex items-center gap-1 rounded-xl border border-border bg-white p-1.5 shadow-lg z-10">
              {QUICK_REACTIONS.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => {
                    onReact(emoji);
                    setShowEmojiPicker(false);
                  }}
                  className="flex h-8 w-8 items-center justify-center rounded-lg text-lg transition-transform hover:scale-125 hover:bg-slate-50"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}
        </div>

        <button
          onClick={onReply}
          className="flex h-7 w-7 items-center justify-center rounded text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
          aria-label="Reply"
        >
          <Reply className="h-3.5 w-3.5" />
        </button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="flex h-7 w-7 items-center justify-center rounded text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
              aria-label="More options"
            >
              <MoreHorizontal className="h-3.5 w-3.5" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            {isOwn && (
              <DropdownMenuItem onClick={onEdit} className="gap-2">
                <Pencil className="h-3.5 w-3.5" />
                Edit
              </DropdownMenuItem>
            )}
            {isOrganizer && (
              <DropdownMenuItem
                onClick={() => onPin(!message.isPinned)}
                className="gap-2"
              >
                <Pin className="h-3.5 w-3.5" />
                {message.isPinned ? "Unpin" : "Pin message"}
              </DropdownMenuItem>
            )}
            {(isOwn || isOrganizer) && <DropdownMenuSeparator />}
            {(isOwn || isOrganizer) && (
              <DropdownMenuItem
                onClick={onDelete}
                className="gap-2 text-red-600 focus:text-red-600"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Delete
              </DropdownMenuItem>
            )}
            {!isOwn && (
              <DropdownMenuItem className="gap-2 text-slate-500">
                <Flag className="h-3.5 w-3.5" />
                Report
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

// ─── Editable message ─────────────────────────────────────────────────────────
function EditableMessage({
  content,
  onChange,
  onSave,
  onCancel,
}: {
  content: string;
  onChange: (v: string) => void;
  onSave: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="mx-2 my-1 flex flex-col gap-1.5 rounded-xl border border-blue-300 bg-blue-50 p-3">
      <Textarea
        value={content}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); onSave(); }
          if (e.key === "Escape") onCancel();
        }}
        autoFocus
        rows={2}
        className="resize-none border-0 bg-transparent text-sm shadow-none focus-visible:ring-0 p-0"
      />
      <div className="flex items-center gap-2 justify-end">
        <button
          onClick={onCancel}
          className="text-xs text-slate-500 hover:text-slate-700"
        >
          Cancel (Esc)
        </button>
        <Button size="sm" className="h-7 gap-1.5 text-xs bg-blue-500 hover:bg-blue-700" onClick={onSave}>
          <Check className="h-3 w-3" />
          Save
        </Button>
      </div>
    </div>
  );
}
