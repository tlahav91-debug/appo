"use client";

import { useEffect } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import posthog from "posthog-js";
import { PostHogProvider as PHProvider } from "posthog-js/react";
import { clientEnv } from "@/env";

// Initialize PostHog once on client
if (typeof window !== "undefined" && clientEnv.NEXT_PUBLIC_POSTHOG_KEY) {
  posthog.init(clientEnv.NEXT_PUBLIC_POSTHOG_KEY, {
    api_host: clientEnv.NEXT_PUBLIC_POSTHOG_HOST,
    // Don't auto-capture everything — we track intentionally
    autocapture: false,
    capture_pageview: false, // We handle this manually below
    capture_pageleave: true,
    persistence: "localStorage",
    // Respect DNT
    respect_dnt: true,
  });
}

export function PostHogProvider({ children }: { children: React.ReactNode }) {
  return (
    <PHProvider client={posthog}>
      {children}
    </PHProvider>
  );
}

// Separate component to track page views (must be inside Suspense for searchParams)
export function Analytics() {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  useEffect(() => {
    if (pathname) {
      const url =
        window.origin +
        pathname +
        (searchParams.toString() ? `?${searchParams.toString()}` : "");

      posthog.capture("$pageview", { $current_url: url });
    }
  }, [pathname, searchParams]);

  return null;
}

// Typed event tracking helper — use in components
export function trackEvent(
  event: string,
  properties?: Record<string, unknown>
): void {
  posthog.capture(event, properties);
}

// Common tracked events
export const analyticsEvents = {
  ctaClicked: (ctaId: string, page: string) =>
    trackEvent("cta_clicked", { cta_id: ctaId, page }),

  eventCreationStarted: () => trackEvent("event_creation_started"),

  eventCreationStepCompleted: (step: number) =>
    trackEvent("event_creation_step_completed", { step }),

  eventPublished: (hasTickets: boolean, capacity?: number) =>
    trackEvent("event_published", { has_tickets: hasTickets, capacity }),

  rsvpStarted: (eventId: string) =>
    trackEvent("rsvp_started", { event_id: eventId }),

  rsvpCompleted: (eventId: string, status: string, paid: boolean) =>
    trackEvent("rsvp_completed", { event_id: eventId, status, paid }),

  memoryUploaded: (eventId: string, type: string) =>
    trackEvent("memory_uploaded", { event_id: eventId, type }),

  inviteShared: (channel: string) =>
    trackEvent("invite_shared", { channel }),

  nominationSubmitted: (eventId: string) =>
    trackEvent("nomination_submitted", { event_id: eventId }),

  voteCast: (categoryId: string) =>
    trackEvent("vote_cast", { category_id: categoryId }),

  chatMessageSent: (eventId: string) =>
    trackEvent("chat_message_sent", { event_id: eventId }),
} as const;
