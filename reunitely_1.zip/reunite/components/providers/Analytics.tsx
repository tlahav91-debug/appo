"use client";

import { useEffect } from "react";
import { usePathname, useSearchParams } from "next/navigation";

// Lightweight PostHog analytics wrapper.
// Only initializes if NEXT_PUBLIC_POSTHOG_KEY is set.
// Respects user consent — no tracking until consent is given.

declare global {
  interface Window {
    posthog?: {
      init: (key: string, options: object) => void;
      capture: (event: string, props?: object) => void;
      identify: (id: string, props?: object) => void;
      reset: () => void;
      pageview?: () => void;
    };
  }
}

export function Analytics() {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  useEffect(() => {
    const key = process.env.NEXT_PUBLIC_POSTHOG_KEY;
    if (!key || typeof window === "undefined") return;

    // Lazy-load PostHog only in production
    if (process.env.NODE_ENV !== "production") return;

    const loadPostHog = async () => {
      if (window.posthog) return;

      // Dynamically import posthog-js to keep it out of the critical bundle
      const { default: posthog } = await import("posthog-js").catch(() => ({
        default: null,
      }));
      if (!posthog) return;

      posthog.init(key, {
        api_host:
          process.env.NEXT_PUBLIC_POSTHOG_HOST ?? "https://app.posthog.com",
        capture_pageview: false, // We'll handle manually for SPA navigation
        persistence: "localStorage+cookie",
        autocapture: false, // Opt-in to avoid capturing PII in element text
        disable_session_recording: true, // Enable explicitly if needed
        loaded: (ph) => {
          // Development-only: verbose logging
          if (process.env.NODE_ENV === "development") {
            ph.debug();
          }
        },
      });
      // @ts-expect-error - posthog is now on window
      window.posthog = posthog;
    };

    loadPostHog();
  }, []);

  // Track page views on route change
  useEffect(() => {
    if (typeof window === "undefined" || !window.posthog) return;
    if (process.env.NODE_ENV !== "production") return;

    const url = pathname + (searchParams?.toString() ? `?${searchParams}` : "");
    window.posthog.capture("$pageview", { $current_url: url });
  }, [pathname, searchParams]);

  return null;
}
