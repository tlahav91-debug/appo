"use client";

import { useState } from "react";
import { Share2, Link2, Check, MessageCircle, Facebook, Twitter } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import {
  getWhatsAppShareUrl,
  getFacebookShareUrl,
  getTwitterShareUrl,
} from "@/lib/utils";

interface ShareMenuProps {
  url: string;
  title: string;
  description?: string;
  variant?: "default" | "outline" | "ghost";
  size?: "default" | "sm" | "icon";
}

export function ShareMenu({
  url,
  title,
  description,
  variant = "outline",
  size = "default",
}: ShareMenuProps) {
  const [copied, setCopied] = useState(false);

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback for older browsers
      const el = document.createElement("textarea");
      el.value = url;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  const shareText = description ?? title;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant={variant} size={size} aria-label="Share event">
          <Share2 className="h-4 w-4" />
          {size !== "icon" && <span className="ml-2">Share</span>}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuItem onClick={copyLink} className="gap-2 cursor-pointer">
          {copied ? (
            <Check className="h-4 w-4 text-emerald-500" />
          ) : (
            <Link2 className="h-4 w-4" />
          )}
          {copied ? "Copied!" : "Copy link"}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild className="gap-2 cursor-pointer">
          <a
            href={getWhatsAppShareUrl(shareText, url)}
            target="_blank"
            rel="noopener noreferrer"
          >
            <MessageCircle className="h-4 w-4 text-emerald-500" />
            Share via WhatsApp
          </a>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className="gap-2 cursor-pointer">
          <a
            href={getFacebookShareUrl(url)}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Facebook className="h-4 w-4 text-blue-600" />
            Share on Facebook
          </a>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className="gap-2 cursor-pointer">
          <a
            href={getTwitterShareUrl(shareText, url)}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Twitter className="h-4 w-4 text-sky-500" />
            Share on X/Twitter
          </a>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
