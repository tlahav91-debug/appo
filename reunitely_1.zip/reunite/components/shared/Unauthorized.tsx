"use client";

import Link from "next/link";
import { Lock, ShieldOff, UserX, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// ─── Generic unauthorized state ───────────────────────────────────────────────

interface UnauthorizedProps {
  title?: string;
  message?: string;
  backHref?: string;
  backLabel?: string;
  className?: string;
}

export function Unauthorized({
  title = "Access denied",
  message = "You don't have permission to view this page.",
  backHref = "/dashboard/events",
  backLabel = "Go to My Events",
  className,
}: UnauthorizedProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center py-24 text-center px-4",
        className
      )}
      role="alert"
      aria-live="assertive"
    >
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 mb-5">
        <Lock className="h-8 w-8 text-slate-400" />
      </div>
      <h2 className="font-display text-xl font-bold text-slate-900">{title}</h2>
      <p className="mt-2 text-sm text-slate-500 max-w-sm">{message}</p>
      <Button asChild variant="outline" className="mt-6">
        <Link href={backHref}>{backLabel}</Link>
      </Button>
    </div>
  );
}

// ─── Not an organizer ─────────────────────────────────────────────────────────

export function NotOrganizer({ eventSlug }: { eventSlug?: string }) {
  return (
    <Unauthorized
      title="Organizers only"
      message="This section is only accessible to the event organizer and committee members."
      backHref={eventSlug ? `/events/${eventSlug}` : "/dashboard/events"}
      backLabel={eventSlug ? "View Event Page" : "My Events"}
    />
  );
}

// ─── Invite required ──────────────────────────────────────────────────────────

export function InviteRequired({ eventTitle }: { eventTitle?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center px-4">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-50 mb-5">
        <UserX className="h-8 w-8 text-blue-500" />
      </div>
      <h2 className="font-display text-xl font-bold text-slate-900">
        Invite required
      </h2>
      <p className="mt-2 text-sm text-slate-500 max-w-sm">
        {eventTitle
          ? `"${eventTitle}" is a private event. You need an invite link to access it.`
          : "This event requires an invite link to access."}
      </p>
      <p className="mt-4 text-xs text-slate-400">
        Already have an invite? Check your email for the link from the organizer.
      </p>
    </div>
  );
}

// ─── Event not found / private ────────────────────────────────────────────────

export function EventPrivate() {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center px-4">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 mb-5">
        <ShieldOff className="h-8 w-8 text-slate-400" />
      </div>
      <h2 className="font-display text-xl font-bold text-slate-900">
        Private event
      </h2>
      <p className="mt-2 text-sm text-slate-500 max-w-sm">
        This event is private. If you received an invite, use your invite link
        to access it.
      </p>
      <Button asChild variant="outline" className="mt-6">
        <Link href="/">Back to Home</Link>
      </Button>
    </div>
  );
}

// ─── Insufficient role banner (inline, not full-page) ─────────────────────────

export function PermissionBanner({
  message,
  className,
}: {
  message: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-3 rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800",
        className
      )}
      role="alert"
    >
      <Lock className="h-4 w-4 text-blue-500 shrink-0" />
      {message}
    </div>
  );
}

// ─── Loading state for permission checks ─────────────────────────────────────

export function PermissionLoading({ label = "Checking access…" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center py-16 gap-2 text-sm text-slate-400">
      <Clock className="h-4 w-4 animate-spin" />
      {label}
    </div>
  );
}

// ─── Guard wrapper — shows children or unauthorized state ─────────────────────
// Use client-side for progressive UI disclosure. Always enforce server-side too.

interface PermissionGateProps {
  allowed: boolean;
  isLoading?: boolean;
  fallback?: React.ReactNode;
  children: React.ReactNode;
}

export function PermissionGate({
  allowed,
  isLoading = false,
  fallback,
  children,
}: PermissionGateProps) {
  if (isLoading) return <PermissionLoading />;
  if (!allowed) return fallback ? <>{fallback}</> : <Unauthorized />;
  return <>{children}</>;
}
