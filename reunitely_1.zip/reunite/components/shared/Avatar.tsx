import Image from "next/image";
import { cn, getInitials } from "@/lib/utils";

type AvatarSize = "xs" | "sm" | "md" | "lg" | "xl" | "2xl";

const SIZE_CLASSES: Record<AvatarSize, string> = {
  xs: "h-6 w-6 text-[10px]",
  sm: "h-8 w-8 text-xs",
  md: "h-10 w-10 text-sm",
  lg: "h-12 w-12 text-base",
  xl: "h-16 w-16 text-lg",
  "2xl": "h-24 w-24 text-2xl",
};

const SIZE_PX: Record<AvatarSize, number> = {
  xs: 24,
  sm: 32,
  md: 40,
  lg: 48,
  xl: 64,
  "2xl": 96,
};

interface AvatarProps {
  name: string;
  src?: string | null;
  size?: AvatarSize;
  className?: string;
  ring?: boolean;
}

export function Avatar({
  name,
  src,
  size = "md",
  className,
  ring = false,
}: AvatarProps) {
  const sizeClass = SIZE_CLASSES[size];
  const px = SIZE_PX[size];

  return (
    <div
      className={cn(
        "relative shrink-0 overflow-hidden rounded-full bg-blue-100",
        sizeClass,
        ring && "ring-2 ring-white ring-offset-0",
        className
      )}
      role="img"
      aria-label={name}
    >
      {src ? (
        <Image
          src={src}
          alt={name}
          width={px}
          height={px}
          className="h-full w-full object-cover"
          sizes={`${px}px`}
        />
      ) : (
        <span className="flex h-full w-full items-center justify-center font-semibold text-blue-700">
          {getInitials(name)}
        </span>
      )}
    </div>
  );
}

// ─── Avatar group (stacked) ───────────────────────────────────────────────────

interface AvatarGroupProps {
  people: Array<{ name: string; avatarUrl?: string | null }>;
  max?: number;
  size?: AvatarSize;
  className?: string;
}

export function AvatarGroup({
  people,
  max = 5,
  size = "sm",
  className,
}: AvatarGroupProps) {
  const visible = people.slice(0, max);
  const overflow = people.length - max;

  const sizeClass = SIZE_CLASSES[size];

  return (
    <div className={cn("flex items-center -space-x-2", className)} aria-label={`${people.length} people`}>
      {visible.map((person, i) => (
        <Avatar
          key={i}
          name={person.name}
          src={person.avatarUrl}
          size={size}
          ring
        />
      ))}
      {overflow > 0 && (
        <div
          className={cn(
            "relative flex shrink-0 items-center justify-center rounded-full border-2 border-white bg-slate-100 font-medium text-slate-600",
            sizeClass
          )}
          aria-label={`${overflow} more`}
        >
          <span className="text-[10px]">+{overflow}</span>
        </div>
      )}
    </div>
  );
}
