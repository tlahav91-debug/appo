import { cn } from "@/lib/utils";
import type { RSVPStatus, EventStatus } from "@prisma/client";

// ─── RSVP Status Badge ────────────────────────────────────────────────────────
// Matches RSVPStatus enum: PENDING | CONFIRMED | DECLINED | WAITLISTED | CANCELLED

const RSVP_STATUS_CONFIG: Record<
  RSVPStatus,
  { label: string; className: string; dot: string }
> = {
  CONFIRMED: {
    label: "Confirmed",
    className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    dot: "bg-emerald-500",
  },
  PENDING: {
    label: "Maybe",
    className: "bg-blue-50 text-blue-700 border-blue-200",
    dot: "bg-blue-400",
  },
  DECLINED: {
    label: "Declined",
    className: "bg-slate-50 text-slate-600 border-slate-200",
    dot: "bg-slate-400",
  },
  WAITLISTED: {
    label: "Waitlisted",
    className: "bg-blue-50 text-blue-700 border-blue-200",
    dot: "bg-blue-500",
  },
  CANCELLED: {
    label: "Cancelled",
    className: "bg-red-50 text-red-600 border-red-200",
    dot: "bg-red-400",
  },
};

interface RsvpStatusBadgeProps {
  status: RSVPStatus | string;
  className?: string;
  showDot?: boolean;
}

export function RsvpStatusBadge({
  status,
  className,
  showDot = true,
}: RsvpStatusBadgeProps) {
  const config =
    RSVP_STATUS_CONFIG[status as RSVPStatus] ??
    // Graceful fallback for any unknown status
    {
      label: status,
      className: "bg-slate-50 text-slate-500 border-slate-200",
      dot: "bg-slate-400",
    };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium",
        config.className,
        className
      )}
    >
      {showDot && (
        <span
          className={cn("h-1.5 w-1.5 shrink-0 rounded-full", config.dot)}
          aria-hidden
        />
      )}
      {config.label}
    </span>
  );
}

// ─── Event Status Badge ───────────────────────────────────────────────────────
// Matches EventStatus enum: DRAFT | PUBLISHED | ARCHIVED

const EVENT_STATUS_CONFIG: Record<
  EventStatus,
  { label: string; className: string }
> = {
  DRAFT: {
    label: "Draft",
    className: "bg-slate-100 text-slate-600 border border-slate-200",
  },
  PUBLISHED: {
    label: "Published",
    className: "bg-emerald-50 text-emerald-700 border border-emerald-200",
  },
  ARCHIVED: {
    label: "Archived",
    className: "bg-slate-100 text-slate-400 border border-slate-200",
  },
};

interface EventStatusBadgeProps {
  status: EventStatus | string;
  className?: string;
}

export function EventStatusBadge({ status, className }: EventStatusBadgeProps) {
  const config =
    EVENT_STATUS_CONFIG[status as EventStatus] ??
    {
      label: status,
      className: "bg-slate-100 text-slate-500 border border-slate-200",
    };

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        config.className,
        className
      )}
    >
      {config.label}
    </span>
  );
}

// ─── Check-in badge (separate from RSVPStatus) ────────────────────────────────
// Used when CheckIn model record exists alongside the RSVP

export function CheckedInBadge({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-violet-200 bg-violet-50 px-2.5 py-0.5 text-xs font-medium text-violet-700",
        className
      )}
    >
      <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-violet-500" aria-hidden />
      Checked In
    </span>
  );
}
