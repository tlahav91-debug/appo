"use client";

import { type UseFormReturn } from "react-hook-form";
import { Checkbox } from "@/components/ui/checkbox";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { cn } from "@/lib/utils";

interface ConsentCheckboxProps {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  form: UseFormReturn<any>;
  name: string;
  label: React.ReactNode;
  required?: boolean;
  className?: string;
}

export function ConsentCheckbox({
  form,
  name,
  label,
  required = false,
  className,
}: ConsentCheckboxProps) {
  return (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem
          className={cn(
            "flex flex-row items-start gap-3 rounded-lg border border-border bg-slate-50 p-4",
            className
          )}
        >
          <FormControl>
            <Checkbox
              checked={field.value}
              onCheckedChange={field.onChange}
              id={name}
              aria-required={required}
              className="mt-0.5"
            />
          </FormControl>
          <div className="space-y-1 leading-none">
            <FormLabel
              htmlFor={name}
              className="cursor-pointer text-sm font-normal text-slate-700"
            >
              {label}
              {required && (
                <span className="ml-1 text-destructive" aria-hidden>
                  *
                </span>
              )}
            </FormLabel>
            <FormMessage />
          </div>
        </FormItem>
      )}
    />
  );
}
