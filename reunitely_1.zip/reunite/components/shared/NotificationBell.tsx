"use client";

import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useNotifications } from "@/hooks/useNotifications";
import { formatRelativeTime } from "@/lib/utils";
import { cn } from "@/lib/utils";

export function NotificationBell() {
  const { notifications, unreadCount, markAllRead } = useNotifications();

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative h-8 w-8"
          aria-label={`Notifications${unreadCount > 0 ? ` (${unreadCount} unread)` : ""}`}
        >
          <Bell className="h-4 w-4" />
          {unreadCount > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-blue-500 text-[10px] font-bold text-slate-900">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <h3 className="text-sm font-semibold text-slate-900">Notifications</h3>
          {unreadCount > 0 && (
            <button
              onClick={markAllRead}
              className="text-xs text-blue-600 hover:text-blue-700"
            >
              Mark all read
            </button>
          )}
        </div>

        {/* List */}
        <div className="max-h-80 overflow-y-auto scrollbar-thin">
          {notifications.length === 0 ? (
            <div className="py-8 text-center text-sm text-slate-400">
              No notifications yet
            </div>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                className={cn(
                  "border-b border-border/50 px-4 py-3 last:border-0",
                  !n.isRead && "bg-blue-50/50"
                )}
              >
                <p className="text-sm text-slate-700">
                  {getNotificationMessage(n.type, n.payload as Record<string, string>)}
                </p>
                <p className="mt-0.5 text-xs text-slate-400">
                  {formatRelativeTime(new Date(n.createdAt))}
                </p>
              </div>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

function getNotificationMessage(
  type: string,
  payload: Record<string, string>
): string {
  switch (type) {
    case "RSVP_CONFIRMED":
      return `${payload.userName ?? "Someone"} RSVP'd to ${payload.eventTitle ?? "your event"}`;
    case "MEMORY_TAGGED":
      return `${payload.uploaderName ?? "Someone"} tagged you in a memory`;
    case "NOMINATION_RECEIVED":
      return `You've been nominated for "${payload.categoryTitle ?? "a category"}"`;
    case "WAITLIST_PROMOTED":
      return `You've been promoted from the waitlist for ${payload.eventTitle ?? "an event"}`;
    case "PAYMENT_RECEIVED":
      return `Payment received for ${payload.eventTitle ?? "your event"}`;
    default:
      return "You have a new notification";
  }
}
