"use client";

import { useState, useTransition } from "react";
import Image from "next/image";
import {
  Heart, MessageCircle, Flag, Star, Trash2, MoreHorizontal,
  ChevronDown, ChevronUp, Send, X, Loader2, Play,
} from "lucide-react";
import { Avatar } from "@/components/shared/Avatar";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { formatRelativeTime, cn } from "@/lib/utils";
import type { MemoryPostWithMedia } from "@/lib/services/memory.service";

const REACTION_EMOJIS = ["❤️", "😂", "😭", "🔥", "🤩", "👏"];

const REPORT_REASONS = [
  { value: "INAPPROPRIATE", label: "Inappropriate content" },
  { value: "WRONG_PERSON", label: "I'm in this photo and don't consent" },
  { value: "SPAM", label: "Spam or misleading" },
  { value: "COPYRIGHT", label: "Copyright violation" },
  { value: "OTHER", label: "Other" },
];

interface MemoryPostCardProps {
  post: MemoryPostWithMedia;
  eventId: string;
  viewerId: string | null;
  isOrganizer: boolean;
  onDelete?: (id: string) => void;
  onFeature?: (id: string, featured: boolean) => void;
  className?: string;
}

export function MemoryPostCard({
  post,
  eventId,
  viewerId,
  isOrganizer,
  onDelete,
  onFeature,
  className,
}: MemoryPostCardProps) {
  const [reaction, setReaction] = useState(post.viewerReaction);
  const [reactionSummary, setReactionSummary] = useState(post.reactionSummary);
  const [likeCount, setLikeCount] = useState(post.likeCount);
  const [showComments, setShowComments] = useState(false);
  const [showReactionPicker, setShowReactionPicker] = useState(false);
  const [showReportMenu, setShowReportMenu] = useState(false);
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [isPending, startTransition] = useTransition();

  const isOwn = post.author.id === viewerId;
  const hasMedia = post.media.length > 0;
  const isPhoto = post.type === "PHOTO" || post.type === "COLLAGE";
  const isText = post.type === "TEXT";
  const isVideo = post.type === "VIDEO_EMBED";

  function handleReact(emoji: string) {
    if (!viewerId) { toast.error("Sign in to react"); return; }
    startTransition(async () => {
      const prev = reaction;
      // Optimistic
      const adding = emoji !== reaction;
      setReaction(adding ? emoji : null);
      setLikeCount((c) => adding ? c + 1 : Math.max(0, c - 1));
      setReactionSummary((prev) => {
        const map = new Map(prev.map((r) => [r.emoji, r.count]));
        if (adding) { map.set(emoji, (map.get(emoji) ?? 0) + 1); if (prev !== null) { const c = map.get(prev!) ?? 1; if (c <= 1) map.delete(prev!); else map.set(prev!, c - 1); } }
        else { const c = map.get(emoji) ?? 1; if (c <= 1) map.delete(emoji); else map.set(emoji, c - 1); }
        return Array.from(map.entries()).map(([e, c]) => ({ emoji: e, count: c })).sort((a, b) => b.count - a.count);
      });
      setShowReactionPicker(false);

      try {
        const res = await fetch(`/api/events/${eventId}/memories/${post.id}/react`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ emoji }),
        });
        if (!res.ok) throw new Error();
      } catch {
        setReaction(prev);
        toast.error("Failed to react");
      }
    });
  }

  async function handleReport(reason: string) {
    await fetch(`/api/events/${eventId}/memories/${post.id}/report`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason }),
    });
    setShowReportMenu(false);
    toast.success("Reported — thanks for keeping the wall safe.");
  }

  async function handleFeature() {
    await fetch(`/api/events/${eventId}/memories/${post.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ featured: !post.isFeatured }),
    });
    onFeature?.(post.id, !post.isFeatured);
    toast.success(post.isFeatured ? "Removed from featured" : "Added to featured ✨");
  }

  async function handleDelete() {
    if (!confirm("Delete this memory? This cannot be undone.")) return;
    await fetch(`/api/events/${eventId}/memories/${post.id}`, { method: "DELETE" });
    onDelete?.(post.id);
    toast.success("Memory deleted");
  }

  const imageUrl = (idx: number) => {
    const m = post.media[idx];
    return m?.cdnUrl ?? m?.publicUrl ?? null;
  };

  return (
    <article
      className={cn(
        "overflow-hidden rounded-2xl border border-border bg-card shadow-sm",
        post.isFeatured && "border-blue-300 shadow-blue-100 shadow-md",
        className
      )}
    >
      {/* Featured ribbon */}
      {post.isFeatured && (
        <div className="flex items-center gap-1.5 bg-blue-50 border-b border-blue-200 px-4 py-1.5">
          <Star className="h-3.5 w-3.5 fill-blue-600 text-blue-500" />
          <span className="text-xs font-semibold text-blue-700">Featured memory</span>
        </div>
      )}

      {/* Year/era banner */}
      {(post.yearContext || post.contextLabel) && (
        <div className="flex items-center gap-2 bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-blue-100 px-4 py-2">
          <span className="text-sm font-bold text-blue-700">
            {post.yearContext ?? ""}
          </span>
          {post.contextLabel && (
            <span className="text-xs text-blue-600">· {post.contextLabel}</span>
          )}
        </div>
      )}

      {/* Photo gallery */}
      {isPhoto && hasMedia && (
        <div className="relative">
          <div className="relative aspect-[4/3] overflow-hidden bg-slate-100">
            {imageUrl(activeImageIdx) ? (
              <Image
                src={imageUrl(activeImageIdx)!}
                alt={post.caption ?? "Memory photo"}
                fill
                className="object-cover"
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
              />
            ) : (
              <div className="flex h-full items-center justify-center">
                <span className="text-4xl">📷</span>
              </div>
            )}
          </div>

          {/* Multi-image nav */}
          {post.media.length > 1 && (
            <>
              {activeImageIdx > 0 && (
                <button
                  onClick={() => setActiveImageIdx((i) => i - 1)}
                  className="absolute left-2 top-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
                  aria-label="Previous"
                >‹</button>
              )}
              {activeImageIdx < post.media.length - 1 && (
                <button
                  onClick={() => setActiveImageIdx((i) => i + 1)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
                  aria-label="Next"
                >›</button>
              )}
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
                {post.media.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImageIdx(i)}
                    className={cn("h-1.5 w-1.5 rounded-full transition-colors", i === activeImageIdx ? "bg-white" : "bg-white/50")}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* Text memory */}
      {isText && (
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 min-h-32 flex items-center">
          <blockquote className="text-slate-800 text-base leading-relaxed italic">
            "{post.caption}"
          </blockquote>
        </div>
      )}

      {/* Video embed */}
      {isVideo && post.videoEmbedUrl && (
        <div className="relative aspect-video bg-slate-900 flex items-center justify-center">
          <a
            href={post.videoEmbedUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center gap-2 text-white"
          >
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white/20 backdrop-blur-sm">
              <Play className="h-8 w-8 fill-white text-white" />
            </div>
            <span className="text-sm font-medium opacity-80">Watch video</span>
          </a>
        </div>
      )}

      {/* Card body */}
      <div className="p-4 flex flex-col gap-3">
        {/* Author + timestamp + menu */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar name={post.author.name} src={post.author.avatarUrl} size="sm" />
            <div>
              <p className="text-sm font-semibold text-slate-900">{post.author.name}</p>
              <p className="text-xs text-slate-400">{formatRelativeTime(post.createdAt)}</p>
            </div>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-50">
                <MoreHorizontal className="h-4 w-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              {isOrganizer && (
                <>
                  <DropdownMenuItem onClick={handleFeature}>
                    <Star className="mr-2 h-4 w-4" />
                    {post.isFeatured ? "Unfeature" : "Feature"}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                </>
              )}
              {(isOwn || isOrganizer) && (
                <DropdownMenuItem onClick={handleDelete} className="text-red-600 focus:text-red-600">
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              )}
              {!isOwn && (
                <DropdownMenuItem onClick={() => setShowReportMenu(true)}>
                  <Flag className="mr-2 h-4 w-4" />
                  Report
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Caption (for photo/video) */}
        {(isPhoto || isVideo) && post.caption && (
          <p className="text-sm text-slate-700 leading-relaxed">{post.caption}</p>
        )}

        {/* Tagged users */}
        {post.taggedUsers.length > 0 && (
          <p className="text-xs text-slate-500">
            <span className="font-medium">With: </span>
            {post.taggedUsers.map((u) => u.name).join(", ")}
          </p>
        )}

        {/* Reactions row */}
        <div className="flex items-center gap-3 pt-1 border-t border-border">
          {/* Reaction picker */}
          <div className="relative">
            <button
              onClick={() => setShowReactionPicker((v) => !v)}
              className={cn(
                "flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm transition-colors",
                reaction
                  ? "bg-blue-50 text-blue-700 font-medium"
                  : "text-slate-500 hover:bg-slate-50"
              )}
            >
              {reaction ?? <Heart className="h-4 w-4" />}
              {likeCount > 0 && <span>{likeCount}</span>}
            </button>

            {showReactionPicker && (
              <div className="absolute bottom-full left-0 mb-2 flex gap-1 rounded-2xl border border-border bg-card p-2 shadow-lg z-10">
                {REACTION_EMOJIS.map((e) => (
                  <button
                    key={e}
                    onClick={() => handleReact(e)}
                    className={cn(
                      "flex h-9 w-9 items-center justify-center rounded-xl text-xl transition-all hover:scale-125",
                      reaction === e && "bg-blue-100"
                    )}
                    aria-label={`React with ${e}`}
                  >
                    {e}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Reaction summary */}
          {reactionSummary.slice(0, 3).map((r) => (
            <span key={r.emoji} className="text-xs text-slate-500">
              {r.emoji} {r.count}
            </span>
          ))}

          {/* Comment toggle */}
          <button
            onClick={() => setShowComments((v) => !v)}
            className="ml-auto flex items-center gap-1.5 text-sm text-slate-500 hover:text-blue-600 transition-colors"
          >
            <MessageCircle className="h-4 w-4" />
            {post.commentCount > 0 && post.commentCount}
          </button>
        </div>

        {/* Comments section */}
        {showComments && (
          <CommentsSection
            postId={post.id}
            eventId={eventId}
            viewerId={viewerId}
            commentCount={post.commentCount}
          />
        )}
      </div>

      {/* Report dialog */}
      {showReportMenu && (
        <div className="border-t border-border bg-red-50 p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-red-800">Report this memory</p>
            <button onClick={() => setShowReportMenu(false)} className="text-red-400 hover:text-red-600">
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="flex flex-col gap-1">
            {REPORT_REASONS.map((r) => (
              <button
                key={r.value}
                onClick={() => handleReport(r.value)}
                className="text-left px-3 py-2 rounded-lg text-sm text-red-700 hover:bg-red-100 transition-colors"
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </article>
  );
}

// ─── Comments section ─────────────────────────────────────────────────────────

interface Comment {
  id: string;
  content: string;
  createdAt: string;
  author: { id: string; name: string; avatarUrl: string | null };
  parentId: string | null;
}

function CommentsSection({
  postId,
  eventId,
  viewerId,
  commentCount,
}: {
  postId: string;
  eventId: string;
  viewerId: string | null;
  commentCount: number;
}) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [newComment, setNewComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function loadComments() {
    const res = await fetch(`/api/events/${eventId}/memories/${postId}/comments`);
    const json = await res.json();
    setComments(json.data ?? []);
    setLoaded(true);
  }

  if (!loaded) {
    return (
      <button onClick={loadComments} className="text-xs text-blue-600 hover:underline self-start">
        {commentCount > 0 ? `View ${commentCount} comment${commentCount !== 1 ? "s" : ""}` : "Add a comment"}
      </button>
    );
  }

  async function submitComment(e: React.FormEvent) {
    e.preventDefault();
    if (!newComment.trim() || !viewerId) return;
    setIsSubmitting(true);
    const res = await fetch(`/api/events/${eventId}/memories/${postId}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: newComment.trim() }),
    });
    if (res.ok) {
      const json = await res.json();
      setComments((prev) => [...prev, json.data]);
      setNewComment("");
    }
    setIsSubmitting(false);
  }

  return (
    <div className="flex flex-col gap-3">
      {comments.map((c) => (
        <div key={c.id} className="flex gap-2.5">
          <Avatar name={c.author.name} src={c.author.avatarUrl} size="xs" className="shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <div className="rounded-xl bg-slate-50 px-3 py-2">
              <p className="text-xs font-semibold text-slate-900">{c.author.name}</p>
              <p className="text-sm text-slate-700 leading-snug">{c.content}</p>
            </div>
            <p className="mt-0.5 text-[11px] text-slate-400 px-1">{formatRelativeTime(new Date(c.createdAt))}</p>
          </div>
        </div>
      ))}

      {viewerId && (
        <form onSubmit={submitComment} className="flex gap-2 items-center">
          <input
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Add a comment…"
            maxLength={1000}
            className="flex-1 rounded-full border border-border bg-slate-50 px-3.5 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            type="submit"
            disabled={!newComment.trim() || isSubmitting}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blue-500 text-white disabled:opacity-40 hover:bg-blue-700 transition-colors"
          >
            {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </button>
        </form>
      )}
    </div>
  );
}
