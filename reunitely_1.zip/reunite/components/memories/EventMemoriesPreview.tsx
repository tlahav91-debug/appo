import { db } from "@/lib/db";
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/shared/EmptyState";
import { Image as ImageIcon, Plus } from "lucide-react";
import { Avatar } from "@/components/shared/Avatar";

interface EventMemoriesPreviewProps {
  eventId: string;
  eventSlug?: string;
}

export async function EventMemoriesPreview({ eventId, eventSlug }: EventMemoriesPreviewProps) {
  const [memories, totalCount] = await Promise.all([
    db.memoryPost.findMany({
      where: { eventId, status: "APPROVED", deletedAt: null },
      include: {
        author: { select: { name: true, avatarUrl: true } },
        media: {
          where: { status: "READY" },
          select: { cdnUrl: true, publicUrl: true, thumbnailUrl: true },
          orderBy: { createdAt: "asc" },
          take: 1,
        },
      },
      orderBy: [{ isFeatured: "desc" }, { createdAt: "desc" }],
      take: 6,
    }),
    db.memoryPost.count({ where: { eventId, status: "APPROVED", deletedAt: null } }),
  ]);

  if (memories.length === 0) {
    return (
      <EmptyState
        icon={<ImageIcon className="h-8 w-8" />}
        title="No memories yet"
        description="Be the first to add a memory from your school days."
        action={eventSlug ? { label: "Add a Memory", href: `/events/${eventSlug}/memories` } : undefined}
        size="md"
      />
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {memories.map((memory) => {
          const mediaUrl = memory.media[0]?.cdnUrl ?? memory.media[0]?.publicUrl ?? null;
          return (
            <Link
              key={memory.id}
              href={eventSlug ? `/events/${eventSlug}/memories` : "#"}
              className="group relative overflow-hidden rounded-xl border border-border bg-card"
            >
              {memory.type === "PHOTO" && mediaUrl ? (
                <div className="relative aspect-square">
                  <Image
                    src={mediaUrl}
                    alt={`Memory by ${memory.author.name}`}
                    fill
                    className="object-cover transition-transform group-hover:scale-105"
                    sizes="(max-width: 640px) 50vw, 33vw"
                  />
                  <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/60 to-transparent p-3 opacity-0 transition-opacity group-hover:opacity-100">
                    <div className="flex items-center gap-1.5">
                      <Avatar name={memory.author.name} src={memory.author.avatarUrl} size="xs" />
                      <p className="text-xs font-medium text-white">{memory.author.name}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex aspect-square flex-col justify-between bg-gradient-to-br from-blue-50 to-indigo-50 p-4">
                  <p className="line-clamp-4 text-sm text-slate-700 italic">"{memory.caption}"</p>
                  <div className="flex items-center gap-1.5 mt-2">
                    <Avatar name={memory.author.name} src={memory.author.avatarUrl} size="xs" />
                    <p className="text-xs text-slate-500">{memory.author.name}</p>
                  </div>
                </div>
              )}
            </Link>
          );
        })}
      </div>

      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-500">
          {totalCount > 6 ? `Showing 6 of ${totalCount} memories` : `${totalCount} ${totalCount === 1 ? "memory" : "memories"}`}
        </p>
        <div className="flex gap-2">
          {eventSlug && totalCount > 6 && (
            <Button asChild variant="outline" size="sm">
              <Link href={`/events/${eventSlug}/memories`}>View All</Link>
            </Button>
          )}
          {eventSlug && (
            <Button asChild size="sm">
              <Link href={`/events/${eventSlug}/memories`}>
                <Plus className="mr-1.5 h-3.5 w-3.5" /> Add Memory
              </Link>
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
