"use client";

import Image from "next/image";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CheckCircle, XCircle, Image as ImageIcon, Type, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/shared/Avatar";
import { EmptyState } from "@/components/shared/EmptyState";
import { toast } from "sonner";
import { formatRelativeTime } from "@/lib/utils";

interface PendingMemory {
  id: string;
  type: "PHOTO" | "TEXT" | "VIDEO_EMBED" | "COLLAGE";
  caption: string | null;
  media: Array<{ publicUrl: string | null; cdnUrl: string | null }>;
  videoEmbedUrl: string | null;
  yearContext: number | null;
  contextLabel: string | null;
  createdAt: string;
  author: { id: string; name: string; avatarUrl: string | null };
}

async function fetchPending(eventId: string): Promise<PendingMemory[]> {
  const res = await fetch(
    `/api/events/${eventId}/memories?status=PENDING&limit=50`
  );
  if (!res.ok) throw new Error("Failed to load pending memories");
  const json = await res.json(); return json.data?.posts ?? json.data?.items ?? [];
}

async function moderateMemory(
  memoryId: string,
  action: "approve" | "reject"
): Promise<void> {
  const res = await fetch(`/api/memories/${memoryId}/${action}`, {
    method: "POST",
  });
  if (!res.ok) throw new Error(`Failed to ${action} memory`);
}

export function MemoryModerationQueue({ eventId }: { eventId: string }) {
  const queryClient = useQueryClient();

  const { data: memories = [], isLoading } = useQuery<PendingMemory[]>({
    queryKey: ["memories-pending", eventId],
    queryFn: () => fetchPending(eventId),
    refetchInterval: 30_000,
  });

  const approveMutation = useMutation({
    mutationFn: (id: string) => moderateMemory(id, "approve"),
    onSuccess: (_, id) => {
      queryClient.setQueryData<PendingMemory[]>(
        ["memories-pending", eventId],
        (old) => old?.filter((m) => m.id !== id) ?? []
      );
      toast.success("Memory approved and published");
    },
    onError: () => toast.error("Failed to approve memory"),
  });

  const rejectMutation = useMutation({
    mutationFn: (id: string) => moderateMemory(id, "reject"),
    onSuccess: (_, id) => {
      queryClient.setQueryData<PendingMemory[]>(
        ["memories-pending", eventId],
        (old) => old?.filter((m) => m.id !== id) ?? []
      );
      toast.success("Memory rejected");
    },
    onError: () => toast.error("Failed to reject memory"),
  });

  async function approveAll() {
    for (const m of memories) {
      await moderateMemory(m.id, "approve");
    }
    queryClient.setQueryData(["memories-pending", eventId], []);
    toast.success(`Approved ${memories.length} memories`);
  }

  if (isLoading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div
            key={i}
            className="h-64 animate-pulse rounded-xl bg-slate-100"
          />
        ))}
      </div>
    );
  }

  if (memories.length === 0) {
    return (
      <EmptyState
        icon={<CheckCircle className="h-8 w-8 text-emerald-500" />}
        title="All caught up!"
        description="No memories are waiting for review. New submissions will appear here."
        size="lg"
      />
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Bulk action bar */}
      <div className="flex items-center justify-between rounded-xl border border-blue-200 bg-blue-50 px-4 py-3">
        <p className="text-sm font-medium text-blue-800">
          {memories.length} memor{memories.length !== 1 ? "ies" : "y"} awaiting
          review
        </p>
        <Button
          size="sm"
          variant="outline"
          className="border-blue-400 text-blue-700 hover:bg-blue-100"
          onClick={approveAll}
        >
          Approve all
        </Button>
      </div>

      {/* Memory cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {memories.map((memory) => (
          <MemoryCard
            key={memory.id}
            memory={memory}
            onApprove={() => approveMutation.mutate(memory.id)}
            onReject={() => rejectMutation.mutate(memory.id)}
            isApproving={
              approveMutation.isPending &&
              approveMutation.variables === memory.id
            }
            isRejecting={
              rejectMutation.isPending &&
              rejectMutation.variables === memory.id
            }
          />
        ))}
      </div>
    </div>
  );
}

// ─── MemoryCard ───────────────────────────────────────────────────────────────

function MemoryCard({
  memory,
  onApprove,
  onReject,
  isApproving,
  isRejecting,
}: {
  memory: PendingMemory;
  onApprove: () => void;
  onReject: () => void;
  isApproving: boolean;
  isRejecting: boolean;
}) {
  const typeIcon =
    memory.type === "PHOTO" ? (
      <ImageIcon className="h-3.5 w-3.5 text-blue-500" />
    ) : memory.type === "VIDEO_EMBED" ? (
      <Video className="h-3.5 w-3.5 text-violet-500" />
    ) : (
      <Type className="h-3.5 w-3.5 text-blue-500" />
    );

  return (
    <div className="flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-card">
      {/* Preview area */}
      <div className="relative h-44 bg-slate-100">
        {memory.type === "PHOTO" && (memory.media[0]?.cdnUrl ?? memory.media[0]?.publicUrl) ? (
          <Image
            src={(memory.media[0]?.cdnUrl ?? memory.media[0]?.publicUrl)}
            alt="Memory photo"
            fill
            className="object-cover"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          />
        ) : memory.type === "TEXT" ? (
          <div className="flex h-full items-center justify-center bg-blue-50 p-4">
            <p className="line-clamp-5 text-center text-sm italic text-slate-700">
              "{memory.caption}"
            </p>
          </div>
        ) : (
          <div className="flex h-full items-center justify-center">
            <Video className="h-10 w-10 text-slate-300" />
          </div>
        )}

        {/* Pending badge */}
        <div className="absolute left-2 top-2">
          <span className="rounded-full bg-blue-500 px-2 py-0.5 text-[10px] font-semibold text-slate-900">
            PENDING
          </span>
        </div>
      </div>

      {/* Meta */}
      <div className="flex flex-1 flex-col gap-3 p-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Avatar
              name={memory.author.name}
              src={memory.author.avatarUrl}
              size="xs"
            />
            <p className="truncate text-xs font-medium text-slate-700">
              {memory.author.name}
            </p>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            {typeIcon}
            <span className="text-[10px] text-slate-400">
              {formatRelativeTime(new Date(memory.createdAt))}
            </span>
          </div>
        </div>

        {memory.contextLabel && (
          <p className="text-xs text-slate-400">
            Context: {memory.contextLabel}
            {memory.yearContext ? ` · ${memory.yearContext}` : ""}
          </p>
        )}

        {/* Actions */}
        <div className="flex gap-2 mt-auto">
          <Button
            size="sm"
            variant="outline"
            className="flex-1 gap-1.5 border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300"
            onClick={onReject}
            disabled={isApproving || isRejecting}
          >
            <XCircle className="h-3.5 w-3.5" />
            {isRejecting ? "Rejecting…" : "Reject"}
          </Button>
          <Button
            size="sm"
            className="flex-1 gap-1.5 bg-emerald-600 text-white hover:bg-emerald-700"
            onClick={onApprove}
            disabled={isApproving || isRejecting}
          >
            <CheckCircle className="h-3.5 w-3.5" />
            {isApproving ? "Approving…" : "Approve"}
          </Button>
        </div>
      </div>
    </div>
  );
}
