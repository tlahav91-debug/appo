"use client";

import { useState, useRef, useCallback, useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form, FormField, FormItem, FormLabel, FormControl, FormDescription, FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  ImagePlus, Type, Film, X, Upload, Loader2, CheckCircle2,
  ArrowLeft, ArrowRight, Sparkles, Clock, Camera,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// ─── Types ────────────────────────────────────────────────────────────────────

type MemoryType = "PHOTO" | "TEXT" | "VIDEO_EMBED";
type UploadStep = "type" | "upload" | "details" | "done";

interface UploadedFile {
  file: File;
  preview: string;
  s3Key: string | null;
  publicUrl: string | null;
  progress: number; // 0-100
  error: string | null;
}

const MEMORY_TYPES = [
  {
    type: "PHOTO" as const,
    icon: Camera,
    label: "Photo",
    description: "Then, now, or both",
    emoji: "📸",
  },
  {
    type: "TEXT" as const,
    icon: Type,
    label: "Story",
    description: "A memory in words",
    emoji: "✍️",
  },
  {
    type: "VIDEO_EMBED" as const,
    icon: Film,
    label: "Video",
    description: "YouTube or Vimeo",
    emoji: "🎬",
  },
];

const MAX_FILE_SIZE_MB = 25;
const MAX_FILES = 10;
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];

// ─── Detail form schema ───────────────────────────────────────────────────────

const detailSchema = z.object({
  caption: z.string().max(2000).optional(),
  yearContext: z.coerce.number().int().min(1900).max(2100).optional().or(z.literal("")),
  contextLabel: z.string().max(100).optional(),
  content: z.string().max(2000).optional(),
  videoEmbedUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});
type DetailForm = z.infer<typeof detailSchema>;

// ─── Upload helpers ───────────────────────────────────────────────────────────

async function presignAndUpload(
  file: File,
  onProgress: (pct: number) => void
): Promise<{ s3Key: string; publicUrl: string }> {
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "jpg";

  // Get presigned URL
  const presignRes = await fetch("/api/upload", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      folder: "events/memories",
      contentType: file.type,
      fileSize: file.size,
      fileExtension: ext,
    }),
  });

  if (!presignRes.ok) {
    const err = await presignRes.json().catch(() => ({}));
    throw new Error(err.error?.message ?? "Failed to get upload URL");
  }

  const { data } = await presignRes.json();

  // Upload directly to S3/R2 with XHR for progress tracking
  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.upload.addEventListener("progress", (e) => {
      if (e.lengthComputable) {
        onProgress(Math.round((e.loaded / e.total) * 100));
      }
    });
    xhr.addEventListener("load", () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve();
      } else {
        reject(new Error(`Upload failed: ${xhr.status}`));
      }
    });
    xhr.addEventListener("error", () => reject(new Error("Network error")));
    xhr.open("PUT", data.uploadUrl);
    xhr.setRequestHeader("Content-Type", file.type);
    xhr.send(file);
  });

  return { s3Key: data.key, publicUrl: data.publicUrl };
}

// ─── Main component ───────────────────────────────────────────────────────────

interface MemoryUploadFlowProps {
  eventId: string;
  eventSlug: string;
  graduationYear: number;
  onSuccess: (post: { id: string; status: string }) => void;
  onCancel: () => void;
}

export function MemoryUploadFlow({
  eventId,
  eventSlug,
  graduationYear,
  onSuccess,
  onCancel,
}: MemoryUploadFlowProps) {
  const [step, setStep] = useState<UploadStep>("type");
  const [memoryType, setMemoryType] = useState<MemoryType>("PHOTO");
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [allUploaded, setAllUploaded] = useState(false);
  const [isPending, startTransition] = useTransition();
  const fileRef = useRef<HTMLInputElement>(null);

  const form = useForm<DetailForm>({
    resolver: zodResolver(detailSchema),
    defaultValues: {
      caption: "",
      yearContext: "",
      contextLabel: "",
      content: "",
      videoEmbedUrl: "",
    },
  });

  // ── File selection ──────────────────────────────────────────────────────────

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const selected = Array.from(e.target.files ?? []);
    const valid = selected.filter((f) => {
      if (!ALLOWED_TYPES.includes(f.type)) {
        toast.error(`${f.name}: unsupported format`);
        return false;
      }
      if (f.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
        toast.error(`${f.name}: too large (max ${MAX_FILE_SIZE_MB}MB)`);
        return false;
      }
      return true;
    });

    const newFiles: UploadedFile[] = valid.map((file) => ({
      file,
      preview: URL.createObjectURL(file),
      s3Key: null,
      publicUrl: null,
      progress: 0,
      error: null,
    }));

    setFiles((prev) => [...prev, ...newFiles].slice(0, MAX_FILES));
    setAllUploaded(false);
    e.target.value = "";
  }

  function removeFile(idx: number) {
    setFiles((prev) => {
      URL.revokeObjectURL(prev[idx]!.preview);
      return prev.filter((_, i) => i !== idx);
    });
    setAllUploaded(false);
  }

  // ── Upload all files ─────────────────────────────────────────────────────────

  async function uploadAllFiles() {
    if (files.length === 0) return;
    setIsUploading(true);

    const updated = [...files];
    let allOk = true;

    for (let i = 0; i < updated.length; i++) {
      if (updated[i]!.s3Key) continue; // Already uploaded

      try {
        const { s3Key, publicUrl } = await presignAndUpload(
          updated[i]!.file,
          (pct) => {
            setFiles((prev) => {
              const next = [...prev];
              next[i] = { ...next[i]!, progress: pct };
              return next;
            });
          }
        );
        updated[i] = { ...updated[i]!, s3Key, publicUrl, progress: 100, error: null };
      } catch (err) {
        updated[i] = {
          ...updated[i]!,
          error: err instanceof Error ? err.message : "Upload failed",
        };
        allOk = false;
      }
      setFiles([...updated]);
    }

    setIsUploading(false);
    if (allOk) setAllUploaded(true);
  }

  // ── Submit post ──────────────────────────────────────────────────────────────

  function submitPost(data: DetailForm) {
    startTransition(async () => {
      const s3Keys = files.map((f) => f.s3Key).filter(Boolean) as string[];

      const payload = {
        type: memoryType,
        caption: data.caption || undefined,
        yearContext: data.yearContext ? Number(data.yearContext) : undefined,
        contextLabel: data.contextLabel || undefined,
        content: memoryType === "TEXT" ? data.content : undefined,
        videoEmbedUrl: memoryType === "VIDEO_EMBED" ? (data.videoEmbedUrl || undefined) : undefined,
        s3Keys,
        taggedUserIds: [],
      };

      const res = await fetch(`/api/events/${eventId}/memories`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const json = await res.json().catch(() => ({}));
        toast.error(json.error?.message ?? "Failed to save memory");
        return;
      }

      const json = await res.json();
      setStep("done");
      onSuccess(json.data);
    });
  }

  // ─── Step renders ─────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col gap-5">
      {/* Progress dots */}
      {step !== "done" && (
        <div className="flex items-center gap-2">
          {(["type", "upload", "details"] as UploadStep[])
            .filter((s) => !(s === "upload" && memoryType !== "PHOTO"))
            .map((s, i, arr) => (
              <div key={s} className="flex items-center gap-2">
                <div className={cn(
                  "flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold transition-colors",
                  step === s
                    ? "bg-blue-500 text-white"
                    : arr.indexOf(step) > arr.indexOf(s)
                    ? "bg-blue-200 text-blue-700"
                    : "bg-slate-100 text-slate-400"
                )}>
                  {i + 1}
                </div>
                {i < arr.length - 1 && (
                  <div className={cn("h-0.5 w-8 rounded-full transition-colors",
                    arr.indexOf(step) > i ? "bg-blue-300" : "bg-slate-100"
                  )} />
                )}
              </div>
            ))}
        </div>
      )}

      {/* Step 1: Pick memory type */}
      {step === "type" && (
        <div className="flex flex-col gap-4">
          <h2 className="font-display text-lg font-bold text-slate-900">What kind of memory?</h2>
          <div className="grid grid-cols-3 gap-3">
            {MEMORY_TYPES.map(({ type, icon: Icon, label, description, emoji }) => (
              <button
                key={type}
                type="button"
                onClick={() => setMemoryType(type)}
                className={cn(
                  "flex flex-col items-center gap-2 rounded-2xl border-2 p-4 text-center transition-all",
                  memoryType === type
                    ? "border-blue-600 bg-blue-50"
                    : "border-border bg-white hover:border-blue-300 hover:bg-blue-50/50"
                )}
              >
                <span className="text-3xl" aria-hidden>{emoji}</span>
                <span className="text-sm font-semibold text-slate-900">{label}</span>
                <span className="text-[11px] text-slate-500">{description}</span>
              </button>
            ))}
          </div>
          <Button onClick={() => setStep(memoryType === "PHOTO" ? "upload" : "details")} size="lg" className="w-full gap-2">
            Continue <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Step 2: Photo upload */}
      {step === "upload" && memoryType === "PHOTO" && (
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-slate-900">Add your photos</h2>
            <button onClick={() => setStep("type")} className="flex items-center gap-1 text-sm text-slate-400 hover:text-slate-600">
              <ArrowLeft className="h-3.5 w-3.5" /> Back
            </button>
          </div>

          {/* Drop zone */}
          {files.length < MAX_FILES && (
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="flex flex-col items-center gap-3 rounded-2xl border-2 border-dashed border-blue-300 bg-blue-50/50 p-8 text-center hover:bg-blue-50 transition-colors"
            >
              <ImagePlus className="h-8 w-8 text-blue-400" />
              <div>
                <p className="text-sm font-semibold text-blue-800">Tap to add photos</p>
                <p className="text-xs text-blue-600 mt-0.5">
                  Up to {MAX_FILES} images · JPEG, PNG, WebP, GIF · {MAX_FILE_SIZE_MB}MB max
                </p>
              </div>
              <input
                ref={fileRef}
                type="file"
                accept={ALLOWED_TYPES.join(",")}
                multiple
                className="hidden"
                onChange={handleFileSelect}
              />
            </button>
          )}

          {/* File previews */}
          {files.length > 0 && (
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
              {files.map((f, i) => (
                <div key={i} className="relative aspect-square overflow-hidden rounded-xl border border-border">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={f.preview} alt="" className="h-full w-full object-cover" />

                  {/* Progress overlay */}
                  {f.progress > 0 && f.progress < 100 && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                      <div className="text-sm font-bold text-white">{f.progress}%</div>
                    </div>
                  )}
                  {f.s3Key && (
                    <div className="absolute bottom-1 right-1 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500">
                      <CheckCircle2 className="h-3 w-3 text-white" />
                    </div>
                  )}
                  {f.error && (
                    <div className="absolute inset-0 flex items-center justify-center bg-red-500/70">
                      <span className="text-[10px] text-white font-semibold px-1 text-center">{f.error}</span>
                    </div>
                  )}
                  {!isUploading && (
                    <button
                      onClick={() => removeFile(i)}
                      className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-black/60 hover:bg-black/80"
                      aria-label="Remove"
                    >
                      <X className="h-3 w-3 text-white" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            {!allUploaded && files.length > 0 && (
              <Button
                type="button"
                variant="outline"
                onClick={uploadAllFiles}
                disabled={isUploading}
                className="flex-1 gap-2"
              >
                {isUploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                {isUploading ? "Uploading…" : "Upload photos"}
              </Button>
            )}
            <Button
              type="button"
              onClick={() => setStep("details")}
              disabled={files.length === 0}
              className="flex-1 gap-2"
            >
              {allUploaded ? <>Next <ArrowRight className="h-4 w-4" /></> : "Skip to details"}
            </Button>
          </div>
        </div>
      )}

      {/* Step 3: Details */}
      {step === "details" && (
        <Form {...form}>
          <form onSubmit={form.handleSubmit(submitPost)} className="flex flex-col gap-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-bold text-slate-900">Add details</h2>
              <button
                type="button"
                onClick={() => setStep(memoryType === "PHOTO" ? "upload" : "type")}
                className="flex items-center gap-1 text-sm text-slate-400 hover:text-slate-600"
              >
                <ArrowLeft className="h-3.5 w-3.5" /> Back
              </button>
            </div>

            {/* Photo thumbnails reminder */}
            {memoryType === "PHOTO" && files.length > 0 && (
              <div className="flex gap-1.5 overflow-x-auto pb-1">
                {files.slice(0, 5).map((f, i) => (
                  <div key={i} className="h-14 w-14 shrink-0 overflow-hidden rounded-lg border border-border">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={f.preview} alt="" className="h-full w-full object-cover" />
                  </div>
                ))}
                {files.length > 5 && (
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-xs font-bold text-slate-500">
                    +{files.length - 5}
                  </div>
                )}
              </div>
            )}

            {/* Text content */}
            {memoryType === "TEXT" && (
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your memory <span className="text-red-400">*</span></FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Share a story, memory, or moment from your school days…"
                        rows={5}
                        className="resize-none"
                        maxLength={2000}
                        {...field}
                        value={field.value ?? ""}
                      />
                    </FormControl>
                    <div className="flex justify-end">
                      <span className="text-xs text-slate-400">{(field.value ?? "").length}/2000</span>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Video embed */}
            {memoryType === "VIDEO_EMBED" && (
              <FormField
                control={form.control}
                name="videoEmbedUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Video URL <span className="text-red-400">*</span></FormLabel>
                    <FormControl>
                      <Input
                        placeholder="https://youtube.com/watch?v=... or https://vimeo.com/..."
                        {...field}
                        value={field.value ?? ""}
                      />
                    </FormControl>
                    <FormDescription>YouTube and Vimeo links supported</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Caption */}
            <FormField
              control={form.control}
              name="caption"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Caption</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={
                        memoryType === "PHOTO"
                          ? "What's happening in this photo?"
                          : "Any additional context…"
                      }
                      rows={2}
                      className="resize-none"
                      maxLength={2000}
                      {...field}
                      value={field.value ?? ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Year + context */}
            <div className="grid grid-cols-2 gap-3">
              <FormField
                control={form.control}
                name="yearContext"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-1.5">
                      <Clock className="h-3.5 w-3.5 text-blue-500" />
                      Year
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder={graduationYear.toString()}
                        min={1900}
                        max={2100}
                        {...field}
                        value={field.value ?? ""}
                        onChange={(e) => field.onChange(e.target.value)}
                      />
                    </FormControl>
                    <FormDescription>When was this?</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="contextLabel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-1.5">
                      <Sparkles className="h-3.5 w-3.5 text-blue-500" />
                      Era
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g. Senior year"
                        maxLength={100}
                        {...field}
                        value={field.value ?? ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button type="submit" size="lg" className="w-full gap-2" disabled={isPending}>
              {isPending ? (
                <><Loader2 className="h-4 w-4 animate-spin" /> Saving…</>
              ) : (
                "Share Memory"
              )}
            </Button>
          </form>
        </Form>
      )}

      {/* Done state */}
      {step === "done" && (
        <div className="flex flex-col items-center gap-5 py-6 text-center">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-blue-100">
            <span className="text-4xl" aria-hidden>🎉</span>
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-slate-900">Memory shared!</h2>
            <p className="mt-1.5 text-sm text-slate-500 max-w-xs">
              It's been submitted for review. Once approved by the organizer it will appear on the memory wall.
            </p>
          </div>
          <Button variant="outline" onClick={onCancel}>Back to memory wall</Button>
        </div>
      )}
    </div>
  );
}
