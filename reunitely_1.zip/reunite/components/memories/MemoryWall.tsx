"use client";

import { useState, useEffect, useRef } from "react";
import { Plus, Loader2, Camera, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MemoryPostCard } from "@/components/memories/MemoryPostCard";
import { MemoryUploadFlow } from "@/components/memories/MemoryUploadFlow";
import { EmptyState } from "@/components/shared/EmptyState";
import { cn } from "@/lib/utils";
import type { MemoryPostWithMedia } from "@/lib/services/memory.service";

interface MemoryWallProps {
  eventId: string;
  eventSlug: string;
  graduationYear: number;
  viewerId: string | null;
  isOrganizer: boolean;
  isAttendee: boolean;
  autoApprove: boolean;
  initialPosts: MemoryPostWithMedia[];
  initialCursor: string | null;
  featuredPosts: MemoryPostWithMedia[];
}

export function MemoryWall({
  eventId,
  eventSlug,
  graduationYear,
  viewerId,
  isOrganizer,
  isAttendee,
  autoApprove,
  initialPosts,
  initialCursor,
  featuredPosts,
}: MemoryWallProps) {
  const [posts, setPosts] = useState<MemoryPostWithMedia[]>(initialPosts);
  const [cursor, setCursor] = useState<string | null>(initialCursor);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(!!initialCursor);
  const [showUpload, setShowUpload] = useState(false);
  const loaderRef = useRef<HTMLDivElement>(null);

  // ── Infinite scroll ─────────────────────────────────────────────────────────
  useEffect(() => {
    if (!hasMore || isLoading) return;
    const observer = new IntersectionObserver(
      (entries) => { if (entries[0]?.isIntersecting) loadMore(); },
      { threshold: 0.1 }
    );
    if (loaderRef.current) observer.observe(loaderRef.current);
    return () => observer.disconnect();
  }, [cursor, hasMore, isLoading]);

  async function loadMore() {
    if (!cursor || isLoading) return;
    setIsLoading(true);
    try {
      const res = await fetch(
        `/api/events/${eventId}/memories?cursor=${cursor}&limit=20`
      );
      const json = await res.json();
      const { posts: newPosts, nextCursor } = json.data as {
        posts: MemoryPostWithMedia[];
        nextCursor: string | null;
      };
      setPosts((prev) => {
        const ids = new Set(prev.map((p) => p.id));
        return [...prev, ...newPosts.filter((p) => !ids.has(p.id))];
      });
      setCursor(nextCursor);
      setHasMore(!!nextCursor);
    } catch {
      // silent
    } finally {
      setIsLoading(false);
    }
  }

  function handlePostCreated(result: { id: string; status: string }) {
    if (result.status === "APPROVED") {
      // Reload to pick up the new post
      window.location.reload();
    } else {
      setShowUpload(false);
    }
  }

  function handleDelete(id: string) {
    setPosts((prev) => prev.filter((p) => p.id !== id));
  }

  function handleFeature(id: string, featured: boolean) {
    setPosts((prev) => prev.map((p) => (p.id === id ? { ...p, isFeatured: featured } : p)));
  }

  // ── Upload modal ────────────────────────────────────────────────────────────
  if (showUpload) {
    return (
      <div className="max-w-lg mx-auto">
        <div className="mb-4 flex items-center gap-3">
          <button
            onClick={() => setShowUpload(false)}
            className="text-sm text-slate-400 hover:text-slate-600 transition-colors"
          >
            ← Cancel
          </button>
          <h2 className="font-display text-lg font-bold text-slate-900">Share a Memory</h2>
        </div>
        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <MemoryUploadFlow
            eventId={eventId}
            eventSlug={eventSlug}
            graduationYear={graduationYear}
            onSuccess={handlePostCreated}
            onCancel={() => setShowUpload(false)}
          />
        </div>
      </div>
    );
  }

  // ── Wall ────────────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col gap-8">
      {/* Header + upload CTA */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-900">Memory Wall</h2>
          <p className="text-sm text-slate-400 mt-0.5">
            {posts.length > 0 ? `${posts.length}+ memories shared` : "Be the first to share"}
          </p>
        </div>
        {isAttendee && (
          <Button
            onClick={() => setShowUpload(true)}
            className="gap-2 shrink-0"
            size="sm"
          >
            <Plus className="h-4 w-4" />
            Add Memory
          </Button>
        )}
      </div>

      {/* Featured memories horizontal scroll */}
      {featuredPosts.length > 0 && (
        <section>
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="h-4 w-4 text-blue-500" />
            <h3 className="text-sm font-semibold text-slate-700">Featured memories</h3>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 sm:mx-0 sm:px-0 sm:flex-wrap">
            {featuredPosts.map((post) => (
              <div key={post.id} className="w-72 shrink-0 sm:w-auto sm:flex-1 sm:min-w-64">
                <MemoryPostCard
                  post={post}
                  eventId={eventId}
                  viewerId={viewerId}
                  isOrganizer={isOrganizer}
                  onDelete={handleDelete}
                  onFeature={handleFeature}
                />
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Pending moderation notice */}
      {isAttendee && !autoApprove && !isOrganizer && (
        <div className="rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">
          📸 <strong>Heads up:</strong> New memories are reviewed before appearing here.
          Yours will show up once approved.
        </div>
      )}

      {/* Main feed */}
      {posts.length === 0 ? (
        <EmptyState
          icon={<Camera className="h-9 w-9" />}
          title="No memories yet"
          description={
            isAttendee
              ? "Share your first photo, story, or video memory from school."
              : "Memories shared by attendees will appear here."
          }
          action={
            isAttendee
              ? { label: "Share First Memory", href: "#", onClick: () => setShowUpload(true) }
              : undefined
          }
          size="lg"
        />
      ) : (
        <>
          {/* Masonry-style grid */}
          <div className="columns-1 gap-4 sm:columns-2 xl:columns-3 space-y-4">
            {posts.map((post) => (
              <div key={post.id} className="break-inside-avoid">
                <MemoryPostCard
                  post={post}
                  eventId={eventId}
                  viewerId={viewerId}
                  isOrganizer={isOrganizer}
                  onDelete={handleDelete}
                  onFeature={handleFeature}
                />
              </div>
            ))}
          </div>

          {/* Load more sentinel */}
          <div ref={loaderRef} className="flex justify-center py-4">
            {isLoading && <Loader2 className="h-5 w-5 animate-spin text-slate-300" />}
            {!hasMore && posts.length > 6 && (
              <p className="text-xs text-slate-300">All memories loaded</p>
            )}
          </div>
        </>
      )}

      {/* Not-yet-attendee gate */}
      {!isAttendee && !isOrganizer && (
        <div className="rounded-2xl border border-dashed border-blue-300 bg-blue-50 p-6 text-center mt-2">
          <p className="text-sm font-semibold text-blue-900 mb-1">
            RSVP to share your memories
          </p>
          <p className="text-xs text-blue-700 mb-4">
            Only confirmed attendees can add memories.
          </p>
          <Button asChild size="sm" variant="outline" className="border-blue-300 text-blue-700">
            <a href={`/events/${eventSlug}/rsvp`}>RSVP Now</a>
          </Button>
        </div>
      )}
    </div>
  );
}
