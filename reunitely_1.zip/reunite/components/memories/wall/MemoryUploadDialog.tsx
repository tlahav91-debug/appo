"use client";

import { useRef, useState, useTransition, useCallback } from "react";
import {
  Upload, X, Image as ImageIcon, Type, Star, Loader2,
  ChevronLeft, ChevronRight, Plus, Check,
} from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useUpload } from "@/hooks/useUpload";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

type PostType = "PHOTO" | "TEXT" | "COLLAGE";
type Step = "type" | "upload" | "details" | "done";

interface MemoryUploadDialogProps {
  open: boolean;
  onClose: () => void;
  eventId: string;
  eventSlug: string;
  graduationYear: number;
}

const REACTION_EMOJIS = ["❤️", "😂", "😢", "🔥", "👏", "😮"];

export function MemoryUploadDialog({
  open,
  onClose,
  eventId,
  eventSlug,
  graduationYear,
}: MemoryUploadDialogProps) {
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [step, setStep] = useState<Step>("type");
  const [postType, setPostType] = useState<PostType>("PHOTO");
  const [caption, setCaption] = useState("");
  const [yearContext, setYearContext] = useState<number | undefined>();
  const [contextLabel, setContextLabel] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const [isSubmitting, startSubmit] = useTransition();

  const { files, upload, remove, reset, isUploading, error, clearError, progress } = useUpload({
    folder: "events/memories",
    maxFiles: postType === "COLLAGE" ? 6 : 10,
  });

  function handleClose() {
    reset();
    setStep("type");
    setCaption("");
    setYearContext(undefined);
    setContextLabel("");
    onClose();
  }

  async function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const selected = Array.from(e.target.files ?? []);
    if (selected.length === 0) return;
    await upload(selected);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  async function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setIsDragging(false);
    const dropped = Array.from(e.dataTransfer.files).filter((f) =>
      f.type.startsWith("image/")
    );
    if (dropped.length > 0) await upload(dropped);
  }

  function handleSubmit() {
    startSubmit(async () => {
      const body = {
        type: postType,
        content: caption.trim() || undefined,
        mediaUrls: files.map((f) => f.publicUrl),
        s3Keys: files.map((f) => f.s3Key),
        yearContext: yearContext ?? graduationYear,
        textContext: contextLabel.trim() || undefined,
        taggedUserIds: [],
      };

      const res = await fetch(`/api/events/${eventId}/memories`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const json = await res.json().catch(() => ({}));
        toast.error(json.error?.message ?? "Failed to post memory");
        return;
      }

      const { data } = await res.json();
      const isPending = data.status === "PENDING";

      queryClient.invalidateQueries({ queryKey: ["memories", eventId] });
      setStep("done");

      if (isPending) {
        toast.success("Memory submitted! It'll appear once an organizer approves it.");
      } else {
        toast.success("Memory posted to the wall 🎉");
      }
    });
  }

  const canProceedToDetails =
    postType === "TEXT" || (postType !== "TEXT" && files.length > 0);

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto p-0">
        {step !== "done" && (
          <DialogHeader className="px-6 pt-6 pb-0">
            <div className="flex items-center gap-3">
              {step !== "type" && (
                <button
                  onClick={() => setStep(step === "details" ? (postType === "TEXT" ? "type" : "upload") : "type")}
                  className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-slate-100 transition-colors"
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
              )}
              <DialogTitle className="text-base font-semibold">
                {step === "type" ? "Share a Memory" : step === "upload" ? "Add Photos" : "Add Details"}
              </DialogTitle>
            </div>
            {/* Progress bar */}
            <div className="flex gap-1 mt-4">
              {["type", "upload", "details"].map((s, i) => {
                const steps = postType === "TEXT" ? ["type", "details"] : ["type", "upload", "details"];
                const stepIndex = steps.indexOf(step);
                const barIndex = postType === "TEXT"
                  ? i < 2 ? (i === 0 ? 0 : 2) : -1
                  : i;
                return barIndex >= 0 ? (
                  <div
                    key={s}
                    className={cn(
                      "h-1 flex-1 rounded-full transition-colors",
                      steps.indexOf(step) >= (postType === "TEXT" ? [0,2].indexOf(barIndex) : barIndex)
                        ? "bg-blue-500"
                        : "bg-slate-200"
                    )}
                  />
                ) : null;
              })}
            </div>
          </DialogHeader>
        )}

        <div className="px-6 pb-6 pt-5">
          {/* ── Step: Type selection ────────────────────────────────────── */}
          {step === "type" && (
            <div className="flex flex-col gap-4">
              <p className="text-sm text-slate-500">
                What kind of memory do you want to share?
              </p>
              <div className="grid grid-cols-1 gap-3">
                {[
                  {
                    type: "PHOTO" as PostType,
                    icon: "📷",
                    title: "Photo(s)",
                    desc: "Upload one or more photos from then or now",
                  },
                  {
                    type: "COLLAGE" as PostType,
                    icon: "🖼️",
                    title: "Before & After",
                    desc: "Side-by-side then and now — up to 6 photos",
                  },
                  {
                    type: "TEXT" as PostType,
                    icon: "✍️",
                    title: "Written Memory",
                    desc: "Share a story, funny moment, or heartfelt note",
                  },
                ].map(({ type, icon, title, desc }) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => {
                      setPostType(type);
                      setStep(type === "TEXT" ? "details" : "upload");
                    }}
                    className="flex items-center gap-4 rounded-xl border-2 border-border px-4 py-3.5 text-left hover:border-blue-300 hover:bg-blue-50/40 transition-all group"
                  >
                    <span className="text-2xl">{icon}</span>
                    <div>
                      <p className="text-sm font-semibold text-slate-900 group-hover:text-blue-700">
                        {title}
                      </p>
                      <p className="text-xs text-slate-500 mt-0.5">{desc}</p>
                    </div>
                    <ChevronRight className="ml-auto h-4 w-4 text-slate-300 group-hover:text-blue-400" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ── Step: Photo upload ──────────────────────────────────────── */}
          {step === "upload" && (
            <div className="flex flex-col gap-4">
              {/* Drop zone */}
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                onClick={() => files.length < (postType === "COLLAGE" ? 6 : 10) && fileInputRef.current?.click()}
                className={cn(
                  "flex flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed p-8 text-center cursor-pointer transition-all",
                  isDragging ? "border-blue-400 bg-blue-50" : "border-slate-200 hover:border-blue-300 hover:bg-slate-50"
                )}
              >
                {isUploading ? (
                  <>
                    <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                    <p className="text-sm text-slate-500">Uploading… {progress}%</p>
                  </>
                ) : (
                  <>
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
                      <ImageIcon className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-700">
                        Drop photos here or tap to browse
                      </p>
                      <p className="text-xs text-slate-400 mt-0.5">
                        JPEG, PNG, WebP · Max 25MB each
                        {postType === "COLLAGE" ? " · Up to 6" : " · Up to 10"}
                      </p>
                    </div>
                  </>
                )}
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp,image/gif"
                multiple={postType !== "TEXT"}
                className="sr-only"
                onChange={handleFileSelect}
              />

              {/* Error */}
              {error && (
                <div className="flex items-center justify-between rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
                  {error}
                  <button onClick={clearError} className="ml-2">
                    <X className="h-4 w-4" />
                  </button>
                </div>
              )}

              {/* Photo preview grid */}
              {files.length > 0 && (
                <div className={cn(
                  "grid gap-2",
                  postType === "COLLAGE"
                    ? files.length === 1 ? "grid-cols-1" : "grid-cols-2"
                    : "grid-cols-3"
                )}>
                  {files.map((f, i) => (
                    <div key={f.s3Key} className="relative aspect-square overflow-hidden rounded-xl bg-slate-100">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={f.previewUrl}
                        alt={`Photo ${i + 1}`}
                        className="h-full w-full object-cover"
                      />
                      <button
                        onClick={(e) => { e.stopPropagation(); remove(f.s3Key); }}
                        className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors"
                        aria-label="Remove photo"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                      {postType === "COLLAGE" && (
                        <div className="absolute bottom-1.5 left-1.5 rounded-full bg-black/60 px-1.5 py-0.5 text-[9px] font-medium text-white">
                          {i === 0 ? "Then" : i === 1 ? "Now" : `+${i}`}
                        </div>
                      )}
                    </div>
                  ))}
                  {files.length < (postType === "COLLAGE" ? 6 : 10) && (
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="flex aspect-square items-center justify-center rounded-xl border-2 border-dashed border-slate-200 text-slate-400 hover:border-blue-300 hover:text-blue-500 transition-colors"
                      aria-label="Add more photos"
                    >
                      <Plus className="h-6 w-6" />
                    </button>
                  )}
                </div>
              )}

              <Button
                onClick={() => setStep("details")}
                disabled={files.length === 0 || isUploading}
                className="w-full"
                size="lg"
              >
                {isUploading ? "Uploading…" : `Continue with ${files.length} photo${files.length !== 1 ? "s" : ""}`}
              </Button>
            </div>
          )}

          {/* ── Step: Details ───────────────────────────────────────────── */}
          {step === "details" && (
            <div className="flex flex-col gap-5">
              {/* Preview thumbnail(s) */}
              {files.length > 0 && (
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {files.slice(0, 4).map((f, i) => (
                    <div key={f.s3Key} className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={f.previewUrl} alt="" className="h-full w-full object-cover" />
                    </div>
                  ))}
                  {files.length > 4 && (
                    <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-sm font-medium text-slate-500">
                      +{files.length - 4}
                    </div>
                  )}
                </div>
              )}

              {/* Caption */}
              <div>
                <Label className="text-sm font-medium">
                  {postType === "TEXT" ? "Your memory" : "Caption"}{" "}
                  {postType === "TEXT" && <span className="text-red-400">*</span>}
                </Label>
                <Textarea
                  placeholder={
                    postType === "TEXT"
                      ? "Share a school memory, funny moment, or heartfelt note…"
                      : "Add a caption — what's happening in this photo?"
                  }
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  rows={postType === "TEXT" ? 5 : 3}
                  maxLength={2000}
                  className="mt-1.5 resize-none"
                  autoFocus
                />
                <div className="flex justify-between mt-1">
                  <span className="text-[11px] text-slate-400">
                    {postType !== "TEXT" && "Optional"}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {caption.length}/2000
                  </span>
                </div>
              </div>

              {/* Year context */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-sm font-medium">Year (approx.)</Label>
                  <Input
                    type="number"
                    min={1950}
                    max={new Date().getFullYear()}
                    placeholder={graduationYear.toString()}
                    value={yearContext ?? ""}
                    onChange={(e) =>
                      setYearContext(e.target.value ? parseInt(e.target.value) : undefined)
                    }
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium">Context label</Label>
                  <Input
                    placeholder="e.g. Prom night, Grade 10"
                    value={contextLabel}
                    onChange={(e) => setContextLabel(e.target.value)}
                    maxLength={100}
                    className="mt-1.5"
                  />
                </div>
              </div>

              {/* Safe content note */}
              <p className="text-[11px] text-slate-400">
                Memories are reviewed by organizers before appearing on the wall.
                Please only share content you have permission to post.
              </p>

              <Button
                onClick={handleSubmit}
                disabled={
                  isSubmitting ||
                  (postType === "TEXT" && !caption.trim()) ||
                  (postType !== "TEXT" && files.length === 0)
                }
                className="w-full gap-2"
                size="lg"
              >
                {isSubmitting ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Posting…</>
                ) : (
                  "Share Memory 🎉"
                )}
              </Button>
            </div>
          )}

          {/* ── Step: Done ──────────────────────────────────────────────── */}
          {step === "done" && (
            <div className="flex flex-col items-center gap-5 py-4 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-100">
                <span className="text-3xl" aria-hidden>🎉</span>
              </div>
              <div>
                <h3 className="font-display text-xl font-bold text-slate-900">Memory shared!</h3>
                <p className="text-sm text-slate-500 mt-1.5 max-w-xs mx-auto">
                  It'll appear on the memory wall once an organizer gives it the green light.
                </p>
              </div>
              <div className="flex gap-2 w-full">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    reset();
                    setStep("type");
                    setCaption("");
                    setYearContext(undefined);
                    setContextLabel("");
                  }}
                >
                  Share another
                </Button>
                <Button className="flex-1" onClick={handleClose}>
                  Done
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
