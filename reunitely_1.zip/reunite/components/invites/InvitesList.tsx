"use client";

import { useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Mail, MessageSquare, Link2, QrCode,
  RefreshCw, MoreHorizontal, CheckCircle2, Clock,
  AlertCircle, XCircle, ArrowUpRight, Loader2, Search,
  Filter,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar } from "@/components/shared/Avatar";
import { EmptyState } from "@/components/shared/EmptyState";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { formatRelativeTime, cn } from "@/lib/utils";

// ─── Types ────────────────────────────────────────────────────────────────────

interface InviteDelivery {
  status: string;
  sentAt: string | null;
  deliveredAt: string | null;
  failureReason: string | null;
}

interface InviteItem {
  id: string;
  email: string | null;
  phone: string | null;
  channel: "EMAIL" | "SMS" | "WHATSAPP" | "LINK" | "QR_CODE";
  status: string;
  sentAt: string | null;
  deliveredAt: string | null;
  openedAt: string | null;
  rsvpdAt: string | null;
  personalMessage: string | null;
  invitedBy: { name: string; avatarUrl: string | null };
  deliveries: InviteDelivery[];
  referralLink: { code: string; label: string | null } | null;
}

// ─── Status config ────────────────────────────────────────────────────────────

const STATUS_CONFIG: Record<string, { label: string; className: string; icon: React.ElementType }> = {
  PENDING:   { label: "Pending",   className: "bg-slate-100 text-slate-500",   icon: Clock },
  SENT:      { label: "Sent",      className: "bg-blue-50 text-blue-600",      icon: ArrowUpRight },
  DELIVERED: { label: "Delivered", className: "bg-indigo-50 text-indigo-600",  icon: CheckCircle2 },
  OPENED:    { label: "Opened",    className: "bg-blue-50 text-blue-700",    icon: ArrowUpRight },
  RSVPD:     { label: "RSVP'd",   className: "bg-emerald-50 text-emerald-700", icon: CheckCircle2 },
  BOUNCED:   { label: "Bounced",   className: "bg-red-50 text-red-600",        icon: AlertCircle },
  SPAM:      { label: "Spam",      className: "bg-red-50 text-red-600",        icon: XCircle },
  EXPIRED:   { label: "Expired",   className: "bg-slate-100 text-slate-400",   icon: Clock },
};

const CHANNEL_CONFIG: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  EMAIL:    { label: "Email",    icon: Mail,           color: "text-blue-500" },
  SMS:      { label: "SMS",      icon: MessageSquare,  color: "text-green-500" },
  WHATSAPP: { label: "WhatsApp", icon: MessageSquare,  color: "text-emerald-500" },
  LINK:     { label: "Link",     icon: Link2,          color: "text-slate-500" },
  QR_CODE:  { label: "QR Code",  icon: QrCode,         color: "text-slate-500" },
};

const ALL_STATUSES = ["SENT", "DELIVERED", "OPENED", "RSVPD", "PENDING", "BOUNCED", "EXPIRED"];

// ─── Fetchers ─────────────────────────────────────────────────────────────────

async function fetchInvites(
  eventId: string,
  status?: string,
  search?: string
): Promise<{ invites: InviteItem[]; nextCursor: string | null }> {
  const params = new URLSearchParams({ limit: "100" });
  if (status) params.set("status", status);
  if (search) params.set("search", search);
  const res = await fetch(`/api/events/${eventId}/invites?${params}`);
  if (!res.ok) throw new Error("Failed to load invites");
  return (await res.json()).data;
}

async function resendInviteApi(eventId: string, inviteId: string) {
  const res = await fetch(
    `/api/events/${eventId}/invites/resend?inviteId=${inviteId}`,
    { method: "POST" }
  );
  if (!res.ok) {
    const json = await res.json().catch(() => ({}));
    throw new Error(json.error?.message ?? "Failed to resend");
  }
}

// ─── Component ────────────────────────────────────────────────────────────────

export function InvitesList({ eventId }: { eventId: string }) {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  const handleSearch = useCallback((val: string) => {
    setSearch(val);
    clearTimeout((handleSearch as { t?: ReturnType<typeof setTimeout> }).t);
    (handleSearch as { t?: ReturnType<typeof setTimeout> }).t = setTimeout(
      () => setDebouncedSearch(val),
      300
    );
  }, []);

  const { data, isLoading } = useQuery({
    queryKey: ["invites", eventId, statusFilter, debouncedSearch],
    queryFn: () => fetchInvites(eventId, statusFilter, debouncedSearch),
    staleTime: 30_000,
  });

  const resendMutation = useMutation({
    mutationFn: (inviteId: string) => resendInviteApi(eventId, inviteId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invites", eventId] });
      toast.success("Invite resent");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const invites = data?.invites ?? [];

  return (
    <div className="flex flex-col gap-4">
      {/* Filters */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <Input
            placeholder="Search by email or phone…"
            value={search}
            onChange={(e) => handleSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {["", ...ALL_STATUSES].map((s) => (
            <button
              key={s || "all"}
              type="button"
              onClick={() => setStatusFilter(s)}
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                statusFilter === s
                  ? "border-blue-600 bg-blue-50 text-blue-700"
                  : "border-border text-slate-600 hover:border-blue-300"
              )}
            >
              {s ? (STATUS_CONFIG[s]?.label ?? s) : "All"}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-slate-300" />
        </div>
      ) : invites.length === 0 ? (
        <EmptyState
          icon={<Mail className="h-8 w-8" />}
          title={statusFilter || search ? "No invites match" : "No invites sent yet"}
          description={
            statusFilter || search
              ? "Try a different filter or search term."
              : "Use the buttons above to invite classmates via email, SMS, or a shareable link."
          }
          size="md"
        />
      ) : (
        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <table className="w-full" aria-label="Invites">
            <thead>
              <tr className="border-b border-border bg-slate-50">
                {["Recipient", "Channel", "Status", "Timeline", ""].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {invites.map((invite) => (
                <InviteRow
                  key={invite.id}
                  invite={invite}
                  onResend={() => resendMutation.mutate(invite.id)}
                  isResending={resendMutation.isPending && resendMutation.variables === invite.id}
                />
              ))}
            </tbody>
          </table>
          <div className="border-t border-border bg-slate-50 px-4 py-2 text-right text-xs text-slate-400">
            {invites.length} invite{invites.length !== 1 ? "s" : ""} shown
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Row ──────────────────────────────────────────────────────────────────────

function InviteRow({
  invite,
  onResend,
  isResending,
}: {
  invite: InviteItem;
  onResend: () => void;
  isResending: boolean;
}) {
  const statusCfg = STATUS_CONFIG[invite.status] ?? STATUS_CONFIG["PENDING"]!;
  const channelCfg = CHANNEL_CONFIG[invite.channel] ?? CHANNEL_CONFIG["EMAIL"]!;
  const StatusIcon = statusCfg.icon;
  const ChannelIcon = channelCfg.icon;

  const canResend = ["SENT", "DELIVERED", "OPENED", "BOUNCED", "EXPIRED"].includes(invite.status);
  const latestDelivery = invite.deliveries[0];

  return (
    <tr className="hover:bg-slate-50/60 transition-colors">
      {/* Recipient */}
      <td className="px-4 py-3">
        <div className="flex items-center gap-2.5">
          <Avatar
            name={invite.email ?? invite.phone ?? "?"}
            size="xs"
          />
          <div className="min-w-0">
            <p className="text-sm font-medium text-slate-900 truncate max-w-[200px]">
              {invite.email ?? invite.phone ?? "—"}
            </p>
            {invite.referralLink && (
              <p className="text-[10px] text-blue-600">
                via ref: {invite.referralLink.label ?? invite.referralLink.code}
              </p>
            )}
          </div>
        </div>
      </td>

      {/* Channel */}
      <td className="px-4 py-3">
        <span className={cn("flex items-center gap-1.5 text-xs font-medium", channelCfg.color)}>
          <ChannelIcon className="h-3.5 w-3.5" />
          {channelCfg.label}
        </span>
      </td>

      {/* Status */}
      <td className="px-4 py-3">
        <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium", statusCfg.className)}>
          <StatusIcon className="h-3 w-3" />
          {statusCfg.label}
        </span>
        {latestDelivery?.failureReason && (
          <p className="text-[10px] text-red-500 mt-0.5 truncate max-w-[120px]" title={latestDelivery.failureReason}>
            {latestDelivery.failureReason}
          </p>
        )}
      </td>

      {/* Timeline */}
      <td className="px-4 py-3">
        <div className="flex flex-col gap-0.5 text-[11px] text-slate-400">
          {invite.sentAt && (
            <span>Sent {formatRelativeTime(new Date(invite.sentAt))}</span>
          )}
          {invite.openedAt && (
            <span className="text-blue-600">Opened {formatRelativeTime(new Date(invite.openedAt))}</span>
          )}
          {invite.rsvpdAt && (
            <span className="text-emerald-600">RSVP'd {formatRelativeTime(new Date(invite.rsvpdAt))}</span>
          )}
        </div>
      </td>

      {/* Actions */}
      <td className="px-4 py-3">
        {canResend && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7" disabled={isResending}>
                {isResending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <MoreHorizontal className="h-4 w-4" />
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              <DropdownMenuItem onClick={onResend} className="gap-2">
                <RefreshCw className="h-3.5 w-3.5" />
                Resend invite
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </td>
    </tr>
  );
}
