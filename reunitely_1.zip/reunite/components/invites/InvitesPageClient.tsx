"use client";

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Mail, Upload, Link2, Share2 } from "lucide-react";
import { InvitesList } from "@/components/invites/InvitesList";
import { SendInvitesButton } from "@/components/invites/SendInvitesButton";
import { CsvImportFlow } from "@/components/invites/CsvImportFlow";
import { ReferralLinksPanel } from "@/components/invites/ReferralLinksPanel";
import { InviteShareCard } from "@/components/invites/InviteShareCard";
import { cn } from "@/lib/utils";

type Tab = "send" | "import" | "referrals" | "share";

const TABS: Array<{ id: Tab; label: string; icon: React.ElementType }> = [
  { id: "send",      label: "Send Invites",    icon: Mail },
  { id: "import",    label: "CSV Import",       icon: Upload },
  { id: "referrals", label: "Referral Links",   icon: Link2 },
  { id: "share",     label: "Share Link",       icon: Share2 },
];

interface InvitesPageClientProps {
  eventId: string;
  eventSlug: string;
}

export function InvitesPageClient({ eventId, eventSlug }: InvitesPageClientProps) {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<Tab>("send");
  const [showImportFlow, setShowImportFlow] = useState(false);
  const [importChannel, setImportChannel] = useState<"EMAIL" | "SMS">("EMAIL");

  function handleImportComplete(result: { sent: number; skipped: number }) {
    setShowImportFlow(false);
    setActiveTab("send");
    queryClient.invalidateQueries({ queryKey: ["invites", eventId] });
    queryClient.invalidateQueries({ queryKey: ["invite-stats", eventId] });
  }

  return (
    <div className="flex flex-col gap-5">
      {/* Tab bar */}
      <div className="-mx-4 overflow-x-auto md:-mx-6 lg:-mx-8">
        <div className="flex min-w-max border-b border-border px-4 md:px-6 lg:px-8">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setActiveTab(tab.id);
                  setShowImportFlow(false);
                }}
                className={cn(
                  "flex items-center gap-1.5 border-b-2 px-4 py-2.5 text-sm font-medium whitespace-nowrap transition-colors",
                  active
                    ? "border-blue-600 text-blue-700"
                    : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
                )}
                aria-selected={active}
                role="tab"
              >
                <Icon className="h-3.5 w-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab content */}
      {activeTab === "send" && (
        <div className="flex flex-col gap-5">
          {/* Invite action buttons */}
          <div className="flex flex-wrap gap-2">
            <SendInvitesButton eventId={eventId} />
          </div>
          {/* Invite list */}
          <InvitesList eventId={eventId} />
        </div>
      )}

      {activeTab === "import" && (
        <div className="rounded-2xl border border-border bg-card p-6">
          {showImportFlow ? (
            <CsvImportFlow
              eventId={eventId}
              channel={importChannel}
              onComplete={handleImportComplete}
              onCancel={() => setShowImportFlow(false)}
            />
          ) : (
            <div className="flex flex-col gap-5">
              <div>
                <h3 className="text-base font-semibold text-slate-900">Import from CSV</h3>
                <p className="text-sm text-slate-500 mt-1">
                  Upload a spreadsheet of email addresses or phone numbers.
                  We'll validate, deduplicate, and give you a chance to review before sending.
                </p>
              </div>

              {/* Channel selection */}
              <div>
                <p className="text-sm font-medium text-slate-700 mb-2">Send via</p>
                <div className="flex gap-2">
                  {(["EMAIL", "SMS"] as const).map((ch) => (
                    <button
                      key={ch}
                      type="button"
                      onClick={() => setImportChannel(ch)}
                      className={cn(
                        "rounded-lg border-2 px-4 py-2.5 text-sm font-medium transition-colors",
                        importChannel === ch
                          ? "border-blue-600 bg-blue-50 text-blue-700"
                          : "border-border text-slate-600 hover:border-blue-300"
                      )}
                    >
                      {ch === "EMAIL" ? "📧 Email" : "💬 SMS"}
                    </button>
                  ))}
                </div>
              </div>

              {/* Format guide */}
              <div className="rounded-xl bg-slate-50 border border-border p-4">
                <p className="text-xs font-semibold text-slate-600 mb-2">
                  Expected CSV format ({importChannel === "EMAIL" ? "email" : "phone"})
                </p>
                <pre className="text-xs font-mono text-slate-500 leading-5">
                  {importChannel === "EMAIL"
                    ? "email,name\nalice@example.com,Alice Smith\nbob@example.com,Bob Jones"
                    : "phone,name\n+12125551234,Alice Smith\n+13105559876,Bob Jones"}
                </pre>
                <p className="text-[11px] text-slate-400 mt-2">
                  Column headers are flexible — we auto-detect email, phone, and name columns.
                  {importChannel === "SMS" && " Phone numbers must be in international E.164 format (e.g. +12125551234)."}
                </p>
              </div>

              {/* Compliance notice */}
              <div className="rounded-xl border border-blue-200 bg-blue-50 p-4 text-xs text-blue-800">
                <p className="font-semibold mb-1">Consent & compliance</p>
                <p>
                  By importing contacts you confirm that all recipients have consented to be
                  contacted about this event, and that you have the right to send them communications.
                  Only people who knew you when the list was built should be included —
                  purchased or scraped contact lists are not permitted.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowImportFlow(true)}
                className="self-start flex items-center gap-2 rounded-lg bg-blue-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 transition-colors"
              >
                <Upload className="h-4 w-4" />
                Upload CSV file
              </button>
            </div>
          )}
        </div>
      )}

      {activeTab === "referrals" && (
        <div className="rounded-2xl border border-border bg-card p-6">
          <ReferralLinksPanel eventId={eventId} />
        </div>
      )}

      {activeTab === "share" && (
        <div className="max-w-lg">
          <InviteShareCard eventSlug={eventSlug} eventId={eventId} />
        </div>
      )}
    </div>
  );
}
