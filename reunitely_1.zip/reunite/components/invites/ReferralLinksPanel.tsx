"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link2, Plus, Copy, Check, QrCode, Loader2, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar } from "@/components/shared/Avatar";
import { EmptyState } from "@/components/shared/EmptyState";
import { toast } from "sonner";
import { formatRelativeTime } from "@/lib/utils";

interface ReferralLink {
  id: string;
  code: string;
  label: string | null;
  clickCount: number;
  rsvpCount: number;
  isActive: boolean;
  expiresAt: string | null;
  createdAt: string;
  createdBy: { name: string; avatarUrl: string | null };
  _count: { invites: number };
}

async function fetchReferralLinks(eventId: string): Promise<ReferralLink[]> {
  const res = await fetch(`/api/events/${eventId}/referral-links`);
  if (!res.ok) throw new Error("Failed to load referral links");
  return (await res.json()).data ?? [];
}

async function createLink(eventId: string, label?: string): Promise<{ code: string; url: string }> {
  const res = await fetch(`/api/events/${eventId}/referral-links`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ label }),
  });
  if (!res.ok) throw new Error("Failed to create link");
  return (await res.json()).data;
}

export function ReferralLinksPanel({ eventId }: { eventId: string }) {
  const queryClient = useQueryClient();
  const [newLabel, setNewLabel] = useState("");
  const [creating, setCreating] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const { data: links = [], isLoading } = useQuery({
    queryKey: ["referral-links", eventId],
    queryFn: () => fetchReferralLinks(eventId),
    staleTime: 60_000,
  });

  const createMutation = useMutation({
    mutationFn: (label?: string) => createLink(eventId, label),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["referral-links", eventId] });
      navigator.clipboard.writeText(data.url).catch(() => {});
      toast.success(`Referral link created and copied! (/${data.code})`);
      setNewLabel("");
      setCreating(false);
    },
    onError: () => toast.error("Failed to create referral link"),
  });

  async function copyLink(code: string) {
    const url = `${window.location.origin}/r/${code}`;
    await navigator.clipboard.writeText(url);
    setCopiedCode(code);
    toast.success("Referral link copied");
    setTimeout(() => setCopiedCode(null), 2000);
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">Referral Links</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Unique trackable links — see who's bringing people to the reunion.
          </p>
        </div>
        <Button
          size="sm"
          variant="outline"
          className="gap-2"
          onClick={() => setCreating(true)}
        >
          <Plus className="h-3.5 w-3.5" />
          New Link
        </Button>
      </div>

      {/* Create form */}
      {creating && (
        <div className="rounded-xl border border-blue-200 bg-blue-50 p-4">
          <p className="text-sm font-medium text-blue-900 mb-3">New referral link</p>
          <div className="flex gap-2">
            <Input
              placeholder="Label (e.g. 'Alice's link', 'Facebook post')"
              value={newLabel}
              onChange={(e) => setNewLabel(e.target.value)}
              className="bg-white"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === "Enter") createMutation.mutate(newLabel || undefined);
                if (e.key === "Escape") setCreating(false);
              }}
            />
            <Button
              size="sm"
              onClick={() => createMutation.mutate(newLabel || undefined)}
              disabled={createMutation.isPending}
              className="shrink-0"
            >
              {createMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                "Create"
              )}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setCreating(false)}
              className="shrink-0"
            >
              Cancel
            </Button>
          </div>
        </div>
      )}

      {/* Links list */}
      {isLoading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-5 w-5 animate-spin text-slate-300" />
        </div>
      ) : links.length === 0 ? (
        <EmptyState
          icon={<Link2 className="h-6 w-6" />}
          title="No referral links yet"
          description="Create a link for each channel or person to track where RSVPs come from."
          size="sm"
        />
      ) : (
        <div className="flex flex-col gap-2">
          {links.map((link) => (
            <div
              key={link.id}
              className="flex items-center gap-3 rounded-xl border border-border bg-card px-4 py-3"
            >
              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <Link2 className="h-3.5 w-3.5 text-blue-500 shrink-0" />
                  <p className="text-sm font-medium text-slate-900 truncate">
                    {link.label ?? "/r/" + link.code}
                  </p>
                  <code className="text-[10px] text-slate-400 font-mono shrink-0">
                    /{link.code}
                  </code>
                </div>
                <div className="flex items-center gap-4 mt-1">
                  <span className="text-xs text-slate-500 flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    {link.clickCount} click{link.clickCount !== 1 ? "s" : ""}
                  </span>
                  <span className="text-xs text-emerald-600 font-medium">
                    {link.rsvpCount} RSVP{link.rsvpCount !== 1 ? "s" : ""}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    by {link.createdBy.name} · {formatRelativeTime(new Date(link.createdAt))}
                  </span>
                </div>
              </div>

              {/* Conversion rate */}
              {link.clickCount > 0 && (
                <div className="text-center shrink-0">
                  <p className="text-sm font-bold text-slate-900">
                    {Math.round((link.rsvpCount / link.clickCount) * 100)}%
                  </p>
                  <p className="text-[10px] text-slate-400">conversion</p>
                </div>
              )}

              {/* Copy button */}
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8 shrink-0"
                onClick={() => copyLink(link.code)}
                aria-label="Copy referral link"
              >
                {copiedCode === link.code ? (
                  <Check className="h-3.5 w-3.5 text-emerald-500" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
