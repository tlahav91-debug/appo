"use client";

import { useState, useTransition, useRef } from "react";
import { Upload, FileText, AlertCircle, CheckCircle2, XCircle, ArrowRight, Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";

interface ParsedRow {
  rowIndex: number;
  email?: string;
  phone?: string;
  name?: string;
}

interface InvalidRow {
  rowIndex: number;
  raw: Record<string, string>;
  errors: string[];
}

interface DuplicateRow {
  rowIndex: number;
  email?: string;
  phone?: string;
  name?: string;
  reason: string;
}

interface ParseResult {
  total: number;
  validCount: number;
  invalidCount: number;
  duplicateCount: number;
  valid: ParsedRow[];
  invalid: InvalidRow[];
  duplicates: DuplicateRow[];
}

interface CsvImportFlowProps {
  eventId: string;
  channel: "EMAIL" | "SMS";
  onComplete: (result: { sent: number; skipped: number }) => void;
  onCancel: () => void;
}

type Stage = "upload" | "review" | "sending" | "done";

export function CsvImportFlow({ eventId, channel, onComplete, onCancel }: CsvImportFlowProps) {
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [stage, setStage] = useState<Stage>("upload");
  const [parseResult, setParseResult] = useState<ParseResult | null>(null);
  const [isParsing, startParse] = useTransition();
  const [isSending, startSend] = useTransition();
  const [isDragging, setIsDragging] = useState(false);
  const [sendResult, setSendResult] = useState<{ sent: number; skipped: number } | null>(null);

  async function parseFile(file: File) {
    if (!file.name.endsWith(".csv") && file.type !== "text/csv") {
      toast.error("Please upload a .csv file");
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      toast.error("CSV file must be under 2 MB");
      return;
    }

    startParse(async () => {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch(`/api/events/${eventId}/invites/import`, {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        toast.error("Failed to parse CSV file");
        return;
      }

      const json = await res.json();
      setParseResult(json.data);
      setStage("review");
    });
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) parseFile(file);
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) parseFile(file);
  }

  function handleSend() {
    if (!parseResult || parseResult.validCount === 0) return;

    startSend(async () => {
      setStage("sending");

      const res = await fetch(`/api/events/${eventId}/invites`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          channel,
          recipients: parseResult.valid.map((r) => ({
            email: r.email,
            phone: r.phone,
            name: r.name,
          })),
          consentConfirmed: true,
        }),
      });

      if (!res.ok) {
        toast.error("Failed to send invites");
        setStage("review");
        return;
      }

      const json = await res.json();
      const result = { sent: json.data.sent, skipped: json.data.skipped };
      setSendResult(result);
      setStage("done");

      queryClient.invalidateQueries({ queryKey: ["invites", eventId] });
      onComplete(result);
    });
  }

  // ── Upload stage ──────────────────────────────────────────────────────────

  if (stage === "upload") {
    return (
      <div className="flex flex-col gap-6">
        <div>
          <h3 className="text-base font-semibold text-slate-900">Import from CSV</h3>
          <p className="text-sm text-slate-500 mt-1">
            Upload a CSV with an <code className="rounded bg-slate-100 px-1 py-0.5 text-xs">email</code> column
            {channel === "SMS" && <> or <code className="rounded bg-slate-100 px-1 py-0.5 text-xs">phone</code> column</>}.
            Other columns like <code className="rounded bg-slate-100 px-1 py-0.5 text-xs">name</code> are
            automatically detected.
          </p>
        </div>

        {/* Drop zone */}
        <label
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={cn(
            "flex flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed p-12 text-center cursor-pointer transition-colors",
            isDragging
              ? "border-blue-400 bg-blue-50"
              : "border-slate-300 hover:border-blue-300 hover:bg-slate-50"
          )}
        >
          {isParsing ? (
            <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
          ) : (
            <Upload className="h-8 w-8 text-slate-400" />
          )}
          <div>
            <p className="text-sm font-medium text-slate-700">
              {isParsing ? "Parsing…" : "Drop CSV here or click to browse"}
            </p>
            <p className="text-xs text-slate-400 mt-0.5">
              Max 2 MB · Supports comma-separated values
            </p>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,text/csv"
            className="sr-only"
            onChange={handleFileChange}
            disabled={isParsing}
          />
        </label>

        {/* Template download */}
        <div className="rounded-lg border border-border bg-slate-50 px-4 py-3">
          <p className="text-xs text-slate-600 font-medium mb-1">Expected CSV format:</p>
          <code className="block text-xs text-slate-500 font-mono">
            email,name{channel === "SMS" ? ",phone" : ""}<br />
            alice@example.com,Alice Smith{channel === "SMS" ? ",+12125551234" : ""}<br />
            bob@example.com,Bob Jones{channel === "SMS" ? ",+13105559876" : ""}
          </code>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
        </div>
      </div>
    );
  }

  // ── Review stage ──────────────────────────────────────────────────────────

  if (stage === "review" && parseResult) {
    return (
      <div className="flex flex-col gap-5">
        <div>
          <h3 className="text-base font-semibold text-slate-900">Review import</h3>
          <p className="text-sm text-slate-500 mt-1">
            Parsed {parseResult.total} rows from your CSV.
          </p>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-3 gap-3">
          <SummaryCard
            count={parseResult.validCount}
            label="Ready to send"
            color="emerald"
            icon={CheckCircle2}
          />
          <SummaryCard
            count={parseResult.duplicateCount}
            label="Skipped (already invited)"
            color="blue"
            icon={AlertCircle}
          />
          <SummaryCard
            count={parseResult.invalidCount}
            label="Invalid rows"
            color="red"
            icon={XCircle}
          />
        </div>

        {/* Invalid rows */}
        {parseResult.invalid.length > 0 && (
          <details className="rounded-xl border border-red-200 bg-red-50 overflow-hidden">
            <summary className="flex items-center gap-2 px-4 py-3 text-sm font-medium text-red-800 cursor-pointer list-none">
              <XCircle className="h-4 w-4 shrink-0" />
              {parseResult.invalid.length} invalid row{parseResult.invalid.length !== 1 ? "s" : ""} — will not be sent
            </summary>
            <div className="px-4 pb-4">
              <div className="mt-2 max-h-40 overflow-y-auto rounded-lg border border-red-200 bg-white">
                {parseResult.invalid.slice(0, 20).map((row) => (
                  <div key={row.rowIndex} className="border-b border-red-100 last:border-0 px-3 py-2">
                    <p className="text-xs font-mono text-slate-600">
                      Row {row.rowIndex}: {Object.values(row.raw).join(", ")}
                    </p>
                    <p className="text-[11px] text-red-600 mt-0.5">{row.errors.join(" · ")}</p>
                  </div>
                ))}
              </div>
            </div>
          </details>
        )}

        {/* Duplicates */}
        {parseResult.duplicates.length > 0 && (
          <details className="rounded-xl border border-blue-200 bg-blue-50 overflow-hidden">
            <summary className="flex items-center gap-2 px-4 py-3 text-sm font-medium text-blue-800 cursor-pointer list-none">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {parseResult.duplicates.length} duplicate{parseResult.duplicates.length !== 1 ? "s" : ""} — will be skipped
            </summary>
            <div className="px-4 pb-4">
              <div className="mt-2 max-h-40 overflow-y-auto rounded-lg border border-blue-200 bg-white">
                {parseResult.duplicates.slice(0, 20).map((row) => (
                  <div key={row.rowIndex} className="border-b border-blue-100 last:border-0 px-3 py-2 flex items-center justify-between">
                    <p className="text-xs text-slate-700">{row.email ?? row.phone}</p>
                    <p className="text-[11px] text-blue-600">
                      {row.reason === "already_invited"
                        ? "Already invited"
                        : row.reason === "already_rsvpd"
                        ? "Already RSVP'd"
                        : "Duplicate in file"}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </details>
        )}

        {/* Valid preview */}
        {parseResult.valid.length > 0 && (
          <div className="rounded-xl border border-border overflow-hidden">
            <div className="bg-slate-50 px-4 py-2.5 text-xs font-semibold text-slate-600 uppercase tracking-wider">
              Ready to invite ({parseResult.validCount})
            </div>
            <div className="max-h-48 overflow-y-auto">
              {parseResult.valid.slice(0, 50).map((row) => (
                <div key={row.rowIndex} className="flex items-center justify-between border-b border-border last:border-0 px-4 py-2.5">
                  <p className="text-sm text-slate-700">{row.email ?? row.phone}</p>
                  {row.name && <p className="text-xs text-slate-400">{row.name}</p>}
                </div>
              ))}
              {parseResult.valid.length > 50 && (
                <p className="px-4 py-2 text-xs text-slate-400 text-center">
                  and {parseResult.valid.length - 50} more…
                </p>
              )}
            </div>
          </div>
        )}

        {parseResult.validCount === 0 && (
          <div className="rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">
            No valid recipients found. Fix the errors above and try again.
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <Button
            variant="outline"
            className="gap-2"
            onClick={() => {
              setStage("upload");
              setParseResult(null);
              if (fileInputRef.current) fileInputRef.current.value = "";
            }}
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Upload different file
          </Button>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={onCancel}>Cancel</Button>
            <Button
              onClick={handleSend}
              disabled={parseResult.validCount === 0}
              className="gap-2"
            >
              Send {parseResult.validCount} invite{parseResult.validCount !== 1 ? "s" : ""}
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // ── Sending stage ─────────────────────────────────────────────────────────

  if (stage === "sending") {
    return (
      <div className="flex flex-col items-center gap-4 py-8 text-center">
        <Loader2 className="h-10 w-10 animate-spin text-blue-500" />
        <p className="text-sm font-medium text-slate-700">Sending invites…</p>
        <p className="text-xs text-slate-400">This may take a moment for large lists.</p>
      </div>
    );
  }

  // ── Done stage ────────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col items-center gap-4 py-8 text-center">
      <div className="h-16 w-16 rounded-full bg-emerald-100 flex items-center justify-center">
        <CheckCircle2 className="h-8 w-8 text-emerald-500" />
      </div>
      <div>
        <p className="text-lg font-semibold text-slate-900">
          {sendResult?.sent ?? 0} invite{(sendResult?.sent ?? 0) !== 1 ? "s" : ""} sent
        </p>
        {(sendResult?.skipped ?? 0) > 0 && (
          <p className="text-sm text-slate-500 mt-0.5">
            {sendResult!.skipped} skipped (already invited)
          </p>
        )}
      </div>
      <Button onClick={() => onComplete(sendResult ?? { sent: 0, skipped: 0 })}>
        Done
      </Button>
    </div>
  );
}

// ─── Helper ────────────────────────────────────────────────────────────────

function SummaryCard({
  count,
  label,
  color,
  icon: Icon,
}: {
  count: number;
  label: string;
  color: "emerald" | "blue" | "red";
  icon: React.ElementType;
}) {
  const colors = {
    emerald: "bg-emerald-50 text-emerald-700 border-emerald-200",
    blue: "bg-blue-50 text-blue-700 border-blue-200",
    red: "bg-red-50 text-red-600 border-red-200",
  };
  const numColors = {
    emerald: "text-emerald-700",
    blue: "text-blue-700",
    red: "text-red-600",
  };

  return (
    <div className={cn("rounded-xl border p-4 text-center", colors[color])}>
      <p className={cn("font-display text-2xl font-bold", numColors[color])}>{count}</p>
      <div className="flex items-center justify-center gap-1 mt-1">
        <Icon className="h-3.5 w-3.5" />
        <p className="text-[11px] font-medium leading-tight">{label}</p>
      </div>
    </div>
  );
}
