"use client";

import { useState, useTransition } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";
import { Plus, Send, X, Loader2, Mail } from "lucide-react";
import { toast } from "sonner";

const inviteFormSchema = z.object({
  recipients: z
    .array(
      z.object({
        email: z.string().email("Valid email required"),
        name: z.string().max(100).optional(),
      })
    )
    .min(1, "Add at least one recipient")
    .max(50, "Maximum 50 recipients per batch"),
  message: z.string().max(300).optional(),
});

type InviteFormData = z.infer<typeof inviteFormSchema>;

async function sendInvites(
  eventId: string,
  data: InviteFormData
): Promise<void> {
  const res = await fetch(`/api/events/${eventId}/invites`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      channel: "EMAIL",
      recipients: data.recipients,
      message: data.message,
      consentConfirmed: true,
    }),
  });
  if (!res.ok) {
    const json = await res.json().catch(() => ({}));
    throw new Error(json.error?.message ?? "Failed to send invites");
  }
}

export function SendInvitesButton({ eventId }: { eventId: string }) {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();

  const form = useForm<InviteFormData>({
    resolver: zodResolver(inviteFormSchema),
    defaultValues: {
      recipients: [{ email: "", name: "" }],
      message: "",
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "recipients",
  });

  function handleClose() {
    setOpen(false);
    form.reset();
  }

  function handleSubmit(data: InviteFormData) {
    startTransition(async () => {
      try {
        await sendInvites(eventId, data);
        const count = data.recipients.length;
        toast.success(`Sent ${count} invite${count !== 1 ? "s" : ""}`);
        handleClose();
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Failed to send invites");
      }
    });
  }

  function handlePaste(e: React.ClipboardEvent<HTMLInputElement>, index: number) {
    const text = e.clipboardData.getData("text");
    const emails = text
      .split(/[\n,;]+/)
      .map((s) => s.trim())
      .filter((s) => s.includes("@"));

    if (emails.length > 1) {
      e.preventDefault();
      const current = form.getValues("recipients");
      // Fill current field with first email, add rest
      const [first, ...rest] = emails;
      current[index]!.email = first ?? "";
      const newRecipients = [
        ...current,
        ...rest.slice(0, 49 - current.length).map((email) => ({ email, name: "" })),
      ];
      form.setValue("recipients", newRecipients);
    }
  }

  return (
    <>
      <Button onClick={() => setOpen(true)} className="gap-2">
        <Send className="h-4 w-4" />
        Send Invites
      </Button>

      <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-blue-500" />
              Send Invites
            </DialogTitle>
            <DialogDescription>
              Invitees will receive a personal link to RSVP. Paste multiple
              emails separated by commas or new lines.
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <div className="flex flex-col gap-4 py-2">
              {/* Recipients */}
              <div className="flex flex-col gap-2 max-h-64 overflow-y-auto">
                {fields.map((field, i) => (
                  <div key={field.id} className="flex items-start gap-2">
                    <div className="flex flex-1 gap-2">
                      <FormField
                        control={form.control}
                        name={`recipients.${i}.email`}
                        render={({ field: f }) => (
                          <FormItem className="flex-1">
                            {i === 0 && (
                              <FormLabel className="text-xs">Email</FormLabel>
                            )}
                            <FormControl>
                              <Input
                                type="email"
                                placeholder="classmate@example.com"
                                className="text-sm"
                                {...f}
                                onPaste={(e) => handlePaste(e, i)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`recipients.${i}.name`}
                        render={({ field: f }) => (
                          <FormItem className="w-32">
                            {i === 0 && (
                              <FormLabel className="text-xs">
                                Name{" "}
                                <span className="text-slate-400">(opt)</span>
                              </FormLabel>
                            )}
                            <FormControl>
                              <Input
                                placeholder="Name"
                                className="text-sm"
                                {...f}
                                value={f.value ?? ""}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    {fields.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className={`h-9 w-9 shrink-0 text-slate-400 hover:text-red-500 ${i === 0 ? "mt-5" : ""}`}
                        onClick={() => remove(i)}
                        aria-label="Remove recipient"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              {fields.length < 50 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="gap-1.5 self-start text-slate-500"
                  onClick={() => append({ email: "", name: "" })}
                >
                  <Plus className="h-3.5 w-3.5" />
                  Add another
                </Button>
              )}

              {/* Personal message */}
              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">
                      Personal message{" "}
                      <span className="font-normal text-slate-400">
                        (optional)
                      </span>
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Add a personal note to the invite email…"
                        rows={2}
                        className="resize-none text-sm"
                        maxLength={300}
                        {...field}
                        value={field.value ?? ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <p className="text-xs text-slate-400">
                By sending invites you confirm recipients have consented to
                receive email from you.
              </p>

              <div className="flex justify-end gap-2 pt-1">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={handleClose}
                  disabled={isPending}
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  onClick={form.handleSubmit(handleSubmit)}
                  disabled={isPending}
                  className="gap-2"
                >
                  {isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                  Send {fields.length > 1 ? `${fields.length} Invites` : "Invite"}
                </Button>
              </div>
            </div>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
}
