"use client";

import { useQuery } from "@tanstack/react-query";
import { Mail, Users, ArrowRight, CheckCircle2, Eye, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface InviteStats {
  total: number;
  conversionRate: number;
  byStatus: Record<string, number>;
  byChannel: Record<string, number>;
  referralPerformance: Array<{
    code: string;
    label: string | null;
    clickCount: number;
    rsvpCount: number;
  }>;
}

async function fetchStats(eventId: string): Promise<InviteStats> {
  const res = await fetch(`/api/events/${eventId}/invites/stats`);
  if (!res.ok) throw new Error("Failed to load stats");
  return (await res.json()).data;
}

const FUNNEL_STEPS = [
  { key: "SENT",      label: "Sent",      icon: Mail,         color: "text-blue-600",    bg: "bg-blue-50" },
  { key: "DELIVERED", label: "Delivered", icon: ArrowRight,   color: "text-indigo-600",  bg: "bg-indigo-50" },
  { key: "OPENED",    label: "Opened",    icon: Eye,          color: "text-blue-600",   bg: "bg-blue-50" },
  { key: "RSVPD",     label: "RSVP'd",   icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50" },
] as const;

export function InviteStatsPanel({ eventId }: { eventId: string }) {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["invite-stats", eventId],
    queryFn: () => fetchStats(eventId),
    staleTime: 60_000,
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-6">
        <Loader2 className="h-5 w-5 animate-spin text-slate-300" />
      </div>
    );
  }

  if (!stats || stats.total === 0) return null;

  const funnelTotal = stats.byStatus["SENT"] ?? stats.total;

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-slate-900">Invite funnel</h3>
        <span className="text-xs text-slate-500">
          {stats.total} total · <span className="text-emerald-600 font-semibold">{stats.conversionRate}%</span> conversion
        </span>
      </div>

      {/* Funnel bars */}
      <div className="flex flex-col gap-2">
        {FUNNEL_STEPS.map((step) => {
          const count = stats.byStatus[step.key] ?? 0;
          const pct = funnelTotal > 0 ? Math.round((count / funnelTotal) * 100) : 0;
          const Icon = step.icon;

          return (
            <div key={step.key} className="flex items-center gap-3">
              <div className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-full", step.bg)}>
                <Icon className={cn("h-3.5 w-3.5", step.color)} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium text-slate-700">{step.label}</span>
                  <span className="text-xs text-slate-500">{count} ({pct}%)</span>
                </div>
                <div className="h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className={cn("h-full rounded-full transition-all", step.bg.replace("50", "400"))}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Channel breakdown */}
      {Object.keys(stats.byChannel).length > 1 && (
        <div className="mt-4 pt-4 border-t border-border">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">By channel</p>
          <div className="flex flex-wrap gap-2">
            {Object.entries(stats.byChannel).map(([channel, count]) => (
              <span
                key={channel}
                className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-xs text-slate-600"
              >
                <Users className="h-3 w-3" />
                {channel}: {count}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
