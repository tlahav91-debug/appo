"use client";

import { useState } from "react";
import { Copy, Check, Link2, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { getEventUrl } from "@/lib/utils";

interface InviteShareCardProps {
  eventSlug: string;
  eventId: string;
}

export function InviteShareCard({ eventSlug }: InviteShareCardProps) {
  const [copied, setCopied] = useState(false);
  const eventUrl = getEventUrl(eventSlug);

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(eventUrl);
      setCopied(true);
      toast.success("Link copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Failed to copy — try selecting the text manually");
    }
  }

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex items-center gap-2 mb-3">
        <Link2 className="h-4 w-4 text-blue-500" />
        <h3 className="text-sm font-semibold text-slate-900">
          Shareable event link
        </h3>
      </div>

      <div className="flex items-center gap-2">
        <div className="flex-1 rounded-lg border border-border bg-slate-50 px-4 py-2.5 min-w-0">
          <p className="text-sm font-mono text-slate-600 truncate">{eventUrl}</p>
        </div>
        <Button
          variant="outline"
          size="icon"
          className="h-10 w-10 shrink-0"
          onClick={handleCopy}
          aria-label={copied ? "Copied" : "Copy link"}
        >
          {copied ? (
            <Check className="h-4 w-4 text-emerald-500" />
          ) : (
            <Copy className="h-4 w-4" />
          )}
        </Button>
      </div>

      <div className="flex flex-wrap gap-2 mt-3">
        <Button variant="outline" size="sm" className="gap-2" asChild>
          <a
            href={`https://wa.me/?text=${encodeURIComponent(`You're invited! ${eventUrl}`)}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Share2 className="h-3.5 w-3.5 text-emerald-500" />
            WhatsApp
          </a>
        </Button>
        <Button variant="outline" size="sm" className="gap-2" asChild>
          <a
            href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(eventUrl)}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Share2 className="h-3.5 w-3.5 text-blue-500" />
            Facebook
          </a>
        </Button>
        <Button variant="outline" size="sm" className="gap-2" asChild>
          <a
            href={`mailto:?subject=You're invited&body=${encodeURIComponent(`Join me! ${eventUrl}`)}`}
          >
            <Share2 className="h-3.5 w-3.5 text-slate-400" />
            Email
          </a>
        </Button>
      </div>

      <p className="mt-3 text-xs text-slate-400">
        Anyone with this link can view the event page. Change visibility in{" "}
        <a href="#settings" className="underline hover:text-slate-600">
          event settings
        </a>{" "}
        to restrict access.
      </p>
    </div>
  );
}
