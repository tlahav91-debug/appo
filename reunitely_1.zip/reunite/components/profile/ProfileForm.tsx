"use client";

import { useState, useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Download, Trash2, Camera } from "lucide-react";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/shared/Avatar";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

// ─── Schema ───────────────────────────────────────────────────────────────────

const profileSchema = z.object({
  // User-level
  name: z.string().min(1, "Name is required").max(100),
  username: z
    .string()
    .min(3, "Minimum 3 characters")
    .max(30)
    .regex(
      /^[a-z0-9_-]+$/,
      "Only lowercase letters, numbers, hyphens and underscores"
    )
    .optional()
    .or(z.literal("")),

  // AttendeeProfile fields
  bio: z.string().max(280, "Keep it under 280 characters").optional().or(z.literal("")),
  currentCity: z.string().max(100).optional().or(z.literal("")),
  currentCountry: z.string().max(100).optional().or(z.literal("")),
  currentJob: z.string().max(100).optional().or(z.literal("")),
  currentEmployer: z.string().max(100).optional().or(z.literal("")),
  funFact: z.string().max(200).optional().or(z.literal("")),
  favoriteMemory: z.string().max(500).optional().or(z.literal("")),
  linkedinUrl: z
    .string()
    .url("Must be a valid URL")
    .refine((v) => v.includes("linkedin.com"), "Must be a LinkedIn URL")
    .optional()
    .or(z.literal("")),
  instagramHandle: z
    .string()
    .max(30)
    .regex(/^[a-zA-Z0-9._]*$/, "Invalid Instagram handle")
    .optional()
    .or(z.literal("")),

  // Privacy
  showInDirectory: z.boolean().default(true),
  showCurrentJob: z.boolean().default(true),
  showCurrentCity: z.boolean().default(true),
  showSocialLinks: z.boolean().default(false),
  allowDirectMessages: z.boolean().default(true),
  allowPhotoTagging: z.boolean().default(true),
  allowNominations: z.boolean().default(true),
  profileVisibleTo: z
    .enum(["EVENT_ATTENDEES", "ORGANIZERS_ONLY", "NOBODY"])
    .default("EVENT_ATTENDEES"),
});

type ProfileFormData = z.infer<typeof profileSchema>;

// ─── Props ────────────────────────────────────────────────────────────────────

interface ExistingProfile {
  bio: string | null;
  currentCity: string | null;
  currentCountry: string | null;
  currentJob: string | null;
  currentEmployer: string | null;
  linkedinUrl: string | null;
  instagramHandle: string | null;
  funFact: string | null;
  favoriteMemory: string | null;
  showInDirectory: boolean;
  showCurrentJob: boolean;
  showCurrentCity: boolean;
  showSocialLinks: boolean;
  allowDirectMessages: boolean;
  allowPhotoTagging: boolean;
  allowNominations: boolean;
  profileVisibleTo: string;
}

interface ProfileFormProps {
  userId: string;
  userName: string;
  userEmail: string;
  userAvatar: string | null;
  existingProfile: ExistingProfile | null;
}

// ─── Component ────────────────────────────────────────────────────────────────

export function ProfileForm({
  userId,
  userName,
  userEmail,
  userAvatar,
  existingProfile,
}: ProfileFormProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [isDeleting, setIsDeleting] = useState(false);

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: userName,
      username: "",
      bio: existingProfile?.bio ?? "",
      currentCity: existingProfile?.currentCity ?? "",
      currentCountry: existingProfile?.currentCountry ?? "",
      currentJob: existingProfile?.currentJob ?? "",
      currentEmployer: existingProfile?.currentEmployer ?? "",
      funFact: existingProfile?.funFact ?? "",
      favoriteMemory: existingProfile?.favoriteMemory ?? "",
      linkedinUrl: existingProfile?.linkedinUrl ?? "",
      instagramHandle: existingProfile?.instagramHandle ?? "",
      showInDirectory: existingProfile?.showInDirectory ?? true,
      showCurrentJob: existingProfile?.showCurrentJob ?? true,
      showCurrentCity: existingProfile?.showCurrentCity ?? true,
      showSocialLinks: existingProfile?.showSocialLinks ?? false,
      allowDirectMessages: existingProfile?.allowDirectMessages ?? true,
      allowPhotoTagging: existingProfile?.allowPhotoTagging ?? true,
      allowNominations: existingProfile?.allowNominations ?? true,
      profileVisibleTo:
        (existingProfile?.profileVisibleTo as ProfileFormData["profileVisibleTo"]) ??
        "EVENT_ATTENDEES",
    },
    mode: "onTouched",
  });

  function handleSubmit(data: ProfileFormData) {
    startTransition(async () => {
      try {
        const res = await fetch("/api/profile", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
        if (!res.ok) {
          const json = await res.json().catch(() => ({}));
          throw new Error(json.error?.message ?? "Failed to save profile");
        }
        toast.success("Profile updated");
        router.refresh();
      } catch (err) {
        toast.error(
          err instanceof Error ? err.message : "Failed to save profile"
        );
      }
    });
  }

  async function handleDeleteAccount() {
    setIsDeleting(true);
    try {
      const res = await fetch("/api/profile", { method: "DELETE" });
      if (!res.ok) throw new Error("Deletion failed");
      toast.success("Account deleted. You'll be signed out shortly.");
      setTimeout(() => (window.location.href = "/"), 2000);
    } catch {
      toast.error("Failed to delete account. Please contact support.");
    } finally {
      setIsDeleting(false);
    }
  }

  const bio = form.watch("bio") ?? "";

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(handleSubmit)}
        className="flex flex-col gap-8 mt-6"
      >
        {/* ── Avatar ────────────────────────────────────────────────────── */}
        <div className="flex items-center gap-4">
          <Avatar name={userName} src={userAvatar} size="xl" />
          <div>
            <p className="text-sm font-semibold text-slate-900">{userName}</p>
            <p className="text-xs text-slate-500">{userEmail}</p>
            <p className="text-[10px] text-slate-400 mt-1">
              Avatar is managed through your Clerk account settings
            </p>
          </div>
        </div>

        {/* ── Basic info ────────────────────────────────────────────────── */}
        <Section title="Basic Information">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Full name</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="bio"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bio</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="A brief intro for your classmates at events you attend"
                    rows={2}
                    className="resize-none"
                    maxLength={280}
                    {...field}
                    value={field.value ?? ""}
                  />
                </FormControl>
                <div className="flex justify-end">
                  <span className="text-xs text-slate-400">
                    {bio.length}/280
                  </span>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="currentCity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Current city</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="San Francisco"
                      {...field}
                      value={field.value ?? ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="currentCountry"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Country</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="United States"
                      {...field}
                      value={field.value ?? ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="currentJob"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Job title</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Software Engineer"
                      {...field}
                      value={field.value ?? ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="currentEmployer"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Employer</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Acme Corp"
                      {...field}
                      value={field.value ?? ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="funFact"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Fun fact</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Something interesting your classmates might not know"
                    {...field}
                    value={field.value ?? ""}
                    maxLength={200}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="favoriteMemory"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Favorite school memory</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="What's the one memory from school you'll never forget?"
                    rows={2}
                    className="resize-none"
                    maxLength={500}
                    {...field}
                    value={field.value ?? ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </Section>

        {/* ── Social links ──────────────────────────────────────────────── */}
        <Section title="Social Links">
          <FormField
            control={form.control}
            name="linkedinUrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>LinkedIn</FormLabel>
                <FormControl>
                  <Input
                    placeholder="https://linkedin.com/in/yourname"
                    {...field}
                    value={field.value ?? ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="instagramHandle"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Instagram</FormLabel>
                <FormControl>
                  <div className="flex">
                    <span className="flex items-center px-3 rounded-l-md border border-r-0 border-input bg-slate-50 text-sm text-slate-500">
                      @
                    </span>
                    <Input
                      placeholder="yourhandle"
                      className="rounded-l-none"
                      {...field}
                      value={field.value ?? ""}
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </Section>

        {/* ── Privacy ───────────────────────────────────────────────────── */}
        <Section title="Privacy Settings">
          <p className="text-xs text-slate-500 -mt-2 mb-2">
            These settings apply to your profile as shown to classmates in
            events you attend.
          </p>

          <FormField
            control={form.control}
            name="profileVisibleTo"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Profile visible to</FormLabel>
                <FormControl>
                  <div className="grid grid-cols-3 gap-2" role="radiogroup">
                    {[
                      { value: "EVENT_ATTENDEES", label: "Attendees" },
                      { value: "ORGANIZERS_ONLY", label: "Organizers" },
                      { value: "NOBODY", label: "Nobody" },
                    ].map((opt) => (
                      <button
                        key={opt.value}
                        type="button"
                        role="radio"
                        aria-checked={field.value === opt.value}
                        onClick={() => field.onChange(opt.value)}
                        className={`rounded-lg border-2 px-3 py-2 text-sm font-medium transition-all ${
                          field.value === opt.value
                            ? "border-blue-600 bg-blue-50 text-blue-700"
                            : "border-border text-slate-600 hover:border-blue-300"
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="rounded-xl border border-border divide-y divide-border overflow-hidden">
            {[
              {
                name: "showInDirectory" as const,
                label: "Show in attendee directory",
                description: "Appear in the list of confirmed attendees",
              },
              {
                name: "showCurrentJob" as const,
                label: "Show job & employer",
                description: "Visible on your profile card",
              },
              {
                name: "showCurrentCity" as const,
                label: "Show current city",
                description: "Visible on your profile card",
              },
              {
                name: "showSocialLinks" as const,
                label: "Show social links",
                description: "LinkedIn, Instagram visible to others",
              },
              {
                name: "allowDirectMessages" as const,
                label: "Allow direct messages",
                description: "Classmates can message you directly",
              },
              {
                name: "allowPhotoTagging" as const,
                label: "Allow photo tagging",
                description: "Others can tag you in memory photos",
              },
              {
                name: "allowNominations" as const,
                label: "Allow nominations",
                description: "Classmates can nominate you for awards",
              },
            ].map(({ name, label, description }) => (
              <FormField
                key={name}
                control={form.control}
                name={name}
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between gap-4 px-4 py-3">
                    <div>
                      <FormLabel className="text-sm font-medium cursor-pointer">
                        {label}
                      </FormLabel>
                      <FormDescription className="mt-0 text-xs">
                        {description}
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value as boolean}
                        onCheckedChange={field.onChange}
                        aria-label={label}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            ))}
          </div>
        </Section>

        {/* ── Actions ───────────────────────────────────────────────────── */}
        <div className="flex items-center justify-between pt-2">
          <Button
            type="submit"
            disabled={isPending || !form.formState.isDirty}
            className="gap-2 min-w-32"
          >
            {isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : null}
            Save changes
          </Button>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild className="gap-1.5 text-slate-500">
              <a href="/api/profile/export" download>
                <Download className="h-3.5 w-3.5" />
                Export data
              </a>
            </Button>
          </div>
        </div>

        {/* ── Danger zone ───────────────────────────────────────────────── */}
        <div className="rounded-xl border border-red-200 bg-red-50 p-5">
          <h3 className="text-sm font-semibold text-red-800 mb-1">
            Danger zone
          </h3>
          <p className="text-xs text-red-600 mb-3">
            Deleting your account will permanently remove your profile and all
            associated data. This cannot be undone.
          </p>
          <ConfirmDialog
            trigger={
              <Button
                variant="ghost"
                size="sm"
                className="gap-2 text-red-600 hover:bg-red-100 hover:text-red-700"
                disabled={isDeleting}
              >
                {isDeleting ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Trash2 className="h-3.5 w-3.5" />
                )}
                Delete account
              </Button>
            }
            title="Delete your account?"
            description="This will permanently delete your profile, RSVPs, memories, and all other data. This action cannot be undone."
            confirmLabel="Yes, delete my account"
            onConfirm={handleDeleteAccount}
          />
        </div>
      </form>
    </Form>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-sm font-semibold text-slate-700 border-b border-border pb-2">
        {title}
      </h2>
      {children}
    </div>
  );
}
