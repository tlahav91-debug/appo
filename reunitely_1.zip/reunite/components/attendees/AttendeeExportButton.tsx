"use client";

import { Download, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export function AttendeeExportButton({ eventId }: { eventId: string }) {
  return (
    <Button
      variant="outline"
      size="sm"
      className="gap-2"
      asChild
    >
      <a
        href={`/api/events/${eventId}/memberships/export`}
        download
        aria-label="Export attendees as CSV"
      >
        <Download className="h-4 w-4" />
        Export CSV
      </a>
    </Button>
  );
}

export function InviteAttendeesButton({ eventId }: { eventId: string }) {
  return (
    <Button asChild size="sm" className="gap-2">
      <Link href={`/dashboard/events/${eventId}/invites`}>
        <UserPlus className="h-4 w-4" />
        Invite People
      </Link>
    </Button>
  );
}
