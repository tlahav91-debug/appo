"use client";

import { useState } from "react";
import {
  X, UserCheck, Send, Trash2, Car, Plane, Train, Home, Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar } from "@/components/shared/Avatar";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { useCheckIn, useRemoveAttendee } from "@/hooks/useAttendees";
import { formatShortDate, formatRelativeTime, cn } from "@/lib/utils";
import { toast } from "sonner";
import type { AttendeeRow } from "@/types";

const TRANSPORT_ICONS: Record<string, React.ElementType> = {
  DRIVING: Car, FLYING: Plane, TRAIN: Train, LOCAL: Home,
  NEED_RIDE: Users, OFFERING_RIDE: Car,
};

const TRANSPORT_LABELS: Record<string, string> = {
  DRIVING: "Driving", FLYING: "Flying in", TRAIN: "Train / bus",
  LOCAL: "Local", NEED_RIDE: "Needs a ride", OFFERING_RIDE: "Offering rides",
};

const STATUS_CONFIG: Record<string, { label: string; className: string }> = {
  CONFIRMED: { label: "Confirmed", className: "bg-emerald-100 text-emerald-700" },
  PENDING: { label: "Maybe", className: "bg-blue-100 text-blue-700" },
  WAITLISTED: { label: "Waitlisted", className: "bg-blue-100 text-blue-700" },
  DECLINED: { label: "Declined", className: "bg-slate-100 text-slate-500" },
  CANCELLED: { label: "Cancelled", className: "bg-red-100 text-red-600" },
};

interface Props {
  eventId: string;
  attendee: AttendeeRow;
  onClose: () => void;
}

export function AttendeeDetailPanel({ eventId, attendee, onClose }: Props) {
  const [notes, setNotes] = useState(attendee.notes ?? "");
  const [isSavingNotes, setIsSavingNotes] = useState(false);
  const checkInMutation = useCheckIn(eventId);
  const removeMutation = useRemoveAttendee(eventId);

  const customAnswers = attendee.customAnswers as Record<string, string>;
  const accessibility = customAnswers["_accessibility"];
  const transportMode = customAnswers["_transport_mode"];
  const transportNotes = customAnswers["_transport_notes"];
  const offeringSeats = customAnswers["_offering_seats"];
  const arrivalCity = customAnswers["_arrival_city"];
  const regularAnswers = Object.entries(customAnswers).filter(([k]) => !k.startsWith("_"));
  const statusCfg = STATUS_CONFIG[attendee.status] ?? STATUS_CONFIG["PENDING"]!;
  const TransportIcon = transportMode ? TRANSPORT_ICONS[transportMode] : null;

  async function saveNotes() {
    setIsSavingNotes(true);
    try {
      const res = await fetch(`/api/events/${eventId}/memberships/${attendee.userId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ organizerNote: notes }),
      });
      if (!res.ok) throw new Error();
      toast.success("Notes saved");
    } catch {
      toast.error("Failed to save notes");
    } finally {
      setIsSavingNotes(false);
    }
  }

  return (
    <div
      className="flex w-80 shrink-0 flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-card-lg"
      role="complementary"
      aria-label={`Details for ${attendee.user.name}`}
    >
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <span className="text-sm font-semibold text-slate-700">Attendee Details</span>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex flex-1 flex-col gap-5 overflow-y-auto p-4">
        {/* Profile */}
        <div className="flex flex-col items-center gap-3 text-center">
          <Avatar name={attendee.user.name} src={attendee.user.avatarUrl} size="xl" />
          <div>
            <p className="font-semibold text-slate-900">{attendee.user.name}</p>
            <p className="text-xs text-slate-500">{attendee.user.email}</p>
            {attendee.user.currentJob && (
              <p className="text-xs text-slate-400 mt-0.5">
                {attendee.user.currentJob}{attendee.user.currentCity ? ` · ${attendee.user.currentCity}` : ""}
              </p>
            )}
          </div>
          <span className={cn("rounded-full px-3 py-1 text-xs font-semibold", statusCfg.className)}>
            {statusCfg.label}{attendee.status === "WAITLISTED" && attendee.waitlistPosition ? ` #${attendee.waitlistPosition}` : ""}
          </span>
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          {attendee.status === "CONFIRMED" && !attendee.checkedInAt && (
            <Button size="sm" className="flex-1 gap-1.5"
              onClick={() => checkInMutation.mutate(attendee.userId)}
              disabled={checkInMutation.isPending}>
              <UserCheck className="h-3.5 w-3.5" />Check In
            </Button>
          )}
          {attendee.checkedInAt && (
            <div className="flex-1 rounded-lg bg-emerald-50 border border-emerald-200 px-3 py-2 text-center">
              <p className="text-xs font-semibold text-emerald-700">✓ Checked in</p>
              <p className="text-[10px] text-emerald-600">{formatRelativeTime(attendee.checkedInAt)}</p>
            </div>
          )}
          <Button variant="outline" size="sm" className="flex-1 gap-1.5"
            onClick={() => window.location.href = "../messages"}>
            <Send className="h-3.5 w-3.5" />Message
          </Button>
        </div>

        {/* RSVP */}
        <Section title="RSVP">
          <Row label="Submitted" value={formatShortDate(attendee.submittedAt)} />
          {attendee.confirmedAt && <Row label="Confirmed" value={formatShortDate(attendee.confirmedAt)} />}
          {attendee.guestCount > 0 && (
            <>
              <Row label="Guests" value={`+${attendee.guestCount}`} />
              {attendee.guestNames?.map((n, i) => (
                <p key={i} className="text-[10px] text-slate-400 text-right">↳ {n}</p>
              ))}
            </>
          )}
        </Section>

        {/* Dietary */}
        {attendee.dietaryRequirements?.length > 0 && (
          <Section title="Dietary">
            <div className="flex flex-wrap gap-1">
              {attendee.dietaryRequirements.filter(d => !d.startsWith("Note:") && d !== "NONE").map(d => (
                <span key={d} className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-600">
                  {d.replace(/_/g, " ").toLowerCase().replace(/\b\w/g, c => c.toUpperCase())}
                </span>
              ))}
            </div>
            {attendee.dietaryRequirements.filter(d => d.startsWith("Note:")).map((d, i) => (
              <p key={i} className="text-xs text-slate-500 italic">{d.replace("Note: ", "")}</p>
            ))}
          </Section>
        )}

        {/* Accessibility */}
        {accessibility && (
          <Section title="Accessibility needs">
            <p className="text-xs text-blue-800 bg-blue-50 border border-blue-200 rounded-lg p-2.5">
              {accessibility}
            </p>
          </Section>
        )}

        {/* Transport */}
        {transportMode && (
          <Section title="Transport">
            <div className="flex items-center gap-2">
              {TransportIcon && <TransportIcon className="h-3.5 w-3.5 text-slate-400" />}
              <span className="text-xs text-slate-700">
                {TRANSPORT_LABELS[transportMode] ?? transportMode}
                {transportMode === "OFFERING_RIDE" && offeringSeats ? ` (${offeringSeats} seats)` : ""}
                {arrivalCity ? ` from ${arrivalCity}` : ""}
              </span>
            </div>
            {transportNotes && <p className="text-xs text-slate-500">{transportNotes}</p>}
          </Section>
        )}

        {/* Custom answers */}
        {regularAnswers.length > 0 && (
          <Section title="Custom Answers">
            {regularAnswers.map(([k, v]) => <Row key={k} label={k} value={String(v)} />)}
          </Section>
        )}

        {/* Attendee note */}
        {attendee.attendeeNote && (
          <Section title="Note from Attendee">
            <p className="text-xs text-slate-600 bg-slate-50 border border-border rounded-lg p-2.5 italic">
              &ldquo;{attendee.attendeeNote}&rdquo;
            </p>
          </Section>
        )}

        {/* Consent */}
        <Section title="Consent">
          <ConsentRow label="Email" granted={attendee.consentEmail} />
          <ConsentRow label="SMS" granted={attendee.consentSms} />
          <ConsentRow label="WhatsApp" granted={attendee.consentWhatsApp} />
        </Section>

        {/* Organizer notes */}
        <Section title="Organizer Notes">
          <Textarea
            placeholder="Private notes visible only to organizers…"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            className="text-sm resize-none"
          />
          {notes !== (attendee.notes ?? "") && (
            <Button size="sm" variant="outline" className="mt-2 w-full"
              onClick={saveNotes} disabled={isSavingNotes}>
              {isSavingNotes ? "Saving…" : "Save Notes"}
            </Button>
          )}
        </Section>
      </div>

      <div className="border-t border-border p-3">
        <ConfirmDialog
          trigger={
            <Button variant="ghost" size="sm"
              className="w-full gap-2 text-destructive hover:bg-destructive/5 hover:text-destructive">
              <Trash2 className="h-3.5 w-3.5" />Remove from event
            </Button>
          }
          title="Remove attendee?"
          description={`Remove ${attendee.user.name} from the event. They can re-RSVP if they wish.`}
          confirmLabel="Remove"
          onConfirm={() => { removeMutation.mutate(attendee.userId); onClose(); }}
        />
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2">
      <h3 className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{title}</h3>
      <div className="flex flex-col gap-1.5">{children}</div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-2 text-xs">
      <span className="shrink-0 text-slate-500">{label}</span>
      <span className="text-right font-medium text-slate-900 max-w-[60%] break-words">{value}</span>
    </div>
  );
}

function ConsentRow({ label, granted }: { label: string; granted: boolean }) {
  return (
    <div className="flex items-center justify-between text-xs">
      <span className="text-slate-500">{label}</span>
      <span className={cn("font-medium", granted ? "text-emerald-600" : "text-slate-400")}>
        {granted ? "✓ Consented" : "✗ Not consented"}
      </span>
    </div>
  );
}
