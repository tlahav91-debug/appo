"use client";

import { useState, useCallback } from "react";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import {
  Search,
  MoreHorizontal,
  UserCheck,
  Trash2,
  Send,
  Download,
  ChevronDown,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { RsvpStatusBadge } from "@/components/shared/StatusBadge";
import { Avatar } from "@/components/shared/Avatar";
import { EmptyState } from "@/components/shared/EmptyState";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { AttendeeDetailPanel } from "@/components/attendees/AttendeeDetailPanel";
import {
  useAttendees,
  useRemoveAttendee,
  useUpdateAttendeeStatus,
  useCheckIn,
} from "@/hooks/useAttendees";
import { cn, formatShortDate, pluralize } from "@/lib/utils";
import { toast } from "sonner";
import type { AttendeeRow, AttendeeFilter } from "@/types";
import type { RSVPStatus } from "@prisma/client";

const STATUS_FILTERS = [
  { label: "All", value: "" },
  { label: "Confirmed", value: "CONFIRMED" },
  { label: "Pending", value: "PENDING" },
  { label: "Declined", value: "DECLINED" },
  { label: "Waitlist", value: "WAITLISTED" },
  { label: "Checked In", value: "CHECKED_IN" },
];

interface AttendeeTableProps {
  eventId: string;
  initialStatus?: string;
  initialSearch?: string;
}

export function AttendeeTable({
  eventId,
  initialStatus = "",
  initialSearch = "",
}: AttendeeTableProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [search, setSearch] = useState(initialSearch);
  const [statusFilter, setStatusFilter] = useState(initialStatus);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [detailUserId, setDetailUserId] = useState<string | null>(null);

  const filter = {
    search: search || undefined,
    status: statusFilter ? ([statusFilter] as RSVPStatus[]) : undefined,
  };

  const { data: attendees = [], isLoading } = useAttendees(eventId, filter);
  const removeMutation = useRemoveAttendee(eventId);
  const statusMutation = useUpdateAttendeeStatus(eventId);
  const checkInMutation = useCheckIn(eventId);

  // Sync URL params
  const updateUrl = useCallback(
    (params: Record<string, string>) => {
      const next = new URLSearchParams(searchParams.toString());
      Object.entries(params).forEach(([k, v]) => {
        v ? next.set(k, v) : next.delete(k);
      });
      router.replace(`${pathname}?${next.toString()}`, { scroll: false });
    },
    [router, pathname, searchParams]
  );

  const handleSearchChange = (val: string) => {
    setSearch(val);
    updateUrl({ search: val });
  };

  const handleStatusChange = (val: string) => {
    setStatusFilter(val);
    updateUrl({ status: val });
    setSelected(new Set());
  };

  // Selection helpers
  const allSelected =
    attendees.length > 0 && attendees.every((a) => selected.has(a.userId));
  const someSelected = selected.size > 0;

  const toggleAll = () => {
    if (allSelected) {
      setSelected(new Set());
    } else {
      setSelected(new Set(attendees.map((a) => a.userId)));
    }
  };

  const toggleOne = (userId: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(userId) ? next.delete(userId) : next.add(userId);
      return next;
    });
  };

  // Bulk actions
  const handleBulkExport = () => {
    const ids = Array.from(selected).join(",");
    window.location.href = `/api/events/${eventId}/memberships/export?userIds=${ids}`;
  };

  const selectedAttendee = detailUserId
    ? attendees.find((a) => a.userId === detailUserId) ?? null
    : null;

  return (
    <div className="flex gap-4">
      {/* Main table column */}
      <div className="flex min-w-0 flex-1 flex-col gap-4">
        {/* Filter bar */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          {/* Status chips */}
          <div className="flex flex-wrap gap-1.5">
            {STATUS_FILTERS.map((f) => (
              <button
                key={f.value}
                onClick={() => handleStatusChange(f.value)}
                className={cn(
                  "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                  statusFilter === f.value
                    ? "border-blue-600 bg-blue-50 text-blue-700"
                    : "border-border bg-card text-slate-600 hover:border-slate-300 hover:bg-slate-50"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative w-full sm:w-56">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <Input
              placeholder="Search by name or email…"
              value={search}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="pl-8 text-sm"
            />
          </div>
        </div>

        {/* Bulk actions bar */}
        {someSelected && (
          <div className="flex items-center gap-3 rounded-lg border border-blue-200 bg-blue-50 px-4 py-2.5">
            <span className="text-sm font-medium text-blue-800">
              {pluralize(selected.size, "attendee")} selected
            </span>
            <div className="ml-auto flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 h-7 text-xs"
                onClick={handleBulkExport}
              >
                <Download className="h-3 w-3" />
                Export
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 h-7 text-xs"
                onClick={() => {
                  window.location.href = `../messages`;
                }}
              >
                <Send className="h-3 w-3" />
                Message
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs text-slate-500"
                onClick={() => setSelected(new Set())}
              >
                Clear
              </Button>
            </div>
          </div>
        )}

        {/* Table */}
        <div className="overflow-hidden rounded-xl border border-border bg-card shadow-card">
          {isLoading ? (
            <AttendeeTableBodySkeleton />
          ) : attendees.length === 0 ? (
            <EmptyState
              title={
                search || statusFilter
                  ? "No attendees match this filter"
                  : "No attendees yet"
              }
              description={
                search || statusFilter
                  ? "Try adjusting your search or filter."
                  : "Share your event link to start collecting RSVPs."
              }
              size="md"
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full" aria-label="Attendees table">
                <thead>
                  <tr className="border-b border-border bg-slate-50">
                    <th className="w-10 px-4 py-3">
                      <Checkbox
                        checked={allSelected}
                        onCheckedChange={toggleAll}
                        aria-label="Select all attendees"
                      />
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
                      Name
                    </th>
                    <th className="hidden px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500 md:table-cell">
                      Email
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
                      Status
                    </th>
                    <th className="hidden px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500 lg:table-cell">
                      +Guests
                    </th>
                    <th className="hidden px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500 lg:table-cell">
                      Joined
                    </th>
                    <th className="w-12 px-4 py-3" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {attendees.map((attendee) => (
                    <AttendeeRow
                      key={attendee.userId}
                      attendee={attendee}
                      selected={selected.has(attendee.userId)}
                      onToggleSelect={() => toggleOne(attendee.userId)}
                      onViewDetail={() => setDetailUserId(attendee.userId)}
                      onCheckIn={() => checkInMutation.mutate(attendee.userId)}
                      onRemove={() => removeMutation.mutate(attendee.userId)}
                    />
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {attendees.length > 0 && (
          <p className="text-right text-xs text-slate-400">
            {pluralize(attendees.length, "attendee")} shown
          </p>
        )}
      </div>

      {/* Detail panel */}
      {selectedAttendee && (
        <AttendeeDetailPanel
          eventId={eventId}
          attendee={selectedAttendee}
          onClose={() => setDetailUserId(null)}
        />
      )}
    </div>
  );
}

// ─── Row component ────────────────────────────────────────────────────────────

function AttendeeRow({
  attendee,
  selected,
  onToggleSelect,
  onViewDetail,
  onCheckIn,
  onRemove,
}: {
  attendee: AttendeeRow;
  selected: boolean;
  onToggleSelect: () => void;
  onViewDetail: () => void;
  onCheckIn: () => void;
  onRemove: () => void;
}) {
  return (
    <tr
      className={cn(
        "transition-colors hover:bg-slate-50/60 cursor-pointer",
        selected && "bg-blue-50/40"
      )}
      onClick={onViewDetail}
    >
      <td
        className="px-4 py-3"
        onClick={(e) => {
          e.stopPropagation();
          onToggleSelect();
        }}
      >
        <Checkbox
          checked={selected}
          onCheckedChange={onToggleSelect}
          aria-label={`Select ${attendee.user.name}`}
        />
      </td>

      <td className="px-4 py-3">
        <div className="flex items-center gap-3">
          <Avatar
            name={attendee.user.name}
            src={attendee.user.avatarUrl}
            size="sm"
          />
          <div className="min-w-0">
            <p className="truncate text-sm font-medium text-slate-900">
              {attendee.user.name}
            </p>
            {attendee.user.currentCity && (
              <p className="truncate text-xs text-slate-400">
                {attendee.user.currentCity}
              </p>
            )}
          </div>
        </div>
      </td>

      <td className="hidden px-4 py-3 md:table-cell">
        <span className="truncate text-sm text-slate-600">
          {attendee.user.email}
        </span>
      </td>

      <td className="px-4 py-3">
        <RsvpStatusBadge status={attendee.status} />
      </td>

      <td className="hidden px-4 py-3 text-sm text-slate-600 lg:table-cell">
        {attendee.guestCount > 0 ? `+${attendee.guestCount}` : "—"}
      </td>

      <td className="hidden px-4 py-3 text-sm text-slate-400 lg:table-cell">
        {formatShortDate(attendee.submittedAt)}
      </td>

      <td
        className="px-4 py-3"
        onClick={(e) => e.stopPropagation()}
      >
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              aria-label={`Actions for ${attendee.user.name}`}
            >
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            <DropdownMenuItem onClick={onViewDetail}>
              View details
            </DropdownMenuItem>
            {attendee.status === "CONFIRMED" && (
              <DropdownMenuItem onClick={onCheckIn} className="gap-2">
                <UserCheck className="h-3.5 w-3.5" />
                Check in
              </DropdownMenuItem>
            )}
            <DropdownMenuItem asChild>
              <a href="../messages">Send broadcast message</a>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <ConfirmDialog
              trigger={
                <DropdownMenuItem
                  className="gap-2 text-destructive focus:text-destructive"
                  onSelect={(e) => e.preventDefault()}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Remove
                </DropdownMenuItem>
              }
              title="Remove attendee?"
              description={`This will remove ${attendee.user.name} from the event. They will need to RSVP again to rejoin.`}
              confirmLabel="Remove"
              onConfirm={onRemove}
            />
          </DropdownMenuContent>
        </DropdownMenu>
      </td>
    </tr>
  );
}

function AttendeeTableBodySkeleton() {
  return (
    <div className="p-4 space-y-3">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4">
          <div className="h-4 w-4 rounded bg-slate-100" />
          <div className="h-8 w-8 rounded-full bg-slate-100" />
          <div className="flex-1 space-y-1.5">
            <div className="h-3 w-32 rounded bg-slate-100" />
            <div className="h-3 w-24 rounded bg-slate-100" />
          </div>
          <div className="h-5 w-20 rounded-full bg-slate-100" />
        </div>
      ))}
    </div>
  );
}
