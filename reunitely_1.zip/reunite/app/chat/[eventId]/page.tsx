import { auth } from "@clerk/nextjs/server";
import { notFound, redirect } from "next/navigation";
import { db } from "@/lib/db";
import { ChatShell } from "@/components/chat/ChatShell";

interface Props {
  params: { eventId: string };
  searchParams: { room?: string };
}

export async function generateMetadata({ params }: Props) {
  const event = await db.event.findUnique({
    where: { id: params.eventId },
    select: { title: true },
  });
  return { title: event ? `Chat — ${event.title}` : "Chat" };
}

export default async function ChatPage({ params, searchParams }: Props) {
  const { userId: clerkId } = auth();
  if (!clerkId) redirect("/login");

  // Verify event exists and user is a member
  const event = await db.event.findUnique({
    where: { id: params.eventId },
    select: { id: true, title: true, slug: true, settings: true },
  });
  if (!event) notFound();

  const user = await db.user.findUnique({
    where: { clerkId },
    select: { id: true, name: true, avatarUrl: true },
  });
  if (!user) redirect("/login");

  const membership = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId: params.eventId, userId: user.id }, revokedAt: null },
    select: { role: true },
  });
  const rsvp = !membership ? await db.rSVP.findUnique({
    where: { eventId_userId: { eventId: params.eventId, userId: user.id } },
    select: { status: true },
  }) : null;
  const membershipData = membership ?? (rsvp ? { role: "ATTENDEE" as const } : null);
  if (!membershipData) notFound();

  // Fetch rooms the user has access to
  const rooms = await db.chatRoom.findMany({
    where: { eventId: params.eventId, isArchived: false },
    orderBy: [{ type: "asc" }, { createdAt: "asc" }],
  });

  const activeRoomId = searchParams.room ?? rooms[0]?.id;
  if (!activeRoomId) notFound();

  return (
    <ChatShell
      event={{ id: event.id, title: event.title, slug: event.slug }}
      rooms={rooms.map((r) => ({
        id: r.id,
        name: r.name,
        type: r.type,
        description: r.description,
      }))}
      activeRoomId={activeRoomId}
      currentUser={{ id: user.id, name: user.name, avatarUrl: user.avatarUrl }}
      isOrganizer={membershipData?.role === "ORGANIZER" || membershipData?.role === "CO_ORGANIZER"}
    />
  );
}
