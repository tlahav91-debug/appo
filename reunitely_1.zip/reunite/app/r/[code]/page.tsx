import { redirect, notFound } from "next/navigation";
import { trackReferralClick } from "@/lib/services/invite.service";

interface Props {
  params: { code: string };
}

// GET /r/[code] — referral link redirect
// Tracks click, then redirects to the event page with ?ref=[code] for attribution
export default async function ReferralRedirectPage({ params }: Props) {
  const eventSlug = await trackReferralClick(params.code);

  if (!eventSlug) {
    notFound();
  }

  // Redirect to event page with referral code in query param
  // The RSVP flow will read this and call attributeReferral on completion
  redirect(`/events/${eventSlug}?ref=${params.code}`);
}
