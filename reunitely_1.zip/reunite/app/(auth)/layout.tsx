// Auth pages get a minimal layout — no sidebar, no nav
export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
