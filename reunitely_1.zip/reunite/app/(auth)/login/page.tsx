import { SignIn } from "@clerk/nextjs";
import type { Metadata } from "next";
import { CLERK_APPEARANCE } from "@/lib/auth/config";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Sign In — Reunitely",
  robots: { index: false },
};

interface Props {
  searchParams: { redirect_url?: string; error?: string };
}

export default function LoginPage({ searchParams }: Props) {
  const errorMessages: Record<string, string> = {
    unauthorized: "You don't have permission to access that page.",
    insufficient_permissions: "Your account doesn't have the required access level.",
    invite_required: "This event requires an invite to access.",
    invite_expired: "Your invite link has expired. Please contact the organizer.",
  };

  const errorMessage = searchParams.error
    ? errorMessages[searchParams.error]
    : null;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-slate-50 px-4">
      {/* Logo */}
      <Link href="/" className="mb-8 font-display text-2xl font-bold text-slate-900">
        <span className="text-blue-500">Re</span>Unite
      </Link>

      {/* Error banner */}
      {errorMessage && (
        <div
          className="mb-6 w-full max-w-md rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
          role="alert"
        >
          {errorMessage}
        </div>
      )}

      {/*
        Clerk SignIn component handles:
        - Email/password
        - Magic link (email link) — enabled in Clerk Dashboard
        - Google OAuth — enabled in Clerk Dashboard → Social Connections
        - Facebook OAuth — enabled in Clerk Dashboard → Social Connections
        
        To enable magic link:
          Clerk Dashboard → User & Authentication → Email, Phone, Username
          → Email address → Email verification → "Email link"
        
        To enable Google:
          Clerk Dashboard → Social Connections → Google → Enable
        
        To enable Facebook:
          Clerk Dashboard → Social Connections → Facebook → Enable
          Requires: Facebook App ID + App Secret from Meta Developer Console
      */}
      <SignIn
        appearance={CLERK_APPEARANCE}
        redirectUrl={searchParams.redirect_url}
        routing="hash"
        fallbackRedirectUrl="/dashboard/events"
      />

      <p className="mt-6 text-xs text-slate-400">
        By signing in, you agree to our{" "}
        <Link href="/terms" className="underline hover:text-slate-600">
          Terms of Service
        </Link>{" "}
        and{" "}
        <Link href="/privacy" className="underline hover:text-slate-600">
          Privacy Policy
        </Link>
        .
      </p>
    </div>
  );
}
