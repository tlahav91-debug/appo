import { SignUp } from "@clerk/nextjs";
import type { Metadata } from "next";
import { CLERK_APPEARANCE } from "@/lib/auth/config";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Create Account — Reunitely",
  robots: { index: false },
};

interface Props {
  searchParams: { redirect_url?: string; invite?: string };
}

export default function SignupPage({ searchParams }: Props) {
  // If an invite token is present, we pre-fill the redirect after signup
  // so the user lands back on the RSVP page automatically
  const afterSignUpUrl = searchParams.redirect_url ?? "/dashboard/events";

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-slate-50 px-4">
      <Link href="/" className="mb-8 font-display text-2xl font-bold text-slate-900">
        <span className="text-blue-500">Re</span>Unite
      </Link>

      {searchParams.invite && (
        <div className="mb-6 w-full max-w-md rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          🎉 You've been invited to a reunion! Create your account to RSVP.
        </div>
      )}

      <SignUp
        appearance={CLERK_APPEARANCE}
        redirectUrl={afterSignUpUrl}
        routing="hash"
        fallbackRedirectUrl="/dashboard/events"
      />

      <p className="mt-6 text-xs text-slate-400">
        Already have an account?{" "}
        <Link href="/login" className="text-blue-600 hover:underline">
          Sign in
        </Link>
      </p>
    </div>
  );
}
