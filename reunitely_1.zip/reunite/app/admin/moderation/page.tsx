import { requirePlatformRole } from "@/lib/auth/session";
import { PageHeader } from "@/components/shared/PageHeader";
import { db } from "@/lib/db";
import { formatRelativeTime } from "@/lib/utils";
import { AdminModerationQueue } from "@/components/admin/AdminModerationQueue";

export const metadata = { title: "Moderation — Admin" };

async function getPendingContent() {
  const [pendingMemories, flaggedMemories] = await Promise.all([
    db.memoryPost.findMany({
      where: { status: "PENDING", deletedAt: null },
      include: {
        author: { select: { name: true, email: true, avatarUrl: true } },
        event: { select: { title: true, slug: true } },
      },
      orderBy: { createdAt: "asc" },
      take: 50,
    }),
    db.memoryPost.findMany({
      where: { reportCount: { gt: 0 }, status: "APPROVED", deletedAt: null },
      include: {
        author: { select: { name: true, email: true, avatarUrl: true } },
        event: { select: { title: true, slug: true } },
      },
      orderBy: { reportCount: "desc" },
      take: 20,
    }),
  ]);

  return { pendingMemories, flaggedMemories };
}

export default async function AdminModerationPage() {
  // Super admin only
  await requirePlatformRole("SUPER_ADMIN");

  const { pendingMemories, flaggedMemories } = await getPendingContent();

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Moderation Queue"
        description="Platform-wide content awaiting review or flagged by users."
      />

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3">
        {[
          { label: "Pending Approval", value: pendingMemories.length, color: "text-blue-600" },
          { label: "Flagged Content", value: flaggedMemories.length, color: "text-red-600" },
          { label: "Total in Queue", value: pendingMemories.length + flaggedMemories.length, color: "text-slate-900" },
        ].map((stat) => (
          <div key={stat.label} className="rounded-xl border border-border bg-card p-4 text-center">
            <p className={`font-display text-3xl font-bold ${stat.color}`}>{stat.value}</p>
            <p className="text-xs text-slate-500 mt-0.5">{stat.label}</p>
          </div>
        ))}
      </div>

      <AdminModerationQueue
        pendingMemories={pendingMemories.map((m) => ({
          id: m.id,
          type: m.type,
          caption: m.caption,
          authorName: m.author.name,
          authorEmail: m.author.email,
          authorAvatar: m.author.avatarUrl,
          eventTitle: m.event.title,
          eventSlug: m.event.slug,
          createdAt: m.createdAt.toISOString(),
          reportCount: m.reportCount,
          isFlagged: false,
        }))}
        flaggedMemories={flaggedMemories.map((m) => ({
          id: m.id,
          type: m.type,
          caption: m.caption,
          authorName: m.author.name,
          authorEmail: m.author.email,
          authorAvatar: m.author.avatarUrl,
          eventTitle: m.event.title,
          eventSlug: m.event.slug,
          createdAt: m.createdAt.toISOString(),
          reportCount: m.reportCount,
          isFlagged: true,
        }))}
      />
    </div>
  );
}
