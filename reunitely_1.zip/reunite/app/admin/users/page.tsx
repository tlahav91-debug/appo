import { requirePlatformRole } from "@/lib/auth/session";
import { PageHeader } from "@/components/shared/PageHeader";
import { AdminUserTable } from "@/components/admin/AdminUserTable";

export const metadata = { title: "Users — Admin" };

export default async function AdminUsersPage() {
  const session = await requirePlatformRole("MODERATOR");

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Users"
        description="Search and manage platform users."
      />
      <AdminUserTable canPromote={session.isSuperAdmin} />
    </div>
  );
}
