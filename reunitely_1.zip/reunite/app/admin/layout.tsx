import { redirect } from "next/navigation";
import { requirePlatformRole } from "@/lib/auth/session";
import Link from "next/link";
import { Shield, ShieldAlert, Users, Calendar, Eye } from "lucide-react";
import { cn } from "@/lib/utils";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Redirects if not MODERATOR or SUPER_ADMIN
  const session = await requirePlatformRole("MODERATOR");

  const navItems = [
    { href: "/admin/events", icon: Calendar, label: "All Events" },
    { href: "/admin/users", icon: Users, label: "Users" },
    { href: "/admin/moderation", icon: Eye, label: "Moderation Queue", superAdminOnly: true },
  ].filter((item) => !item.superAdminOnly || session.isSuperAdmin);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Admin sidebar */}
      <aside className="hidden w-56 shrink-0 flex-col border-r border-border bg-red-50 md:flex">
        <div className="flex h-16 items-center gap-2 border-b border-red-200 px-5">
          <ShieldAlert className="h-5 w-5 text-red-600" />
          <span className="font-semibold text-red-800 text-sm">
            {session.isSuperAdmin ? "Super Admin" : "Moderator"}
          </span>
        </div>
        <nav className="flex flex-1 flex-col gap-0.5 p-3">
          <Link
            href="/dashboard/events"
            className="flex items-center gap-2 rounded-md px-3 py-2 text-xs text-red-600 hover:bg-red-100 mb-2"
          >
            ← Back to Dashboard
          </Link>
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium text-red-800 hover:bg-red-100 transition-colors"
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      {/* Main content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-16 items-center border-b border-red-200 bg-red-50 px-6">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-red-600" />
            <span className="text-sm font-semibold text-red-800">Platform Administration</span>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto px-6 py-6">
          {children}
        </main>
      </div>
    </div>
  );
}
