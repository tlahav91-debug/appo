import { Suspense } from "react";
import { requirePlatformRole } from "@/lib/auth/session";
import { PageHeader } from "@/components/shared/PageHeader";
import { Skeleton } from "@/components/ui/skeleton";
import { db } from "@/lib/db";
import { EventStatusBadge } from "@/components/shared/StatusBadge";
import { formatShortDate, pluralize } from "@/lib/utils";
import { Shield } from "lucide-react";

export const metadata = { title: "All Events — Admin" };

async function AllEventsList() {
  const events = await db.event.findMany({
    include: {
      createdBy: { select: { name: true, email: true } },
      _count: { select: { rsvps: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <table className="w-full" aria-label="All events">
        <thead>
          <tr className="border-b border-border bg-slate-50">
            {["Event", "Organizer", "Status", "Attendees", "Date", ""].map((h) => (
              <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {events.map((event) => (
            <tr key={event.id} className="hover:bg-slate-50/50">
              <td className="px-4 py-3">
                <p className="text-sm font-medium text-slate-900 truncate max-w-xs">{event.title}</p>
                <p className="text-xs text-slate-400">{event.schoolName} · {event.graduationYear}</p>
              </td>
              <td className="px-4 py-3">
                <p className="text-sm text-slate-700">{event.createdBy.name}</p>
                <p className="text-xs text-slate-400">{event.createdBy.email}</p>
              </td>
              <td className="px-4 py-3">
                <EventStatusBadge status={event.status} />
              </td>
              <td className="px-4 py-3 text-sm text-slate-600">
                {event._count.rsvps}
              </td>
              <td className="px-4 py-3 text-sm text-slate-400">
                {formatShortDate(event.startAt)}
              </td>
              <td className="px-4 py-3">
                <a
                  href={`/dashboard/events/${event.id}/overview`}
                  className="text-xs text-blue-600 hover:underline"
                >
                  View →
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default async function AdminEventsPage() {
  await requirePlatformRole("MODERATOR");

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="All Events"
        description="Platform-wide view of all reunion events."
      />
      <Suspense fallback={<Skeleton className="h-96 rounded-xl" />}>
        <AllEventsList />
      </Suspense>
    </div>
  );
}
