import { processUnsubscribe } from "@/lib/services/consent.service";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle } from "lucide-react";
import Link from "next/link";

interface Props {
  params: { token: string };
  searchParams: { type?: string };
}

export const metadata = {
  title: "Unsubscribe",
  robots: { index: false },
};

export default async function UnsubscribePage({ params, searchParams }: Props) {
  const type = searchParams.type === "all" ? "all" : "event";
  const result = await processUnsubscribe(params.token, type);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-8 text-center shadow-card">
        {result.success ? (
          <>
            <CheckCircle className="mx-auto h-12 w-12 text-emerald-500" />
            <h1 className="mt-4 font-display text-2xl font-bold text-slate-900">
              You're unsubscribed
            </h1>
            <p className="mt-2 text-slate-500">{result.message}</p>
          </>
        ) : (
          <>
            <XCircle className="mx-auto h-12 w-12 text-red-400" />
            <h1 className="mt-4 font-display text-2xl font-bold text-slate-900">
              Link expired
            </h1>
            <p className="mt-2 text-slate-500">{result.message}</p>
          </>
        )}

        <div className="mt-8 flex flex-col gap-3">
          <Button asChild variant="outline" className="w-full">
            <Link href="/">Back to Reunitely</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
