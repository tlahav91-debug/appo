import { notFound, redirect } from "next/navigation";
import type { Metadata } from "next";
import { auth } from "@clerk/nextjs/server";
import Link from "next/link";
import { RSVPFlow } from "@/components/rsvp/RSVPFlow";
import { RSVPConfirmation } from "@/components/rsvp/RSVPConfirmation";
import { InviteRequired } from "@/components/shared/Unauthorized";
import { getPublicEvent } from "@/lib/services/event.service";
import { canAccessPublicEvent, validateInviteToken } from "@/lib/auth/permissions";
import { db } from "@/lib/db";

interface Props {
  params: { slug: string };
  searchParams: {
    invite?: string;
    // Stripe payment return params
    session_id?: string;
    success?: string;
    cancelled?: string;
  };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getPublicEvent(params.slug);
  if (!event) return {};
  return {
    title: `RSVP — ${event.title}`,
    description: `RSVP for ${event.title}`,
    robots: { index: false },
  };
}

export default async function RsvpPage({ params, searchParams }: Props) {
  // ── 1. Load event ─────────────────────────────────────────────────────────
  const event = await getPublicEvent(params.slug);
  if (!event) notFound();

  // ── 2. Visibility gate ────────────────────────────────────────────────────
  const { accessible, requiresInvite } = await canAccessPublicEvent(event.id);

  if (requiresInvite || !accessible) {
    if (!searchParams.invite) {
      return (
        <RsvpShell slug={params.slug} title={event.title}>
          <InviteRequired eventTitle={event.title} />
        </RsvpShell>
      );
    }

    const validation = await validateInviteToken(searchParams.invite);
    if (!validation.valid) {
      const errorMessage = validation.expired
        ? "This invite link has expired. Ask the organizer for a new one."
        : validation.alreadyUsed
        ? "This invite has already been used. Sign in to view your RSVP."
        : "This invite link is not valid.";

      return (
        <RsvpShell slug={params.slug} title={event.title}>
          <div className="flex flex-col items-center gap-4 py-8 text-center">
            <span className="text-4xl">⏰</span>
            <div>
              <h2 className="font-semibold text-slate-900">
                {validation.expired ? "Invite expired" : "Invalid invite"}
              </h2>
              <p className="mt-1 text-sm text-slate-500">{errorMessage}</p>
            </div>
            <Link
              href={`/events/${params.slug}`}
              className="text-sm text-blue-600 hover:underline"
            >
              View event page
            </Link>
          </div>
        </RsvpShell>
      );
    }
  }

  // ── 3. Auth gate ──────────────────────────────────────────────────────────
  const { userId: clerkId } = auth();
  if (!clerkId) {
    const rsvpUrl = `/events/${params.slug}/rsvp${searchParams.invite ? `?invite=${searchParams.invite}` : ""}`;
    redirect(`/login?redirect_url=${encodeURIComponent(rsvpUrl)}`);
  }

  // ── 4. Resolve DB user ────────────────────────────────────────────────────
  const user = await db.user.findUnique({
    where: { clerkId, deletedAt: null },
    select: { id: true },
  });
  if (!user) redirect("/login");

  // ── 5. Check for existing RSVP ────────────────────────────────────────────
  const existingRsvp = await db.rSVP.findUnique({
    where: { eventId_userId: { eventId: event.id, userId: user.id } },
    select: {
      status: true,
      guestCount: true,
      guestNames: true,
      dietaryRequirements: true,
      customAnswers: true,
      attendeeNote: true,
      consentEmail: true,
      consentSms: true,
      consentWhatsApp: true,
    },
  });

  // ── 6. Payment success redirect ───────────────────────────────────────────
  // If coming back from Stripe checkout, mark as paid and show confirmation
  if (searchParams.success === "true" && searchParams.session_id) {
    // The Stripe webhook already handled marking the payment — just show confirmation
    return (
      <RsvpShell slug={params.slug} title={event.title} minimal>
        <RSVPConfirmation
          event={{
            id: event.id,
            title: event.title,
            slug: event.slug,
            startAt: event.startAt,
            timezone: event.timezone,
          }}
          status="CONFIRMED"
          isExisting
        />
      </RsvpShell>
    );
  }

  // ── 7. Payment cancelled ──────────────────────────────────────────────────
  if (searchParams.cancelled === "true") {
    // RSVP was saved before checkout — show existing confirmation with payment note
    return (
      <RsvpShell slug={params.slug} title={event.title} minimal>
        <div className="flex flex-col items-center gap-4 py-6 text-center">
          <span className="text-4xl">💳</span>
          <div>
            <h2 className="font-semibold text-slate-900">Payment cancelled</h2>
            <p className="mt-1 text-sm text-slate-500">
              Your RSVP is saved, but payment is still needed to confirm your
              spot.
            </p>
          </div>
          <Link
            href={`/events/${params.slug}/rsvp`}
            className="text-sm text-blue-600 hover:underline"
          >
            Try again
          </Link>
        </div>
      </RsvpShell>
    );
  }

  // ── 8. Showing confirmation for already-confirmed RSVPs ───────────────────
  // Users who arrive without explicitly wanting to edit see their status
  if (
    existingRsvp &&
    (existingRsvp.status === "CONFIRMED" ||
      existingRsvp.status === "WAITLISTED" ||
      existingRsvp.status === "PENDING") &&
    !searchParams.invite // invite token means they came from an invite link — allow re-RSVP
  ) {
    return (
      <RsvpShell slug={params.slug} title={event.title} minimal>
        <RSVPConfirmation
          event={{
            id: event.id,
            title: event.title,
            slug: event.slug,
            startAt: event.startAt,
            timezone: event.timezone,
          }}
          status={existingRsvp.status as "CONFIRMED" | "PENDING" | "WAITLISTED" | "DECLINED"}
          isExisting
        />
      </RsvpShell>
    );
  }

  // ── 9. Load data for the flow ─────────────────────────────────────────────
  const [tickets, attendeeProfile] = await Promise.all([
    db.ticket.findMany({
      where: { eventId: event.id, isVisible: true, isActive: true },
      orderBy: { price: "asc" },
      select: {
        id: true,
        name: true,
        description: true,
        price: true,
        currency: true,
        capacity: true,
        soldCount: true,
      },
    }),
    db.attendeeProfile.findUnique({
      where: { userId: user.id },
      select: {
        currentCity: true,
        currentJob: true,
        currentEmployer: true,
        bio: true,
        showInDirectory: true,
        showCurrentJob: true,
        showCurrentCity: true,
        allowDirectMessages: true,
        allowNominations: true,
        profileVisibleTo: true,
      },
    }),
  ]);

  const settings = event.settings as {
    allowGuestPlus1?: boolean;
    maxGuestsPerRsvp?: number;
    customQuestions?: Array<{
      id: string;
      label: string;
      type: "TEXT" | "SELECT" | "BOOLEAN";
      options?: string[];
      required: boolean;
    }>;
    requireApproval?: boolean;
    verifySchoolEmail?: boolean;
  } | null;

  // ── 10. Render the flow ───────────────────────────────────────────────────
  return (
    <RsvpShell slug={params.slug} title={event.title}>
      <RSVPFlow
        event={{
          id: event.id,
          title: event.title,
          slug: event.slug,
          startAt: event.startAt,
          endAt: event.endAt,
          timezone: event.timezone,
          venueName: event.venueName,
          venueAddress: event.venueAddress,
          ticketingEnabled: event.ticketingEnabled,
          stripeAccountId: event.stripeAccountId,
          settings: {
            allowGuestPlus1: settings?.allowGuestPlus1,
            maxGuestsPerRsvp: settings?.maxGuestsPerRsvp,
            customQuestions: settings?.customQuestions ?? [],
            requireApproval: settings?.requireApproval,
          },
        }}
        tickets={tickets}
        inviteToken={searchParams.invite}
        existingRsvp={
          existingRsvp
            ? {
                status: existingRsvp.status,
                guestCount: existingRsvp.guestCount,
                dietaryRequirements: existingRsvp.dietaryRequirements,
                customAnswers:
                  (existingRsvp.customAnswers as Record<string, string>) ?? {},
                attendeeNote: existingRsvp.attendeeNote,
                consentEmail: existingRsvp.consentEmail,
                consentSms: existingRsvp.consentSms,
                consentWhatsApp: existingRsvp.consentWhatsApp,
              }
            : null
        }
        currentUserProfile={attendeeProfile}
      />
    </RsvpShell>
  );
}

// ─── Layout shell ─────────────────────────────────────────────────────────────

function RsvpShell({
  slug,
  title,
  children,
  minimal = false,
}: {
  slug: string;
  title: string;
  children: React.ReactNode;
  minimal?: boolean;
}) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Minimal branded header */}
      <header className="border-b border-border bg-white/95 backdrop-blur-sm px-4 py-3 sticky top-0 z-30">
        <div className="container flex items-center justify-between max-w-2xl mx-auto">
          <Link href="/" className="font-display text-lg font-bold text-slate-900">
            <span className="text-blue-500">Re</span>Unite
          </Link>
          <Link
            href={`/events/${slug}`}
            className="text-sm text-slate-500 hover:text-slate-700 transition-colors"
          >
            ← {minimal ? "Back" : "Back to event"}
          </Link>
        </div>
      </header>

      <main className="container max-w-lg mx-auto py-8 px-4 pb-24">
        {children}
      </main>
    </div>
  );
}
