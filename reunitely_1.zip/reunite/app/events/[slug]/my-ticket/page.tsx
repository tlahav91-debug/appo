import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { auth } from "@clerk/nextjs/server";
import Link from "next/link";
import {
  CheckCircle, QrCode, Download, ArrowLeft, Calendar,
  MapPin, AlertCircle, RefreshCcw, Ticket,
} from "lucide-react";
import { db } from "@/lib/db";
import { getPublicEvent } from "@/lib/services/event.service";
import { formatEventDate, formatEventTime, formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { QrCodeDisplay } from "@/components/payments/QrCodeDisplay";

interface Props {
  params: { slug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getPublicEvent(params.slug);
  return {
    title: event ? `My Ticket — ${event.title}` : "My Ticket",
    robots: { index: false },
  };
}

export default async function MyTicketPage({ params }: Props) {
  const event = await getPublicEvent(params.slug);
  if (!event || event.status !== "PUBLISHED") notFound();

  const { userId: clerkId } = auth();
  if (!clerkId) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 px-4 text-center">
        <Ticket className="h-12 w-12 text-slate-300" />
        <h1 className="text-xl font-bold text-slate-900">Sign in to view your ticket</h1>
        <Button asChild>
          <Link href={`/login?redirect_url=/events/${params.slug}/my-ticket`}>
            Sign in
          </Link>
        </Button>
      </div>
    );
  }

  const user = await db.user.findUnique({
    where: { clerkId, deletedAt: null },
    select: { id: true, name: true, email: true },
  });
  if (!user) notFound();

  const payment = await db.payment.findFirst({
    where: { eventId: event.id, userId: user.id },
    include: {
      ticket: {
        select: { name: true, type: true, description: true },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  if (!payment) {
    return (
      <div className="max-w-md mx-auto py-16 px-4 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 mx-auto mb-4">
          <Ticket className="h-7 w-7 text-slate-400" />
        </div>
        <h1 className="text-xl font-bold text-slate-900 mb-2">No ticket found</h1>
        <p className="text-sm text-slate-500 mb-6">
          You haven't purchased a ticket for this event yet.
        </p>
        <Button asChild className="bg-blue-500 hover:bg-blue-700">
          <Link href={`/events/${params.slug}/rsvp`}>Get tickets</Link>
        </Button>
      </div>
    );
  }

  const isPaid = payment.status === "PAID" || payment.status === "WAIVED";
  const isRefunded = payment.status === "REFUNDED" || payment.status === "PARTIALLY_REFUNDED";
  const isPending = payment.status === "PENDING" || payment.status === "PROCESSING";
  const isFailed = payment.status === "FAILED";

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      {/* Back */}
      <Link
        href={`/events/${params.slug}`}
        className="mb-6 flex items-center gap-1.5 text-sm text-slate-400 hover:text-blue-600 transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to event
      </Link>

      {/* Ticket card */}
      <div className="rounded-3xl border border-border bg-white shadow-lg overflow-hidden">
        {/* Header band */}
        <div className={`px-6 py-5 ${isPaid ? "bg-gradient-to-r from-blue-600 to-blue-700" : isRefunded ? "bg-slate-400" : isFailed ? "bg-red-500" : "bg-blue-400"}`}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-xs font-semibold uppercase tracking-widest">
                Your ticket
              </p>
              <h1 className="text-white font-display text-xl font-bold mt-1 leading-tight">
                {event.title}
              </h1>
            </div>
            {isPaid && <CheckCircle className="h-8 w-8 text-white/80" />}
            {isRefunded && <RefreshCcw className="h-8 w-8 text-white/80" />}
            {isFailed && <AlertCircle className="h-8 w-8 text-white/80" />}
          </div>
        </div>

        {/* Ticket details */}
        <div className="px-6 py-5 flex flex-col gap-4">
          {/* Event meta */}
          <div className="grid grid-cols-2 gap-4 pb-4 border-b border-dashed border-slate-200">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Date</p>
              <div className="flex items-center gap-1.5 mt-1">
                <Calendar className="h-3.5 w-3.5 text-slate-400" />
                <p className="text-sm text-slate-900">{formatEventDate(event.startAt, event.timezone)}</p>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 pl-5">{formatEventTime(event.startAt, event.timezone)}</p>
            </div>
            {event.venueName && (
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Venue</p>
                <div className="flex items-center gap-1.5 mt-1">
                  <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <p className="text-sm text-slate-900 leading-tight">{event.venueName}</p>
                </div>
              </div>
            )}
          </div>

          {/* Ticket type + holder */}
          <div className="grid grid-cols-2 gap-4 pb-4 border-b border-dashed border-slate-200">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Ticket</p>
              <p className="text-sm font-semibold text-slate-900 mt-1">{payment.ticket.name}</p>
              {payment.quantity > 1 && (
                <p className="text-xs text-slate-400">× {payment.quantity}</p>
              )}
            </div>
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Name</p>
              <p className="text-sm font-semibold text-slate-900 mt-1">{user.name}</p>
            </div>
            {payment.totalAmountCents > 0 && (
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Paid</p>
                <p className="text-sm font-semibold text-slate-900 mt-1">
                  {formatCurrency(payment.totalAmountCents, payment.currency)}
                </p>
              </div>
            )}
            {payment.ticketCode && (
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Code</p>
                <p className="text-sm font-mono font-bold text-blue-700 mt-1">{payment.ticketCode}</p>
              </div>
            )}
          </div>

          {/* QR code */}
          {isPaid && payment.qrPayload ? (
            <div className="flex flex-col items-center gap-3 py-2">
              <p className="text-xs text-slate-400 text-center">
                Show this QR code at check-in
              </p>
              <QrCodeDisplay payload={payment.qrPayload} size={200} />
              <p className="text-[10px] text-slate-300 font-mono">
                {payment.ticketCode}
              </p>
            </div>
          ) : isPending ? (
            <div className="flex items-center gap-3 rounded-xl bg-blue-50 border border-blue-200 p-4">
              <AlertCircle className="h-5 w-5 text-blue-500 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-blue-900">Payment processing</p>
                <p className="text-xs text-blue-700 mt-0.5">Your QR ticket will appear here once confirmed.</p>
              </div>
            </div>
          ) : isRefunded ? (
            <div className="flex items-center gap-3 rounded-xl bg-slate-50 border border-slate-200 p-4">
              <RefreshCcw className="h-5 w-5 text-slate-400 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-slate-700">Ticket refunded</p>
                <p className="text-xs text-slate-500 mt-0.5">
                  {payment.refundedAmountCents > 0
                    ? `${formatCurrency(payment.refundedAmountCents, payment.currency)} refunded`
                    : "Full refund issued"}
                  {payment.refundedAt && ` on ${formatEventDate(payment.refundedAt, "UTC")}`}
                </p>
              </div>
            </div>
          ) : isFailed ? (
            <div className="flex items-center gap-3 rounded-xl bg-red-50 border border-red-200 p-4">
              <AlertCircle className="h-5 w-5 text-red-500 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-red-700">Payment failed</p>
                <Button asChild size="sm" className="mt-2 bg-red-500 hover:bg-red-600">
                  <Link href={`/events/${params.slug}/rsvp`}>Try again</Link>
                </Button>
              </div>
            </div>
          ) : null}
        </div>

        {/* Perforated separator */}
        <div className="relative border-t border-dashed border-slate-200 mx-4">
          <div className="absolute -left-4 -top-3 h-6 w-6 rounded-full bg-slate-100 border border-border" />
          <div className="absolute -right-4 -top-3 h-6 w-6 rounded-full bg-slate-100 border border-border" />
        </div>

        {/* Actions footer */}
        <div className="px-6 py-4 flex gap-3">
          {payment.receiptUrl && (
            <Button variant="outline" size="sm" className="gap-1.5 flex-1" asChild>
              <a href={payment.receiptUrl} target="_blank" rel="noopener noreferrer">
                <Download className="h-3.5 w-3.5" />
                Receipt
              </a>
            </Button>
          )}
          <Button variant="outline" size="sm" className="gap-1.5 flex-1" asChild>
            <Link href={`/events/${params.slug}`}>
              <Calendar className="h-3.5 w-3.5" />
              Event details
            </Link>
          </Button>
        </div>
      </div>

      {/* Ticket tip */}
      {isPaid && (
        <p className="mt-4 text-center text-xs text-slate-400">
          Save a screenshot of your QR code for offline access at the venue.
        </p>
      )}
    </div>
  );
}
