import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { auth } from "@clerk/nextjs/server";
import Link from "next/link";
import { getPublicEvent } from "@/lib/services/event.service";
import { getMemoryFeed } from "@/lib/services/memory.service";
import { MemoryWall } from "@/components/memories/MemoryWall";
import { db } from "@/lib/db";

interface Props {
  params: { slug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getPublicEvent(params.slug);
  if (!event) return {};
  return {
    title: `Memories — ${event.title}`,
    description: `Photos and stories from the ${event.schoolName} Class of ${event.graduationYear} reunion.`,
    robots: { index: false },
  };
}

export default async function MemoryWallPage({ params }: Props) {
  const event = await getPublicEvent(params.slug);
  if (!event || event.status !== "PUBLISHED") notFound();

  // Viewer identity
  const { userId: clerkId } = auth();
  let viewerId: string | null = null;
  if (clerkId) {
    const user = await db.user.findUnique({
      where: { clerkId, deletedAt: null },
      select: { id: true },
    });
    viewerId = user?.id ?? null;
  }

  // Determine viewer roles
  let isOrganizer = false;
  let isAttendee = false;
  if (viewerId) {
    const [committee, rsvp] = await Promise.all([
      db.committeeMember.findUnique({
        where: { eventId_userId: { eventId: event.id, userId: viewerId }, revokedAt: null },
        select: { role: true },
      }),
      db.rSVP.findUnique({
        where: { eventId_userId: { eventId: event.id, userId: viewerId } },
        select: { status: true },
      }),
    ]);
    isOrganizer =
      !!committee &&
      (committee.role === "ORGANIZER" || committee.role === "CO_ORGANIZER");
    isAttendee =
      !!committee ||
      (!!rsvp && rsvp.status !== "CANCELLED" && rsvp.status !== "DECLINED");
  }

  const autoApprove =
    (event.settings as { memoriesAutoApprove?: boolean } | null)
      ?.memoriesAutoApprove ?? false;

  // Load initial feed + featured posts in parallel
  const [feed, featuredResult] = await Promise.all([
    getMemoryFeed(event.id, viewerId, { limit: 20 }),
    getMemoryFeed(event.id, viewerId, { featuredOnly: true, limit: 6 }),
  ]);

  return (
    <div className="container max-w-4xl py-8 px-4 mx-auto">
      {/* Breadcrumb */}
      <nav className="mb-6 text-sm text-slate-400">
        <Link href={`/events/${params.slug}`} className="hover:text-blue-600 transition-colors">
          ← Back to event
        </Link>
      </nav>

      <MemoryWall
        eventId={event.id}
        eventSlug={params.slug}
        graduationYear={event.graduationYear}
        viewerId={viewerId}
        isOrganizer={isOrganizer}
        isAttendee={isAttendee}
        autoApprove={autoApprove}
        initialPosts={feed.posts}
        initialCursor={feed.nextCursor}
        featuredPosts={featuredResult.posts}
      />
    </div>
  );
}
