import { notFound, redirect } from "next/navigation";
import type { Metadata } from "next";
import { auth } from "@clerk/nextjs/server";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { getPublicEvent } from "@/lib/services/event.service";
import { TicketPurchaseFlow } from "@/components/payments/TicketPurchaseFlow";
import { db } from "@/lib/db";

interface Props {
  params: { slug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getPublicEvent(params.slug);
  if (!event) return {};
  return {
    title: `Tickets — ${event.title}`,
    description: `Get your ticket for ${event.title}`,
    robots: { index: false },
  };
}

export default async function TicketsPage({ params }: Props) {
  const event = await getPublicEvent(params.slug);
  if (!event || event.status !== "PUBLISHED") notFound();

  // If ticketing not enabled, redirect to RSVP
  if (!event.ticketingEnabled) {
    redirect(`/events/${params.slug}/rsvp`);
  }

  // Must be signed in
  const { userId: clerkId } = auth();
  if (!clerkId) {
    redirect(`/login?redirect_url=/events/${params.slug}/tickets`);
  }

  // Fetch available tickets
  const tickets = await db.ticket.findMany({
    where: {
      eventId: event.id,
      isVisible: true,
      isActive: true,
    },
    select: {
      id: true,
      name: true,
      description: true,
      price: true,
      currency: true,
      capacity: true,
      soldCount: true,
      maxPerOrder: true,
      type: true,
      earlyBirdPrice: true,
      earlyBirdDeadline: true,
      couponCode: true,
    },
    orderBy: { price: "asc" },
  });

  if (tickets.length === 0) {
    redirect(`/events/${params.slug}/rsvp`);
  }

  const settings = event.settings as {
    allowGuestPlus1?: boolean;
    maxGuestsPerRsvp?: number;
  } | null;

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <Link
        href={`/events/${params.slug}`}
        className="mb-6 flex items-center gap-1.5 text-sm text-slate-400 hover:text-blue-600 transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to event
      </Link>

      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-slate-900">
          Get your ticket
        </h1>
        <p className="text-sm text-slate-500 mt-1">{event.title}</p>
      </div>

      <TicketPurchaseFlow
        eventId={event.id}
        eventSlug={params.slug}
        tickets={tickets}
        allowPlusOne={settings?.allowGuestPlus1 ?? false}
        maxGuests={settings?.maxGuestsPerRsvp ?? 1}
      />
    </div>
  );
}
