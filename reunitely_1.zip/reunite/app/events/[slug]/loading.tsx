import { Skeleton } from "@/components/ui/skeleton";

export default function EventPageLoading() {
  return (
    <div>
      {/* Hero skeleton */}
      <Skeleton className="h-48 w-full sm:h-64 md:h-80" />

      <div className="container">
        <div className="-mt-8 rounded-2xl border border-border bg-card p-6 shadow-card-lg sm:-mt-12">
          <div className="flex flex-col gap-4 md:flex-row md:justify-between">
            <div className="flex flex-col gap-3">
              <Skeleton className="h-4 w-40" />
              <Skeleton className="h-8 w-72" />
              <div className="flex gap-4">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-24" />
              </div>
            </div>
            <div className="flex gap-2">
              <Skeleton className="h-11 w-36 rounded-md" />
              <Skeleton className="h-11 w-24 rounded-md" />
            </div>
          </div>
        </div>
      </div>

      {/* Tab bar skeleton */}
      <div className="mt-4 border-b border-border">
        <div className="container flex gap-6 pb-0">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-10 w-16" />
          ))}
        </div>
      </div>

      {/* Content skeleton */}
      <div className="container py-8">
        <div className="grid gap-8 md:grid-cols-3">
          <div className="md:col-span-2 space-y-4">
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-5 w-4/5" />
            <Skeleton className="h-5 w-3/5" />
          </div>
          <div className="space-y-4">
            <Skeleton className="h-40 rounded-xl" />
            <Skeleton className="h-32 rounded-xl" />
          </div>
        </div>
      </div>
    </div>
  );
}
