import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { auth } from "@clerk/nextjs/server";
import { getPublicEvent } from "@/lib/services/event.service";
import {
  getDirectoryAttendees,
  getDirectoryCities,
} from "@/lib/services/directory.service";
import { AttendeeDirectory } from "@/components/directory/AttendeeDirectory";
import { db } from "@/lib/db";

interface Props {
  params: { slug: string };
  searchParams: { search?: string; badge?: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getPublicEvent(params.slug);
  if (!event) return {};
  return {
    title: `Attendees — ${event.title}`,
    description: `See who's coming to the ${event.schoolName} Class of ${event.graduationYear} reunion.`,
    robots: { index: false },
  };
}

export default async function AttendeesPage({ params, searchParams }: Props) {
  const event = await getPublicEvent(params.slug);
  if (!event || event.status !== "PUBLISHED") notFound();

  // Get viewer identity
  const { userId: clerkId } = auth();
  let viewerId: string | null = null;
  if (clerkId) {
    const user = await db.user.findUnique({
      where: { clerkId, deletedAt: null },
      select: { id: true },
    });
    viewerId = user?.id ?? null;
  }

  // Load directory data
  const [directoryData, cities] = await Promise.all([
    getDirectoryAttendees(event.id, viewerId, {
      search: searchParams.search,
      limit: 48,
    }),
    getDirectoryCities(event.id),
  ]);

  return (
    <AttendeeDirectory
      initialAttendees={directoryData.attendees}
      total={directoryData.total}
      eventSlug={params.slug}
      eventId={event.id}
      viewerUserId={viewerId}
      viewerIsAttendee={directoryData.viewerIsAttendee}
      cities={cities}
      initialSearch={searchParams.search ?? ""}
      initialBadge={searchParams.badge ?? ""}
    />
  );
}
