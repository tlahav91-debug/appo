import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { auth } from "@clerk/nextjs/server";
import { getPublicEvent } from "@/lib/services/event.service";
import { getAttendeeProfile } from "@/lib/services/directory.service";
import { AttendeeProfileView } from "@/components/directory/AttendeeProfileView";
import { db } from "@/lib/db";
import Link from "next/link";
import { Lock } from "lucide-react";

interface Props {
  params: { slug: string; userId: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getPublicEvent(params.slug);
  if (!event) return {};

  const user = await db.user.findUnique({
    where: { id: params.userId, deletedAt: null },
    select: { name: true },
  });

  return {
    title: user ? `${user.name} — ${event.title}` : event.title,
    robots: { index: false },
  };
}

export default async function AttendeeProfilePage({ params }: Props) {
  const event = await getPublicEvent(params.slug);
  if (!event || event.status !== "PUBLISHED") notFound();

  // Viewer identity
  const { userId: clerkId } = auth();
  let viewerId: string | null = null;
  if (clerkId) {
    const user = await db.user.findUnique({
      where: { clerkId, deletedAt: null },
      select: { id: true },
    });
    viewerId = user?.id ?? null;
  }

  const attendee = await getAttendeeProfile(event.id, params.userId, viewerId);

  // Profile not found or not visible
  if (!attendee) {
    return (
      <div className="max-w-md mx-auto py-16 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 mx-auto mb-4">
          <Lock className="h-7 w-7 text-slate-400" />
        </div>
        <h1 className="font-display text-xl font-bold text-slate-900 mb-2">
          Profile not available
        </h1>
        <p className="text-sm text-slate-500 mb-6">
          {viewerId
            ? "This attendee has set their profile to private, or they haven't confirmed their RSVP yet."
            : "Sign in to view attendee profiles."}
        </p>
        {!viewerId && (
          <Link
            href={`/login?redirect_url=/events/${params.slug}/attendees/${params.userId}`}
            className="inline-flex items-center gap-2 rounded-lg bg-blue-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 transition-colors"
          >
            Sign in to view
          </Link>
        )}
        <div className="mt-4">
          <Link
            href={`/events/${params.slug}/attendees`}
            className="text-sm text-slate-400 hover:text-blue-600 transition-colors"
          >
            ← Back to directory
          </Link>
        </div>
      </div>
    );
  }

  const isOwnProfile = attendee.userId === viewerId;

  // Check if viewer is an attendee
  let viewerIsAttendee = false;
  if (viewerId) {
    const [rsvp, committee] = await Promise.all([
      db.rSVP.findUnique({
        where: { eventId_userId: { eventId: event.id, userId: viewerId } },
        select: { status: true },
      }),
      db.committeeMember.findUnique({
        where: { eventId_userId: { eventId: event.id, userId: viewerId }, revokedAt: null },
        select: { id: true },
      }),
    ]);
    viewerIsAttendee =
      !!committee ||
      (!!rsvp && rsvp.status !== "CANCELLED" && rsvp.status !== "DECLINED");
  }

  return (
    <div className="container py-8 max-w-2xl mx-auto px-4">
      <AttendeeProfileView
        attendee={attendee}
        eventSlug={params.slug}
        eventTitle={event.title}
        schoolName={event.schoolName}
        graduationYear={event.graduationYear}
        isOwnProfile={isOwnProfile}
        viewerIsAttendee={viewerIsAttendee}
      />
    </div>
  );
}
