import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { EventHero } from "@/components/events/EventHero";
import { EventTabBar } from "@/components/events/EventTabBar";
import { EventAboutTab } from "@/components/events/EventAboutTab";
import { EventAttendeesTab } from "@/components/events/EventAttendeesTab";
import { EventMemoriesPreview } from "@/components/memories/EventMemoriesPreview";
import { EventNominationsPreview } from "@/components/nominations/EventNominationsPreview";
import { StickyRsvpBar } from "@/components/rsvp/StickyRsvpBar";
import { getPublicEvent } from "@/lib/services/event.service";
import { Skeleton } from "@/components/ui/skeleton";

interface Props {
  params: { slug: string };
  searchParams: { tab?: string };
}

// Generate SEO metadata from event data
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getPublicEvent(params.slug);
  if (!event) return {};

  return {
    title: event.title,
    description: `${event.schoolName} Class of ${event.graduationYear} Reunion — ${new Intl.DateTimeFormat("en-US", { dateStyle: "long" }).format(new Date(event.startAt))}`,
    openGraph: {
      title: event.title,
      description: `Join the ${event.schoolName} Class of ${event.graduationYear} reunion.`,
      images: event.coverImageUrl
        ? [{ url: event.coverImageUrl, width: 1200, height: 630 }]
        : undefined,
    },
  };
}

// ISR: revalidate every 60 seconds
export const revalidate = 60;

export default async function PublicEventPage({ params, searchParams }: Props) {
  const event = await getPublicEvent(params.slug);
  if (!event) notFound();

  // Enforce password-protected events (handled client-side gate if passwordHash set)
  const isPasswordProtected = !!event.passwordHash;
  const activeTab = searchParams.tab ?? "about";

  return (
    <>
      {/* Hero section */}
      <EventHero
        event={event}
        theme={event.theme ? {
          primaryColor: event.theme.primaryColor,
          accentColor: event.theme.accentColor,
          headerLayout: event.theme.headerLayout,
        } : undefined}
        confirmedCount={event._count.rsvps ?? 0}
      />

      {/* Tab navigation */}
      <div className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="container">
          <EventTabBar
            slug={params.slug}
            activeTab={activeTab}
            hasNominations={(event.settings as { nominationsEnabled?: boolean } | null)?.nominationsEnabled}
            hasSchedule={(event.settings as { scheduleEnabled?: boolean } | null)?.scheduleEnabled}
          />
        </div>
      </div>

      {/* Tab content */}
      <div className="container py-8">
        {activeTab === "about" && <EventAboutTab event={event} />}

        {activeTab === "attendees" && (
          <Suspense fallback={<Skeleton className="h-64 rounded-xl" />}>
            <EventAttendeesTab eventId={event.id} eventSlug={params.slug} />
          </Suspense>
        )}

        {activeTab === "memories" && (
          <Suspense fallback={<Skeleton className="h-96 rounded-xl" />}>
            <EventMemoriesPreview eventId={event.id} eventSlug={params.slug} />
          </Suspense>
        )}

        {activeTab === "nominations" && event.settings?.nominationsEnabled && (
          <Suspense fallback={<Skeleton className="h-64 rounded-xl" />}>
            <EventNominationsPreview eventId={event.id} />
          </Suspense>
        )}
      </div>

      {/* Mobile sticky RSVP bar */}
      <StickyRsvpBar event={event} />
    </>
  );
}
