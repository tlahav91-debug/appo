import { notFound, redirect } from "next/navigation";
import { auth } from "@clerk/nextjs/server";
import type { Metadata } from "next";
import Link from "next/link";
import { getPublicEvent } from "@/lib/services/event.service";
import { db } from "@/lib/db";
import { NominateClassmateForm } from "@/components/cohort-discovery/NominateClassmateForm";

interface Props {
  params: { slug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getPublicEvent(params.slug);
  if (!event) return {};
  return {
    title: `Nominate a Classmate — ${event.title}`,
    robots: { index: false },
  };
}

export default async function NominatePage({ params }: Props) {
  const event = await getPublicEvent(params.slug);
  if (!event || event.status !== "PUBLISHED") notFound();

  // Auth required
  const { userId: clerkId } = auth();
  if (!clerkId) {
    redirect(`/login?redirect_url=${encodeURIComponent(`/events/${params.slug}/nominate`)}`);
  }

  const user = await db.user.findUnique({
    where: { clerkId, deletedAt: null },
    select: { id: true },
  });
  if (!user) redirect("/login");

  // Check user is an attendee or committee member
  const [rsvp, committee] = await Promise.all([
    db.rSVP.findUnique({
      where: { eventId_userId: { eventId: event.id, userId: user.id } },
      select: { status: true },
    }),
    db.committeeMember.findUnique({
      where: { eventId_userId: { eventId: event.id, userId: user.id }, revokedAt: null },
      select: { id: true },
    }),
  ]);

  const isAttendee =
    committee ||
    (rsvp && rsvp.status !== "CANCELLED" && rsvp.status !== "DECLINED");

  if (!isAttendee) {
    return (
      <Shell slug={params.slug} title={event.title}>
        <div className="rounded-2xl border border-border bg-card p-8 text-center">
          <p className="text-4xl mb-3">🎟️</p>
          <h2 className="font-display text-xl font-bold text-slate-900 mb-2">
            RSVP first
          </h2>
          <p className="text-sm text-slate-500 mb-4">
            Only confirmed attendees can nominate missing classmates.
          </p>
          <Link
            href={`/events/${params.slug}/rsvp`}
            className="inline-flex items-center gap-2 rounded-lg bg-blue-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 transition-colors"
          >
            RSVP Now
          </Link>
        </div>
      </Shell>
    );
  }

  // How many leads has this user already submitted?
  const submittedCount = await db.cohortNominationLead.count({
    where: {
      eventId: event.id,
      submittedById: user.id,
      status: { notIn: ["REJECTED", "DUPLICATE"] },
    },
  });

  return (
    <Shell slug={params.slug} title={event.title}>
      <NominateClassmateForm
        eventId={event.id}
        eventTitle={event.title}
        graduationYear={event.graduationYear}
        schoolName={event.schoolName}
        remainingLeads={Math.max(0, 5 - submittedCount)}
      />
    </Shell>
  );
}

function Shell({
  slug,
  title,
  children,
}: {
  slug: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <header className="sticky top-0 z-30 border-b border-border bg-white/95 backdrop-blur-sm px-4 py-3">
        <div className="container flex items-center justify-between max-w-2xl mx-auto">
          <Link href="/" className="font-display text-lg font-bold text-slate-900">
            <span className="text-blue-500">Re</span>Unite
          </Link>
          <Link
            href={`/events/${slug}`}
            className="text-sm text-slate-500 hover:text-slate-700 transition-colors"
          >
            ← Back to event
          </Link>
        </div>
      </header>
      <main className="container max-w-lg mx-auto py-8 px-4 pb-24">
        {children}
      </main>
    </div>
  );
}
