import { notFound, redirect } from "next/navigation";
import type { Metadata } from "next";
import { requireAuth } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { EventHero } from "@/components/events/EventHero";
import { EventAboutTab } from "@/components/events/EventAboutTab";
import { formatEventDate, formatEventTime } from "@/lib/utils";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Eye, ArrowLeft } from "lucide-react";

export const metadata: Metadata = {
  title: "Event Preview — Reunitely",
  robots: { index: false },
};

interface Props {
  params: { id: string };
}

export default async function EventPreviewPage({ params }: Props) {
  const session = await requireAuth();

  const event = await db.event.findUnique({
    where: { id: params.id, createdById: session.user.id },
    include: {
      theme: true,
      createdBy: { select: { name: true, avatarUrl: true } },
      _count: { select: { rsvps: true } },
    },
  });

  if (!event) notFound();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Preview banner */}
      <div className="sticky top-0 z-50 flex items-center justify-between border-b border-blue-200 bg-blue-50 px-4 py-2.5">
        <div className="flex items-center gap-2 text-sm text-blue-800">
          <Eye className="h-4 w-4" />
          <span className="font-medium">Preview mode</span>
          <span className="hidden sm:inline text-blue-600">
            — This is how your event will look to attendees
          </span>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline" size="sm" className="gap-1.5 h-7 text-xs border-blue-300 text-blue-700 hover:bg-blue-100">
            <Link href={`/dashboard/events/new?draft=${params.id}`}>
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to wizard
            </Link>
          </Button>
          {event.status === "DRAFT" && (
            <Button asChild size="sm" className="h-7 text-xs">
              <Link href={`/dashboard/events/new?draft=${params.id}&step=8`}>
                Publish →
              </Link>
            </Button>
          )}
        </div>
      </div>

      {/* Rendered event page */}
      <div>
        {/* Hero */}
        <EventHero
          event={{
            id: event.id,
            title: event.title,
            slug: event.slug,
            coverImageUrl: event.coverImageUrl,
            startAt: event.startAt,
            endAt: event.endAt,
            timezone: event.timezone,
            venueName: event.venueName,
            venueAddress: event.venueAddress,
            schoolName: event.schoolName,
            graduationYear: event.graduationYear,
            status: event.status,
            visibility: event.visibility,
            ticketingEnabled: event.ticketingEnabled,
          }}
          theme={{
            primaryColor: event.theme?.primaryColor ?? "#1E3A5F",
            accentColor: event.theme?.accentColor ?? "#D4AF37",
            headerLayout: event.theme?.headerLayout ?? "centered",
          }}
          confirmedCount={event._count.rsvps}
          isOrganizer={true}
          isPreview={true}
        />

        {/* Content */}
        <div className="container py-8 max-w-4xl">
          <EventAboutTab event={event} />
        </div>
      </div>
    </div>
  );
}
