import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok } from "@/lib/utils/api-response";
import { withPlatformPermission } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";

const querySchema = z.object({
  search: z.string().max(100).default(""),
  limit: z.coerce.number().int().min(1).max(100).default(50),
  cursor: z.string().optional(),
});

export const GET = withPlatformPermission(
  "platform:view_all_events",
  async (req: NextRequest) => {
    const url = new URL(req.url);
    const { search, limit, cursor } = querySchema.parse(
      Object.fromEntries(url.searchParams)
    );

    const users = await db.user.findMany({
      where: {
        ...(search
          ? {
              OR: [
                { name: { contains: search, mode: "insensitive" } },
                { email: { contains: search, mode: "insensitive" } },
              ],
            }
          : {}),
        ...(cursor ? { id: { gt: cursor } } : {}),
      },
      select: {
        id: true,
        name: true,
        email: true,
        avatarUrl: true,
        platformRole: true,
        lastActiveAt: true,
        loginCount: true,
        deletedAt: true,
        _count: { select: { rsvps: true } },
      },
      orderBy: { createdAt: "desc" },
      take: limit,
    });

    return ok(users);
  }
);
