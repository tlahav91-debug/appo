import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, badRequest, notFound, withErrorHandling } from "@/lib/utils/api-response";
import { withPlatformPermission } from "@/lib/auth/action-guards";
import { syncPlatformRoleToClerk } from "@/lib/auth/session";
import { auditLog } from "@/lib/audit/log";
import { db } from "@/lib/db";

const roleSchema = z.object({
  platformRole: z.enum(["USER", "MODERATOR", "SUPER_ADMIN"]),
  reason: z.string().max(200).optional(),
});

// PATCH /api/admin/users/[userId]/role
// Only SUPER_ADMIN can change platform roles.
// MODERATOR can only be set/removed by SUPER_ADMIN.
export const PATCH = withPlatformPermission(
  "platform:admin",
  async (req: NextRequest, { user: actor, params }) => {
    const targetUserId = params["userId"];
    if (!targetUserId) return badRequest("User ID required.");

    // Prevent self-demotion (safety guard)
    if (targetUserId === actor.id) {
      return badRequest("You cannot change your own platform role.");
    }

    const body = roleSchema.parse(await req.json());

    const targetUser = await db.user.findUnique({
      where: { id: targetUserId, deletedAt: null },
      select: { id: true, clerkId: true, name: true, email: true, platformRole: true },
    });
    if (!targetUser) return notFound("User not found.");

    const previousRole = targetUser.platformRole;

    // Update DB
    await db.user.update({
      where: { id: targetUserId },
      data: { platformRole: body.platformRole },
    });

    // Sync to Clerk JWT so the change takes effect on next request
    await syncPlatformRoleToClerk(targetUser.clerkId, body.platformRole);

    await auditLog({
      actorId: actor.id,
      action: "ROLE_CHANGED",
      resourceType: "User",
      resourceId: targetUserId,
      before: { platformRole: previousRole },
      after: { platformRole: body.platformRole },
      metadata: { reason: body.reason, targetEmail: targetUser.email },
    });

    return ok({
      userId: targetUserId,
      previousRole,
      newRole: body.platformRole,
    });
  }
);
