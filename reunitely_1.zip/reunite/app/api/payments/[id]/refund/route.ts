import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, forbidden, notFound, badRequest } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { refundPayment } from "@/lib/stripe";
import { db } from "@/lib/db";
import { auditLog } from "@/lib/audit/log";

const refundSchema = z.object({
  amountCents: z.number().int().min(1).optional(), // omit for full refund
  reason: z.enum(["DUPLICATE", "CANCELLED_EVENT", "ORGANIZER_CANCELLED", "ATTENDEE_REQUEST", "OTHER"]),
  note: z.string().max(500).optional(),
});

// POST /api/payments/[id]/refund — organizer initiates refund
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const paymentId = params["id"]!;
  const input = refundSchema.parse(await req.json());

  const payment = await db.payment.findUnique({
    where: { id: paymentId },
    select: {
      id: true,
      eventId: true,
      userId: true,
      status: true,
      totalAmountCents: true,
      refundedAmountCents: true,
      stripePaymentIntentId: true,
      currency: true,
    },
  });
  if (!payment) return notFound();

  // Must be event organizer
  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId: payment.eventId, userId: user.id }, revokedAt: null },
    select: { role: true },
  });
  if (!committee) return forbidden("Only organizers can issue refunds.");

  if (payment.status !== "PAID") {
    return badRequest("Only paid orders can be refunded.");
  }

  if (!payment.stripePaymentIntentId) {
    // Manual/waived payment — mark as refunded directly
    await db.payment.update({
      where: { id: paymentId },
      data: {
        status: "REFUNDED",
        refundedAmountCents: payment.totalAmountCents,
        refundedAt: new Date(),
        refundReason: input.reason as never,
        refundNote: input.note,
      },
    });

    await auditLog({
      actorId: user.id,
      action: "PAYMENT_REFUNDED",
      resourceType: "Payment",
      resourceId: paymentId,
      eventId: payment.eventId,
      metadata: { reason: input.reason, manual: true },
    });

    return ok({ refunded: true, amount: payment.totalAmountCents });
  }

  // Stripe refund
  const refundAmount = input.amountCents ?? undefined;
  const stripeRefund = await refundPayment(
    payment.stripePaymentIntentId,
    refundAmount
  );

  const newRefundedTotal = payment.refundedAmountCents + stripeRefund.amount;
  const isFullRefund = newRefundedTotal >= payment.totalAmountCents;

  await db.payment.update({
    where: { id: paymentId },
    data: {
      status: isFullRefund ? "REFUNDED" : "PARTIALLY_REFUNDED",
      refundedAmountCents: newRefundedTotal,
      refundedAt: new Date(),
      refundReason: input.reason as never,
      refundNote: input.note,
      stripeRefundId: stripeRefund.id,
    },
  });

  await auditLog({
    actorId: user.id,
    action: "PAYMENT_REFUNDED",
    resourceType: "Payment",
    resourceId: paymentId,
    eventId: payment.eventId,
    metadata: {
      stripeRefundId: stripeRefund.id,
      amount: stripeRefund.amount,
      reason: input.reason,
    },
  });

  return ok({
    refunded: true,
    amount: stripeRefund.amount,
    stripeRefundId: stripeRefund.id,
    newStatus: isFullRefund ? "REFUNDED" : "PARTIALLY_REFUNDED",
  });
});
