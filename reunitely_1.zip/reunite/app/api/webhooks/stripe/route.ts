import { type NextRequest, NextResponse } from "next/server";
import { constructWebhookEvent } from "@/lib/stripe";
import { db } from "@/lib/db";

import { promoteFromWaitlist } from "@/lib/services/rsvp.service";
import { auditLog } from "@/lib/audit/log";
import * as Sentry from "@sentry/nextjs";
import type Stripe from "stripe";

// Stripe requires the raw body for signature verification
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const signature = req.headers.get("stripe-signature");
  if (!signature) {
    return NextResponse.json({ error: "Missing Stripe signature" }, { status: 400 });
  }

  let event: Stripe.Event;
  try {
    const rawBody = await req.arrayBuffer();
    event = constructWebhookEvent(Buffer.from(rawBody), signature);
  } catch (err) {
    console.error("[Stripe Webhook] Signature verification failed:", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutCompleted(
          event.data.object as Stripe.Checkout.Session
        );
        break;

      case "payment_intent.payment_failed":
        await handlePaymentFailed(
          event.data.object as Stripe.PaymentIntent
        );
        break;

      case "charge.dispute.created":
        await handleDisputeCreated(event.data.object as Stripe.Dispute);
        break;

      default:
        // Acknowledge unhandled events
        break;
    }
  } catch (err) {
    Sentry.captureException(err, {
      extra: { stripeEventType: event.type, stripeEventId: event.id },
    });
    console.error("[Stripe Webhook] Handler error:", err);
    // Return 200 to prevent Stripe from retrying — log the error internally
    return NextResponse.json({ received: true, error: "Handler failed" });
  }

  return NextResponse.json({ received: true });
}

// ─── Handlers ────────────────────────────────────────────────────────────────

async function handleCheckoutCompleted(
  session: Stripe.Checkout.Session
): Promise<void> {
  const { eventId, ticketId, userId, guestCount } = session.metadata ?? {};
  if (!eventId || !ticketId || !userId) {
    console.error("[Stripe Webhook] Missing metadata on checkout session:", session.id);
    return;
  }

  const totalCents = session.amount_total ?? 0;
  const paymentIntentId = typeof session.payment_intent === "string"
    ? session.payment_intent
    : session.payment_intent?.id;

  // Calculate quantity from Stripe line items
  const stripe = (await import("@/lib/stripe")).getStripe();
  const lineItems = await stripe.checkout.sessions.listLineItems(session.id, { limit: 10 });
  const totalQty = lineItems.data.reduce((s, li) => s + (li.quantity ?? 1), 0);
  const primaryQty = lineItems.data[0]?.quantity ?? 1;

  // Generate QR ticket data
  const { generateTicketCode, generateQrPayload } = await import("@/lib/payments/ticket-generator");
  const ticketCode = generateTicketCode();
  const qrPayload = generateQrPayload(ticketCode, eventId, userId);

  await db.payment.upsert({
    where: { stripeCheckoutSessionId: session.id },
    create: {
      eventId,
      userId,
      ticketId,
      quantity: primaryQty,
      unitAmountCents: primaryQty > 0 ? Math.round(totalCents / primaryQty) : totalCents,
      totalAmountCents: totalCents,
      netAmountCents: totalCents,
      currency: (session.currency ?? "usd").toUpperCase(),
      stripeCheckoutSessionId: session.id,
      stripePaymentIntentId: paymentIntentId ?? null,
      status: "PAID",
      method: "STRIPE",
      ticketCode,
      qrPayload,
      qrGeneratedAt: new Date(),
      paidAt: new Date(),
    },
    update: {
      status: "PAID",
      stripePaymentIntentId: paymentIntentId ?? null,
      totalAmountCents: totalCents,
      paidAt: new Date(),
    },
  });

  // Increment ticket sold count
  await db.ticket.update({
    where: { id: ticketId },
    data: { soldCount: { increment: primaryQty } },
  });

  // Update RSVP — include guest count if provided
  const guestCountInt = parseInt(guestCount ?? "0", 10);
  await db.rSVP.upsert({
    where: { eventId_userId: { eventId, userId } },
    create: {
      eventId,
      userId,
      status: "CONFIRMED",
      guestCount: guestCountInt,
      consentEmail: true,
      consentGivenAt: new Date(),
    },
    update: { status: "CONFIRMED", guestCount: guestCountInt },
  });

  await auditLog({
    actorId: userId,
    action: "PAYMENT_RECEIVED",
    resourceType: "Payment",
    resourceId: session.id,
    eventId,
    metadata: {
      amount: totalCents,
      currency: session.currency,
      ticketCode,
      stripeSessionId: session.id,
    },
  });

  // Send payment confirmation notification
  const { createNotification } = await import("@/lib/services/notification.service");
  const event = await db.event.findUnique({
    where: { id: eventId },
    select: { title: true },
  });
  if (event) {
    createNotification(userId, {
      type: "PAYMENT_RECEIVED",
      amount: totalCents,
      currency: (session.currency ?? "usd").toUpperCase(),
      eventTitle: event.title,
    }).catch(console.error);
  }
}

async function handlePaymentFailed(
  paymentIntent: Stripe.PaymentIntent
): Promise<void> {
  await db.payment.updateMany({
    where: { stripePaymentIntentId: paymentIntent.id },
    data: { status: "FAILED" },
  });
}

async function handleDisputeCreated(
  dispute: Stripe.Dispute
): Promise<void> {
  const chargeId =
    typeof dispute.charge === "string" ? dispute.charge : dispute.charge?.id;

  // Find the payment record linked to this dispute's payment intent
  const paymentIntentId =
    typeof dispute.payment_intent === "string"
      ? dispute.payment_intent
      : dispute.payment_intent?.id;

  const payment = paymentIntentId
    ? await db.payment.findFirst({
        where: { stripePaymentIntentId: paymentIntentId },
        select: {
          id: true,
          eventId: true,
          totalAmountCents: true,
          currency: true,
          event: { select: { title: true, slug: true } },
        },
      })
    : null;

  // Log for audit regardless
  if (payment?.eventId) {
    await auditLog({
      actorId: "system",
      action: "DISPUTE_CREATED",
      resourceType: "Payment",
      resourceId: payment.id,
      eventId: payment.eventId,
      metadata: {
        disputeId: dispute.id,
        chargeId,
        reason: dispute.reason,
        amountCents: dispute.amount,
      },
    });
  }

  // Notify all organizers of the event about the dispute
  if (payment?.eventId && payment.event) {
    const { notifyEventOrganizers } = await import(
      "@/lib/services/notification.service"
    );
    await notifyEventOrganizers(payment.eventId, {
      type: "PAYMENT_RECEIVED", // reuse closest type — dispute detail is in metadata
      amount: dispute.amount,
      currency: dispute.currency,
      eventTitle: payment.event.title,
    }).catch((err) =>
      console.error("[Stripe Webhook] Failed to notify organizers of dispute:", err)
    );
  }
}
