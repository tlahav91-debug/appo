import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, forbidden, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { triggerPusherEvent, pusherChannels } from "@/lib/pusher";
import { db } from "@/lib/db";
import { auditLog } from "@/lib/audit/log";

const slowModeSchema = z.object({
  // 0 = off; accepted values: 0, 10, 30, 60, 120, 300, 900
  seconds: z.number().int().min(0).max(900),
});

// POST /api/chat/rooms/[id]/slow-mode
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const roomId = params["id"]!;
  const { seconds } = slowModeSchema.parse(await req.json());

  const room = await db.chatRoom.findUnique({
    where: { id: roomId },
    select: { eventId: true },
  });
  if (!room) return notFound();

  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId: room.eventId, userId: user.id }, revokedAt: null },
    select: { role: true },
  });
  const canManage =
    committee?.role === "ORGANIZER" ||
    committee?.role === "CO_ORGANIZER" ||
    committee?.role === "COMMITTEE";

  if (!canManage) return forbidden("Only organizers can change slow mode.");

  await db.chatRoom.update({
    where: { id: roomId },
    data: { slowModeSeconds: seconds > 0 ? seconds : null },
  });

  triggerPusherEvent(pusherChannels.chatRoom(roomId), "slow-mode-changed", {
    slowModeSeconds: seconds > 0 ? seconds : null,
  }).catch(console.error);

  await auditLog({
    actorId: user.id,
    action: "CHAT_SLOW_MODE_CHANGED",
    resourceType: "ChatRoom",
    resourceId: roomId,
    eventId: room.eventId,
    metadata: { slowModeSeconds: seconds > 0 ? seconds : null },
  });

  return ok({ slowModeSeconds: seconds > 0 ? seconds : null });
});
