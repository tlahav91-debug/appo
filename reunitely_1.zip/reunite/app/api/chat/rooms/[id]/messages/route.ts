import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, forbidden, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { triggerPusherEvent, pusherChannels, pusherEvents } from "@/lib/pusher";
import { db } from "@/lib/db";

// Strip HTML tags from chat content to prevent XSS if content is ever
// rendered as HTML in a future client (e.g., a desktop/native app).
// The current web client renders as text, but defense-in-depth matters.
function stripHtml(str: string): string {
  return str.replace(/<[^>]*>/g, "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
}

const messageSchema = z.object({
  content: z
    .string()
    .min(1)
    .max(4000)
    .trim()
    .transform(stripHtml),
  replyToId: z.string().cuid().optional(),
  mediaUrl: z.string().url().optional(),
});

const PAGE_SIZE = 50;

// ─── GET /api/chat/rooms/[id]/messages ────────────────────────────────────────
export const GET = withApiAuth(async (req: NextRequest, { user, params }) => {
  const roomId = params["id"]!;
  const url = new URL(req.url);
  const cursor = url.searchParams.get("cursor") ?? undefined;
  const limit = Math.min(Number(url.searchParams.get("limit") ?? PAGE_SIZE), 100);

  const room = await db.chatRoom.findUnique({
    where: { id: roomId },
    select: { id: true, eventId: true, isArchived: true },
  });
  if (!room) return notFound();
  if (room.isArchived) return forbidden("This room is archived.");

  const hasAccess = await checkEventAccess(user.id, room.eventId);
  if (!hasAccess) return forbidden("You must RSVP to access this chat.");

  const messages = await db.chatMessage.findMany({
    where: {
      roomId,
      isDeleted: false,
      ...(cursor ? { createdAt: { lt: new Date(cursor) } } : {}),
    },
    include: {
      author: { select: { id: true, name: true, avatarUrl: true } },
      reactions: { select: { emoji: true, userId: true } },
      replyTo: {
        select: {
          id: true,
          content: true,
          isDeleted: true,
          author: { select: { name: true } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
    take: limit + 1,
  });

  const hasMore = messages.length > limit;
  const items = hasMore ? messages.slice(0, limit) : messages;

  // Normalize: rename `author` -> `user` to match client type
  const normalized = items.map(normalizeMessage);
  const nextCursor = hasMore
    ? items[items.length - 1]?.createdAt.toISOString() ?? null
    : null;

  return ok({ items: normalized, nextCursor });
});

// ─── POST /api/chat/rooms/[id]/messages ───────────────────────────────────────
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const rl = await applyRateLimit("chat", user.id);
  if (!rl.success) return rl.response!;

  const roomId = params["id"]!;
  const room = await db.chatRoom.findUnique({
    where: { id: roomId },
    select: { id: true, eventId: true, isArchived: true, slowModeSeconds: true },
  });
  if (!room) return notFound();
  if (room.isArchived) return forbidden("This room is archived.");

  const hasAccess = await checkEventAccess(user.id, room.eventId);
  if (!hasAccess) return forbidden("You must RSVP to send messages.");

  // Slow mode enforcement
  if (room.slowModeSeconds) {
    const lastMsg = await db.chatMessage.findFirst({
      where: { roomId, authorId: user.id, isDeleted: false },
      orderBy: { createdAt: "desc" },
      select: { createdAt: true },
    });
    if (lastMsg) {
      const elapsed = (Date.now() - lastMsg.createdAt.getTime()) / 1000;
      if (elapsed < room.slowModeSeconds) {
        const wait = Math.ceil(room.slowModeSeconds - elapsed);
        return forbidden(`Slow mode active — wait ${wait}s before sending.`);
      }
    }
  }

  const input = messageSchema.parse(await req.json());

  const message = await db.chatMessage.create({
    data: {
      roomId,
      authorId: user.id,
      content: input.content,
      replyToId: input.replyToId ?? null,
      mediaUrl: input.mediaUrl ?? null,
    },
    include: {
      author: { select: { id: true, name: true, avatarUrl: true } },
      reactions: { select: { emoji: true, userId: true } },
      replyTo: {
        select: {
          id: true,
          content: true,
          isDeleted: true,
          author: { select: { name: true } },
        },
      },
    },
  });

  const payload = normalizeMessage(message);

  triggerPusherEvent(
    pusherChannels.chatRoom(roomId),
    pusherEvents.NEW_MESSAGE,
    payload
  ).catch(console.error);

  return ok(payload);
});

// ─── Helpers ──────────────────────────────────────────────────────────────────
// Renames `author` -> `user` so client ChatMessageWithAuthor type is satisfied.
// Uses destructuring to exclude `author` cleanly (avoids `key: undefined` pollution).
function normalizeMessage(m: {
  id: string;
  roomId: string;
  authorId: string;
  content: string;
  mediaUrl: string | null;
  replyToId: string | null;
  isDeleted: boolean;
  deletedAt: Date | null;
  deletedById: string | null;
  editedAt: Date | null;
  editedContent: string | null;
  isPinned: boolean;
  pinnedAt: Date | null;
  pinnedById: string | null;
  createdAt: Date;
  author: { id: string; name: string; avatarUrl: string | null };
  reactions: Array<{ emoji: string; userId: string }>;
  replyTo: {
    id: string;
    content: string;
    isDeleted: boolean;
    author: { name: string };
  } | null;
}) {
  const { author, replyTo, ...rest } = m;
  return {
    ...rest,
    userId: m.authorId,
    user: author,
    replyTo: replyTo
      ? (() => {
          const { author: replyAuthor, ...replyRest } = replyTo;
          return { ...replyRest, user: replyAuthor };
        })()
      : null,
  };
}

async function checkEventAccess(userId: string, eventId: string): Promise<boolean> {
  const [committee, rsvp] = await Promise.all([
    db.committeeMember.findUnique({
      where: { eventId_userId: { eventId, userId }, revokedAt: null },
      select: { id: true },
    }),
    db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId } },
      select: { status: true },
    }),
  ]);
  return (
    !!committee ||
    (!!rsvp && rsvp.status !== "CANCELLED" && rsvp.status !== "DECLINED")
  );
}
