import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, forbidden, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";
import { auditLog } from "@/lib/audit/log";

const muteSchema = z.object({
  userId: z.string().cuid(),
  // duration in minutes; 0 = permanent (until unmuted)
  durationMinutes: z.number().int().min(0).max(60 * 24 * 7).default(60),
});

// POST /api/chat/rooms/[id]/members/mute — organizer mutes a user
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const roomId = params["id"]!;
  const input = muteSchema.parse(await req.json());

  const room = await db.chatRoom.findUnique({
    where: { id: roomId },
    select: { eventId: true },
  });
  if (!room) return notFound();

  // Must be organizer
  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId: room.eventId, userId: user.id }, revokedAt: null },
    select: { role: true },
  });
  const canMute =
    committee?.role === "ORGANIZER" || committee?.role === "CO_ORGANIZER";
  if (!canMute) return forbidden("Only organizers can mute users.");

  const mutedUntil =
    input.durationMinutes > 0
      ? new Date(Date.now() + input.durationMinutes * 60 * 1000)
      : null; // permanent until manually unmuted

  await db.chatRoomMember.upsert({
    where: { roomId_userId: { roomId, userId: input.userId } },
    create: {
      roomId,
      userId: input.userId,
      isMuted: true,
      mutedUntil,
    },
    update: {
      isMuted: true,
      mutedUntil,
    },
  });

  await auditLog({
    actorId: user.id,
    action: "CHAT_USER_MUTED",
    resourceType: "ChatRoom",
    resourceId: roomId,
    eventId: room.eventId,
    metadata: {
      targetUserId: input.userId,
      durationMinutes: input.durationMinutes,
      mutedUntil: mutedUntil?.toISOString() ?? "permanent",
    },
  });

  return ok({ muted: true, mutedUntil });
});

// DELETE /api/chat/rooms/[id]/members/mute — unmute
export const DELETE = withApiAuth(async (req: NextRequest, { user, params }) => {
  const roomId = params["id"]!;
  const { userId } = z.object({ userId: z.string().cuid() }).parse(await req.json());

  const room = await db.chatRoom.findUnique({
    where: { id: roomId },
    select: { eventId: true },
  });
  if (!room) return notFound();

  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId: room.eventId, userId: user.id }, revokedAt: null },
    select: { role: true },
  });
  const canMute =
    committee?.role === "ORGANIZER" || committee?.role === "CO_ORGANIZER";
  if (!canMute) return forbidden("Only organizers can unmute users.");

  await db.chatRoomMember.updateMany({
    where: { roomId, userId },
    data: { isMuted: false, mutedUntil: null },
  });

  return ok({ muted: false });
});
