import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, forbidden, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { triggerPusherEvent, pusherChannels, pusherEvents } from "@/lib/pusher";
import { db } from "@/lib/db";

const reactionSchema = z.object({
  emoji: z.string().min(1).max(10),
});

// POST /api/chat/rooms/[id]/react
// body: { messageId, emoji }
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const rl = await applyRateLimit("reaction", user.id);
  if (!rl.success) return rl.response!;
  const roomId = params["id"]!;
  const body = z
    .object({ messageId: z.string().cuid(), emoji: z.string().min(1).max(10) })
    .parse(await req.json());

  const room = await db.chatRoom.findUnique({
    where: { id: roomId },
    select: { eventId: true },
  });
  if (!room) return notFound();

  // Access check
  const hasAccess = await checkEventAccess(user.id, room.eventId);
  if (!hasAccess) return forbidden("You must RSVP to react to messages.");

  // Toggle: remove if exists, add if not
  const existing = await db.chatMessageReaction.findUnique({
    where: {
      messageId_userId_emoji: {
        messageId: body.messageId,
        userId: user.id,
        emoji: body.emoji,
      },
    },
  });

  let action: "added" | "removed";

  if (existing) {
    await db.chatMessageReaction.delete({ where: { id: existing.id } });
    action = "removed";
  } else {
    await db.chatMessageReaction.create({
      data: {
        messageId: body.messageId,
        userId: user.id,
        emoji: body.emoji,
      },
    });
    action = "added";
  }

  // Get updated reaction summary
  const reactions = await db.chatMessageReaction.findMany({
    where: { messageId: body.messageId },
    select: { emoji: true, userId: true },
  });

  const payload = {
    messageId: body.messageId,
    emoji: body.emoji,
    action,
    userId: user.id,
    reactions,
  };

  triggerPusherEvent(
    pusherChannels.chatRoom(roomId),
    pusherEvents.REACTION_ADDED,
    payload
  ).catch(console.error);

  return ok(payload);
});

async function checkEventAccess(userId: string, eventId: string): Promise<boolean> {
  const [committee, rsvp] = await Promise.all([
    db.committeeMember.findUnique({
      where: { eventId_userId: { eventId, userId }, revokedAt: null },
      select: { id: true },
    }),
    db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId } },
      select: { status: true },
    }),
  ]);
  return (
    !!committee ||
    (!!rsvp && rsvp.status !== "CANCELLED" && rsvp.status !== "DECLINED")
  );
}
