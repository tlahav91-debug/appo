import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, forbidden, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { triggerPusherEvent, pusherChannels } from "@/lib/pusher";
import { db } from "@/lib/db";
import { auditLog } from "@/lib/audit/log";

const pinSchema = z.object({
  messageId: z.string().cuid(),
  pinned: z.boolean(),
});

// POST /api/chat/rooms/[id]/pin
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const roomId = params["id"]!;
  const { messageId, pinned } = pinSchema.parse(await req.json());

  const room = await db.chatRoom.findUnique({
    where: { id: roomId },
    select: { eventId: true },
  });
  if (!room) return notFound();

  // Pin/unpin requires organizer or co-organizer
  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId: room.eventId, userId: user.id }, revokedAt: null },
    select: { role: true },
  });
  const canPin =
    committee?.role === "ORGANIZER" ||
    committee?.role === "CO_ORGANIZER" ||
    committee?.role === "COMMITTEE";

  if (!canPin) return forbidden("Only organizers can pin messages.");

  const message = await db.chatMessage.findUnique({
    where: { id: messageId, roomId },
    select: { id: true },
  });
  if (!message) return notFound();

  const updated = await db.chatMessage.update({
    where: { id: messageId },
    data: {
      isPinned: pinned,
      pinnedAt: pinned ? new Date() : null,
      pinnedById: pinned ? user.id : null,
    },
    include: {
      author: { select: { id: true, name: true, avatarUrl: true } },
    },
  });

  await auditLog({
    actorId: user.id,
    action: pinned ? "CHAT_MESSAGE_PINNED" : "CHAT_MESSAGE_UNPINNED",
    resourceType: "ChatMessage",
    resourceId: messageId,
    eventId: room.eventId,
    metadata: { roomId },
  });

  triggerPusherEvent(pusherChannels.chatRoom(roomId), "message-pinned", {
    messageId,
    pinned,
    pinnedBy: updated.author.name,
  }).catch(console.error);

  return ok({ messageId, pinned });
});
