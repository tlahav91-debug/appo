import { type NextRequest } from "next/server";
import { ok, forbidden, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { triggerPusherEvent, pusherChannels, pusherEvents } from "@/lib/pusher";
import { db } from "@/lib/db";
import { auditLog } from "@/lib/audit/log";
import { z } from "zod";

// DELETE /api/chat/messages/[id]
export const DELETE = withApiAuth(async (_req: NextRequest, { user, params }) => {
  const messageId = params["id"]!;

  const message = await db.chatMessage.findUnique({
    where: { id: messageId },
    select: {
      id: true,
      authorId: true,
      roomId: true,
      room: { select: { eventId: true } },
    },
  });
  if (!message) return notFound();

  // Check permissions: own message OR organizer
  const isOwn = message.authorId === user.id;
  const isOrganizer = !isOwn
    ? !!(await db.committeeMember.findUnique({
        where: {
          eventId_userId: {
            eventId: message.room.eventId,
            userId: user.id,
          },
          revokedAt: null,
        },
        select: { id: true },
      }))
    : false;

  if (!isOwn && !isOrganizer) return forbidden("Cannot delete this message.");

  await db.chatMessage.update({
    where: { id: messageId },
    data: {
      isDeleted: true,
      deletedAt: new Date(),
      deletedById: user.id,
      content: "",
    },
  });

  if (!isOwn) {
    await auditLog({
      actorId: user.id,
      action: "CHAT_MESSAGE_DELETED",
      resourceType: "ChatMessage",
      resourceId: messageId,
      eventId: message.room.eventId,
      metadata: { moderatorAction: true },
    });
  }

  triggerPusherEvent(
    pusherChannels.chatRoom(message.roomId),
    pusherEvents.MESSAGE_DELETED,
    { messageId }
  ).catch(console.error);

  return ok({ deleted: true });
});

// PATCH /api/chat/messages/[id] — edit content
const editSchema = z.object({ content: z.string().min(1).max(4000).trim() });

export const PATCH = withApiAuth(async (req: NextRequest, { user, params }) => {
  const messageId = params["id"]!;

  const message = await db.chatMessage.findUnique({
    where: { id: messageId },
    select: { id: true, authorId: true, roomId: true, isDeleted: true },
  });
  if (!message || message.isDeleted) return notFound();
  if (message.authorId !== user.id) return forbidden("Can only edit your own messages.");

  const { content } = editSchema.parse(await req.json());

  const updated = await db.chatMessage.update({
    where: { id: messageId },
    data: { editedContent: content, editedAt: new Date() },
    include: {
      author: { select: { id: true, name: true, avatarUrl: true } },
      reactions: { select: { emoji: true, userId: true } },
    },
  });

  const payload = {
    ...updated,
    userId: updated.authorId,
    user: updated.author,
    author: undefined,
    content: updated.editedContent ?? updated.content,
  };

  triggerPusherEvent(
    pusherChannels.chatRoom(message.roomId),
    pusherEvents.MESSAGE_EDITED,
    payload
  ).catch(console.error);

  return ok(payload);
});
