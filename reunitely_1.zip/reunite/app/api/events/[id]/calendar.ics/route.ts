import { type NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { notFound } from "next/navigation";
import { getEventUrl } from "@/lib/utils";

// GET /api/events/[id]/calendar.ics
export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const event = await db.event.findUnique({
    where: { id: params.id, status: "PUBLISHED" },
    select: {
      id: true,
      title: true,
      description: true,
      startAt: true,
      endAt: true,
      timezone: true,
      venueName: true,
      venueAddress: true,
      slug: true,
    },
  });

  if (!event) {
    return new NextResponse("Not Found", { status: 404 });
  }

  const eventUrl = getEventUrl(event.slug);
  const start = formatIcsDate(event.startAt);
  const end = formatIcsDate(
    event.endAt ?? new Date(event.startAt.getTime() + 3 * 60 * 60 * 1000)
  );
  const now = formatIcsDate(new Date());
  const location = [event.venueName, event.venueAddress]
    .filter(Boolean)
    .join(", ");

  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Reunitely//Reunitely//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:${event.id}@reunitely.app`,
    `DTSTAMP:${now}`,
    `DTSTART:${start}`,
    `DTEND:${end}`,
    `SUMMARY:${escapeIcs(event.title)}`,
    ...(location ? [`LOCATION:${escapeIcs(location)}`] : []),
    `URL:${eventUrl}`,
    `DESCRIPTION:${escapeIcs(`RSVP and event details: ${eventUrl}`)}`,
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");

  return new NextResponse(ics, {
    status: 200,
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `attachment; filename="${event.slug}.ics"`,
      "Cache-Control": "no-cache",
    },
  });
}

function formatIcsDate(date: Date): string {
  return date
    .toISOString()
    .replace(/[-:]/g, "")
    .replace(/\.\d{3}/, "");
}

function escapeIcs(str: string): string {
  return str
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/\n/g, "\\n");
}
