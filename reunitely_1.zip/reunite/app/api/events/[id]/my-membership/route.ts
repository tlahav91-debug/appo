import { type NextRequest } from "next/server";
import {
  ok,
  unauthorized,
  notFound,
  withErrorHandling,
} from "@/lib/utils/api-response";
import { getApiUser } from "@/lib/auth/session";
import { db } from "@/lib/db";

export const GET = withErrorHandling(
  async (_req: NextRequest, { params }: { params: { id: string } }) => {
    const user = await getApiUser();
    if (!user) return unauthorized();

    const eventId = params.id;

    const [committee, rsvp] = await Promise.all([
      db.committeeMember.findUnique({
        where: {
          eventId_userId: { eventId, userId: user.id },
          revokedAt: null,
        },
        select: {
          role: true,
          canManageRsvps: true,
          canSendMessages: true,
          canModerateContent: true,
          canManageTickets: true,
          canViewPayments: true,
          canCheckIn: true,
        },
      }),
      db.rSVP.findUnique({
        where: { eventId_userId: { eventId, userId: user.id } },
        select: { status: true },
      }),
    ]);

    const hasActiveRsvp = !!rsvp && rsvp.status !== "CANCELLED";

    if (!committee && !hasActiveRsvp) {
      return notFound();
    }

    return ok({
      role: committee?.role ?? "ATTENDEE",
      hasRsvp: hasActiveRsvp,
      platformRole: user.platformRole,
      canManageRsvps: committee?.canManageRsvps ?? false,
      canSendMessages: committee?.canSendMessages ?? false,
      canModerateContent: committee?.canModerateContent ?? false,
      canManageTickets: committee?.canManageTickets ?? false,
      canViewPayments: committee?.canViewPayments ?? false,
      canCheckIn: committee?.canCheckIn ?? false,
    });
  }
);
