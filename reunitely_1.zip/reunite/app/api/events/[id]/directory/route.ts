import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { getDirectoryAttendees } from "@/lib/services/directory.service";
import type { AttendeeBadgeType } from "@/lib/services/directory.service";

const filterSchema = z.object({
  search: z.string().max(100).optional(),
  badge: z.string().optional(),
  city: z.string().max(100).optional(),
  cursor: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(96).default(48),
});

// GET /api/events/[id]/directory
export const GET = withApiAuth(async (req: NextRequest, { user, params }) => {
  const url = new URL(req.url);
  const query = filterSchema.parse(Object.fromEntries(url.searchParams));

  const result = await getDirectoryAttendees(params["id"]!, user.id, {
    search: query.search,
    badge: query.badge as AttendeeBadgeType | undefined,
    city: query.city,
    cursor: query.cursor,
    limit: query.limit,
  });

  return ok(result);
});
