import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, badRequest, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { createCheckoutSession } from "@/lib/stripe";
import { db } from "@/lib/db";

// Each line item: a ticket + optional quantity + optional add-on donation
const lineItemSchema = z.object({
  ticketId: z.string().cuid(),
  quantity: z.number().int().min(1).max(10).default(1),
});

const schema = z.object({
  lineItems: z.array(lineItemSchema).min(1).max(5),
  // Optional donation add-on (cents)
  donationCents: z.number().int().min(0).max(100_000).optional(),
  // Optional coupon code (validated server-side against ticket.couponCode)
  couponCode: z.string().max(50).optional(),
  // Plus-one handling: if event allows it, we accept guestCount via RSVP
  guestCount: z.number().int().min(0).max(5).default(0),
});

export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const body = schema.parse(await req.json());
  const eventId = params["id"]!;

  const event = await db.event.findUnique({
    where: { id: eventId },
    select: {
      slug: true,
      stripeAccountId: true,
      ticketingEnabled: true,
      title: true,
    },
  });
  if (!event) return notFound("Event not found.");
  if (!event.ticketingEnabled) return badRequest("Ticketing is not enabled for this event.");

  // Validate all ticket IDs
  const ticketIds = body.lineItems.map((li) => li.ticketId);
  const tickets = await db.ticket.findMany({
    where: { id: { in: ticketIds }, eventId, isActive: true, isVisible: true },
  });

  if (tickets.length !== ticketIds.length) {
    return badRequest("One or more tickets are unavailable.");
  }

  // Check capacity and coupon per ticket
  const lineItemDetails = [];
  for (const li of body.lineItems) {
    const ticket = tickets.find((t) => t.id === li.ticketId)!;

    // Capacity check: re-read soldCount inside a short-circuit check.
    // The authoritative atomic decrement happens in the Stripe webhook handler
    // (incrementing soldCount only after payment_intent.succeeded).
    // This pre-check is a UX guard, not the security boundary.
    if (ticket.capacity !== null && ticket.soldCount + li.quantity > ticket.capacity) {
      return badRequest(`"${ticket.name}" is sold out or doesn't have enough capacity.`);
    }

    // For high-demand events, use a Redis lock here:
    // const lock = await acquireSeatLock(ticket.id, li.quantity);
    // if (!lock) return badRequest(`"${ticket.name}" — seats reserved by another buyer.`);

    // Coupon validation
    let pricePerUnit = ticket.price;
    if (body.couponCode && ticket.couponCode && body.couponCode.toUpperCase() === ticket.couponCode.toUpperCase()) {
      const discountPct = ticket.couponPercent ?? 0;
      pricePerUnit = Math.round(ticket.price * (1 - discountPct / 100));
    }

    lineItemDetails.push({
      ticket,
      quantity: li.quantity,
      pricePerUnit,
      lineTotal: pricePerUnit * li.quantity,
    });
  }

  const ticketTotal = lineItemDetails.reduce((s, li) => s + li.lineTotal, 0);
  const donationCents = body.donationCents ?? 0;
  const grandTotal = ticketTotal + donationCents;

  // Free event: skip Stripe, create RSVP + payment record directly
  if (grandTotal === 0) {
    const primaryTicket = lineItemDetails[0]!;
    const { generateTicketCode, generateQrPayload } = await import("@/lib/payments/ticket-generator");
    const ticketCode = generateTicketCode();
    const qrPayload = generateQrPayload(ticketCode, eventId, user.id);

    await db.$transaction([
      db.payment.create({
        data: {
          eventId,
          userId: user.id,
          ticketId: primaryTicket.ticket.id,
          quantity: primaryTicket.quantity,
          unitAmountCents: 0,
          totalAmountCents: 0,
          netAmountCents: 0,
          currency: primaryTicket.ticket.currency,
          method: "WAIVED",
          status: "WAIVED",
          ticketCode,
          qrPayload,
          qrGeneratedAt: new Date(),
          paidAt: new Date(),
        },
      }),
      db.rSVP.upsert({
        where: { eventId_userId: { eventId, userId: user.id } },
        create: {
          eventId,
          userId: user.id,
          status: "CONFIRMED",
          consentEmail: true,
          consentGivenAt: new Date(),
        },
        update: { status: "CONFIRMED" },
      }),
    ]);

    return ok({
      free: true,
      redirectUrl: `/events/${event.slug}/rsvp?success=true&free=true`,
    });
  }

  // Paid event: build Stripe line items
  if (!event.stripeAccountId) {
    return badRequest("This event hasn't set up payments yet. Contact the organizer.");
  }

  const stripeLineItems = lineItemDetails.map((li) => ({
    price_data: {
      currency: li.ticket.currency.toLowerCase(),
      unit_amount: li.pricePerUnit,
      product_data: {
        name: li.ticket.name,
        description: li.ticket.description ?? undefined,
      },
    },
    quantity: li.quantity,
  }));

  // Donation add-on line item
  if (donationCents > 0) {
    stripeLineItems.push({
      price_data: {
        currency: lineItemDetails[0]!.ticket.currency.toLowerCase(),
        unit_amount: donationCents,
        product_data: { name: "Donation", description: "Optional contribution" },
      },
      quantity: 1,
    });
  }

  const primaryTicket = lineItemDetails[0]!;
  const { sessionId, url } = await createCheckoutSession({
    eventId,
    ticketId: primaryTicket.ticket.id,
    ticketName: primaryTicket.ticket.name,
    priceInCents: grandTotal,
    currency: primaryTicket.ticket.currency,
    quantity: 1, // already multiplied into lineItems
    userId: user.id,
    userEmail: user.email,
    eventSlug: event.slug,
    connectedAccountId: event.stripeAccountId ?? undefined,
    applicationFeePercent: 2,
    lineItems: stripeLineItems,
    metadata: {
      eventId,
      ticketId: primaryTicket.ticket.id,
      userId: user.id,
      guestCount: String(body.guestCount),
      donationCents: String(donationCents),
    },
  });

  return ok({ sessionId, url, free: false });
});
