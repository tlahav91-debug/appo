import { type NextRequest } from "next/server";
import { ok, notFound } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";
import { auditLog } from "@/lib/audit/log";

export const POST = withEventPermission(
  "nominations:manage",
  async (_req: NextRequest, { user, params }) => {
    const categoryId = params["categoryId"];
    if (!categoryId) return notFound();

    const category = await db.nominationCategory.findUnique({
      where: { id: categoryId },
      select: { id: true, eventId: true, votingStatus: true },
    });
    if (!category || category.eventId !== params["id"]) return notFound();

    await db.nominationCategory.update({
      where: { id: categoryId },
      data: {
        resultsRevealedAt: new Date(),
        votingStatus: "RESULTS_REVEALED",
      },
    });

    await auditLog({
      actorId: user.id,
      action: "RESULTS_REVEALED",
      resourceType: "NominationCategory",
      resourceId: categoryId,
      eventId: params["id"]!,
    });

    return ok({ revealed: true });
  }
);
