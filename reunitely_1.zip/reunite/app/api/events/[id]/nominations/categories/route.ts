import { type NextRequest } from "next/server";
import { ok, created } from "@/lib/utils/api-response";
import { withErrorHandling } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { nominationCategorySchema } from "@/schemas";
import { db } from "@/lib/db";

export const GET = withErrorHandling(async (_req: NextRequest, { params }: { params: { id: string } }) => {
  const categories = await db.nominationCategory.findMany({
    where: { eventId: params["id"] },
    include: { nominations: { include: { nominee: { select: { id: true, name: true, avatarUrl: true } } } }, _count: { select: { votes: true } } },
    orderBy: { sortOrder: "asc" },
  });
  return ok(categories);
});

export const POST = withEventPermission("nominations:manage", async (req: NextRequest, { params }) => {
  const input = nominationCategorySchema.parse(await req.json());
  const category = await db.nominationCategory.create({
    data: {
      eventId: params["id"]!,
      title: input.title,
      description: input.description,
      votingOpenAt: input.votingOpenAt ? new Date(input.votingOpenAt) : null,
      votingClosedAt: input.votingClosedAt ? new Date(input.votingClosedAt) : null,
    },
  });
  return created(category);
});
