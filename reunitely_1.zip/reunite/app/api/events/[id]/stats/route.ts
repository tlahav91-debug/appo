import { type NextRequest } from "next/server";
import { ok, notFound } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { getEventStats } from "@/lib/services/event.service";

export const GET = withEventPermission("event:read", async (_req: NextRequest, { user, params }) => {
  const stats = await getEventStats(params["id"]!, user.id);
  if (!stats) return notFound("Event not found.");
  return ok(stats);
});
