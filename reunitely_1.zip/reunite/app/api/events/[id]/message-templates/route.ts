import { type NextRequest } from "next/server";
import { ok } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { withErrorHandling } from "@/lib/utils/api-response";
import { db } from "@/lib/db";
import { ALL_TEMPLATES } from "@/lib/messaging/templates";
import { getApiUser } from "@/lib/auth/session";

// GET /api/events/[id]/message-templates
// Returns event-specific templates + built-in defaults
export const GET = withErrorHandling(async (_req: NextRequest, { params }: { params: { id: string } }) => {
  const eventId = params["id"]!;
  
  const [eventTemplates] = await Promise.all([
    db.messageTemplate.findMany({
      where: { OR: [{ eventId }, { isDefault: true, eventId: null }] },
      orderBy: [{ isDefault: "desc" }, { createdAt: "asc" }],
    }),
  ]);

  // Merge DB templates with built-in defaults (built-ins shown if no DB override exists)
  const dbTypes = new Set(eventTemplates.map((t) => `${t.type}:${t.channel}`));
  const builtIns = ALL_TEMPLATES.filter(
    (t) => !dbTypes.has(`${t.type}:${t.channel}`)
  ).map((t) => ({
    id: `builtin:${t.type}:${t.channel}`,
    name: t.name,
    type: t.type,
    channel: t.channel,
    subject: t.subject ?? null,
    body: { type: "text", content: t.body },
    variables: t.variables,
    isDefault: true,
    isBuiltIn: true,
  }));

  return ok([
    ...eventTemplates.map((t) => ({ ...t, isBuiltIn: false })),
    ...builtIns,
  ]);
});
