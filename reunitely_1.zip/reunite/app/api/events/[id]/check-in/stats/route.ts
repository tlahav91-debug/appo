import { type NextRequest } from "next/server";
import { ok } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";

// GET /api/events/[id]/check-in/stats
export const GET = withEventPermission(
  "attendees:read",
  async (_req: NextRequest, { params }) => {
    const eventId = params["id"]!;

    const [confirmed, checkedIn] = await Promise.all([
      db.rSVP.count({ where: { eventId, status: "CONFIRMED" } }),
      db.checkIn.count({ where: { eventId, status: "CHECKED_IN" } }),
    ]);

    return ok({
      confirmed,
      checkedIn,
      remaining: Math.max(0, confirmed - checkedIn),
      percentCheckedIn: confirmed > 0 ? Math.round((checkedIn / confirmed) * 100) : 0,
    });
  }
);
