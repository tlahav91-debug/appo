import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, badRequest, forbidden, notFound } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { verifyQrPayload } from "@/lib/payments/ticket-generator";
import { checkInAttendee } from "@/lib/services/rsvp.service";
import { db } from "@/lib/db";

const schema = z.object({
  qrPayload: z.string().min(1).max(2000),
});

// POST /api/events/[id]/check-in/qr
// Validates a QR code and checks in the attendee
export const POST = withEventPermission(
  "attendees:checkin",
  async (req: NextRequest, { user, params }) => {
    const rl = await applyRateLimit("checkIn", user.id);
    if (!rl.success) return rl.response!;
    const eventId = params["id"]!;
    const { qrPayload } = schema.parse(await req.json());

    // 1. Verify QR signature and extract userId
    const payload = verifyQrPayload(qrPayload);
    if (!payload) {
      return badRequest("Invalid or expired QR code.");
    }

    // 2. Verify the QR belongs to this event
    if (payload.ev !== eventId) {
      return badRequest("This ticket is for a different event.");
    }

    const { u: userId, tc: ticketCode } = payload;

    // 3. Verify the user has a valid RSVP for this event
    const rsvp = await db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId } },
      select: { status: true, user: { select: { name: true, avatarUrl: true } } },
    });

    if (!rsvp) {
      return notFound("No RSVP found for this ticket.");
    }

    if (rsvp.status === "CANCELLED" || rsvp.status === "DECLINED") {
      return forbidden(`This attendee's RSVP is ${rsvp.status.toLowerCase()}.`);
    }

    // 4. Verify ticket code matches a payment record
    const payment = await db.payment.findFirst({
      where: { eventId, userId, ticketCode },
      select: { id: true, status: true, ticketCode: true },
    });

    if (!payment) {
      return badRequest("Ticket code not found. Please check in manually.");
    }

    if (payment.status !== "PAID" && payment.status !== "WAIVED") {
      return forbidden(`Payment status is ${payment.status}. Cannot check in.`);
    }

    // 5. Perform check-in (handles duplicate prevention internally)
    const result = await checkInAttendee(eventId, userId, user.id, "QR");

    return ok({
      ...result,
      ticketCode,
      attendeeAvatar: rsvp.user.avatarUrl,
    });
  }
);
