import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, notFound, forbidden } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { checkInAttendee } from "@/lib/services/rsvp.service";
import { db } from "@/lib/db";
import { auditLog } from "@/lib/audit/log";

const bodySchema = z.object({
  method: z.enum(["MANUAL", "QR", "SEARCH"]).default("MANUAL"),
}).optional();

// POST /api/events/[id]/check-in/[userId] — check in an attendee
export const POST = withEventPermission(
  "attendees:checkin",
  async (req: NextRequest, { user, params }) => {
    const body = bodySchema.parse(await req.json().catch(() => ({})));
    const result = await checkInAttendee(
      params["id"]!,
      params["userId"]!,
      user.id,
      body?.method ?? "MANUAL"
    );
    return ok(result);
  }
);

// DELETE /api/events/[id]/check-in/[userId] — undo check-in (organizer only)
export const DELETE = withEventPermission(
  "attendees:checkin",
  async (_req: NextRequest, { user, params }) => {
    const eventId = params["id"]!;
    const userId = params["userId"]!;

    const checkIn = await db.checkIn.findUnique({
      where: { eventId_userId: { eventId, userId } },
      select: { id: true, status: true },
    });

    if (!checkIn) return notFound("No check-in found.");
    if (checkIn.status !== "CHECKED_IN") {
      return forbidden("Attendee is not checked in.");
    }

    await db.checkIn.update({
      where: { id: checkIn.id },
      data: { status: "NOT_ARRIVED", checkedInAt: null },
    });

    // Also clear payment checkedInAt
    await db.payment.updateMany({
      where: { eventId, userId, checkedInAt: { not: null } },
      data: { checkedInAt: null },
    });

    await auditLog({
      actorId: user.id,
      action: "ATTENDEE_CHECKED_IN", // reuse — differentiated by metadata
      resourceType: "CheckIn",
      resourceId: checkIn.id,
      eventId,
      metadata: { undone: true, attendeeUserId: userId },
    });

    return ok({ undone: true });
  }
);
