import { type NextRequest } from "next/server";
import { ok } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { publishEvent } from "@/lib/services/event.service";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { DEFAULT_ROOMS } from "@/app/api/events/[id]/chat/rooms/route";

export const POST = withEventPermission("event:publish", async (_req, { user, params }) => {
  const eventId = params["id"]!;
  const event = await publishEvent(eventId, user.id);

  // Seed default chat rooms if none exist yet
  const existing = await db.chatRoom.count({ where: { eventId } });
  if (existing === 0) {
    await db.chatRoom.createMany({
      data: DEFAULT_ROOMS.map((room) => ({
        eventId,
        name: room.name,
        description: room.description,
        type: room.type,
        slug: room.slug,
        isPinned: room.isPinned,
        createdById: user.id,
      })),
      skipDuplicates: true,
    });
  }

  revalidatePath(`/events/${event.slug}`);
  return ok(event);
});
