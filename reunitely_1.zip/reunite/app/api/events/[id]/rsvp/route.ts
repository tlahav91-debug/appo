import { type NextRequest } from "next/server";
import {
  ok,
  conflict,
  notFound,
  forbidden,
} from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { cancelRsvp } from "@/lib/services/rsvp.service";
import { submitRsvpAction } from "@/lib/actions/rsvp.actions";
import { fullRsvpSchema } from "@/schemas/rsvp";
import { db } from "@/lib/db";

// POST — create or update RSVP
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const rl = await applyRateLimit("rsvp", user.id);
  if (!rl.success) return rl.response!;

  const eventId = params["id"]!;
  const event = await db.event.findFirst({
    where: { id: eventId, status: "PUBLISHED" },
    select: { id: true },
  });
  if (!event) return notFound("Event not available.");

  const body = await req.json();
  const inviteToken = body.inviteToken as string | undefined;
  const input = fullRsvpSchema.parse(body);

  const result = await submitRsvpAction(eventId, input, inviteToken);
  if (!result.success) {
    if (result.code === "EVENT_FULL") return conflict("Event is at capacity.");
    if (result.code === "WAITLIST_FULL") return conflict("Waitlist is full.");
    throw new Error(result.error ?? "RSVP failed");
  }
  return ok(result.data);
});

// PUT — idempotent update
export const PUT = withApiAuth(async (req: NextRequest, { user, params }) => {
  const rl = await applyRateLimit("rsvp", user.id);
  if (!rl.success) return rl.response!;
  const input = fullRsvpSchema.parse(await req.json());
  const result = await submitRsvpAction(params["id"]!, input);
  if (!result.success) throw new Error(result.error ?? "Update failed");
  return ok(result.data);
});

// DELETE — cancel RSVP
export const DELETE = withApiAuth(async (_req, { user, params }) => {
  const eventId = params["id"]!;
  const rsvp = await db.rSVP.findUnique({
    where: { eventId_userId: { eventId, userId: user.id } },
    select: { status: true },
  });
  if (!rsvp) return notFound("RSVP not found.");
  if (rsvp.status === "CANCELLED") return forbidden("Already cancelled.");
  await cancelRsvp(eventId, user.id);
  return ok({ cancelled: true });
});

// GET — fetch current user's RSVP
export const GET = withApiAuth(async (_req, { user, params }) => {
  const rsvp = await db.rSVP.findUnique({
    where: { eventId_userId: { eventId: params["id"]!, userId: user.id } },
    select: {
      id: true,
      status: true,
      guestCount: true,
      guestNames: true,
      dietaryRequirements: true,
      customAnswers: true,
      attendeeNote: true,
      consentEmail: true,
      consentSms: true,
      consentWhatsApp: true,
      waitlistPosition: true,
      submittedAt: true,
      confirmedAt: true,
    },
  });
  if (!rsvp || rsvp.status === "CANCELLED") return notFound("No active RSVP.");
  return ok(rsvp);
});
