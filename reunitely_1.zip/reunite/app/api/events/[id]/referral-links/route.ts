import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, created } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { createReferralLink, getReferralLinks } from "@/lib/services/invite.service";

const createSchema = z.object({
  label: z.string().max(80).optional(),
  expiryDays: z.number().int().min(1).max(365).optional(),
});

export const GET = withEventPermission(
  "invites:view",
  async (_req: NextRequest, { params }) => {
    const links = await getReferralLinks(params["id"]!);
    return ok(links);
  }
);

export const POST = withEventPermission(
  "invites:manage",
  async (req: NextRequest, { user, params }) => {
    const body = createSchema.parse(await req.json().catch(() => ({})));
    const result = await createReferralLink(
      params["id"]!,
      user.id,
      body.label,
      body.expiryDays
    );
    return created(result);
  }
);
