import { type NextRequest, NextResponse } from "next/server";
import { unauthorized } from "@/lib/utils/api-response";
import { getApiUser } from "@/lib/auth/session";
import { requireEventPermission } from "@/lib/auth/permissions";
import { auditLog } from "@/lib/audit/log";
import { db } from "@/lib/db";
import { formatShortDate } from "@/lib/utils";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getApiUser();
  if (!user) return unauthorized();
  await requireEventPermission(user.id, params.id, "attendees:export");
  const rsvps = await db.rSVP.findMany({
    where: { eventId: params.id },
    include: { user: { select: { name: true, email: true, attendeeProfile: { select: { currentCity: true, currentJob: true } } } } },
    orderBy: { submittedAt: "asc" },
  });
  const headers = ["Name","Email","Status","Guest Count","Dietary","City","Job","RSVP Date","Consent Email","Consent SMS"];
  const rows = rsvps.map((r) => [
    r.user.name, r.user.email, r.status, r.guestCount,
    r.dietaryRequirements.join("; "),
    r.user.attendeeProfile?.currentCity ?? "",
    r.user.attendeeProfile?.currentJob ?? "",
    formatShortDate(r.submittedAt),
    r.consentEmail ? "Yes" : "No",
    r.consentSms ? "Yes" : "No",
  ]);
  const csv = [headers, ...rows].map((row) => row.map((c) => {
    const s = String(c ?? "");
    return s.includes(",") || s.includes('"') ? `"${s.replace(/"/g,'""')}"` : s;
  }).join(",")).join("\n");
  await auditLog({ actorId: user.id, action: "DATA_EXPORTED", resourceType: "RSVP", resourceId: params.id, eventId: params.id, metadata: { format: "csv", count: rsvps.length } });
  return new NextResponse(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="attendees-${params.id}.csv"`, "Cache-Control": "no-store" } });
}
