import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";
import type { RSVPStatus } from "@prisma/client";

const filterSchema = z.object({
  status: z.string().optional(),
  search: z.string().max(100).optional(),
  cursor: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(100).default(50),
});

// GET /api/events/[id]/memberships
// Returns AttendeeRow[] — complete RSVP data for organizer use
export const GET = withEventPermission(
  "attendees:read",
  async (req: NextRequest, { params }) => {
    const url = new URL(req.url);
    const query = filterSchema.parse(Object.fromEntries(url.searchParams));
    const eventId = params["id"]!;

    // Handle CHECKED_IN as a special filter — check via CheckIn model
    const isCheckedInFilter = query.status
      ?.split(",")
      .includes("CHECKED_IN");
    const statusFilter = query.status
      ? (query.status
          .split(",")
          .filter((s) => s !== "CHECKED_IN") as RSVPStatus[])
      : undefined;

    const rsvps = await db.rSVP.findMany({
      where: {
        eventId,
        status: {
          notIn: ["CANCELLED"],
          ...(statusFilter?.length ? { in: statusFilter } : {}),
        },
        ...(isCheckedInFilter
          ? { checkIn: { status: "CHECKED_IN" } }
          : {}),
        ...(query.search
          ? {
              user: {
                OR: [
                  { name: { contains: query.search, mode: "insensitive" } },
                  { email: { contains: query.search, mode: "insensitive" } },
                ],
              },
            }
          : {}),
        ...(query.cursor ? { id: { gt: query.cursor } } : {}),
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatarUrl: true,
            currentCity: true,
            currentJob: true,
            currentEmployer: true,
            attendeeProfile: {
              select: {
                currentCity: true,
                currentJob: true,
                currentEmployer: true,
                bio: true,
              },
            },
          },
        },
        checkIn: {
          select: { checkedInAt: true, status: true },
        },
      },
      orderBy: { submittedAt: "desc" },
      take: query.limit,
    });

    // Map to AttendeeRow shape
    const rows = rsvps.map((rsvp) => ({
      userId: rsvp.userId,
      rsvpId: rsvp.id,
      status: rsvp.status,
      guestCount: rsvp.guestCount,
      guestNames: rsvp.guestNames,
      dietaryRequirements: rsvp.dietaryRequirements,
      mealChoice: rsvp.mealChoice,
      customAnswers: (rsvp.customAnswers ?? {}) as Record<string, unknown>,
      attendeeNote: rsvp.attendeeNote,
      notes: rsvp.organizerNote,
      tableAssignment: rsvp.tableAssignment,
      consentEmail: rsvp.consentEmail,
      consentSms: rsvp.consentSms,
      consentWhatsApp: rsvp.consentWhatsApp,
      submittedAt: rsvp.submittedAt,
      confirmedAt: rsvp.confirmedAt,
      checkedInAt: rsvp.checkIn?.checkedInAt ?? null,
      waitlistPosition: rsvp.waitlistPosition,
      user: {
        name: rsvp.user.name,
        email: rsvp.user.email,
        avatarUrl: rsvp.user.avatarUrl,
        currentCity: rsvp.user.attendeeProfile?.currentCity ?? null,
        currentJob: rsvp.user.attendeeProfile?.currentJob ?? null,
        currentEmployer: rsvp.user.attendeeProfile?.currentEmployer ?? null,
      },
    }));

    const nextCursor =
      rows.length === query.limit
        ? rsvps[rsvps.length - 1]?.id ?? null
        : null;

    return ok(rows, 200);
  }
);
