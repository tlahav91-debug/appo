import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, notFound } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { auditLog } from "@/lib/audit/log";
import { db } from "@/lib/db";
import { cacheDelete, cacheKeys } from "@/lib/cache/redis";
import type { RSVPStatus } from "@prisma/client";

const updateSchema = z.object({
  status: z.enum(["CONFIRMED","PENDING","DECLINED","WAITLISTED","CANCELLED"]).optional(),
  organizerNote: z.string().max(2000).optional(),
  tableAssignment: z.string().max(50).optional(),
});

export const PUT = withEventPermission("attendees:update", async (req, { user: actor, params }) => {
  const eventId = params["id"]!;
  const targetUserId = params["userId"]!;
  const rsvp = await db.rSVP.findUnique({ where: { eventId_userId: { eventId, userId: targetUserId } }, select: { id: true, status: true } });
  if (!rsvp) return notFound("RSVP not found.");
  const input = updateSchema.parse(await req.json());
  const updated = await db.rSVP.update({
    where: { eventId_userId: { eventId, userId: targetUserId } },
    data: {
      ...(input.status ? { status: input.status as RSVPStatus, previousStatus: rsvp.status } : {}),
      ...(input.organizerNote !== undefined ? { organizerNote: input.organizerNote } : {}),
      ...(input.tableAssignment !== undefined ? { tableAssignment: input.tableAssignment } : {}),
    },
  });
  await cacheDelete(cacheKeys.eventStats(eventId));
  if (input.status) {
    await auditLog({ actorId: actor.id, action: "ATTENDEE_STATUS_CHANGED", resourceType: "RSVP", resourceId: rsvp.id, eventId, before: { status: rsvp.status }, after: { status: input.status } });
  }
  return ok(updated);
});

export const DELETE = withEventPermission("attendees:remove", async (_req, { user: actor, params }) => {
  const eventId = params["id"]!;
  const targetUserId = params["userId"]!;
  await db.rSVP.update({ where: { eventId_userId: { eventId, userId: targetUserId } }, data: { status: "CANCELLED", cancelledAt: new Date(), cancelledReason: "Removed by organizer" } });
  await cacheDelete(cacheKeys.eventStats(eventId));
  await auditLog({ actorId: actor.id, action: "ATTENDEE_REMOVED", resourceType: "RSVP", resourceId: targetUserId, eventId });
  return ok({ removed: true });
});
