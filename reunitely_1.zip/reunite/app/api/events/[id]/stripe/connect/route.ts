import { type NextRequest } from "next/server";
import { ok, badRequest } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { createConnectAccount, createConnectAccountLink } from "@/lib/stripe";
import { db } from "@/lib/db";

export const POST = withEventPermission("settings:manage", async (_req: NextRequest, { user, params }) => {
  const eventId = params["id"]!;
  const event = await db.event.findUniqueOrThrow({ where: { id: eventId }, select: { id: true, stripeAccountId: true } });
  let accountId = event.stripeAccountId;
  if (!accountId) {
    accountId = await createConnectAccount(user.email);
    await db.event.update({ where: { id: eventId }, data: { stripeAccountId: accountId } });
  }
  const url = await createConnectAccountLink(accountId, eventId);
  return ok({ url });
});
