import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, created, badRequest } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { sendBatchInvites } from "@/lib/services/invite.service";
import { db } from "@/lib/db";
import type { InviteStatus, InviteChannel } from "@prisma/client";

const filterSchema = z.object({
  status: z.string().optional(),
  channel: z.string().optional(),
  search: z.string().max(100).optional(),
  cursor: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(200).default(100),
});

const batchInviteSchema = z.object({
  channel: z.enum(["EMAIL", "SMS", "WHATSAPP", "LINK"]),
  recipients: z
    .array(
      z.object({
        email: z.string().email().optional().or(z.literal("")),
        phone: z.string().optional(),
        name: z.string().max(100).optional(),
        referralCode: z.string().optional(),
      })
    )
    .min(1, "At least one recipient required")
    .max(200, "Maximum 200 per batch"),
  personalMessage: z.string().max(300).optional(),
  consentConfirmed: z.literal(true, {
    errorMap: () => ({ message: "Recipient consent must be confirmed" }),
  }),
  expiryDays: z.number().int().min(1).max(365).default(30),
});

// GET /api/events/[id]/invites — paginated invite list with optional filters
export const GET = withEventPermission(
  "invites:view",
  async (req: NextRequest, { params }) => {
    const url = new URL(req.url);
    const query = filterSchema.parse(Object.fromEntries(url.searchParams));
    const eventId = params["id"]!;

    const statusFilter = query.status
      ? (query.status.split(",") as InviteStatus[])
      : undefined;
    const channelFilter = query.channel
      ? (query.channel.split(",") as InviteChannel[])
      : undefined;

    const invites = await db.invite.findMany({
      where: {
        eventId,
        ...(statusFilter && { status: { in: statusFilter } }),
        ...(channelFilter && { channel: { in: channelFilter } }),
        ...(query.search && {
          OR: [
            { email: { contains: query.search, mode: "insensitive" } },
            { phone: { contains: query.search } },
          ],
        }),
        ...(query.cursor && { id: { gt: query.cursor } }),
      },
      include: {
        invitedBy: { select: { name: true, avatarUrl: true } },
        deliveries: {
          orderBy: { createdAt: "desc" },
          take: 1,
          select: { status: true, sentAt: true, deliveredAt: true, failureReason: true },
        },
        referralLink: { select: { code: true, label: true } },
      },
      orderBy: { createdAt: "desc" },
      take: query.limit,
    });

    const nextCursor =
      invites.length === query.limit
        ? invites[invites.length - 1]?.id
        : null;

    return ok({ invites, nextCursor });
  }
);

// POST /api/events/[id]/invites — create and send batch invites
export const POST = withEventPermission(
  "invites:manage",
  async (req: NextRequest, { user, params }) => {
    const rl = await applyRateLimit("api", user.id);
    if (!rl.success) return rl.response!;

    const body = await req.json();
    const input = batchInviteSchema.parse(body);

    const result = await sendBatchInvites(params["id"]!, user.id, {
      channel: input.channel,
      recipients: input.recipients.map((r) => ({
        email: r.email || undefined,
        phone: r.phone || undefined,
        name: r.name,
        referralCode: r.referralCode,
      })),
      personalMessage: input.personalMessage,
      consentConfirmed: input.consentConfirmed,
      expiryDays: input.expiryDays,
    });

    return created(result);
  }
);
