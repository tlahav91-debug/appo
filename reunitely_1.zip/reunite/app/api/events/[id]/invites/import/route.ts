import { type NextRequest } from "next/server";
import { ok, badRequest } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { parseCsvForImport } from "@/lib/services/invite.service";

// POST /api/events/[id]/invites/import
// Accepts: multipart/form-data with "file" field (CSV)
// Returns: parsed rows for review — does NOT send invites yet.
// Actual sending uses the regular POST /api/events/[id]/invites after user confirms.
export const POST = withEventPermission(
  "invites:manage",
  async (req: NextRequest, { params }) => {
    let csvText: string;

    const contentType = req.headers.get("content-type") ?? "";
    if (contentType.includes("multipart/form-data")) {
      const formData = await req.formData();
      const file = formData.get("file");
      if (!file || !(file instanceof File)) {
        return badRequest("A CSV file is required (field name: 'file')");
      }
      if (file.size > 2 * 1024 * 1024) {
        return badRequest("CSV file must be under 2 MB");
      }
      csvText = await file.text();
    } else {
      // Also accept raw CSV text body
      csvText = await req.text();
    }

    if (!csvText.trim()) return badRequest("CSV file is empty");

    const result = await parseCsvForImport(csvText, params["id"]!);

    return ok({
      total: result.total,
      validCount: result.valid.length,
      invalidCount: result.invalid.length,
      duplicateCount: result.duplicates.length,
      valid: result.valid.slice(0, 500), // cap preview at 500 rows
      invalid: result.invalid.slice(0, 100),
      duplicates: result.duplicates.slice(0, 100),
    });
  }
);
