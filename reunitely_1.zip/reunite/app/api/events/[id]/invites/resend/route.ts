import { type NextRequest } from "next/server";
import { ok, notFound, conflict } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { resendInvite } from "@/lib/services/invite.service";
import { db } from "@/lib/db";

// POST /api/events/[id]/invites/resend?inviteId=...
export const POST = withEventPermission(
  "invites:manage",
  async (req: NextRequest, { user, params }) => {
    const rl = await applyRateLimit("api", user.id);
    if (!rl.success) return rl.response!;

    const url = new URL(req.url);
    const inviteId = url.searchParams.get("inviteId");
    if (!inviteId) return notFound("inviteId is required");

    const invite = await db.invite.findUnique({
      where: { id: inviteId, eventId: params["id"] },
      select: { status: true },
    });
    if (!invite) return notFound("Invite not found");
    if (invite.status === "RSVPD") return conflict("This person has already RSVP'd");

    await resendInvite(inviteId, user.id);
    return ok({ resent: true });
  }
);
