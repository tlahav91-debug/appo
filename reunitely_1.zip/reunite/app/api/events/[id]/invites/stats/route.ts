import { type NextRequest } from "next/server";
import { ok } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { getInviteStats } from "@/lib/services/invite.service";

// GET /api/events/[id]/invites/stats
export const GET = withEventPermission(
  "invites:view",
  async (_req: NextRequest, { params }) => {
    const stats = await getInviteStats(params["id"]!);
    return ok(stats);
  }
);
