import { type NextRequest } from "next/server";
import { ok, withErrorHandling, notFound } from "@/lib/utils/api-response";
import { withApiAuth, withEventPermission } from "@/lib/auth/action-guards";
import { getPublicEvent, updateEvent, archiveEvent } from "@/lib/services/event.service";
import { updateEventSchema } from "@/schemas";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";

export const GET = withErrorHandling(async (_req: NextRequest, { params }: { params: { id: string } }) => {
  const event = await getPublicEvent(params.id) ??
    await db.event.findUnique({
      where: { id: params.id },
      include: {
        createdBy: { select: { name: true, avatarUrl: true } },
        _count: { select: { rsvps: true, memoryPosts: true } },
      },
    });
  if (!event) return notFound("Event not found.");
  return ok(event);
});

export const PUT = withEventPermission("event:update", async (req: NextRequest, { user, params }) => {
  const input = updateEventSchema.parse(await req.json());
  const updated = await updateEvent(params["id"]!, user.id, input);
  return ok(updated);
});

export const DELETE = withEventPermission("event:delete", async (_req, { user, params }) => {
  await archiveEvent(params["id"]!, user.id);
  return ok({ archived: true });
});
