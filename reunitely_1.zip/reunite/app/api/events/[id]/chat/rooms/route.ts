import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, created, forbidden, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { withErrorHandling } from "@/lib/utils/api-response";
import { db } from "@/lib/db";
import { getApiUser } from "@/lib/auth/session";

// Default rooms seeded for every event
export const DEFAULT_ROOMS = [
  {
    slug: "general",
    name: "General",
    description: "Main reunion chat — say hello!",
    type: "GENERAL" as const,
    emoji: "💬",
    isPinned: true,
  },
  {
    slug: "memories",
    name: "Memories",
    description: "Share old stories and relive the good times",
    type: "TOPIC" as const,
    emoji: "📸",
    isPinned: false,
  },
  {
    slug: "logistics",
    name: "Logistics",
    description: "Parking, hotels, directions, and schedules",
    type: "TOPIC" as const,
    emoji: "🗺️",
    isPinned: false,
  },
  {
    slug: "rides",
    name: "Ride Sharing",
    description: "Coordinate rides and carpools",
    type: "TOPIC" as const,
    emoji: "🚗",
    isPinned: false,
  },
] as const;

const createRoomSchema = z.object({
  name: z.string().min(1).max(50).trim(),
  description: z.string().max(200).optional(),
  type: z.enum(["GENERAL", "TOPIC", "ANNOUNCEMENT"]).default("TOPIC"),
  isPrivate: z.boolean().default(false),
  slowModeSeconds: z.number().int().min(0).max(900).optional(),
});

// GET /api/events/[id]/chat/rooms
export const GET = withErrorHandling(async (req: NextRequest, { params }: { params: { id: string } }) => {
  const eventId = params["id"]!;

  // Viewer optional
  const user = await getApiUser().catch(() => null);

  const event = await db.event.findUnique({
    where: { id: eventId },
    select: { id: true, status: true },
  });
  if (!event) return notFound();

  // Non-members can't see chat rooms
  if (user) {
    const [committee, rsvp] = await Promise.all([
      db.committeeMember.findUnique({
        where: { eventId_userId: { eventId, userId: user.id }, revokedAt: null },
        select: { id: true },
      }),
      db.rSVP.findUnique({
        where: { eventId_userId: { eventId, userId: user.id } },
        select: { status: true },
      }),
    ]);
    const hasAccess =
      !!committee ||
      (!!rsvp && rsvp.status !== "CANCELLED" && rsvp.status !== "DECLINED");
    if (!hasAccess) return forbidden("RSVP required to view chat.");
  }

  const rooms = await db.chatRoom.findMany({
    where: { eventId, isArchived: false },
    orderBy: [{ isPinned: "desc" }, { createdAt: "asc" }],
    select: {
      id: true,
      name: true,
      description: true,
      type: true,
      slug: true,
      isPrivate: true,
      isPinned: true,
      slowModeSeconds: true,
      _count: { select: { messages: true } },
    },
  });

  return ok(rooms);
});

// POST /api/events/[id]/chat/rooms — create a room (organizer) or seed defaults
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const eventId = params["id"]!;

  const event = await db.event.findUnique({
    where: { id: eventId },
    select: { id: true },
  });
  if (!event) return notFound();

  // Only committee members can create rooms
  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId, userId: user.id }, revokedAt: null },
    select: { role: true },
  });
  if (!committee) return forbidden("Only organizers can create rooms.");

  const body = await req.json();

  // Special action: seed default rooms for the event
  if (body.seedDefaults) {
    const existing = await db.chatRoom.findMany({
      where: { eventId },
      select: { slug: true },
    });
    const existingSlugs = new Set(existing.map((r) => r.slug));

    const toCreate = DEFAULT_ROOMS.filter((r) => !existingSlugs.has(r.slug));
    if (toCreate.length === 0) return ok({ seeded: 0, rooms: existing });

    const seeded = await Promise.all(
      toCreate.map((room) =>
        db.chatRoom.create({
          data: {
            eventId,
            name: room.name,
            description: room.description,
            type: room.type,
            slug: room.slug,
            isPinned: room.isPinned,
            createdById: user.id,
          },
        })
      )
    );
    return created({ seeded: seeded.length, rooms: seeded });
  }

  // Normal room creation
  const input = createRoomSchema.parse(body);
  const slug = input.name.toLowerCase().replace(/[^a-z0-9]/g, "-").replace(/-+/g, "-");

  const room = await db.chatRoom.create({
    data: {
      eventId,
      name: input.name,
      description: input.description ?? null,
      type: input.type,
      slug,
      isPrivate: input.isPrivate,
      slowModeSeconds: input.slowModeSeconds ?? null,
      createdById: user.id,
    },
  });

  return created(room);
});
