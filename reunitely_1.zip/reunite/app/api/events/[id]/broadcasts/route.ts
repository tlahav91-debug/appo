import { type NextRequest } from "next/server";
import { ok, created } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { createBroadcast } from "@/lib/services/broadcast.service";
import { createBroadcastSchema } from "@/schemas";
import { db } from "@/lib/db";

export const GET = withEventPermission("messages:view_history", async (_req: NextRequest, { params }) => {
  const broadcasts = await db.broadcast.findMany({
    where: { eventId: params["id"] },
    orderBy: { createdAt: "desc" },
  });
  return ok(broadcasts);
});

export const POST = withEventPermission("messages:broadcast", async (req: NextRequest, { user, params }) => {
  const rl = await applyRateLimit("broadcast", user.id);
  if (!rl.success) return rl.response!;
  const input = createBroadcastSchema.parse(await req.json());
  const broadcast = await createBroadcast(params["id"]!, user.id, input);
  return created(broadcast);
});
