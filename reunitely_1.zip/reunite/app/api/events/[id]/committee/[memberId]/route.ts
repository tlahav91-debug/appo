import { type NextRequest } from "next/server";
import { ok, notFound } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { auditLog } from "@/lib/audit/log";
import { db } from "@/lib/db";

// DELETE /api/events/[id]/committee/[memberId] — revoke committee access
export const DELETE = withEventPermission(
  "settings:manage",
  async (_req: NextRequest, { user: actor, params }) => {
    const member = await db.committeeMember.findUnique({
      where: { id: params["memberId"] },
      select: { id: true, role: true, userId: true, eventId: true },
    });

    if (!member || member.eventId !== params["id"]) {
      return notFound("Committee member not found.");
    }

    // Cannot revoke the lead ORGANIZER
    if (member.role === "ORGANIZER") {
      return notFound("Cannot remove the lead organizer.");
    }

    await db.committeeMember.update({
      where: { id: member.id },
      data: { revokedAt: new Date(), revokedByUserId: actor.id },
    });

    await auditLog({
      actorId: actor.id,
      action: "CO_ORGANIZER_REMOVED",
      resourceType: "CommitteeMember",
      resourceId: member.id,
      eventId: params["id"],
      metadata: { removedUserId: member.userId },
    });

    return ok({ revoked: true });
  }
);
