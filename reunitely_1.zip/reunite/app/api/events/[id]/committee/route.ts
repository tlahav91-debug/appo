import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, created, notFound, conflict, withErrorHandling } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { auditLog } from "@/lib/audit/log";
import { db } from "@/lib/db";

const addMemberSchema = z.object({
  userId: z.string().cuid(),
  role: z.enum(["CO_ORGANIZER", "COMMITTEE"]),
  title: z.string().max(80).optional(),
  canManageRsvps: z.boolean().default(false),
  canSendMessages: z.boolean().default(false),
  canModerateContent: z.boolean().default(false),
  canManageTickets: z.boolean().default(false),
  canViewPayments: z.boolean().default(false),
  canCheckIn: z.boolean().default(true),
});

// GET /api/events/[id]/committee — list committee members
export const GET = withEventPermission(
  "event:read",
  async (_req: NextRequest, { params }) => {
    const members = await db.committeeMember.findMany({
      where: { eventId: params["id"], revokedAt: null },
      include: { user: { select: { id: true, name: true, email: true, avatarUrl: true } } },
      orderBy: { addedAt: "asc" },
    });
    return ok(members);
  }
);

// POST /api/events/[id]/committee — add committee member (organizer only)
export const POST = withEventPermission(
  "settings:manage",
  async (req: NextRequest, { user: actor, params }) => {
    const input = addMemberSchema.parse(await req.json());
    const eventId = params["id"]!;

    // Prevent adding ORGANIZER role via this endpoint (only one organizer per event)
    const targetUser = await db.user.findUnique({
      where: { id: input.userId, deletedAt: null },
      select: { id: true, name: true },
    });
    if (!targetUser) return notFound("User not found.");

    const existing = await db.committeeMember.findUnique({
      where: { eventId_userId: { eventId, userId: input.userId } },
    });

    if (existing && !existing.revokedAt) {
      return conflict("This user is already a committee member.");
    }

    const member = existing
      ? await db.committeeMember.update({
          where: { id: existing.id },
          data: { ...input, revokedAt: null, addedByUserId: actor.id, addedAt: new Date() },
        })
      : await db.committeeMember.create({
          data: { eventId, ...input, addedByUserId: actor.id },
        });

    await auditLog({
      actorId: actor.id,
      action: "CO_ORGANIZER_ADDED",
      resourceType: "CommitteeMember",
      resourceId: member.id,
      eventId,
      metadata: { addedUserId: input.userId, role: input.role },
    });

    return created(member);
  }
);
