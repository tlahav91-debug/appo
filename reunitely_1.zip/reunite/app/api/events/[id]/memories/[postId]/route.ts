import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, forbidden, notFound } from "@/lib/utils/api-response";
import { withEventPermission, withApiAuth } from "@/lib/auth/action-guards";
import { setFeatured, deleteMemory } from "@/lib/services/memory.service";
import { auditLog } from "@/lib/audit/log";
import { db } from "@/lib/db";

// PATCH — feature/unfeature (organizer moderation action)
export const PATCH = withEventPermission(
  "memories:moderate",
  async (req: NextRequest, { user, params }) => {
    const { featured } = z.object({ featured: z.boolean() }).parse(await req.json());
    const post = await db.memoryPost.findUnique({
      where: { id: params["postId"]!, eventId: params["id"] },
      select: { id: true },
    });
    if (!post) return notFound("Memory not found.");
    await setFeatured(params["postId"]!, user.id, featured);

    await auditLog({
      actorId: user.id,
      action: featured ? "MEMORY_FEATURED" : "MEMORY_UNFEATURED",
      resourceType: "MemoryPost",
      resourceId: params["postId"]!,
      eventId: params["id"]!,
      metadata: { featured },
    });

    return ok({ featured });
  }
);

// DELETE — soft delete (own post or organizer)
export const DELETE = withApiAuth(async (_req: NextRequest, { user, params }) => {
  const post = await db.memoryPost.findUnique({
    where: { id: params["postId"]!, eventId: params["id"] },
    select: { authorId: true },
  });
  if (!post) return notFound("Memory not found.");

  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId: params["id"]!, userId: user.id }, revokedAt: null },
    select: { role: true },
  });
  const isOrganizer = !!committee;
  const isOwnPost = post.authorId === user.id;

  try {
    await deleteMemory(params["postId"]!, user.id, isOrganizer);

    await auditLog({
      actorId: user.id,
      action: "MEMORY_DELETED",
      resourceType: "MemoryPost",
      resourceId: params["postId"]!,
      eventId: params["id"]!,
      metadata: {
        moderatorAction: !isOwnPost && isOrganizer,
        ownPost: isOwnPost,
      },
    });

    return ok({ deleted: true });
  } catch (err) {
    return forbidden(err instanceof Error ? err.message : "Cannot delete");
  }
});
