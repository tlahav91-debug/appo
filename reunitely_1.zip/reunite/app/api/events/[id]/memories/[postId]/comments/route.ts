import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, created, badRequest } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { withErrorHandling } from "@/lib/utils/api-response";
import { addComment, getComments } from "@/lib/services/memory.service";
import { db } from "@/lib/db";

const commentSchema = z.object({
  content: z.string().min(1).max(1000).trim(),
  parentId: z.string().cuid().optional(),
});

// GET /api/events/[id]/memories/[postId]/comments
export const GET = withErrorHandling(async (_req: NextRequest, { params }: { params: { postId: string } }) => {
  const comments = await getComments(params.postId);
  return ok(comments);
});

// POST /api/events/[id]/memories/[postId]/comments
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const { content, parentId } = commentSchema.parse(await req.json());

  const post = await db.memoryPost.findUnique({
    where: { id: params["postId"], eventId: params["id"], deletedAt: null, status: "APPROVED" },
    select: { id: true },
  });
  if (!post) return badRequest("Memory not found.");

  const result = await addComment(params["postId"]!, user.id, content, parentId);
  return created(result);
});
