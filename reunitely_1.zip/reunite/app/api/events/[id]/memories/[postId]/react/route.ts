import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, badRequest, forbidden } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { toggleReaction } from "@/lib/services/memory.service";
import { db } from "@/lib/db";

const reactSchema = z.object({
  emoji: z.string().min(1).max(10),
});

// POST /api/events/[id]/memories/[postId]/react
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const { emoji } = reactSchema.parse(await req.json());

  const post = await db.memoryPost.findUnique({
    where: { id: params["postId"], eventId: params["id"], deletedAt: null },
    select: { status: true },
  });
  if (!post || post.status !== "APPROVED") {
    return badRequest("Memory not found or not approved.");
  }

  const result = await toggleReaction(params["postId"]!, user.id, emoji);
  return ok(result);
});
