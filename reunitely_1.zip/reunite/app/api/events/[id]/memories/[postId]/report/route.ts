import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { reportMemory } from "@/lib/services/memory.service";

const reportSchema = z.object({
  reason: z.enum([
    "INAPPROPRIATE",
    "SPAM",
    "WRONG_PERSON",
    "COPYRIGHT",
    "OTHER",
  ]),
});

export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const rl = await applyRateLimit("report", user.id);
  if (!rl.success) return rl.response!;
  const { reason } = reportSchema.parse(await req.json());
  await reportMemory(params["postId"]!, user.id, reason);

  // Audit the report action for moderation review trails
  const { auditLog } = await import("@/lib/audit/log");
  await auditLog({
    actorId: user.id,
    action: "CONTENT_REPORTED",
    resourceType: "MemoryPost",
    resourceId: params["postId"]!,
    eventId: params["id"]!,
    metadata: { reason },
  });

  return ok({ reported: true });
});
