import { type NextRequest } from "next/server";
import { ok, created, forbidden } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { withErrorHandling } from "@/lib/utils/api-response";
import { createMemory } from "@/lib/services/memory.service";
import { getMemoryFeed } from "@/lib/services/memory.service";
import { getApiUser } from "@/lib/auth/session";
import { z } from "zod";
import type { ContentStatus, MemoryType } from "@prisma/client";

const postSchema = z.object({
  type: z.enum(["PHOTO", "TEXT", "VIDEO_EMBED", "COLLAGE"]),
  caption: z.string().max(2000).optional(),
  yearContext: z.number().int().min(1900).max(2100).optional(),
  contextLabel: z.string().max(100).optional(),
  videoEmbedUrl: z.string().url().optional(),
  s3Keys: z.array(z.string()).max(10).default([]),
  taggedUserIds: z.array(z.string().cuid()).max(20).default([]),
});

// GET /api/events/[id]/memories
export const GET = withErrorHandling(async (req: NextRequest, { params }: { params: { id: string } }) => {
  const url = new URL(req.url);
  const cursor = url.searchParams.get("cursor") ?? undefined;
  const status = (url.searchParams.get("status") ?? "APPROVED") as ContentStatus;
  const limit = Math.min(Number(url.searchParams.get("limit") ?? "20"), 50);
  const featuredOnly = url.searchParams.get("featured") === "1";

  // Try to get viewer ID for reaction state
  const user = await getApiUser().catch(() => null);

  const result = await getMemoryFeed(params["id"]!, user?.id ?? null, {
    status,
    cursor,
    limit,
    featuredOnly,
  });

  return ok(result);
});

// POST /api/events/[id]/memories
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const input = postSchema.parse(await req.json());
  try {
    const result = await createMemory(params["id"]!, user.id, {
      type: input.type as MemoryType,
      caption: input.caption,
      yearContext: input.yearContext,
      contextLabel: input.contextLabel,
      videoEmbedUrl: input.videoEmbedUrl,
      s3Keys: input.s3Keys,
      taggedUserIds: input.taggedUserIds,
    });
    return created(result);
  } catch (err) {
    if (err instanceof Error && err.message.startsWith("UNAUTHORIZED")) {
      return forbidden(err.message);
    }
    throw err;
  }
});
