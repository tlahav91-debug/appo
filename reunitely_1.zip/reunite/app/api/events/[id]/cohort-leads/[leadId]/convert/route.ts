import { type NextRequest } from "next/server";
import { ok, badRequest, conflict } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { convertLeadToInvite, bulkConvertApprovedLeads } from "@/lib/services/cohort-discovery.service";

// POST /api/events/[id]/cohort-leads/[leadId]/convert
// Converts a single approved lead into an Invite
export const POST = withEventPermission(
  "invites:manage",
  async (req: NextRequest, { user, params }) => {
    const leadId = params["leadId"]!;
    const eventId = params["id"]!;

    // leadId === "bulk" → convert all approved leads in one shot
    if (leadId === "bulk") {
      const result = await bulkConvertApprovedLeads(eventId, user.id);
      return ok(result);
    }

    try {
      const result = await convertLeadToInvite(leadId, user.id);
      return ok(result);
    } catch (err) {
      if (err instanceof Error) {
        if (err.message.startsWith("LEAD_NOT_APPROVED"))
          return conflict("Lead must be approved before converting to invite.");
        if (err.message.startsWith("NO_CONTACT_INFO"))
          return badRequest("No contact information — add email or phone to the lead first.");
        if (err.message.startsWith("INVITE_FAILED"))
          return conflict("Could not create invite — this address may already be invited.");
      }
      throw err;
    }
  }
);
