import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, badRequest, notFound, conflict } from "@/lib/utils/api-response";
import { withEventPermission } from "@/lib/auth/action-guards";
import { reviewCohortLead } from "@/lib/services/cohort-discovery.service";

const reviewSchema = z.object({
  status: z.enum(["APPROVED", "REJECTED", "DUPLICATE"]),
  adminNote: z.string().max(1000).optional(),
  rejectionReason: z.string().max(300).optional(),
  duplicateOfId: z.string().cuid().optional(),
});

// POST /api/events/[id]/cohort-leads/[leadId]/review
export const POST = withEventPermission(
  "invites:manage",
  async (req: NextRequest, { user, params }) => {
    const input = reviewSchema.parse(await req.json());

    if (input.status === "REJECTED" && !input.rejectionReason) {
      return badRequest("A rejection reason is required when rejecting a lead.");
    }
    if (input.status === "DUPLICATE" && !input.duplicateOfId) {
      return badRequest("Specify which existing lead this is a duplicate of.");
    }

    try {
      await reviewCohortLead(params["leadId"]!, user.id, input);
      return ok({ reviewed: true, status: input.status });
    } catch (err) {
      if (err instanceof Error) {
        if (err.message.startsWith("ALREADY_REVIEWED")) return conflict(err.message);
        if (err.message.includes("not found")) return notFound("Lead not found");
      }
      throw err;
    }
  }
);
