import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, created, badRequest, forbidden } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { withEventPermission } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import {
  submitCohortLead,
  listLeads,
  getLeadStats,
  checkForDuplicates,
} from "@/lib/services/cohort-discovery.service";
import type { CohortLeadStatus } from "@prisma/client";

const submitSchema = z.object({
  fullName: z.string().min(2, "Full name is required").max(120).trim(),
  emailHint: z
    .string()
    .email("Must be a valid email")
    .max(255)
    .optional()
    .or(z.literal("")),
  phoneHint: z.string().max(30).optional().or(z.literal("")),
  socialHint: z.string().url().max(200).optional().or(z.literal("")),
  schoolConnection: z
    .string()
    .min(10, "Please explain how you know this person from school")
    .max(500)
    .trim(),
  graduationYear: z.number().int().min(1950).max(2100).optional(),
  knownSince: z.string().max(100).optional().or(z.literal("")),
  submitterNote: z.string().max(500).optional().or(z.literal("")),
  consentGiven: z.literal(true, {
    errorMap: () => ({
      message:
        "You must confirm you have permission to share this person's contact information.",
    }),
  }),
});

// GET /api/events/[id]/cohort-leads — organizer list with filters
export const GET = withEventPermission(
  "invites:view",
  async (req: NextRequest, { params }) => {
    const url = new URL(req.url);
    const status = url.searchParams.get("status") as CohortLeadStatus | null;
    const search = url.searchParams.get("search") ?? undefined;
    const statsOnly = url.searchParams.get("stats") === "1";

    if (statsOnly) {
      const stats = await getLeadStats(params["id"]!);
      return ok(stats);
    }

    const leads = await listLeads(params["id"]!, (req as any).userId, {
      status: status ?? undefined,
      search,
    });
    return ok(leads);
  }
);

// POST /api/events/[id]/cohort-leads — attendee submits a lead
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const rl = await applyRateLimit("api", user.id);
  if (!rl.success) return rl.response!;

  const body = await req.json();
  const input = submitSchema.parse(body);

  try {
    const result = await submitCohortLead(params["id"]!, user.id, {
      fullName: input.fullName,
      emailHint: input.emailHint || undefined,
      phoneHint: input.phoneHint || undefined,
      socialHint: input.socialHint || undefined,
      schoolConnection: input.schoolConnection,
      graduationYear: input.graduationYear,
      knownSince: input.knownSince || undefined,
      submitterNote: input.submitterNote || undefined,
      consentGiven: input.consentGiven,
    });
    return created(result);
  } catch (err) {
    if (err instanceof Error) {
      if (err.message.startsWith("CONSENT_REQUIRED")) return badRequest("Consent required");
      if (err.message.startsWith("UNAUTHORIZED")) return forbidden(err.message);
      if (err.message.startsWith("RATE_LIMIT")) return badRequest(err.message);
    }
    throw err;
  }
});
