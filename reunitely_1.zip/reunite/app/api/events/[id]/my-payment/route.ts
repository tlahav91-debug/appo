import { type NextRequest } from "next/server";
import { ok, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";

// GET /api/events/[id]/my-payment — fetch current user's payment for this event
export const GET = withApiAuth(async (_req: NextRequest, { user, params }) => {
  const payment = await db.payment.findFirst({
    where: { eventId: params["id"]!, userId: user.id },
    select: {
      id: true,
      status: true,
      totalAmountCents: true,
      currency: true,
      quantity: true,
      ticketCode: true,
      qrPayload: true,
      qrGeneratedAt: true,
      paidAt: true,
      receiptUrl: true,
      refundedAmountCents: true,
      refundedAt: true,
      ticket: {
        select: { name: true, type: true, description: true },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  if (!payment) return notFound("No payment found for this event.");
  return ok(payment);
});
