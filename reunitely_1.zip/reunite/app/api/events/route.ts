import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, created, withErrorHandling } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { createEvent, listUserEvents } from "@/lib/services/event.service";
import { createEventSchema } from "@/schemas";

export const GET = withApiAuth(async (_req, { user }) => {
  const events = await listUserEvents(user.id);
  return ok(events);
});

export const POST = withApiAuth(async (req: NextRequest, { user }) => {
  const rl = await applyRateLimit("api", user.id);
  if (!rl.success) return rl.response!;
  const input = createEventSchema.parse(await req.json());
  const event = await createEvent(user.id, {
    ...input,
    startAt: new Date(input.startAt),
    endAt: input.endAt ? new Date(input.endAt) : undefined,
  });
  return created(event);
});
