import { type NextRequest } from "next/server";
import { ok, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { db } from "@/lib/db";
import type { Prisma } from "@prisma/client";
import { z } from "zod";

const draftPatchSchema = z.object({
  title: z.string().max(120).optional(),
  shortDescription: z.string().max(300).optional().nullable(),
  schoolName: z.string().max(100).optional(),
  schoolCity: z.string().max(100).optional().nullable(),
  schoolCountry: z.string().max(100).optional(),
  graduationYear: z.number().int().min(1950).max(2100).optional(),
  startAt: z.string().datetime().optional(),
  endAt: z.string().datetime().optional().nullable(),
  timezone: z.string().max(50).optional(),
  venueName: z.string().max(100).optional().nullable(),
  venueAddress: z.string().max(300).optional().nullable(),
  coverImageUrl: z.string().url().optional().nullable().or(z.literal("")),
  visibility: z.enum(["PUBLIC", "UNLISTED", "PRIVATE"]).optional(),
  capacity: z.number().int().positive().optional().nullable(),
  waitlistEnabled: z.boolean().optional(),
  ticketingEnabled: z.boolean().optional(),
  settings: z.record(z.unknown()).optional(),
});

// PATCH /api/events/drafts/[id]
export const PATCH = withApiAuth(async (req: NextRequest, { user, params }) => {
  const rl = await applyRateLimit("api", user.id);
  if (!rl.success) return rl.response!;

  const draftId = params["id"];
  if (!draftId) return notFound("Draft ID required.");

  const existing = await db.event.findUnique({
    where: { id: draftId, createdById: user.id, status: "DRAFT" },
    select: { id: true },
  });
  if (!existing) return notFound("Draft not found.");

  const body = draftPatchSchema.parse(await req.json());

  await db.event.update({
    where: { id: draftId },
    data: {
      ...(body.title !== undefined && { title: body.title }),
      ...(body.shortDescription !== undefined && { shortDescription: body.shortDescription }),
      ...(body.schoolName !== undefined && { schoolName: body.schoolName }),
      ...(body.schoolCity !== undefined && { schoolCity: body.schoolCity }),
      ...(body.schoolCountry !== undefined && { schoolCountry: body.schoolCountry }),
      ...(body.graduationYear !== undefined && { graduationYear: body.graduationYear }),
      ...(body.startAt !== undefined && { startAt: new Date(body.startAt) }),
      ...(body.endAt !== undefined && { endAt: body.endAt ? new Date(body.endAt) : null }),
      ...(body.timezone !== undefined && { timezone: body.timezone }),
      ...(body.venueName !== undefined && { venueName: body.venueName }),
      ...(body.venueAddress !== undefined && { venueAddress: body.venueAddress }),
      ...(body.coverImageUrl !== undefined && { coverImageUrl: body.coverImageUrl || null }),
      ...(body.visibility !== undefined && { visibility: body.visibility }),
      ...(body.capacity !== undefined && { capacity: body.capacity }),
      ...(body.waitlistEnabled !== undefined && { waitlistEnabled: body.waitlistEnabled }),
      ...(body.ticketingEnabled !== undefined && { ticketingEnabled: body.ticketingEnabled }),
      ...(body.settings !== undefined && { settings: body.settings as Prisma.InputJsonValue }),
    },
  });

  return ok({ saved: true, savedAt: new Date().toISOString() });
});

// DELETE /api/events/drafts/[id]
export const DELETE = withApiAuth(async (_req: NextRequest, { user, params }) => {
  const draftId = params["id"];
  if (!draftId) return notFound();

  await db.event.deleteMany({
    where: { id: draftId, createdById: user.id, status: "DRAFT" },
  });

  return ok({ deleted: true });
});
