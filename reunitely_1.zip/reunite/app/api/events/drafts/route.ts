import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, created, notFound, withErrorHandling } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { db } from "@/lib/db";
import { generateUniqueSlug } from "@/lib/utils";
import type { Prisma } from "@prisma/client";

// Lightweight partial schema — any fields are valid for autosave
const draftPatchSchema = z.object({
  title: z.string().max(120).optional(),
  shortDescription: z.string().max(300).optional().nullable(),
  schoolName: z.string().max(100).optional(),
  schoolCity: z.string().max(100).optional().nullable(),
  schoolCountry: z.string().max(100).optional(),
  graduationYear: z.number().int().min(1950).max(2100).optional(),
  startAt: z.string().datetime().optional(),
  endAt: z.string().datetime().optional().nullable(),
  timezone: z.string().max(50).optional(),
  venueName: z.string().max(100).optional().nullable(),
  venueAddress: z.string().max(300).optional().nullable(),
  coverImageUrl: z.string().url().optional().nullable().or(z.literal("")),
  visibility: z.enum(["PUBLIC", "UNLISTED", "PRIVATE"]).optional(),
  capacity: z.number().int().positive().optional().nullable(),
  waitlistEnabled: z.boolean().optional(),
  ticketingEnabled: z.boolean().optional(),
  settings: z.record(z.unknown()).optional(),
});

// POST /api/events/drafts — create a new draft
export const POST = withApiAuth(async (req: NextRequest, { user }) => {
  const rl = await applyRateLimit("api", user.id);
  if (!rl.success) return rl.response!;

  const body = draftPatchSchema.parse(await req.json());

  const title = body.title?.trim() || "Untitled Reunion";
  const schoolSlugPart = body.schoolName?.toLowerCase().replace(/\s+/g, "-") ?? "reunion";
  const yearPart = body.graduationYear ?? new Date().getFullYear();
  const slug = generateUniqueSlug(`${schoolSlugPart}-${yearPart}`);

  const event = await db.event.create({
    data: {
      slug,
      title,
      status: "DRAFT",
      visibility: body.visibility ?? "UNLISTED",
      schoolName: body.schoolName ?? "TBD",
      schoolCountry: body.schoolCountry ?? "US",
      graduationYear: body.graduationYear ?? new Date().getFullYear(),
      classSections: [],
      startAt: body.startAt ? new Date(body.startAt) : new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
      timezone: body.timezone ?? "America/New_York",
      createdById: user.id,
      shortDescription: body.shortDescription ?? null,
      schoolCity: body.schoolCity ?? null,
      venueName: body.venueName ?? null,
      venueAddress: body.venueAddress ?? null,
      coverImageUrl: body.coverImageUrl || null,
      capacity: body.capacity ?? null,
      waitlistEnabled: body.waitlistEnabled ?? true,
      ticketingEnabled: body.ticketingEnabled ?? false,
      settings: (body.settings ?? {}) as Prisma.InputJsonValue,
    },
    select: { id: true, slug: true },
  });

  // Make creator an organizer
  await db.committeeMember.create({
    data: {
      eventId: event.id,
      userId: user.id,
      role: "ORGANIZER",
      title: "Lead Organizer",
      canManageRsvps: true,
      canSendMessages: true,
      canModerateContent: true,
      canManageTickets: true,
      canViewPayments: true,
      canCheckIn: true,
      addedByUserId: user.id,
    },
  });

  return created({ id: event.id, slug: event.slug });
});

// PATCH /api/events/drafts/[id] — update existing draft
export const PATCH = withApiAuth(async (req: NextRequest, { user, params }) => {
  const rl = await applyRateLimit("api", user.id);
  if (!rl.success) return rl.response!;

  const draftId = params["id"];
  if (!draftId) return notFound("Draft ID required.");

  // Ownership check
  const existing = await db.event.findUnique({
    where: { id: draftId, createdById: user.id, status: "DRAFT" },
    select: { id: true },
  });
  if (!existing) return notFound("Draft not found.");

  const body = draftPatchSchema.parse(await req.json());

  await db.event.update({
    where: { id: draftId },
    data: {
      ...(body.title !== undefined && { title: body.title }),
      ...(body.shortDescription !== undefined && { shortDescription: body.shortDescription }),
      ...(body.schoolName !== undefined && { schoolName: body.schoolName }),
      ...(body.schoolCity !== undefined && { schoolCity: body.schoolCity }),
      ...(body.schoolCountry !== undefined && { schoolCountry: body.schoolCountry }),
      ...(body.graduationYear !== undefined && { graduationYear: body.graduationYear }),
      ...(body.startAt !== undefined && { startAt: new Date(body.startAt) }),
      ...(body.endAt !== undefined && { endAt: body.endAt ? new Date(body.endAt) : null }),
      ...(body.timezone !== undefined && { timezone: body.timezone }),
      ...(body.venueName !== undefined && { venueName: body.venueName }),
      ...(body.venueAddress !== undefined && { venueAddress: body.venueAddress }),
      ...(body.coverImageUrl !== undefined && { coverImageUrl: body.coverImageUrl || null }),
      ...(body.visibility !== undefined && { visibility: body.visibility }),
      ...(body.capacity !== undefined && { capacity: body.capacity }),
      ...(body.waitlistEnabled !== undefined && { waitlistEnabled: body.waitlistEnabled }),
      ...(body.ticketingEnabled !== undefined && { ticketingEnabled: body.ticketingEnabled }),
      ...(body.settings !== undefined && { settings: body.settings as Prisma.InputJsonValue }),
    },
  });

  return ok({ saved: true, savedAt: new Date().toISOString() });
});
