import { type NextRequest } from "next/server";
import { ok, badRequest } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { createPresignedUpload, validateUploadRequest, type UploadFolder, type AllowedMimeType } from "@/lib/storage/s3";
import { presignUploadSchema } from "@/schemas";
import { db } from "@/lib/db";
import { getEnv } from "@/env";

export const POST = withApiAuth(async (req: NextRequest, { user }) => {
  const rl = await applyRateLimit("upload", user.id);
  if (!rl.success) return rl.response!;

  const input = presignUploadSchema.parse(await req.json());
  const validation = validateUploadRequest(input.contentType, input.fileSize, input.folder as UploadFolder, input.fileExtension);
  if (!validation.valid) return badRequest(validation.error ?? "Invalid upload.");

  const { S3_BUCKET_NAME } = getEnv();
  const result = await createPresignedUpload(
    input.folder as UploadFolder,
    input.contentType as AllowedMimeType,
    input.fileExtension,
    user.id
  );

  // Pre-create the MediaAsset record in UPLOADING state so it exists when the
  // memory post is submitted. createMemory transitions it to READY/PENDING.
  const isImage = input.contentType.startsWith("image/");
  await db.mediaAsset.create({
    data: {
      uploadedById: user.id,
      s3Key: result.key,
      s3Bucket: S3_BUCKET_NAME,
      publicUrl: result.publicUrl,
      mimeType: input.contentType,
      fileSizeBytes: input.fileSize,
      type: isImage ? "IMAGE" : "VIDEO",
      status: "UPLOADING",
      moderationStatus: "PENDING",
    },
  });

  return ok(result);
});
