import { type NextRequest } from "next/server";
import { ok, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { rejectMemory } from "@/lib/services/moderation.service";
import { db } from "@/lib/db";

export const POST = withApiAuth(async (_req: NextRequest, { user, params }) => {
  const memory = await db.memoryPost.findUnique({ where: { id: params["id"] }, select: { id: true } });
  if (!memory) return notFound("Memory not found.");
  await rejectMemory(params["id"]!, user.id, false);
  return ok({ rejected: true });
});
