import { type NextRequest, NextResponse } from "next/server";
import { Webhook } from "svix";
import { db } from "@/lib/db";
import { syncPlatformRoleToClerk } from "@/lib/auth/session";
import * as Sentry from "@sentry/nextjs";

interface ClerkEmailAddress {
  email_address: string;
  id: string;
  verification?: { status: "verified" | "unverified" };
}

interface ClerkUserData {
  id: string;
  email_addresses: ClerkEmailAddress[];
  primary_email_address_id: string;
  first_name: string | null;
  last_name: string | null;
  image_url: string | null;
  username: string | null;
  public_metadata: Record<string, unknown>;
  created_at: number;
  updated_at: number;
  deleted?: boolean;
}

interface ClerkSessionData {
  id: string;
  user_id: string;
  status: "active" | "revoked" | "ended";
  last_active_at: number;
}

type ClerkWebhookEvent =
  | { type: "user.created"; data: ClerkUserData }
  | { type: "user.updated"; data: ClerkUserData }
  | { type: "user.deleted"; data: { id: string; deleted: true } }
  | { type: "session.created"; data: ClerkSessionData };

export async function POST(req: NextRequest) {
  const webhookSecret = process.env.CLERK_WEBHOOK_SECRET;
  if (!webhookSecret) {
    return NextResponse.json({ error: "Webhook not configured" }, { status: 500 });
  }

  const svixId = req.headers.get("svix-id");
  const svixTimestamp = req.headers.get("svix-timestamp");
  const svixSignature = req.headers.get("svix-signature");

  if (!svixId || !svixTimestamp || !svixSignature) {
    return NextResponse.json({ error: "Missing svix headers" }, { status: 400 });
  }

  const rawBody = await req.text();
  let event: ClerkWebhookEvent;

  try {
    const wh = new Webhook(webhookSecret);
    event = wh.verify(rawBody, {
      "svix-id": svixId,
      "svix-timestamp": svixTimestamp,
      "svix-signature": svixSignature,
    }) as ClerkWebhookEvent;
  } catch {
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  try {
    switch (event.type) {
      case "user.created":
        await handleUserCreated(event.data);
        break;
      case "user.updated":
        await handleUserUpdated(event.data);
        break;
      case "user.deleted":
        await handleUserDeleted(event.data.id);
        break;
      case "session.created":
        await handleSessionCreated(event.data);
        break;
    }
  } catch (err) {
    Sentry.captureException(err, { extra: { clerkEventType: event.type } });
    console.error("[Clerk Webhook] Handler error:", err);
    return NextResponse.json({ received: true, error: "Handler failed" });
  }

  return NextResponse.json({ received: true });
}

// ─── Handlers ─────────────────────────────────────────────────────────────────

async function handleUserCreated(data: ClerkUserData): Promise<void> {
  const { email, name, firstName, lastName, emailVerified } = extractUserFields(data);
  if (!email) return;

  const user = await db.user.upsert({
    where: { clerkId: data.id },
    create: {
      clerkId: data.id,
      email,
      emailVerified,
      name,
      firstName,
      lastName,
      username: data.username ?? undefined,
      avatarUrl: data.image_url ?? undefined,
      platformRole: "USER",
      lastLoginAt: new Date(data.created_at),
      lastActiveAt: new Date(data.created_at),
      loginCount: 1,
    },
    update: {},
  });

  await db.attendeeProfile.upsert({
    where: { userId: user.id },
    update: {},
    create: {
      userId: user.id,
      profileCompleteness: calcCompleteness(data),
    },
  });

  await syncPlatformRoleToClerk(data.id, "USER");
  // User created — not logging email to avoid PII in logs
}

async function handleUserUpdated(data: ClerkUserData): Promise<void> {
  const { email, name, firstName, lastName, emailVerified } = extractUserFields(data);
  if (!email) return;

  const existing = await db.user.findUnique({
    where: { clerkId: data.id },
    select: { id: true, platformRole: true },
  });

  if (!existing) {
    await handleUserCreated(data);
    return;
  }

  await db.user.update({
    where: { clerkId: data.id },
    data: {
      email,
      emailVerified,
      name,
      firstName,
      lastName,
      username: data.username ?? undefined,
      avatarUrl: data.image_url ?? undefined,
    },
  });

  await syncPlatformRoleToClerk(
    data.id,
    existing.platformRole as "USER" | "MODERATOR" | "SUPER_ADMIN"
  );
}

async function handleUserDeleted(clerkId: string): Promise<void> {
  const user = await db.user.findUnique({
    where: { clerkId },
    select: { id: true },
  });
  if (!user) return;

  await db.$transaction([
    db.user.update({
      where: { id: user.id },
      data: {
        deletedAt: new Date(),
        email: `deleted-${user.id}@deleted.invalid`,
        name: "Deleted User",
        firstName: null,
        lastName: null,
        avatarUrl: null,
        username: null,
      },
    }),
    db.attendeeProfile.updateMany({
      where: { userId: user.id },
      data: {
        bio: null,
        currentCity: null,
        currentJob: null,
        showInDirectory: false,
        profileVisibleTo: "NOBODY",
      },
    }),
    db.rSVP.updateMany({
      where: { userId: user.id },
      data: { consentEmail: false, consentSms: false, consentWhatsApp: false },
    }),
  ]);
}

async function handleSessionCreated(data: ClerkSessionData): Promise<void> {
  await db.user.updateMany({
    where: { clerkId: data.user_id, deletedAt: null },
    data: {
      lastLoginAt: new Date(data.last_active_at),
      lastActiveAt: new Date(data.last_active_at),
      loginCount: { increment: 1 },
    },
  });
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function extractUserFields(data: ClerkUserData) {
  const primary = data.email_addresses.find(
    (e) => e.id === data.primary_email_address_id
  );
  const email = primary?.email_address;
  const emailVerified = primary?.verification?.status === "verified";
  const firstName = data.first_name ?? undefined;
  const lastName = data.last_name ?? undefined;
  const name =
    [firstName, lastName].filter(Boolean).join(" ") ||
    email?.split("@")[0] ||
    "User";
  return { email, emailVerified, name, firstName, lastName };
}

function calcCompleteness(data: ClerkUserData): number {
  let score = 20;
  if (data.first_name) score += 20;
  if (data.last_name) score += 10;
  if (data.image_url) score += 20;
  return score;
}
