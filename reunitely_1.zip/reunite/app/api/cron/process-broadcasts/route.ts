import { type NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sendBroadcastToAll } from "@/lib/messaging/notify";
import * as Sentry from "@sentry/nextjs";

/**
 * Cron: process-scheduled-broadcasts
 * Runs every 5 minutes via Vercel Cron.
 *
 * Handles:
 * 1. Broadcasts with scheduledAt <= now (scheduled delivery)
 * 2. SKIPPED deliveries whose quiet-hours window has passed (retry)
 *
 * vercel.json entry:
 * { "path": "/api/cron/process-broadcasts", "schedule": "*\/5 * * * *" }
 */
export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  const cronSecret = process.env.CRON_SECRET;
  if (authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const now = new Date();
  let processed = 0;
  let errors = 0;

  try {
    // ── 1. Send scheduled broadcasts ────────────────────────────────────────
    const scheduled = await db.broadcast.findMany({
      where: {
        status: "SCHEDULED",
        scheduledAt: { lte: now },
      },
      select: { id: true, eventId: true },
      take: 20, // process at most 20 per run to stay within function timeout
    });

    for (const broadcast of scheduled) {
      try {
        // Mark as SENDING (idempotent guard)
        const updated = await db.broadcast.updateMany({
          where: { id: broadcast.id, status: "SCHEDULED" },
          data: { status: "SENDING", sendAttempts: { increment: 1 } },
        });

        if (updated.count === 0) continue; // Another worker picked it up

        const result = await sendBroadcastToAll(broadcast.id);

        const finalStatus =
          result.failed === 0 ? "SENT" : result.sent > 0 ? "PARTIALLY_SENT" : "FAILED";

        await db.broadcast.update({
          where: { id: broadcast.id },
          data: {
            status: finalStatus,
            sentAt: new Date(),
            recipientCount: result.sent + result.failed + result.skipped,
            deliveredCount: result.sent,
            failedCount: result.failed,
          },
        });

        processed++;
      } catch (err) {
        errors++;
        const errMsg = err instanceof Error ? err.message : "Unknown error";
        await db.broadcast.update({
          where: { id: broadcast.id },
          data: { status: "FAILED", lastError: errMsg },
        });
        Sentry.captureException(err, { extra: { broadcastId: broadcast.id } });
      }
    }

    // ── 2. Retry SKIPPED deliveries (quiet hours lifted) ───────────────────
    // Find broadcasts with skipped deliveries that are now in their active window
    const skippedDeliveries = await db.broadcastDelivery.findMany({
      where: {
        status: "SKIPPED",
        broadcast: { status: "SENT" }, // only retry for already-sent broadcasts
      },
      include: {
        broadcast: {
          include: {
            event: {
              select: {
                id: true,
                title: true,
                slug: true,
                schoolName: true,
                graduationYear: true,
                startAt: true,
                timezone: true,
              },
            },
          },
        },
        user: {
          select: { id: true, name: true, email: true, phone: true },
        },
      },
      take: 200,
    });

    // Group by broadcast to check quiet hours once per broadcast
    const byBroadcast = skippedDeliveries.reduce(
      (acc, d) => {
        if (!acc[d.broadcastId]) acc[d.broadcastId] = [];
        acc[d.broadcastId]!.push(d);
        return acc;
      },
      {} as Record<string, typeof skippedDeliveries>
    );

    for (const [broadcastId, deliveries] of Object.entries(byBroadcast)) {
      const broadcast = deliveries[0]!.broadcast;
      const tz = broadcast.event.timezone;

      // Check if we're still in quiet hours for this broadcast
      const stillQuiet =
        broadcast.quietHoursStart != null &&
        broadcast.quietHoursEnd != null &&
        (() => {
          const localHour = parseInt(
            new Intl.DateTimeFormat("en-US", {
              timeZone: tz,
              hour: "numeric",
              hour12: false,
            }).format(new Date()),
            10
          );
          const s = broadcast.quietHoursStart!;
          const e = broadcast.quietHoursEnd!;
          return s > e
            ? localHour >= s || localHour < e
            : localHour >= s && localHour < e;
        })();

      if (stillQuiet) continue;

      // Retry deliveries
      for (const delivery of deliveries) {
        try {
          await db.broadcastDelivery.update({
            where: { id: delivery.id },
            data: { status: "QUEUED" },
          });

          const { sendToRecipient } = await import("@/lib/messaging/notify");
          const { renderBroadcastBodyToHtml, extractPlainText } = await import(
            "@/lib/services/broadcast.service"
          );

          const bodyText = extractPlainText(broadcast.body as Record<string, unknown>);
          const bodyHtml = broadcast.channel === "EMAIL"
            ? renderBroadcastBodyToHtml(broadcast.body as Record<string, unknown>)
            : undefined;

          await sendToRecipient(
            {
              userId: delivery.user.id,
              name: delivery.user.name,
              email: delivery.user.email,
              phone: delivery.user.phone,
            },
            {
              broadcastId,
              eventId: broadcast.event.id,
              eventTitle: broadcast.event.title,
              eventSlug: broadcast.event.slug,
              schoolName: broadcast.event.schoolName,
              graduationYear: broadcast.event.graduationYear,
              startAt: broadcast.event.startAt,
              timezone: broadcast.event.timezone,
              organizerName: "The organizing team",
              channel: broadcast.channel as "EMAIL" | "SMS" | "WHATSAPP" | "IN_APP",
              bodyText,
              bodyHtml,
              subject: broadcast.subject ?? undefined,
              quietHoursStart: null, // don't re-check quiet hours on retry
              quietHoursEnd: null,
            }
          );
        } catch (err) {
          Sentry.captureException(err, { extra: { deliveryId: delivery.id } });
        }
      }
    }

    return NextResponse.json({
      ok: true,
      scheduled: processed,
      errors,
      retriedSkipped: Object.keys(byBroadcast).length,
    });
  } catch (err) {
    Sentry.captureException(err);
    return NextResponse.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
