import { type NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getRemindableInvites } from "@/lib/services/invite.service";
import { sendInviteEmail } from "@/lib/email";
import * as Sentry from "@sentry/nextjs";

/**
 * GET /api/cron/invite-reminders
 *
 * Runs weekly (Mondays 9am UTC) — sends a follow-up to invitees who
 * haven't RSVP'd within 7 days of receiving their invite.
 *
 * Only runs for events set to send reminders (checked via event.settings).
 * Respects channel consent — only resends via the original channel.
 * Updates sentAt after sending so the invite won't trigger again for 7+ days.
 *
 * vercel.json schedule: "0 9 * * 1"
 */
export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let reminded = 0;
  let failed = 0;
  let skipped = 0;

  try {
    // Only process future events (past events don't need invite reminders)
    const upcomingEvents = await db.event.findMany({
      where: { status: "PUBLISHED", startAt: { gt: new Date() } },
      select: {
        id: true,
        title: true,
        slug: true,
        schoolName: true,
        graduationYear: true,
        startAt: true,
        timezone: true,
        settings: true,
        createdBy: { select: { name: true } },
      },
    });

    for (const event of upcomingEvents) {
      const settings = event.settings as { sendEventReminder?: boolean } | null;
      // Skip if organizer has disabled reminders
      if (settings?.sendEventReminder === false) {
        skipped++;
        continue;
      }

      // Get invites eligible for reminder: sent 7+ days ago, not yet RSVP'd
      const remindable = await getRemindableInvites(event.id, 7, 200);
      if (remindable.length === 0) continue;

      for (const invite of remindable) {
        try {
          if (invite.channel === "EMAIL" && invite.email) {
            await sendInviteEmail({
              to: invite.email,
              inviteToken: invite.token,
              eventTitle: event.title,
              eventSlug: event.slug,
              organizerName: event.createdBy.name,
              schoolName: event.schoolName,
              graduationYear: event.graduationYear,
              startAt: event.startAt,
              timezone: event.timezone,
              isReminder: true,
            });
          }
          // Bump sentAt so this invite won't be picked up for another 7 days
          await db.invite.update({
            where: { id: invite.id },
            data: { sentAt: new Date() },
          });
          reminded++;
        } catch (err) {
          failed++;
          console.error(`[InviteReminder] Failed for invite ${invite.id}:`, err);
        }
      }
    }

    console.log(
      `[Cron] invite-reminders: reminded=${reminded} failed=${failed} skipped_events=${skipped}`
    );
    return NextResponse.json({ success: true, reminded, failed });
  } catch (err) {
    Sentry.captureException(err);
    console.error("[Cron] invite-reminders failed:", err);
    return NextResponse.json({ error: "Cron failed" }, { status: 500 });
  }
}
