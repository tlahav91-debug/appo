import { type NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import * as Sentry from "@sentry/nextjs";

function verifyCronSecret(req: NextRequest): boolean {
  return req.headers.get("authorization") === `Bearer ${process.env.CRON_SECRET}`;
}

// ─── /api/cron/reveal-nominations ────────────────────────────────────────────
// Runs every 15 minutes — auto-reveals nomination results at scheduled time

export async function GET(req: NextRequest) {
  if (!verifyCronSecret(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const now = new Date();

    // Find categories scheduled for reveal that haven't been revealed yet
    const dueCategories = await db.nominationCategory.findMany({
      where: {
        resultsRevealedAt: null,
        votingClosedAt: { lte: now },
        // Only auto-reveal if organizer set a reveal time in the past
        // (we use votingClosedAt as the trigger; organizer can set resultsRevealedAt manually)
      },
      select: { id: true, eventId: true, title: true },
    });

    let revealed = 0;
    for (const category of dueCategories) {
      await db.nominationCategory.update({
        where: { id: category.id },
        data: { resultsRevealedAt: now },
      });
      revealed++;
    }

    if (revealed > 0) {
      console.log(`[Cron] reveal-nominations: revealed ${revealed} categories`);
    }

    return NextResponse.json({ success: true, revealed });
  } catch (err) {
    Sentry.captureException(err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
