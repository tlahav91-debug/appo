import { type NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sendEventReminder } from "@/lib/email";

import { addDays, startOfDay, endOfDay, addHours } from "date-fns";
import * as Sentry from "@sentry/nextjs";

// ─── Cron: send event reminders ───────────────────────────────────────────────
// Runs daily at 8:00 AM UTC via Vercel Cron
// vercel.json: { "crons": [{ "path": "/api/cron/send-reminders", "schedule": "0 8 * * *" }] }

export async function GET(req: NextRequest) {
  // Verify cron secret
  const authHeader = req.headers.get("authorization");
  const cronSecret = process.env.CRON_SECRET;
  if (authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const now = new Date();
  let sent = 0;
  let failed = 0;

  try {
    // 1-day reminders: events starting tomorrow
    const oneDayStart = startOfDay(addDays(now, 1));
    const oneDayEnd = endOfDay(addDays(now, 1));

    // 3-day reminders: events starting in 3 days
    const threeDayStart = startOfDay(addDays(now, 3));
    const threeDayEnd = endOfDay(addDays(now, 3));

    const upcomingEvents = await db.event.findMany({
      where: {
        status: "PUBLISHED",
        startAt: {
          gte: oneDayStart,
          lte: threeDayEnd,
        },
      },
      select: {
        id: true,
        title: true,
        slug: true,
        startAt: true,
        timezone: true,
      },
    });

    for (const event of upcomingEvents) {
      const isOneDayReminder =
        event.startAt >= oneDayStart && event.startAt <= oneDayEnd;
      const isThreeDayReminder =
        event.startAt >= threeDayStart && event.startAt <= threeDayEnd;

      const daysUntil = isOneDayReminder ? 1 : isThreeDayReminder ? 3 : null;
      if (!daysUntil) continue;

      // Get confirmed attendees who have email consent
      const attendees = await db.rSVP.findMany({
        where: {
          eventId: event.id,
          status: { in: ["CONFIRMED", "CHECKED_IN"] },
          consentEmail: true,
        },
        include: {
          user: { select: { email: true, name: true } },
        },
      });

      for (const attendee of attendees) {
        try {
          await sendEventReminder({
            to: attendee.user.email,
            eventTitle: event.title,
            eventSlug: event.slug,
            startAt: event.startAt,
            timezone: event.timezone,
            daysUntil,
          });
          sent++;
        } catch (err) {
          failed++;
          console.error(
            `[Cron] Failed to send reminder to ${attendee.user.email}:`,
            err
          );
        }
      }
    }

    console.log(`[Cron] send-reminders: sent=${sent} failed=${failed}`);
    return NextResponse.json({ success: true, sent, failed });
  } catch (err) {
    Sentry.captureException(err);
    console.error("[Cron] send-reminders failed:", err);
    return NextResponse.json(
      { error: "Cron job failed" },
      { status: 500 }
    );
  }
}
