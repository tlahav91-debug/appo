import { type NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import * as Sentry from "@sentry/nextjs";

function verifyCronSecret(req: NextRequest): boolean {
  return req.headers.get("authorization") === `Bearer ${process.env.CRON_SECRET}`;
}

// ─── /api/cron/cleanup-expired-invites ───────────────────────────────────────
// Runs weekly — expires invite tokens older than 30 days that were never used

export async function GET(req: NextRequest) {
  if (!verifyCronSecret(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const now = new Date();

    // Expire invites past their expiresAt date
    const { count } = await db.invite.updateMany({
      where: {
        status: { in: ["SENT", "DELIVERED", "OPENED"] },
        expiresAt: { lt: now },
      },
      data: { status: "EXPIRED" },
    });

    // Also expire old invites without an expiresAt set (legacy)
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const { count: legacyCount } = await db.invite.updateMany({
      where: {
        status: { in: ["SENT", "DELIVERED", "OPENED"] },
        expiresAt: null,
        sentAt: { lt: thirtyDaysAgo },
      },
      data: { status: "EXPIRED" },
    });

    console.log(`[Cron] cleanup-expired-invites: expired ${count + legacyCount} invites (${count} by expiry, ${legacyCount} legacy)`);
    return NextResponse.json({ success: true, expired: count + legacyCount });
  } catch (err) {
    Sentry.captureException(err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
