import { type NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import * as Sentry from "@sentry/nextjs";

function verifyCronSecret(req: NextRequest): boolean {
  const auth = req.headers.get("authorization");
  return auth === `Bearer ${process.env.CRON_SECRET}`;
}

// ─── /api/cron/close-expired-rsvp ────────────────────────────────────────────
// Runs daily — marks events as ARCHIVED if end date passed

export async function GET(req: NextRequest) {
  if (!verifyCronSecret(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const now = new Date();

    // Archive events that ended more than 7 days ago
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const { count } = await db.event.updateMany({
      where: {
        status: "PUBLISHED",
        endAt: { lt: sevenDaysAgo },
      },
      data: { status: "ARCHIVED" },
    });

    console.log(`[Cron] close-expired-rsvp: archived ${count} events`);
    return NextResponse.json({ success: true, archived: count });
  } catch (err) {
    Sentry.captureException(err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
