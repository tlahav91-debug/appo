import { auth } from "@clerk/nextjs/server";
import { type NextRequest, NextResponse } from "next/server";
import { getPusherServer } from "@/lib/pusher";
import { getUserByClerkId } from "@/lib/services/user.service";
import { db } from "@/lib/db";

// POST /api/pusher/auth — authenticate private Pusher channels
export async function POST(req: NextRequest) {
  const { userId: clerkId } = auth();
  if (!clerkId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const user = await getUserByClerkId(clerkId);
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const formData = await req.formData();
  const socketId = formData.get("socket_id") as string;
  const channelName = formData.get("channel_name") as string;

  if (!socketId || !channelName) {
    return NextResponse.json({ error: "Missing parameters" }, { status: 400 });
  }

  // Verify the user has access to the requested channel
  const authorized = await canAccessChannel(user.id, channelName);
  if (!authorized) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const pusher = getPusherServer();
  const authResponse = pusher.authorizeChannel(socketId, channelName, {
    user_id: user.id,
    user_info: { name: user.name },
  });

  return NextResponse.json(authResponse);
}

async function canAccessChannel(
  userId: string,
  channelName: string
): Promise<boolean> {
  // private-chat-room-{roomId}
  if (channelName.startsWith("private-chat-room-")) {
    const roomId = channelName.replace("private-chat-room-", "");
    const room = await db.chatRoom.findUnique({
      where: { id: roomId },
      select: { eventId: true },
    });
    if (!room) return false;

    const [committee, rsvp] = await Promise.all([
      db.committeeMember.findUnique({
        where: { eventId_userId: { eventId: room.eventId, userId }, revokedAt: null },
        select: { id: true },
      }),
      db.rSVP.findUnique({
        where: { eventId_userId: { eventId: room.eventId, userId } },
        select: { status: true },
      }),
    ]);
    return (
      !!committee ||
      (!!rsvp && rsvp.status !== "CANCELLED" && rsvp.status !== "DECLINED")
    );
  }

  // private-user-{userId} — only the matching user
  if (channelName.startsWith("private-user-")) {
    const channelUserId = channelName.replace("private-user-", "");
    return channelUserId === userId;
  }

  // private-organizer-{eventId}
  if (channelName.startsWith("private-organizer-")) {
    const eventId = channelName.replace("private-organizer-", "");
    const committee = await db.committeeMember.findUnique({
      where: { eventId_userId: { eventId, userId }, revokedAt: null },
      select: { role: true },
    });
    return (
      committee?.role === "ORGANIZER" ||
      committee?.role === "CO_ORGANIZER"
    );
  }

  return false;
}
