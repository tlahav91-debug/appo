import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, forbidden, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";

const voteSchema = z.object({ categoryId: z.string().cuid() });

// POST /api/nominations/[id] — cast or change a vote for this nominee in a category
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const nomineeId = params["id"]!;
  const { categoryId } = voteSchema.parse(await req.json());

  const category = await db.nominationCategory.findUnique({
    where: { id: categoryId },
    select: { votingStatus: true, eventId: true },
  });
  if (!category) return notFound("Category not found.");
  if (category.votingStatus !== "OPEN") {
    return forbidden("Voting is not currently open for this category.");
  }

  const rsvp = await db.rSVP.findUnique({
    where: { eventId_userId: { eventId: category.eventId, userId: user.id } },
    select: { status: true },
  });
  if (!rsvp || rsvp.status === "DECLINED" || rsvp.status === "CANCELLED") {
    return forbidden("Only confirmed attendees can vote.");
  }

  await db.nominationVote.upsert({
    where: { categoryId_voterId: { categoryId, voterId: user.id } },
    create: { categoryId, voterId: user.id, nomineeId },
    update: { nomineeId },
  });

  return ok({ voted: true, nomineeId });
});

// DELETE /api/nominations/[id] — withdraw a nomination (own only)
export const DELETE = withApiAuth(async (_req: NextRequest, { user, params }) => {
  const nomination = await db.classmateNomination.findUnique({
    where: { id: params["id"]! },
    select: { nominatorId: true, status: true },
  });

  if (!nomination) return notFound();
  if (nomination.nominatorId !== user.id) return forbidden("Not your nomination.");
  if (nomination.status === "ACCEPTED") return forbidden("Cannot withdraw an accepted nomination.");

  await db.classmateNomination.update({
    where: { id: params["id"]! },
    data: { status: "WITHDRAWN" },
  });

  return ok({ withdrawn: true });
});
