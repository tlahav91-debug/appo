import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, conflict } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { exportUserData, softDeleteUser } from "@/lib/services/user.service";
import { auditLog } from "@/lib/audit/log";
import { db } from "@/lib/db";

// PUT /api/profile — update User name/username and upsert AttendeeProfile
export const GET = withApiAuth(async (_req, { user }) => {
  const profile = await db.user.findUnique({
    where: { id: user.id },
    select: {
      id: true,
      name: true,
      email: true,
      username: true,
      avatarUrl: true,
      platformRole: true,
      createdAt: true,
      attendeeProfile: {
        select: {
          bio: true,
          currentCity: true,
          currentCountry: true,
          currentJob: true,
          currentEmployer: true,
          linkedinUrl: true,
          instagramHandle: true,
          funFact: true,
          favoriteMemory: true,
          showInDirectory: true,
          showCurrentJob: true,
          showCurrentCity: true,
          showSocialLinks: true,
          allowDirectMessages: true,
          allowPhotoTagging: true,
          allowNominations: true,
          profileVisibleTo: true,
          profileCompleteness: true,
        },
      },
    },
  });
  return ok(profile);
});

// Profile update schema — what the ProfileForm sends
const profileUpdateSchema = z.object({
  // User fields
  name: z.string().min(1).max(100).optional(),
  username: z
    .string()
    .min(3)
    .max(30)
    .regex(/^[a-z0-9_-]+$/)
    .optional()
    .or(z.literal("")),

  // AttendeeProfile fields
  bio: z.string().max(280).optional().or(z.literal("")),
  currentCity: z.string().max(100).optional().or(z.literal("")),
  currentCountry: z.string().max(100).optional().or(z.literal("")),
  currentJob: z.string().max(100).optional().or(z.literal("")),
  currentEmployer: z.string().max(100).optional().or(z.literal("")),
  funFact: z.string().max(200).optional().or(z.literal("")),
  favoriteMemory: z.string().max(500).optional().or(z.literal("")),
  linkedinUrl: z.string().url().optional().or(z.literal("")),
  instagramHandle: z
    .string()
    .max(30)
    .regex(/^[a-zA-Z0-9._]*$/)
    .optional()
    .or(z.literal("")),

  // Privacy
  showInDirectory: z.boolean().optional(),
  showCurrentJob: z.boolean().optional(),
  showCurrentCity: z.boolean().optional(),
  showSocialLinks: z.boolean().optional(),
  allowDirectMessages: z.boolean().optional(),
  allowPhotoTagging: z.boolean().optional(),
  allowNominations: z.boolean().optional(),
  profileVisibleTo: z
    .enum(["EVENT_ATTENDEES", "ORGANIZERS_ONLY", "NOBODY"])
    .optional(),
});

export const PUT = withApiAuth(async (req: NextRequest, { user }) => {
  const input = profileUpdateSchema.parse(await req.json());

  // Split into User fields vs AttendeeProfile fields
  const {
    name,
    username,
    bio,
    currentCity,
    currentCountry,
    currentJob,
    currentEmployer,
    funFact,
    favoriteMemory,
    linkedinUrl,
    instagramHandle,
    ...privacyFields
  } = input;

  try {
    await db.$transaction(async (tx) => {
      // Update User
      if (name || username !== undefined) {
        await tx.user.update({
          where: { id: user.id },
          data: {
            ...(name && { name }),
            ...(username !== undefined && {
              username: username || null,
            }),
          },
        });
      }

      // Calculate profile completeness
      const profileFields = [bio, currentCity, currentJob, currentEmployer, linkedinUrl];
      const filledCount = profileFields.filter(Boolean).length;
      const completeness = Math.round((filledCount / profileFields.length) * 100);

      // Upsert AttendeeProfile
      await tx.attendeeProfile.upsert({
        where: { userId: user.id },
        create: {
          userId: user.id,
          bio: bio || null,
          currentCity: currentCity || null,
          currentCountry: currentCountry || null,
          currentJob: currentJob || null,
          currentEmployer: currentEmployer || null,
          funFact: funFact || null,
          favoriteMemory: favoriteMemory || null,
          linkedinUrl: linkedinUrl || null,
          instagramHandle: instagramHandle || null,
          profileCompleteness: completeness,
          ...privacyFields,
        },
        update: {
          ...(bio !== undefined && { bio: bio || null }),
          ...(currentCity !== undefined && { currentCity: currentCity || null }),
          ...(currentCountry !== undefined && { currentCountry: currentCountry || null }),
          ...(currentJob !== undefined && { currentJob: currentJob || null }),
          ...(currentEmployer !== undefined && { currentEmployer: currentEmployer || null }),
          ...(funFact !== undefined && { funFact: funFact || null }),
          ...(favoriteMemory !== undefined && { favoriteMemory: favoriteMemory || null }),
          ...(linkedinUrl !== undefined && { linkedinUrl: linkedinUrl || null }),
          ...(instagramHandle !== undefined && { instagramHandle: instagramHandle || null }),
          profileCompleteness: completeness,
          ...privacyFields,
        },
      });
    });

    return ok({ updated: true });
  } catch (err: unknown) {
    if (
      typeof err === "object" &&
      err !== null &&
      "code" in err &&
      (err as { code: string }).code === "P2002"
    ) {
      return conflict("This username is already taken.");
    }
    throw err;
  }
});

export const DELETE = withApiAuth(async (_req, { user }) => {
  await softDeleteUser(user.id);
  await auditLog({
    actorId: user.id,
    action: "ACCOUNT_DELETED",
    resourceType: "User",
    resourceId: user.id,
  });
  return ok({ deleted: true });
});
