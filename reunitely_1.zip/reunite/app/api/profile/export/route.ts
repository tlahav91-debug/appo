import { type NextRequest, NextResponse } from "next/server";
import { unauthorized } from "@/lib/utils/api-response";
import { getApiUser } from "@/lib/auth/session";
import { exportUserData } from "@/lib/services/user.service";
import { auditLog } from "@/lib/audit/log";

export async function GET(_req: NextRequest) {
  const user = await getApiUser();
  if (!user) return unauthorized();
  const data = await exportUserData(user.id);
  await auditLog({ actorId: user.id, action: "DATA_EXPORTED", resourceType: "User", resourceId: user.id });
  return new NextResponse(JSON.stringify(data, null, 2), {
    headers: { "Content-Type": "application/json", "Content-Disposition": `attachment; filename="reunitely-export-${user.id}.json"`, "Cache-Control": "no-store" },
  });
}
