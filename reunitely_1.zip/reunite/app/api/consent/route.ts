import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { logConsent, getConsentStatus } from "@/lib/services/consent.service";

const schema = z.object({
  type: z.enum(["EMAIL_MARKETING", "SMS_MARKETING", "WHATSAPP_MARKETING", "DATA_PROCESSING", "COOKIE_ANALYTICS"]),
  granted: z.boolean(),
  eventId: z.string().optional(),
});

// GET /api/consent — fetch current user's consent statuses
export const GET = withApiAuth(async (_req: NextRequest, { user }) => {
  const { db } = await import("@/lib/db");
  const records = await db.consentRecord.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
  });
  return ok(records);
});

// POST /api/consent — record a consent grant or revocation
export const POST = withApiAuth(async (req: NextRequest, { user }) => {
  const { type, granted, eventId } = schema.parse(await req.json());
  await logConsent({
    userId: user.id,
    type: type as never,
    granted,
    eventId,
    ipAddress: req.headers.get("x-forwarded-for") ?? undefined,
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  return ok({ recorded: true });
});
