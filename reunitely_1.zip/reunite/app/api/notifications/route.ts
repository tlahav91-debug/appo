import { type NextRequest } from "next/server";
import { ok } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";

export const GET = withApiAuth(async (_req, { user }) => {
  const notifications = await db.notification.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
  return ok(notifications);
});
