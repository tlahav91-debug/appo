import { type NextRequest } from "next/server";
import { ok } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";

export const POST = withApiAuth(async (_req, { user }) => {
  await db.notification.updateMany({ where: { userId: user.id, isRead: false }, data: { isRead: true } });
  return ok({ updated: true });
});
