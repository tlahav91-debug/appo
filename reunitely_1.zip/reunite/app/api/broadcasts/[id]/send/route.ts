import { type NextRequest } from "next/server";
import { ok } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { applyRateLimit } from "@/lib/rate-limit";
import { sendBroadcast } from "@/lib/services/broadcast.service";

export const POST = withApiAuth(async (_req: NextRequest, { user, params }) => {
  const rl = await applyRateLimit("broadcast", user.id);
  if (!rl.success) return rl.response!;
  const result = await sendBroadcast(params["id"]!, user.id);
  return ok(result);
});
