import { type NextRequest } from "next/server";
import { z } from "zod";
import { ok, forbidden, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { sendTestBroadcast } from "@/lib/messaging/notify";
import { db } from "@/lib/db";

const schema = z.object({
  recipientEmail: z.string().email(),
});

// POST /api/broadcasts/[id]/test-send
export const POST = withApiAuth(async (req: NextRequest, { user, params }) => {
  const broadcastId = params["id"]!;
  const { recipientEmail } = schema.parse(await req.json());

  const broadcast = await db.broadcast.findUnique({
    where: { id: broadcastId },
    select: { eventId: true, createdById: true },
  });
  if (!broadcast) return notFound();

  // Must be creator or organizer
  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId: broadcast.eventId, userId: user.id }, revokedAt: null },
    select: { id: true },
  });
  if (!committee && broadcast.createdById !== user.id) {
    return forbidden("Access denied.");
  }

  await sendTestBroadcast(broadcastId, recipientEmail, user.name);
  return ok({ sent: true, to: recipientEmail });
});
