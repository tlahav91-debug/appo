import { type NextRequest } from "next/server";
import { ok, forbidden, notFound } from "@/lib/utils/api-response";
import { withApiAuth } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";

// GET /api/broadcasts/[id]/deliveries — delivery stats + breakdown
export const GET = withApiAuth(async (_req: NextRequest, { user, params }) => {
  const broadcastId = params["id"]!;

  const broadcast = await db.broadcast.findUnique({
    where: { id: broadcastId },
    select: { eventId: true, recipientCount: true, deliveredCount: true,
              failedCount: true, openedCount: true, clickedCount: true, status: true },
  });
  if (!broadcast) return notFound();

  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId: broadcast.eventId, userId: user.id }, revokedAt: null },
    select: { id: true },
  });
  if (!committee) return forbidden("Access denied.");

  const deliveries = await db.broadcastDelivery.findMany({
    where: { broadcastId },
    select: {
      id: true,
      status: true,
      channel: true,
      recipientEmail: true,
      sentAt: true,
      failedAt: true,
      errorMessage: true,
      user: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: "asc" },
    take: 500,
  });

  const statusCounts = deliveries.reduce((acc, d) => {
    acc[d.status] = (acc[d.status] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return ok({
    summary: {
      recipientCount: broadcast.recipientCount,
      deliveredCount: broadcast.deliveredCount,
      failedCount: broadcast.failedCount,
      openedCount: broadcast.openedCount,
      clickedCount: broadcast.clickedCount,
      status: broadcast.status,
    },
    statusCounts,
    deliveries,
  });
});
