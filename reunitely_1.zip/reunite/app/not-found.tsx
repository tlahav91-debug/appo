import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-md text-center">
        <div className="mb-6 font-display text-8xl font-bold text-blue-200">
          404
        </div>
        <h1 className="font-display text-2xl font-bold text-slate-900">
          Page not found
        </h1>
        <p className="mt-3 text-slate-500">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
          <Button asChild>
            <Link href="/">Back to Home</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/dashboard/events">My Events</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
