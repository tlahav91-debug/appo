import { requireAuth } from "@/lib/auth/session";
import { PageHeader } from "@/components/shared/PageHeader";
import { db } from "@/lib/db";
import { CreditCard, ExternalLink, CheckCircle, AlertCircle, DollarSign, Shield } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/utils";

export const metadata = { title: "Billing" };

export default async function BillingPage() {
  const session = await requireAuth();

  // Load organizer profile for Stripe info + all events where user is organizer
  const [organizerProfile, organizerEvents] = await Promise.all([
    db.organizerProfile.findUnique({
      where: { userId: session.user.id },
      select: {
        stripeAccountId: true,
        stripeOnboarded: true,
        isVerifiedHost: true,
      },
    }),
    db.committeeMember.findMany({
      where: {
        userId: session.user.id,
        role: "ORGANIZER",
        revokedAt: null,
      },
      include: {
        event: {
          select: {
            id: true,
            title: true,
            slug: true,
            ticketingEnabled: true,
            stripeAccountId: true,
            _count: { select: { rsvps: { where: { status: "CONFIRMED" } } } },
          },
        },
      },
      orderBy: { addedAt: "desc" },
    }),
  ]);

  // Revenue across all events
  const allEventIds = organizerEvents.map((e) => e.eventId);
  const revenueData =
    allEventIds.length > 0
      ? await db.payment.aggregate({
          where: { eventId: { in: allEventIds }, status: "PAID" },
          _sum: { totalAmountCents: true },
          _count: { id: true },
        })
      : { _sum: { totalAmountCents: 0 }, _count: { id: 0 } };

  const totalRevenueCents = revenueData._sum.totalAmountCents ?? 0;
  const totalPayments = revenueData._count.id ?? 0;

  const hasStripe = !!organizerProfile?.stripeOnboarded;
  const ticketedEvents = organizerEvents.filter((e) => e.event.ticketingEnabled);

  return (
    <div className="flex flex-col gap-8 max-w-3xl">
      <PageHeader
        title="Billing & Payments"
        description="Manage your Stripe Connect account and view payment history."
      />

      {/* ── Stripe Connect status ─────────────────────────────────────── */}
      <section className="flex flex-col gap-4">
        <h2 className="text-sm font-semibold text-slate-700">Stripe Connect</h2>

        {hasStripe ? (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-6">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100">
                  <CheckCircle className="h-5 w-5 text-emerald-600" />
                </div>
                <div>
                  <p className="font-semibold text-emerald-900">Account connected</p>
                  <p className="text-sm text-emerald-700 mt-0.5">
                    You can accept payments for ticketed events. Payouts go
                    directly to your Stripe account.
                  </p>
                </div>
              </div>
              <Button variant="outline" size="sm" className="shrink-0 gap-1.5 border-emerald-300 text-emerald-700 hover:bg-emerald-100" asChild>
                <a href="https://dashboard.stripe.com" target="_blank" rel="noopener noreferrer">
                  Stripe Dashboard
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </Button>
            </div>
          </div>
        ) : (
          <div className="rounded-2xl border border-border bg-card p-6">
            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100">
                <CreditCard className="h-5 w-5 text-slate-500" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-900">Connect Stripe to accept payments</p>
                <p className="text-sm text-slate-500 mt-1">
                  Enable ticketing on your events and get paid directly via
                  Stripe. Reunitely uses Stripe Connect — funds go straight to
                  your bank account, not through us.
                </p>

                <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
                  {[
                    { icon: Shield, label: "Bank-grade security", desc: "PCI DSS compliant" },
                    { icon: DollarSign, label: "Fast payouts", desc: "2–7 business days" },
                    { icon: CreditCard, label: "All major cards", desc: "Visa, Mastercard, Amex" },
                  ].map(({ icon: Icon, label, desc }) => (
                    <div key={label} className="flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2">
                      <Icon className="h-4 w-4 text-slate-400 shrink-0" />
                      <div>
                        <p className="text-xs font-medium text-slate-700">{label}</p>
                        <p className="text-[11px] text-slate-400">{desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <p className="mt-4 text-xs text-slate-400">
                  You'll be redirected to Stripe to set up your account. This takes
                  about 5 minutes. Connect Stripe per-event in each event's
                  Payments section.
                </p>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* ── Revenue summary ───────────────────────────────────────────── */}
      {totalRevenueCents > 0 && (
        <section className="flex flex-col gap-4">
          <h2 className="text-sm font-semibold text-slate-700">All-time revenue</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-2xl border border-border bg-card p-5">
              <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
                Total collected
              </p>
              <p className="font-display mt-2 text-3xl font-bold text-slate-900">
                {formatCurrency(totalRevenueCents, "USD")}
              </p>
              <p className="text-xs text-slate-400 mt-1">across all your events</p>
            </div>
            <div className="rounded-2xl border border-border bg-card p-5">
              <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
                Transactions
              </p>
              <p className="font-display mt-2 text-3xl font-bold text-slate-900">
                {totalPayments.toLocaleString()}
              </p>
              <p className="text-xs text-slate-400 mt-1">successful payments</p>
            </div>
          </div>
        </section>
      )}

      {/* ── Events with ticketing ──────────────────────────────────────── */}
      {ticketedEvents.length > 0 && (
        <section className="flex flex-col gap-4">
          <h2 className="text-sm font-semibold text-slate-700">Ticketed events</h2>
          <div className="flex flex-col gap-2">
            {ticketedEvents.map(({ event }) => (
              <div
                key={event.id}
                className="flex items-center gap-4 rounded-xl border border-border bg-card px-4 py-3"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">{event.title}</p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {event._count.rsvps} confirmed
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {event.stripeAccountId ? (
                    <span className="flex items-center gap-1 rounded-full bg-emerald-50 border border-emerald-200 px-2 py-0.5 text-[10px] font-semibold text-emerald-700">
                      <CheckCircle className="h-3 w-3" />
                      Stripe connected
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 rounded-full bg-blue-50 border border-blue-200 px-2 py-0.5 text-[10px] font-semibold text-blue-700">
                      <AlertCircle className="h-3 w-3" />
                      Not connected
                    </span>
                  )}
                  <Button variant="ghost" size="sm" asChild className="text-xs">
                    <Link href={`/dashboard/events/${event.id}/payments`}>
                      View payments →
                    </Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ── Help & legal ──────────────────────────────────────────────── */}
      <section className="rounded-xl bg-slate-50 border border-border p-5">
        <h2 className="text-sm font-semibold text-slate-700 mb-3">Help & policies</h2>
        <div className="flex flex-col gap-2 text-sm text-slate-600">
          <p>
            Reunitely does not store card details. All payment data is handled
            securely by <a href="https://stripe.com" className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">Stripe</a>.
          </p>
          <p>
            For refund requests, disputes, or payout questions — log in to your{" "}
            <a href="https://dashboard.stripe.com" className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">
              Stripe Dashboard
            </a>.
          </p>
          <p className="text-slate-400 text-xs mt-1">
            Questions? <a href="mailto:support@reunitely.app" className="underline hover:text-slate-600">support@reunitely.app</a>
          </p>
        </div>
      </section>
    </div>
  );
}
