import { requireAuth } from "@/lib/auth/session";
import { PageHeader } from "@/components/shared/PageHeader";
import { ProfileForm } from "@/components/profile/ProfileForm";
import { db } from "@/lib/db";

export const metadata = { title: "My Profile" };

export default async function ProfilePage() {
  const session = await requireAuth();

  const profile = await db.attendeeProfile.findUnique({
    where: { userId: session.user.id },
    select: {
      bio: true,
      currentCity: true,
      currentCountry: true,
      currentJob: true,
      currentEmployer: true,
      linkedinUrl: true,
      instagramHandle: true,
      funFact: true,
      favoriteMemory: true,
      showInDirectory: true,
      showCurrentJob: true,
      showCurrentCity: true,
      showSocialLinks: true,
      allowDirectMessages: true,
      allowPhotoTagging: true,
      allowNominations: true,
      profileVisibleTo: true,
    },
  });

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader
        title="My Profile"
        description="Update your public profile visible to classmates at events you attend."
      />
      <ProfileForm
        userId={session.user.id}
        userName={session.user.name}
        userEmail={session.user.email}
        userAvatar={session.user.avatarUrl}
        existingProfile={profile}
      />
    </div>
  );
}
