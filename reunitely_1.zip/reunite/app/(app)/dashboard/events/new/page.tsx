import type { Metadata } from "next";
import { requireAuth } from "@/lib/auth/session";
import { CreateEventWizard } from "@/components/events/CreateEventWizard";
import { loadDraftAction } from "@/lib/actions/wizard.actions";

export const metadata: Metadata = { title: "Create Event — Reunitely" };

interface Props {
  searchParams: {
    draft?: string;
    step?: string;
  };
}

export default async function NewEventPage({ searchParams }: Props) {
  await requireAuth();

  const initialStep = searchParams.step ? parseInt(searchParams.step, 10) : 1;
  const safeStep = isNaN(initialStep) || initialStep < 1 || initialStep > 8 ? 1 : initialStep;

  // If a draft ID is in the URL, load its data so the form is pre-populated
  let initialData = undefined;
  if (searchParams.draft) {
    const result = await loadDraftAction(searchParams.draft);
    if (result.success) {
      initialData = result.data;
    }
  }

  return (
    <div className="mx-auto max-w-2xl pb-16">
      {/* Header — only shown on the first step landing */}
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-slate-900">
          Create a Reunion Event
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Your progress is saved automatically. You can return to finish this
          later.
        </p>
      </div>

      <CreateEventWizard
        initialStep={safeStep}
        initialEventId={searchParams.draft}
        initialData={initialData}
      />
    </div>
  );
}
