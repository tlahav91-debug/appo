import { Suspense } from "react";
import { Plus } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/shared/PageHeader";
import { EventCardList, EventCardListSkeleton } from "@/components/events/EventCardList";

export const metadata = { title: "My Events" };

export default function DashboardEventsPage() {
  return (
    <div className="flex flex-col gap-8">
      <PageHeader
        title="My Events"
        description="Manage your reunions, track RSVPs, and communicate with classmates."
      >
        <Button asChild>
          <Link href="/dashboard/events/new">
            <Plus className="mr-2 h-4 w-4" />
            Create Event
          </Link>
        </Button>
      </PageHeader>

      <Suspense fallback={<EventCardListSkeleton />}>
        <EventCardList />
      </Suspense>
    </div>
  );
}
