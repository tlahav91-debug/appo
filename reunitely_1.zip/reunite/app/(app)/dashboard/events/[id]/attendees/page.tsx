import { notFound } from "next/navigation";
import { Suspense } from "react";
import { requireAuth } from "@/lib/auth/session";
import { requireEventPermission, PermissionError } from "@/lib/auth/permissions";
import { Unauthorized } from "@/components/shared/Unauthorized";
import { PageHeader } from "@/components/shared/PageHeader";
import { AttendeeTable } from "@/components/attendees/AttendeeTable";
import { AttendeeTableSkeleton } from "@/components/attendees/AttendeeTableSkeleton";
import { AttendeeExportButton, InviteAttendeesButton } from "@/components/attendees/AttendeeExportButton";
import { db } from "@/lib/db";

export const metadata = { title: "Attendees" };

interface Props {
  params: { id: string };
  searchParams: { status?: string; search?: string };
}

export default async function AttendeesPage({ params, searchParams }: Props) {
  const session = await requireAuth();

  let eventCtx;
  try {
    eventCtx = await requireEventPermission(
      session.user.id,
      params.id,
      "attendees:read"
    );
  } catch (err) {
    if (err instanceof PermissionError) {
      if (err.code === "NOT_MEMBER" || err.code === "NOT_FOUND") notFound();
      return (
        <Unauthorized
          title="Organizers only"
          message="You need organizer or co-organizer access to view attendees."
        />
      );
    }
    throw err;
  }

  const event = await db.event.findUnique({
    where: { id: params.id },
    select: { title: true },
  });
  if (!event) notFound();

  const canExport = eventCtx.isSuperAdmin || eventCtx.effectiveRole === "ORGANIZER";
  const canInvite =
    eventCtx.isSuperAdmin ||
    (eventCtx.effectiveRole !== "ATTENDEE" &&
      eventCtx.effectiveRole !== "GUEST_ATTENDEE");

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Attendees"
        description="Manage RSVPs, check-ins, and attendee details."
      >
        {canExport && <AttendeeExportButton eventId={params.id} />}
        {canInvite && <InviteAttendeesButton eventId={params.id} />}
      </PageHeader>
      <Suspense fallback={<AttendeeTableSkeleton />}>
        <AttendeeTable
          eventId={params.id}
          initialStatus={searchParams.status}
          initialSearch={searchParams.search}
        />
      </Suspense>
    </div>
  );
}
