import { notFound } from "next/navigation";
import { Suspense } from "react";
import { requireAuth } from "@/lib/auth/session";
import { requireEventPermission, PermissionError } from "@/lib/auth/permissions";
import { PageHeader } from "@/components/shared/PageHeader";
import { NominationManager } from "@/components/nominations/NominationManager";
import { Skeleton } from "@/components/ui/skeleton";

export const metadata = { title: "Nominations" };

interface Props { params: { id: string } }

export default async function NominationsPage({ params }: Props) {
  const session = await requireAuth();

  try {
    await requireEventPermission(session.user.id, params.id, "nominations:manage");
  } catch (err) {
    if (err instanceof PermissionError) notFound();
    throw err;
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Nominations"
        description="Create categories, manage nominees, and reveal results."
      />
      <Suspense fallback={<Skeleton className="h-96 rounded-xl" />}>
        <NominationManager eventId={params.id} />
      </Suspense>
    </div>
  );
}
