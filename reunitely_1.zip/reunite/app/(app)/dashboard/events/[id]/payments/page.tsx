import { notFound } from "next/navigation";
import { Suspense } from "react";
import { requireAuth } from "@/lib/auth/session";
import { requireEventPermission, PermissionError } from "@/lib/auth/permissions";
import { Unauthorized } from "@/components/shared/Unauthorized";
import { PageHeader } from "@/components/shared/PageHeader";
import { PaymentsOverview, OrdersTable } from "@/components/payments/PaymentsOverview";
import { StripeConnectCard } from "@/components/payments/StripeConnectCard";
import { Skeleton } from "@/components/ui/skeleton";
import { db } from "@/lib/db";

export const metadata = { title: "Payments" };

interface Props { params: { id: string } }

export default async function PaymentsPage({ params }: Props) {
  const session = await requireAuth();

  try {
    await requireEventPermission(session.user.id, params.id, "payments:read");
  } catch (err) {
    if (err instanceof PermissionError) {
      if (err.code === "NOT_MEMBER" || err.code === "NOT_FOUND") notFound();
      return (
        <Unauthorized
          title="Payment access required"
          message="Only organizers with payment access can view this section."
        />
      );
    }
    throw err;
  }

  const event = await db.event.findUnique({
    where: { id: params.id },
    select: { stripeAccountId: true, ticketingEnabled: true },
  });
  if (!event) notFound();

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Payments"
        description="Track ticket revenue, manage orders, and configure payouts."
      />
      <StripeConnectCard
        eventId={params.id}
        stripeAccountId={event.stripeAccountId}
        ticketingEnabled={event.ticketingEnabled}
      />
      <Suspense fallback={<Skeleton className="h-32 rounded-xl" />}>
        <PaymentsOverview eventId={params.id} />
      </Suspense>
      <Suspense fallback={<Skeleton className="h-64 rounded-xl" />}>
        <OrdersTable eventId={params.id} />
      </Suspense>
    </div>
  );
}
