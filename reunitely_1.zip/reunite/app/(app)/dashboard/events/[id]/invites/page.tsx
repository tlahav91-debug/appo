import { notFound } from "next/navigation";
import { Suspense } from "react";
import { requireAuth } from "@/lib/auth/session";
import { requireEventPermission, PermissionError } from "@/lib/auth/permissions";
import { PageHeader } from "@/components/shared/PageHeader";
import { InvitesPageClient } from "@/components/invites/InvitesPageClient";
import { InviteStatsPanel } from "@/components/invites/InviteStatsPanel";
import { Skeleton } from "@/components/ui/skeleton";
import { db } from "@/lib/db";

export const metadata = { title: "Invites" };

interface Props { params: { id: string } }

export default async function InvitesPage({ params }: Props) {
  const session = await requireAuth();

  try {
    await requireEventPermission(session.user.id, params.id, "invites:manage");
  } catch (err) {
    if (err instanceof PermissionError) notFound();
    throw err;
  }

  const event = await db.event.findUnique({
    where: { id: params.id },
    select: {
      slug: true,
      title: true,
      ticketingEnabled: true,
      settings: true,
    },
  });
  if (!event) notFound();

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Invites"
        description="Invite classmates, track responses, and manage referral links."
      />

      {/* Stats funnel */}
      <Suspense fallback={<Skeleton className="h-36 rounded-xl" />}>
        <InviteStatsPanel eventId={params.id} />
      </Suspense>

      {/* Main tabs: Send / Import / Referrals */}
      <InvitesPageClient eventId={params.id} eventSlug={event.slug} />
    </div>
  );
}
