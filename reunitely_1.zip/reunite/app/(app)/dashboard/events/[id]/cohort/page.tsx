import { notFound } from "next/navigation";
import { requireAuth } from "@/lib/auth/session";
import { requireEventPermission, PermissionError } from "@/lib/auth/permissions";
import { PageHeader } from "@/components/shared/PageHeader";
import { CohortLeadsQueue } from "@/components/cohort-discovery/CohortLeadsQueue";
import { db } from "@/lib/db";

export const metadata = { title: "Classmate Nominations" };

interface Props { params: { id: string } }

export default async function CohortPage({ params }: Props) {
  const session = await requireAuth();

  try {
    await requireEventPermission(session.user.id, params.id, "invites:manage");
  } catch (err) {
    if (err instanceof PermissionError) notFound();
    throw err;
  }

  const event = await db.event.findUnique({
    where: { id: params.id },
    select: { title: true, slug: true, schoolName: true, graduationYear: true },
  });
  if (!event) notFound();

  // Total pending count for the badge
  const pendingCount = await db.cohortNominationLead.count({
    where: { eventId: params.id, status: "PENDING" },
  });

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Classmate Nominations"
        description={`Attendees can nominate missing classmates from ${event.schoolName} · ${event.graduationYear}. Review leads and convert them to invites.`}
      >
        {pendingCount > 0 && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-100 px-3 py-1.5 text-sm font-semibold text-blue-800">
            {pendingCount} pending review
          </span>
        )}
      </PageHeader>

      <CohortLeadsQueue eventId={params.id} />
    </div>
  );
}
