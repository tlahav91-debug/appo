import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { requireAuth } from "@/lib/auth/session";
import { requireEventPermission, PermissionError } from "@/lib/auth/permissions";
import { PageHeader } from "@/components/shared/PageHeader";
import { ScheduleBuilder } from "@/components/events/ScheduleBuilder";

export const metadata: Metadata = { title: "Schedule" };

interface Props { params: { id: string } }

export default async function SchedulePage({ params }: Props) {
  const session = await requireAuth();

  try {
    await requireEventPermission(session.user.id, params.id, "event:update");
  } catch (err) {
    if (err instanceof PermissionError) notFound();
    throw err;
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Schedule"
        description="Plan the run-of-show for your reunion. Drag items to reorder."
      />
      <ScheduleBuilder eventId={params.id} />
    </div>
  );
}
