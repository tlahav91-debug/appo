import { notFound } from "next/navigation";
import { requireAuth } from "@/lib/auth/session";
import { requireEventPermission, PermissionError } from "@/lib/auth/permissions";
import { Unauthorized } from "@/components/shared/Unauthorized";
import { PageHeader } from "@/components/shared/PageHeader";
import { EventSettingsForm } from "@/components/events/EventSettingsForm";
import { db } from "@/lib/db";

export const metadata = { title: "Settings" };

interface Props { params: { id: string } }

export default async function EventSettingsPage({ params }: Props) {
  const session = await requireAuth();

  // settings:manage is ORGANIZER-only — CO_ORGANIZER cannot access
  try {
    await requireEventPermission(session.user.id, params.id, "settings:manage");
  } catch (err) {
    if (err instanceof PermissionError) {
      if (err.code === "NOT_MEMBER" || err.code === "NOT_FOUND") notFound();
      return (
        <Unauthorized
          title="Lead organizer only"
          message="Event settings can only be changed by the lead organizer."
        />
      );
    }
    throw err;
  }

  const event = await db.event.findUnique({
    where: { id: params.id },
    select: {
      id: true,
      slug: true,
      status: true,
      settings: true,
    },
  });
  if (!event) notFound();

  const settings = event.settings as Record<string, boolean | unknown> | null;

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Settings"
        description="Manage event configuration, features, and danger zone."
      />
      <EventSettingsForm
        event={{
          id: event.id,
          slug: event.slug,
          status: event.status,
          settings: {
            nominationsEnabled: Boolean(settings?.nominationsEnabled),
            scheduleEnabled: Boolean(settings?.scheduleEnabled),
            memoriesAutoApprove: Boolean(settings?.memoriesAutoApprove),
            chatEnabled: settings?.chatEnabled !== false,
            directoryEnabled: Boolean(settings?.directoryEnabled),
          },
        }}
      />
    </div>
  );
}
