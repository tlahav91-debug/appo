import { notFound } from "next/navigation";
import type { Metadata } from "next";
import Link from "next/link";
import { requireAuth } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { Button } from "@/components/ui/button";
import {
  CheckCircle,
  ExternalLink,
  Share2,
  Users,
  Send,
  ArrowRight,
  Copy,
} from "lucide-react";
import { getEventUrl } from "@/lib/utils";
import { CopyEventLinkButton } from "@/components/events/CopyEventLinkButton";

export const metadata: Metadata = { title: "Event Published! — Reunitely" };

interface Props {
  params: { id: string };
  searchParams: { slug?: string };
}

export default async function EventPublishedPage({ params, searchParams }: Props) {
  const session = await requireAuth();

  // Load the event to show real data
  const event = await db.event.findUnique({
    where: {
      id: params.id,
      createdById: session.user.id,
      status: "PUBLISHED",
    },
    select: {
      id: true,
      title: true,
      slug: true,
      startAt: true,
      timezone: true,
      schoolName: true,
      graduationYear: true,
      visibility: true,
      ticketingEnabled: true,
      coverImageUrl: true,
    },
  });

  if (!event) notFound();

  const eventUrl = getEventUrl(event.slug);

  const nextSteps = [
    {
      icon: Users,
      title: "Invite classmates",
      description: "Send personal invite links to your class list",
      href: `/dashboard/events/${event.id}/invites`,
      cta: "Send invites",
    },
    {
      icon: Send,
      title: "Send a broadcast",
      description: "Email your confirmed attendees with event details",
      href: `/dashboard/events/${event.id}/messages`,
      cta: "Write message",
    },
    {
      icon: Users,
      title: "Manage your committee",
      description: "Add co-organizers to help run the event",
      href: `/dashboard/events/${event.id}/settings`,
      cta: "Add committee",
    },
  ];

  return (
    <div className="mx-auto max-w-2xl py-8">
      <div className="flex flex-col items-center gap-8">
        {/* Success animation */}
        <div className="flex flex-col items-center gap-4 text-center">
          <div className="flex h-24 w-24 items-center justify-center rounded-full bg-emerald-100">
            <CheckCircle className="h-12 w-12 text-emerald-500" />
          </div>
          <div>
            <h1 className="font-display text-3xl font-bold text-slate-900">
              Your event is live! 🎉
            </h1>
            <p className="mt-2 text-slate-500 text-base max-w-md">
              <strong className="text-slate-700">{event.title}</strong> is now
              {event.visibility === "PUBLIC"
                ? " publicly discoverable"
                : event.visibility === "PRIVATE"
                ? " live for invited attendees"
                : " accessible via link"}
              .
            </p>
          </div>
        </div>

        {/* Event link card */}
        <div className="w-full rounded-2xl border border-border bg-card p-6 shadow-card">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
            Your event link
          </p>
          <div className="flex items-center gap-2">
            <div className="flex-1 min-w-0 rounded-lg bg-slate-50 border border-border px-4 py-3">
              <p className="text-sm font-mono text-slate-700 truncate">
                {eventUrl}
              </p>
            </div>
            <CopyEventLinkButton url={eventUrl} />
            <Button asChild variant="outline" size="icon" className="h-11 w-11 shrink-0">
              <a href={eventUrl} target="_blank" rel="noopener noreferrer" aria-label="Open event page">
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          </div>

          {/* Quick share row */}
          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              asChild
              variant="outline"
              size="sm"
              className="gap-2 text-xs"
            >
              <a
                href={`https://wa.me/?text=${encodeURIComponent(`You're invited to ${event.title}! RSVP here: ${eventUrl}`)}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Share2 className="h-3.5 w-3.5 text-emerald-500" />
                WhatsApp
              </a>
            </Button>
            <Button
              asChild
              variant="outline"
              size="sm"
              className="gap-2 text-xs"
            >
              <a
                href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(eventUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Share2 className="h-3.5 w-3.5 text-blue-500" />
                Facebook
              </a>
            </Button>
            <Button
              asChild
              variant="outline"
              size="sm"
              className="gap-2 text-xs"
            >
              <a href={`mailto:?subject=${encodeURIComponent(`You're invited: ${event.title}`)}&body=${encodeURIComponent(`Join me at ${event.title}!\n\nRSVP here: ${eventUrl}`)}`}>
                <Send className="h-3.5 w-3.5 text-blue-500" />
                Email
              </a>
            </Button>
          </div>
        </div>

        {/* Next steps */}
        <div className="w-full">
          <p className="text-sm font-semibold text-slate-700 mb-3">
            Recommended next steps
          </p>
          <div className="flex flex-col gap-3">
            {nextSteps.map((step) => (
              <Link
                key={step.href}
                href={step.href}
                className="flex items-center gap-4 rounded-xl border border-border bg-card px-5 py-4 transition-all hover:border-blue-300 hover:shadow-sm group"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-blue-50">
                  <step.icon className="h-5 w-5 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-900">
                    {step.title}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {step.description}
                  </p>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-400 shrink-0 group-hover:text-blue-500 transition-colors" />
              </Link>
            ))}
          </div>
        </div>

        {/* Dashboard link */}
        <div className="flex gap-3">
          <Button asChild variant="outline">
            <Link href="/dashboard/events">View all events</Link>
          </Button>
          <Button asChild>
            <Link href={`/dashboard/events/${event.id}/overview`}>
              Go to event dashboard
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
