import { notFound } from "next/navigation";
import { Suspense } from "react";
import Link from "next/link";
import { requireAuth } from "@/lib/auth/session";
import { loadDashboardData } from "@/lib/services/dashboard.service";
import { resolveEventContext } from "@/lib/auth/permissions";
import { PermissionError } from "@/lib/auth/permissions";

// ─── Section components
import { DashboardKpiRow } from "@/components/dashboard/DashboardKpiRow";
import { RsvpFunnelCard } from "@/components/dashboard/RsvpFunnelCard";
import { InviteFunnelCard } from "@/components/dashboard/InviteFunnelCard";
import { RsvpTrendChart } from "@/components/dashboard/RsvpTrendChart";
import { PaymentSummaryCard } from "@/components/dashboard/PaymentSummaryCard";
import { NominationSummaryCard } from "@/components/dashboard/NominationSummaryCard";
import { CohortCoverageCard } from "@/components/dashboard/CohortCoverageCard";
import { AmbassadorLeaderboard } from "@/components/dashboard/AmbassadorLeaderboard";
import { RemindersPanel } from "@/components/dashboard/RemindersPanel";
import { DashboardQuickActions } from "@/components/dashboard/DashboardQuickActions";
import { DashboardActivityFeed } from "@/components/dashboard/DashboardActivityFeed";
import { CommitteeRoster } from "@/components/dashboard/CommitteeRoster";
import { Skeleton } from "@/components/ui/skeleton";

export const metadata = { title: "Overview" };

interface Props { params: { id: string } }

export default async function EventOverviewPage({ params }: Props) {
  const session = await requireAuth();

  // Permission check
  let canView = false;
  try {
    const ctx = await resolveEventContext(session.user.id, params.id);
    canView = ctx.isSuperAdmin ||
      ctx.effectiveRole === "ORGANIZER" ||
      ctx.effectiveRole === "CO_ORGANIZER" ||
      ctx.effectiveRole === "COMMITTEE";
  } catch (err) {
    if (err instanceof PermissionError) notFound();
    throw err;
  }
  if (!canView) notFound();

  const data = await loadDashboardData(params.id, session.user.id);
  if (!data) notFound();

  const { event, rsvp, invites, payments, nominations, cohort, ambassadors, reminders, recentActivity, committee } = data;

  const isOrganizer = committee.find(m => m.userId === session.user.id)?.role === "ORGANIZER";

  return (
    <div className="flex flex-col gap-6 pb-8">
      {/* ── Reminders panel (priority alerts at top) ──────────────── */}
      {reminders.length > 0 && (
        <RemindersPanel reminders={reminders} eventId={params.id} />
      )}

      {/* ── KPI row ───────────────────────────────────────────────── */}
      <DashboardKpiRow
        rsvp={rsvp}
        payments={payments}
        invites={invites}
        event={event}
      />

      {/* ── Main 3-col grid ──────────────────────────────────────── */}
      <div className="grid gap-5 xl:grid-cols-3">
        {/* Left: funnels + chart (spans 2 cols on xl) */}
        <div className="flex flex-col gap-5 xl:col-span-2">
          {/* RSVP trend chart */}
          <RsvpTrendChart trend={rsvp.trend} confirmedCount={rsvp.confirmed} />

          {/* RSVP + Invite funnels side by side */}
          <div className="grid gap-5 sm:grid-cols-2">
            <RsvpFunnelCard rsvp={rsvp} capacity={event.capacity} />
            <InviteFunnelCard invites={invites} />
          </div>

          {/* Payment + Nominations (conditional) */}
          <div className="grid gap-5 sm:grid-cols-2">
            {payments.enabled && (
              <PaymentSummaryCard payments={payments} eventId={params.id} />
            )}
            {nominations.enabled && nominations.categoryCount > 0 && (
              <NominationSummaryCard nominations={nominations} eventId={params.id} />
            )}
            {!payments.enabled && nominations.enabled && nominations.categoryCount === 0 && (
              <CohortCoverageCard cohort={cohort} eventId={params.id} />
            )}
          </div>

          {/* Cohort coverage + Ambassador leaderboard */}
          <div className="grid gap-5 sm:grid-cols-2">
            {(payments.enabled || nominations.categoryCount > 0) && (
              <CohortCoverageCard cohort={cohort} eventId={params.id} />
            )}
            {ambassadors.length > 0 && (
              <AmbassadorLeaderboard ambassadors={ambassadors} eventId={params.id} />
            )}
          </div>
        </div>

        {/* Right column: quick actions + activity + committee */}
        <div className="flex flex-col gap-5">
          <DashboardQuickActions
            eventId={params.id}
            eventSlug={event.slug}
            eventStatus={event.status}
            isOrganizer={isOrganizer}
            rsvpCount={rsvp.confirmed}
            hasStripeConnect={payments.enabled}
          />

          <DashboardActivityFeed
            activities={recentActivity}
            eventId={params.id}
          />

          {committee.length > 0 && (
            <CommitteeRoster
              members={committee}
              eventId={params.id}
              isOrganizer={isOrganizer}
            />
          )}
        </div>
      </div>
    </div>
  );
}
