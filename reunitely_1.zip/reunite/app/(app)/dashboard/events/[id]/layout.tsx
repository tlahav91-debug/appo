import { notFound } from "next/navigation";
import { requireAuth } from "@/lib/auth/session";
import {
  resolveEventContext,
  contextHasPermission,
  PermissionError,
} from "@/lib/auth/permissions";
import { EventManagementNav } from "@/components/events/EventManagementNav";
import { EventStatusBadge } from "@/components/shared/StatusBadge";
import { db } from "@/lib/db";

interface EventLayoutProps {
  children: React.ReactNode;
  params: { id: string };
}

export default async function EventManagementLayout({
  children,
  params,
}: EventLayoutProps) {
  const session = await requireAuth();

  let eventCtx;
  try {
    eventCtx = await resolveEventContext(session.user.id, params.id);
  } catch (err) {
    if (err instanceof PermissionError) notFound();
    throw err;
  }

  // Must have at least some role in the event
  if (!eventCtx.effectiveRole && !eventCtx.isSuperAdmin) notFound();

  const event = await db.event.findUnique({
    where: { id: params.id },
    select: {
      title: true,
      slug: true,
      status: true,
      schoolName: true,
      graduationYear: true,
    },
  });
  if (!event) notFound();

  const navPermissions = {
    canViewAttendees: contextHasPermission(eventCtx, "attendees:read"),
    canCheckIn: contextHasPermission(eventCtx, "attendees:checkin"),
    canViewInvites: contextHasPermission(eventCtx, "invites:view"),
    canSendMessages: contextHasPermission(eventCtx, "messages:broadcast"),
    canModerateMemories: contextHasPermission(eventCtx, "memories:moderate"),
    canManageNominations: contextHasPermission(eventCtx, "nominations:manage"),
    canViewPayments: contextHasPermission(eventCtx, "payments:read"),
    canManageSettings: contextHasPermission(eventCtx, "settings:manage"),
    canManageCohort: contextHasPermission(eventCtx, "invites:manage"),
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <h1 className="font-display text-2xl font-bold text-slate-900 truncate max-w-xs md:max-w-md">
            {event.title}
          </h1>
          <EventStatusBadge status={event.status} />
        </div>
        <span className="text-sm text-slate-500 shrink-0">
          {event.schoolName} · {event.graduationYear}
        </span>
      </div>

      <EventManagementNav eventId={params.id} permissions={navPermissions} />

      <div className="min-h-0">{children}</div>
    </div>
  );
}
