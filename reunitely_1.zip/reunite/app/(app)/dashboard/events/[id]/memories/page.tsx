import { notFound } from "next/navigation";
import { Suspense } from "react";
import { requireAuth } from "@/lib/auth/session";
import { requireEventPermission, PermissionError } from "@/lib/auth/permissions";
import { PageHeader } from "@/components/shared/PageHeader";
import { MemoryModerationQueue } from "@/components/memories/MemoryModerationQueue";
import { Skeleton } from "@/components/ui/skeleton";

export const metadata = { title: "Memories" };

interface Props { params: { id: string } }

export default async function MemoriesPage({ params }: Props) {
  const session = await requireAuth();

  try {
    await requireEventPermission(session.user.id, params.id, "memories:moderate");
  } catch (err) {
    if (err instanceof PermissionError) notFound();
    throw err;
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Memories"
        description="Review and approve memories submitted by attendees."
      />
      <Suspense fallback={<Skeleton className="h-96 rounded-xl" />}>
        <MemoryModerationQueue eventId={params.id} />
      </Suspense>
    </div>
  );
}
