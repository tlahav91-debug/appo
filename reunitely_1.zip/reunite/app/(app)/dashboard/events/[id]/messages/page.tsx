import { notFound } from "next/navigation";
import { requireAuth } from "@/lib/auth/session";
import { requireEventPermission, PermissionError } from "@/lib/auth/permissions";
import { PageHeader } from "@/components/shared/PageHeader";
import { MessagingCenter } from "@/components/messaging/MessagingCenter";

export const metadata = { title: "Messages" };

interface Props { params: { id: string } }

export default async function MessagesPage({ params }: Props) {
  const session = await requireAuth();

  try {
    await requireEventPermission(session.user.id, params.id, "messages:broadcast");
  } catch (err) {
    if (err instanceof PermissionError) notFound();
    throw err;
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Messaging Center"
        description="Send emails, SMS, and in-app messages to your attendees."
      />
      <MessagingCenter eventId={params.id} />
    </div>
  );
}
