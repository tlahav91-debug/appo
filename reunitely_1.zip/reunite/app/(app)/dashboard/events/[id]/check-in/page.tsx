import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { requireAuth } from "@/lib/auth/session";
import { requireEventPermission, PermissionError } from "@/lib/auth/permissions";
import { Unauthorized } from "@/components/shared/Unauthorized";
import { CheckInDashboard } from "@/components/checkin/CheckInDashboard";
import { db } from "@/lib/db";

export async function generateMetadata({
  params,
}: {
  params: { id: string };
}): Promise<Metadata> {
  const event = await db.event.findUnique({
    where: { id: params.id },
    select: { title: true },
  });
  return {
    title: event ? `Check-in · ${event.title}` : "Check-in",
    // Prevent caching on mobile browsers on event day
    robots: { index: false },
  };
}

interface Props {
  params: { id: string };
}

export default async function CheckInPage({ params }: Props) {
  const session = await requireAuth();

  let eventCtx;
  try {
    eventCtx = await requireEventPermission(
      session.user.id,
      params.id,
      "attendees:checkin"
    );
  } catch (err) {
    if (err instanceof PermissionError) {
      if (err.code === "NOT_MEMBER" || err.code === "NOT_FOUND") notFound();
      return (
        <Unauthorized
          title="Organizer access required"
          message="Only organizers and committee members can access the check-in system."
        />
      );
    }
    throw err;
  }

  const event = await db.event.findUnique({
    where: { id: params.id },
    select: { id: true, title: true, startAt: true, status: true },
  });
  if (!event) notFound();

  return (
    // Full-viewport, no padding — the CheckInDashboard manages its own layout
    <div className="min-h-screen bg-slate-50">
      <CheckInDashboard eventId={event.id} eventTitle={event.title} />
    </div>
  );
}
