"use client";

import { useEffect } from "react";
import * as Sentry from "@sentry/nextjs";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

export default function DashboardError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    Sentry.captureException(error);
  }, [error]);

  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-red-50 mb-4">
        <AlertTriangle className="h-7 w-7 text-red-500" />
      </div>
      <h2 className="text-lg font-semibold text-slate-900">
        Something went wrong
      </h2>
      <p className="mt-2 text-sm text-slate-500 max-w-sm">
        This page encountered an error. We've been notified.
      </p>
      {error.digest && (
        <p className="mt-1 font-mono text-xs text-slate-300">
          {error.digest}
        </p>
      )}
      <Button onClick={reset} className="mt-6" size="sm">
        Try again
      </Button>
    </div>
  );
}
