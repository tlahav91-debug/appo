import { DashboardSidebar } from "@/components/layout/DashboardSidebar";
import { DashboardTopbar } from "@/components/layout/DashboardTopbar";
import { MobileNav } from "@/components/layout/MobileNav";
import { requireAuth } from "@/lib/auth/session";
import { db } from "@/lib/db";

export default async function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Redirects to /login if not authenticated — no manual redirect needed
  const session = await requireAuth();

  const organizerProfile = await db.organizerProfile.findUnique({
    where: { userId: session.user.id },
    select: { isVerifiedHost: true },
  });

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <DashboardSidebar
        isSuperAdmin={session.isSuperAdmin}
        isModerator={session.isModerator}
        isVerifiedHost={organizerProfile?.isVerifiedHost ?? false}
        userName={session.user.name}
        userAvatar={session.user.avatarUrl}
      />

      <div className="flex flex-1 flex-col overflow-hidden">
        <DashboardTopbar
          userName={session.user.name}
          userAvatar={session.user.avatarUrl}
          platformRole={session.platformRole}
        />

        <main
          id="main-content"
          className="flex-1 overflow-y-auto px-4 py-6 pb-24 md:px-6 lg:px-8 md:pb-6"
        >
          {children}
        </main>
      </div>

      <MobileNav isModerator={session.isModerator} />
    </div>
  );
}
