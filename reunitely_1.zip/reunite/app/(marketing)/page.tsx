import Link from "next/link";
import { ArrowRight, Calendar, Users, Image, MessageCircle, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MarketingNav } from "@/components/layout/MarketingNav";
import { MarketingFooter } from "@/components/layout/MarketingFooter";

export default function HomePage() {
  return (
    <>
      <MarketingNav />

      <div className="flex min-h-screen flex-col">
        {/* ─── Hero ──────────────────────────────────────────────────────── */}
        <section className="relative flex flex-col items-center justify-center overflow-hidden bg-gradient-to-b from-blue-50 to-background px-6 pb-24 pt-24 text-center md:pt-32">
          {/* Decorative background */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 overflow-hidden"
          >
            <div className="absolute -left-20 -top-20 h-96 w-96 rounded-full bg-blue-100/60 blur-3xl" />
            <div className="absolute -right-20 top-40 h-80 w-80 rounded-full bg-rose-100/40 blur-3xl" />
          </div>

          <div className="relative z-10 flex max-w-3xl flex-col items-center gap-6">
            <Badge
              variant="secondary"
              className="rounded-full border-blue-200 bg-blue-50 px-4 py-1 text-blue-700"
            >
              ✨ Built for real organizers
            </Badge>

            <h1 className="font-display text-4xl font-bold leading-tight text-slate-900 md:text-6xl">
              Your reunion,
              <br />
              <span className="text-blue-600">actually organized.</span>
            </h1>

            <p className="max-w-xl text-lg text-slate-600">
              Create a beautiful event page, invite classmates, collect RSVPs
              and payments — all in one place. No spreadsheets, no group chat
              chaos.
            </p>

            <div className="flex flex-col gap-3 sm:flex-row">
              <Button asChild size="lg" className="gap-2">
                <Link href="/signup">
                  Create Your Reunion
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link href="/events/demo">See a Demo Event</Link>
              </Button>
            </div>

            <p className="text-sm text-slate-500">
              Free to start · No credit card required
            </p>
          </div>
        </section>

        {/* ─── Social Proof Strip ────────────────────────────────────────── */}
        <section className="border-y border-border bg-background py-6">
          <div className="container flex flex-wrap items-center justify-center gap-x-12 gap-y-3 text-center text-sm text-slate-500">
            <span className="font-medium text-slate-700">
              Trusted by 1,200+ organizers
            </span>
            <span>•</span>
            <span>40+ countries</span>
            <span>•</span>
            <span>50,000+ RSVPs collected</span>
            <span>•</span>
            <span>⭐⭐⭐⭐⭐ 4.9/5 on average</span>
          </div>
        </section>

        {/* ─── Feature Highlights ────────────────────────────────────────── */}
        <section className="container py-24">
          <div className="mb-16 text-center">
            <h2 className="font-display text-3xl font-bold text-slate-900 md:text-4xl">
              Everything your reunion needs
            </h2>
            <p className="mt-4 text-slate-500">
              From the first invite to the final photo album.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((feature) => (
              <FeatureCard key={feature.title} {...feature} />
            ))}
          </div>
        </section>

        {/* ─── How it Works ──────────────────────────────────────────────── */}
        <section className="bg-slate-50 py-24">
          <div className="container">
            <div className="mb-16 text-center">
              <h2 className="font-display text-3xl font-bold text-slate-900 md:text-4xl">
                Up and running in minutes
              </h2>
            </div>

            <ol className="grid gap-8 md:grid-cols-3">
              {HOW_IT_WORKS.map((step, i) => (
                <li key={step.title} className="flex flex-col gap-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-500 font-display text-lg font-bold text-slate-900">
                    {i + 1}
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900">
                    {step.title}
                  </h3>
                  <p className="text-slate-600">{step.description}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* ─── CTA Banner ────────────────────────────────────────────────── */}
        <section className="container py-24">
          <div className="rounded-2xl bg-gradient-to-br from-blue-600 to-blue-700 p-12 text-center shadow-card-lg">
            <h2 className="font-display text-3xl font-bold text-slate-900 md:text-4xl">
              Ready to plan your reunion?
            </h2>
            <p className="mt-4 text-slate-800">
              Join thousands of organizers who've used Reunitely to bring their
              class back together.
            </p>
            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <Button
                asChild
                size="lg"
                className="bg-slate-900 text-white hover:bg-slate-800"
              >
                <Link href="/signup">Get Started for Free</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-slate-900/20 bg-transparent text-slate-900 hover:bg-blue-400"
              >
                <Link href="/pricing">See Pricing</Link>
              </Button>
            </div>
          </div>
        </section>
      </div>

      <MarketingFooter />
    </>
  );
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function FeatureCard({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col gap-4 rounded-xl border border-border bg-card p-6 shadow-card transition-shadow hover:shadow-card-hover">
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50">
        <Icon className="h-5 w-5 text-blue-600" />
      </div>
      <h3 className="text-lg font-semibold text-slate-900">{title}</h3>
      <p className="text-sm text-slate-600">{description}</p>
    </div>
  );
}

// ─── Static Data ─────────────────────────────────────────────────────────────

const FEATURES = [
  {
    icon: Calendar,
    title: "RSVPs & Payments",
    description:
      "Collect confirmations and ticket payments in one flow. No more Venmo chasing or manual tracking.",
  },
  {
    icon: Users,
    title: "Invite Management",
    description:
      "Send invites via email, SMS, or shareable link. Track who opened, who RSVP'd, who's pending.",
  },
  {
    icon: Image,
    title: "Memory Wall",
    description:
      "Upload old photos, share memories before and after the event. Build your class archive.",
  },
  {
    icon: MessageCircle,
    title: "Event Chat",
    description:
      "Keep everyone in the loop with an event-scoped chat room. No more group chat chaos.",
  },
  {
    icon: Star,
    title: "Class Nominations",
    description:
      "Run 'Most Likely To' votes with full consent from nominees. Reveal results at the event.",
  },
  {
    icon: Users,
    title: "Organizer CRM",
    description:
      "See every attendee in one table. Filter, message, export, check in. You're in control.",
  },
];

const HOW_IT_WORKS = [
  {
    title: "Create your event page",
    description:
      "Set your school, year, venue, and ticket options in a 5-step wizard. Takes under 5 minutes.",
  },
  {
    title: "Invite your classmates",
    description:
      "Share a link, send emails, or blast an SMS. Classmates RSVP and pay without leaving the page.",
  },
  {
    title: "Show up and enjoy",
    description:
      "Use the check-in tool, run the memory wall, reveal nominations. Reunitely handles the logistics.",
  },
];
