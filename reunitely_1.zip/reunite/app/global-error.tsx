"use client";

import { useEffect } from "react";
import * as Sentry from "@sentry/nextjs";
import { Button } from "@/components/ui/button";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    Sentry.captureException(error);
  }, [error]);

  return (
    <html lang="en">
      <body className="bg-slate-50">
        <div className="flex min-h-screen flex-col items-center justify-center px-4">
          <div className="w-full max-w-md text-center">
            <div className="mb-4 text-6xl">⚠️</div>
            <h1 className="font-display text-2xl font-bold text-slate-900">
              Something went wrong
            </h1>
            <p className="mt-3 text-slate-500">
              An unexpected error occurred. We've been notified and are looking
              into it.
            </p>
            {error.digest && (
              <p className="mt-2 font-mono text-xs text-slate-400">
                Error ID: {error.digest}
              </p>
            )}
            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <Button onClick={reset}>Try Again</Button>
              <Button variant="outline" asChild>
                <a href="/">Go Home</a>
              </Button>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}
