import type { Metadata, Viewport } from "next";
import { ClerkProvider } from "@clerk/nextjs";
import { Toaster } from "sonner";
import { QueryProvider } from "@/components/providers/QueryProvider";
import { PostHogProvider } from "@/components/providers/PostHogProvider";
import { ThemeProvider } from "@/components/providers/ThemeProvider";
import { Analytics } from "@/components/providers/Analytics";
import "@/app/globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_APP_URL ?? "https://reunitely.app"
  ),
  title: {
    default: "Reunitely — School Reunion Platform",
    template: "%s | Reunitely",
  },
  description:
    "Create a beautiful event page, invite classmates, collect RSVPs and payments — all in one place.",
  keywords: [
    "school reunion",
    "class reunion",
    "alumni",
    "event planning",
    "RSVP",
    "reunion organizer",
  ],
  authors: [{ name: "Reunitely" }],
  creator: "Reunitely",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "/",
    title: "Reunitely — School Reunion Platform",
    description: "Your reunion, actually organized.",
    siteName: "Reunitely",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Reunitely — School Reunion Platform",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Reunitely — School Reunion Platform",
    description: "Your reunion, actually organized.",
    images: ["/og-image.png"],
    creator: "@reuniteapp",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180" }],
  },
  manifest: "/site.webmanifest",
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#F8FAFC" },
    { media: "(prefers-color-scheme: dark)", color: "#0F172A" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ClerkProvider>
      <html lang="en" suppressHydrationWarning>
        <body>
          <ThemeProvider
            attribute="data-theme"
            defaultTheme="light"
            enableSystem
            disableTransitionOnChange
          >
            <QueryProvider>
              <PostHogProvider>
                {/* Skip to content for accessibility */}
                <a
                  href="#main-content"
                  className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
                >
                  Skip to content
                </a>

                <main id="main-content">{children}</main>

                {/* Global toast notifications */}
                <Toaster
                  position="top-right"
                  toastOptions={{
                    duration: 4000,
                    classNames: {
                      toast:
                        "font-sans text-sm rounded-lg border border-border shadow-card-hover",
                      title: "font-semibold",
                    },
                  }}
                  richColors
                  closeButton
                />

                {/* PostHog page view tracking */}
                <Analytics />
              </PostHogProvider>
            </QueryProvider>
          </ThemeProvider>
        </body>
      </html>
    </ClerkProvider>
  );
}
