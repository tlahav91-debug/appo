import { redirect } from "next/navigation";
import { auth } from "@clerk/nextjs/server";
import type { Metadata } from "next";
import Link from "next/link";
import { CalendarDays, MapPin, Users, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { validateInviteToken } from "@/lib/auth/permissions";
import { db } from "@/lib/db";
import { formatEventDate, formatEventTime } from "@/lib/utils";

export const metadata: Metadata = {
  title: "You're Invited — Reunitely",
  robots: { index: false },
};

interface Props {
  params: { token: string };
}

export default async function InviteLandingPage({ params }: Props) {
  const validation = await validateInviteToken(params.token);

  if (validation.expired) {
    return (
      <ErrorScreen
        emoji="⏰"
        title="Invite expired"
        message="This invite link has expired. Contact the event organizer for a new one."
      />
    );
  }

  if (validation.alreadyUsed) {
    return (
      <ErrorScreen
        emoji="✅"
        title="Already RSVP'd"
        message="This invite has already been used. Sign in to view your event details."
        cta={{ label: "Sign In", href: "/login" }}
      />
    );
  }

  if (!validation.valid || !validation.invite) {
    return (
      <ErrorScreen
        emoji="⚠️"
        title="Invalid invite"
        message="This invite link is not valid. It may have been revoked or doesn't exist."
      />
    );
  }

  const { invite } = validation;

  const event = await db.event.findUnique({
    where: { id: invite.eventId },
    select: {
      id: true,
      slug: true,
      title: true,
      status: true,
      startAt: true,
      timezone: true,
      venueName: true,
      schoolName: true,
      graduationYear: true,
      coverImageUrl: true,
      createdBy: { select: { name: true } },
      _count: {
        select: {
          rsvps: { where: { status: { in: ["CONFIRMED"] } } },
        },
      },
    },
  });

  if (!event || event.status === "ARCHIVED" || event.status === "DRAFT") {
    return (
      <ErrorScreen
        emoji="🚫"
        title="Event not available"
        message="This event is no longer accepting RSVPs."
      />
    );
  }

  // Mark opened (fire and forget)
  db.invite
    .updateMany({
      where: { token: params.token, openedAt: null },
      data: { openedAt: new Date(), status: "OPENED" },
    })
    .catch(console.error);

  // Already authenticated → redirect straight to RSVP
  const { userId } = auth();
  if (userId) {
    redirect(`/events/${event.slug}/rsvp?invite=${params.token}`);
  }

  const rsvpUrl = `/events/${event.slug}/rsvp?invite=${params.token}`;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-slate-50 px-4 py-12">
      <Link href="/" className="mb-8 font-display text-2xl font-bold text-slate-900">
        <span className="text-blue-500">Re</span>Unite
      </Link>

      <div className="w-full max-w-md">
        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-card-lg">
          {event.coverImageUrl && (
            <div className="relative h-36 overflow-hidden bg-blue-100">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={event.coverImageUrl}
                alt=""
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
            </div>
          )}

          <div className="p-6">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-100 px-3 py-1 text-xs font-semibold text-blue-800 mb-3">
              🎉 You&apos;ve been invited
            </span>

            <h1 className="font-display text-xl font-bold text-slate-900">{event.title}</h1>
            <p className="mt-0.5 text-sm text-slate-500">
              {event.schoolName} · Class of {event.graduationYear}
            </p>

            <div className="mt-4 flex flex-col gap-2 text-sm text-slate-600">
              <span className="flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-blue-500 shrink-0" />
                {formatEventDate(event.startAt, event.timezone)}
              </span>
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-blue-500 shrink-0" />
                {formatEventTime(event.startAt, event.timezone)}
              </span>
              {event.venueName && (
                <span className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-blue-500 shrink-0" />
                  {event.venueName}
                </span>
              )}
              <span className="flex items-center gap-2">
                <Users className="h-4 w-4 text-blue-500 shrink-0" />
                <strong className="text-slate-900">{event._count.rsvps}</strong>&nbsp;confirmed
              </span>
            </div>
          </div>

          <div className="border-t border-border bg-slate-50 p-6">
            <p className="mb-4 text-center text-sm text-slate-600">
              Create a free account or sign in to RSVP.
            </p>
            <div className="flex flex-col gap-2">
              <Button asChild className="w-full">
                <Link href={`/signup?redirect_url=${encodeURIComponent(rsvpUrl)}&invite=${params.token}`}>
                  Create Account & RSVP
                </Link>
              </Button>
              <Button asChild variant="outline" className="w-full">
                <Link href={`/login?redirect_url=${encodeURIComponent(rsvpUrl)}`}>
                  Sign In
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <p className="mt-4 text-center text-xs text-slate-400">
          Organized by {event.createdBy.name} · Powered by Reunitely
        </p>
      </div>
    </div>
  );
}

function ErrorScreen({
  emoji,
  title,
  message,
  cta,
}: {
  emoji: string;
  title: string;
  message: string;
  cta?: { label: string; href: string };
}) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-sm text-center">
        <p className="text-5xl mb-4">{emoji}</p>
        <h1 className="font-display text-2xl font-bold text-slate-900">{title}</h1>
        <p className="mt-2 text-slate-500">{message}</p>
        {cta && (
          <Button asChild className="mt-6">
            <Link href={cta.href}>{cta.label}</Link>
          </Button>
        )}
        <p className="mt-4">
          <Link href="/" className="text-sm text-slate-400 hover:text-slate-600">
            ← Back to Reunitely
          </Link>
        </p>
      </div>
    </div>
  );
}
