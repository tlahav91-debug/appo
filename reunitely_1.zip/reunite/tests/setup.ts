import "@testing-library/jest-dom";
import { vi } from "vitest";

// Mock Next.js navigation
vi.mock("next/navigation", () => ({
  useRouter: () => ({
    push: vi.fn(),
    replace: vi.fn(),
    prefetch: vi.fn(),
    back: vi.fn(),
  }),
  usePathname: () => "/",
  useSearchParams: () => new URLSearchParams(),
  redirect: vi.fn(),
  notFound: vi.fn(),
}));

// Mock Clerk
vi.mock("@clerk/nextjs", () => ({
  auth: () => ({ userId: "test_user_id" }),
  useUser: () => ({ user: { id: "test_user_id" }, isLoaded: true }),
  useAuth: () => ({ userId: "test_user_id", isLoaded: true }),
  ClerkProvider: ({ children }: { children: React.ReactNode }) => children,
  UserButton: () => null,
}));

vi.mock("@clerk/nextjs/server", () => ({
  auth: () => ({ userId: "test_user_id" }),
  currentUser: () => Promise.resolve({ id: "test_user_id" }),
}));

// Suppress console.error in tests unless explicitly testing it
const originalConsoleError = console.error;
beforeEach(() => {
  console.error = vi.fn();
});
afterEach(() => {
  console.error = originalConsoleError;
  vi.clearAllMocks();
});
