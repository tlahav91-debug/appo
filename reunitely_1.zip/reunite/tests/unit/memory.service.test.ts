import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── Mocks ────────────────────────────────────────────────────────────────────

const mockPost = {
  id: "post-1",
  eventId: "event-1",
  authorId: "user-1",
  type: "PHOTO" as const,
  caption: "Great times!",
  status: "APPROVED" as const,
  isFeatured: false,
  likeCount: 0,
  commentCount: 0,
  reportCount: 0,
  yearContext: 2005,
  contextLabel: "Prom",
  videoEmbedUrl: null,
  flaggedAt: null,
  createdAt: new Date("2024-01-15"),
};

const mockDb = {
  memoryPost: {
    findUnique: vi.fn(),
    findMany: vi.fn(),
    create: vi.fn().mockResolvedValue(mockPost),
    update: vi.fn().mockResolvedValue(mockPost),
    count: vi.fn().mockResolvedValue(0),
  },
  memoryReaction: {
    findUnique: vi.fn(),
    create: vi.fn(),
    delete: vi.fn(),
    groupBy: vi.fn().mockResolvedValue([]),
    count: vi.fn().mockResolvedValue(0),
  },
  memoryComment: {
    create: vi.fn(),
    findMany: vi.fn().mockResolvedValue([]),
    count: vi.fn().mockResolvedValue(0),
  },
  mediaAsset: {
    updateMany: vi.fn().mockResolvedValue({ count: 0 }),
    findMany: vi.fn().mockResolvedValue([]),
  },
  rSVP: {
    findFirst: vi.fn().mockResolvedValue({ status: "CONFIRMED" }),
  },
  event: {
    findUnique: vi.fn().mockResolvedValue({
      id: "event-1",
      settings: { memoriesAutoApprove: true },
    }),
  },
  attendeeProfile: {
    findMany: vi.fn().mockResolvedValue([]),
  },
  memoryPostTag: {
    createMany: vi.fn(),
  },
  committeeMember: {
    findMany: vi.fn().mockResolvedValue([]),
    findUnique: vi.fn().mockResolvedValue(null),
  },
  $transaction: vi.fn((fn: Function) => fn(mockDb)),
};

vi.mock("@/lib/db", () => ({ db: mockDb }));
vi.mock("@/lib/audit/log", () => ({ auditLog: vi.fn() }));
vi.mock("@/lib/services/notification.service", () => ({
  createNotification: vi.fn(),
  notifyEventOrganizers: vi.fn(),
}));

import {
  createMemory,
  toggleReaction,
  addComment,
  reportMemory,
} from "@/lib/services/memory.service";

// ─── createMemory ─────────────────────────────────────────────────────────────

describe("createMemory", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockDb.event.findUnique.mockResolvedValue({
      id: "event-1",
      settings: { memoriesAutoApprove: true },
    });
    mockDb.rSVP.findFirst.mockResolvedValue({ status: "CONFIRMED" });
    mockDb.committeeMember.findUnique.mockResolvedValue(null);
    mockDb.memoryPost.create.mockResolvedValue(mockPost);
    mockDb.mediaAsset.updateMany.mockResolvedValue({ count: 1 });
    mockDb.attendeeProfile.findMany.mockResolvedValue([]);
    mockDb.committeeMember.findMany.mockResolvedValue([]);
  });

  it("throws UNAUTHORIZED if user has no RSVP and is not committee", async () => {
    mockDb.rSVP.findFirst.mockResolvedValue(null);
    mockDb.committeeMember.findUnique.mockResolvedValue(null);

    await expect(
      createMemory("event-1", "user-no-rsvp", {
        type: "TEXT",
        caption: "Hello",
        s3Keys: [],
        taggedUserIds: [],
      })
    ).rejects.toThrow(/UNAUTHORIZED/);
  });

  it("sets status APPROVED when memoriesAutoApprove is true", async () => {
    await createMemory("event-1", "user-1", {
      type: "TEXT",
      caption: "My memory",
      s3Keys: [],
      taggedUserIds: [],
    });

    expect(mockDb.memoryPost.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "APPROVED" }),
      })
    );
  });

  it("sets status PENDING when memoriesAutoApprove is false", async () => {
    mockDb.event.findUnique.mockResolvedValue({
      id: "event-1",
      settings: { memoriesAutoApprove: false },
    });

    await createMemory("event-1", "user-1", {
      type: "TEXT",
      caption: "My memory",
      s3Keys: [],
      taggedUserIds: [],
    });

    expect(mockDb.memoryPost.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: "PENDING" }),
      })
    );
  });

  it("links s3Keys via mediaAsset.updateMany with READY status", async () => {
    const s3Key = "events/memories/user-1/abc123.jpg";
    await createMemory("event-1", "user-1", {
      type: "PHOTO",
      caption: "Look at this",
      s3Keys: [s3Key],
      taggedUserIds: [],
    });

    expect(mockDb.mediaAsset.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          s3Key: { in: [s3Key] },
          uploadedById: "user-1",
        }),
        data: expect.objectContaining({ status: "READY" }),
      })
    );
  });

  it("skips mediaAsset.updateMany when no s3Keys provided", async () => {
    await createMemory("event-1", "user-1", {
      type: "TEXT",
      caption: "Just text",
      s3Keys: [],
      taggedUserIds: [],
    });

    expect(mockDb.mediaAsset.updateMany).not.toHaveBeenCalled();
  });

  it("returns the created post", async () => {
    const result = await createMemory("event-1", "user-1", {
      type: "TEXT",
      caption: "My memory",
      s3Keys: [],
      taggedUserIds: [],
    });

    expect(result).toMatchObject({ id: "post-1", status: "APPROVED" });
  });
});

// ─── toggleReaction ───────────────────────────────────────────────────────────

describe("toggleReaction", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockDb.memoryPost.update.mockResolvedValue({ ...mockPost, likeCount: 1 });
    mockDb.memoryReaction.count.mockResolvedValue(1);
  });

  it("creates reaction when none exists → returns added: true", async () => {
    mockDb.memoryReaction.findUnique.mockResolvedValue(null);
    mockDb.memoryReaction.create.mockResolvedValue({
      id: "r-1",
      emoji: "❤️",
      memoryPostId: "post-1",
      userId: "user-1",
    });

    const result = await toggleReaction("post-1", "user-1", "❤️");

    expect(mockDb.memoryReaction.create).toHaveBeenCalled();
    expect(result.added).toBe(true);
  });

  it("deletes reaction when same emoji exists → returns added: false", async () => {
    mockDb.memoryReaction.findUnique.mockResolvedValue({
      id: "r-1",
      emoji: "❤️",
      userId: "user-1",
      memoryPostId: "post-1",
    });
    mockDb.memoryPost.update.mockResolvedValue({ ...mockPost, likeCount: 0 });
    mockDb.memoryReaction.count.mockResolvedValue(0);

    const result = await toggleReaction("post-1", "user-1", "❤️");

    expect(mockDb.memoryReaction.delete).toHaveBeenCalledWith({
      where: { id: "r-1" },
    });
    expect(result.added).toBe(false);
  });

  it("returns totalCount reflecting new reaction count", async () => {
    mockDb.memoryReaction.findUnique.mockResolvedValue(null);
    mockDb.memoryReaction.create.mockResolvedValue({ id: "r-2", emoji: "🔥" });
    mockDb.memoryReaction.count.mockResolvedValue(5);
    mockDb.memoryPost.update.mockResolvedValue({ ...mockPost, likeCount: 5 });

    const result = await toggleReaction("post-1", "user-1", "🔥");

    expect(result.totalCount).toBe(5);
  });
});

// ─── addComment ───────────────────────────────────────────────────────────────

describe("addComment", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockDb.memoryComment.create.mockResolvedValue({
      id: "c-1",
      content: "Great photo!",
      memoryPostId: "post-1",
      authorId: "user-2",
      createdAt: new Date(),
    });
    mockDb.memoryPost.update.mockResolvedValue({
      ...mockPost,
      commentCount: 1,
    });
  });

  it("creates comment with correct fields", async () => {
    await addComment("post-1", "user-2", "Great photo!");

    expect(mockDb.memoryComment.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          memoryPostId: "post-1",
          authorId: "user-2",
          content: "Great photo!",
        }),
      })
    );
  });

  it("increments commentCount on the post", async () => {
    await addComment("post-1", "user-2", "Great photo!");

    expect(mockDb.memoryPost.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: { commentCount: { increment: 1 } },
      })
    );
  });

  it("returns the created comment id", async () => {
    const result = await addComment("post-1", "user-2", "Great photo!");
    expect(result).toMatchObject({ id: "c-1" });
  });

  it("supports threaded replies via parentId", async () => {
    await addComment("post-1", "user-2", "Reply!", "parent-comment-1");

    expect(mockDb.memoryComment.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          parentId: "parent-comment-1",
        }),
      })
    );
  });
});

// ─── reportMemory ─────────────────────────────────────────────────────────────

describe("reportMemory", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockDb.memoryPost.update.mockResolvedValue({
      ...mockPost,
      reportCount: 1,
      flaggedAt: new Date(),
    });
  });

  it("increments reportCount and sets flaggedAt", async () => {
    await reportMemory("post-1", "user-reporter", "INAPPROPRIATE");

    expect(mockDb.memoryPost.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          reportCount: { increment: 1 },
          flaggedAt: expect.any(Date),
        }),
      })
    );
  });

  it("creates an audit log entry with the reason", async () => {
    const { auditLog } = await import("@/lib/audit/log");
    await reportMemory("post-1", "user-reporter", "SPAM");

    expect(auditLog).toHaveBeenCalledWith(
      expect.objectContaining({
        actorId: "user-reporter",
        action: "MEMORY_REPORTED",
        metadata: expect.objectContaining({ reason: "SPAM" }),
      })
    );
  });
});
