import { describe, it, expect } from "vitest";
import {
  cn,
  generateSlug,
  formatCurrency,
  centsToFloat,
  floatToCents,
  truncate,
  getInitials,
  pluralize,
  isValidEmail,
  isValidE164Phone,
  isDefined,
  groupBy,
  chunk,
  pick,
  omit,
} from "@/lib/utils";

describe("cn", () => {
  it("merges class names correctly", () => {
    expect(cn("foo", "bar")).toBe("foo bar");
    expect(cn("px-2 py-1", "px-4")).toBe("py-1 px-4"); // tailwind-merge deduplication
    expect(cn(undefined, null, "foo")).toBe("foo");
    expect(cn(false && "hidden", "block")).toBe("block");
  });
});

describe("generateSlug", () => {
  it("lowercases and removes special chars", () => {
    expect(generateSlug("Central High School")).toBe("central-high-school");
    expect(generateSlug("Class of 2015!")).toBe("class-of-2015");
    expect(generateSlug("  spaces  ")).toBe("spaces");
  });
});

describe("formatCurrency", () => {
  it("formats cents to USD string", () => {
    expect(formatCurrency(1000)).toBe("$10");
    expect(formatCurrency(2999)).toBe("$29.99");
    expect(formatCurrency(0)).toBe("$0");
  });

  it("handles other currencies", () => {
    expect(formatCurrency(1000, "EUR")).toBe("€10");
    expect(formatCurrency(1000, "GBP")).toBe("£10");
  });
});

describe("centsToFloat / floatToCents", () => {
  it("converts correctly", () => {
    expect(centsToFloat(1999)).toBe(19.99);
    expect(floatToCents(19.99)).toBe(1999);
    expect(floatToCents(0)).toBe(0);
  });

  it("handles floating point precision", () => {
    expect(floatToCents(1.005)).toBe(101); // rounding
  });
});

describe("truncate", () => {
  it("truncates long strings", () => {
    expect(truncate("hello world", 5)).toBe("he...");
    expect(truncate("short", 10)).toBe("short");
    expect(truncate("exactly ten", 11)).toBe("exactly ten");
  });
});

describe("getInitials", () => {
  it("extracts initials from name", () => {
    expect(getInitials("Maya Chen")).toBe("MC");
    expect(getInitials("James")).toBe("J");
    expect(getInitials("First Middle Last")).toBe("FM"); // max 2
  });
});

describe("pluralize", () => {
  it("returns singular for count of 1", () => {
    expect(pluralize(1, "attendee")).toBe("1 attendee");
    expect(pluralize(0, "attendee")).toBe("0 attendees");
    expect(pluralize(5, "attendee")).toBe("5 attendees");
  });

  it("uses custom plural form", () => {
    expect(pluralize(2, "person", "people")).toBe("2 people");
  });
});

describe("isValidEmail", () => {
  it("validates email addresses", () => {
    expect(isValidEmail("user@example.com")).toBe(true);
    expect(isValidEmail("user+tag@sub.domain.co")).toBe(true);
    expect(isValidEmail("not-an-email")).toBe(false);
    expect(isValidEmail("@missing-local.com")).toBe(false);
    expect(isValidEmail("missing-domain@")).toBe(false);
    expect(isValidEmail("")).toBe(false);
  });
});

describe("isValidE164Phone", () => {
  it("validates E.164 phone numbers", () => {
    expect(isValidE164Phone("+15551234567")).toBe(true);
    expect(isValidE164Phone("+447700900000")).toBe(true);
    expect(isValidE164Phone("5551234567")).toBe(false); // missing +
    expect(isValidE164Phone("+1")).toBe(false); // too short
    expect(isValidE164Phone("+123456789012345678")).toBe(false); // too long
  });
});

describe("isDefined", () => {
  it("returns true for non-null/undefined", () => {
    expect(isDefined("hello")).toBe(true);
    expect(isDefined(0)).toBe(true);
    expect(isDefined(false)).toBe(true);
    expect(isDefined(null)).toBe(false);
    expect(isDefined(undefined)).toBe(false);
  });
});

describe("groupBy", () => {
  it("groups array items by key function", () => {
    const items = [
      { id: 1, status: "CONFIRMED" },
      { id: 2, status: "PENDING" },
      { id: 3, status: "CONFIRMED" },
    ];
    const grouped = groupBy(items, (item) => item.status);
    expect(grouped["CONFIRMED"]).toHaveLength(2);
    expect(grouped["PENDING"]).toHaveLength(1);
  });
});

describe("chunk", () => {
  it("splits array into chunks of given size", () => {
    expect(chunk([1, 2, 3, 4, 5], 2)).toEqual([[1, 2], [3, 4], [5]]);
    expect(chunk([], 3)).toEqual([]);
    expect(chunk([1, 2, 3], 5)).toEqual([[1, 2, 3]]);
  });
});

describe("pick", () => {
  it("picks only specified keys", () => {
    const obj = { a: 1, b: 2, c: 3 };
    expect(pick(obj, ["a", "c"])).toEqual({ a: 1, c: 3 });
  });
});

describe("omit", () => {
  it("omits specified keys", () => {
    const obj = { a: 1, b: 2, c: 3 };
    expect(omit(obj, ["b"])).toEqual({ a: 1, c: 3 });
  });
});
