import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── Mock all external deps ───────────────────────────────────────────────────

const mockDb = {
  rSVP: {
    findUnique: vi.fn(),
    findFirst: vi.fn(),
    findMany: vi.fn(),
    create: vi.fn(),
    update: vi.fn(),
    updateMany: vi.fn(),
    count: vi.fn(),
    upsert: vi.fn(),
  },
  event: {
    findUnique: vi.fn(),
    findUniqueOrThrow: vi.fn(),
  },
  checkIn: {
    upsert: vi.fn(),
  },
  attendeeProfile: {
    upsert: vi.fn(),
  },
  consentRecord: {
    createMany: vi.fn(),
  },
  $transaction: vi.fn((fn: (tx: typeof mockDb) => unknown) => fn(mockDb)),
};

vi.mock("@/lib/db", () => ({ db: mockDb }));
vi.mock("@/lib/audit/log", () => ({ auditLog: vi.fn() }));
vi.mock("@/lib/cache/redis", () => ({
  cacheDelete: vi.fn(),
  cacheKeys: { eventDashboard: (id: string) => `dashboard:${id}` },
}));
vi.mock("@/lib/services/consent.service", () => ({ logConsent: vi.fn() }));
vi.mock("@/lib/email", () => ({
  sendRsvpConfirmation: vi.fn(),
  sendWaitlistPromoted: vi.fn(),
}));
vi.mock("@/lib/services/notification.service", () => ({
  createNotification: vi.fn(),
  notifyEventOrganizers: vi.fn(),
}));

import { promoteFromWaitlist } from "@/lib/services/rsvp.service";

// ─── promoteFromWaitlist ──────────────────────────────────────────────────────

describe("promoteFromWaitlist", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("does nothing if event has no capacity", async () => {
    mockDb.event.findUnique.mockResolvedValue({
      capacity: null,
      waitlistEnabled: true,
      title: "Test Reunion",
      slug: "test-reunion",
      schoolName: "Test High",
      graduationYear: 2005,
      startAt: new Date(),
      timezone: "UTC",
    });

    await promoteFromWaitlist("event-1");

    expect(mockDb.rSVP.count).not.toHaveBeenCalled();
    expect(mockDb.rSVP.update).not.toHaveBeenCalled();
  });

  it("does nothing if waitlist is disabled", async () => {
    mockDb.event.findUnique.mockResolvedValue({
      capacity: 100,
      waitlistEnabled: false,
      title: "Test Reunion",
      slug: "test-reunion",
      schoolName: "Test High",
      graduationYear: 2005,
      startAt: new Date(),
      timezone: "UTC",
    });

    await promoteFromWaitlist("event-1");

    expect(mockDb.rSVP.count).not.toHaveBeenCalled();
  });

  it("does nothing if event is at capacity", async () => {
    mockDb.event.findUnique.mockResolvedValue({
      capacity: 50,
      waitlistEnabled: true,
      title: "Test Reunion",
      slug: "test-reunion",
      schoolName: "Test High",
      graduationYear: 2005,
      startAt: new Date(),
      timezone: "UTC",
    });
    mockDb.rSVP.count.mockResolvedValue(50); // at capacity

    await promoteFromWaitlist("event-1");

    expect(mockDb.rSVP.findFirst).not.toHaveBeenCalled();
    expect(mockDb.rSVP.update).not.toHaveBeenCalled();
  });

  it("does nothing if waitlist is empty", async () => {
    mockDb.event.findUnique.mockResolvedValue({
      capacity: 100,
      waitlistEnabled: true,
      title: "Test Reunion",
      slug: "test-reunion",
      schoolName: "Test High",
      graduationYear: 2005,
      startAt: new Date(),
      timezone: "UTC",
    });
    mockDb.rSVP.count.mockResolvedValue(40); // under capacity
    mockDb.rSVP.findFirst.mockResolvedValue(null); // no waitlisted

    await promoteFromWaitlist("event-1");

    expect(mockDb.rSVP.update).not.toHaveBeenCalled();
  });

  it("promotes first waitlisted person when space opens", async () => {
    const startAt = new Date("2025-09-15T18:00:00Z");
    mockDb.event.findUnique.mockResolvedValue({
      capacity: 100,
      waitlistEnabled: true,
      title: "Lincoln High Reunion",
      slug: "lincoln-high-2005",
      schoolName: "Lincoln High",
      graduationYear: 2005,
      startAt,
      timezone: "America/Los_Angeles",
    });
    mockDb.rSVP.count.mockResolvedValue(99); // one spot open
    mockDb.rSVP.findFirst.mockResolvedValue({
      id: "rsvp-waitlisted-1",
      userId: "user-123",
      user: { id: "user-123", email: "jane@example.com", name: "Jane Smith" },
    });

    await promoteFromWaitlist("event-1");

    expect(mockDb.rSVP.update).toHaveBeenCalledWith({
      where: { id: "rsvp-waitlisted-1" },
      data: expect.objectContaining({
        status: "CONFIRMED",
        previousStatus: "WAITLISTED",
        waitlistPosition: null,
      }),
    });
  });

  it("uses FIFO ordering (orderBy submittedAt asc)", async () => {
    mockDb.event.findUnique.mockResolvedValue({
      capacity: 10,
      waitlistEnabled: true,
      title: "Test",
      slug: "test",
      schoolName: "Test",
      graduationYear: 2000,
      startAt: new Date(),
      timezone: "UTC",
    });
    mockDb.rSVP.count.mockResolvedValue(9);
    mockDb.rSVP.findFirst.mockResolvedValue({
      id: "rsvp-1",
      userId: "user-1",
      user: { id: "user-1", email: "a@b.com", name: "A" },
    });

    await promoteFromWaitlist("event-1");

    expect(mockDb.rSVP.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { eventId: "event-1", status: "WAITLISTED" },
        orderBy: { submittedAt: "asc" },
      })
    );
  });
});
