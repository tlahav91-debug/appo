import { describe, it, expect, vi, beforeEach } from "vitest";

const mockDb = {
  broadcast: {
    findUnique: vi.fn(),
    update: vi.fn(),
  },
  rSVP: {
    findMany: vi.fn(),
  },
  user: {
    findMany: vi.fn(),
  },
  committeeMember: {
    findUnique: vi.fn(),
  },
};

vi.mock("@/lib/db", () => ({ db: mockDb }));
vi.mock("@/lib/audit/log", () => ({ auditLog: vi.fn() }));
vi.mock("@/lib/auth/permissions", () => ({
  requireEventPermission: vi.fn().mockResolvedValue({ role: "ORGANIZER" }),
}));
vi.mock("@/lib/email", () => ({ sendEmailBatch: vi.fn().mockResolvedValue({ sent: 3, failed: 0 }) }));
vi.mock("@/lib/sms/twilio", () => ({
  sendSmsBatch: vi.fn().mockResolvedValue({ sent: 2, failed: 0, errors: [] }),
}));
vi.mock("@/env", () => ({
  getEnv: () => ({ TWILIO_WHATSAPP_FROM: undefined }),
}));

describe("broadcast channel routing", () => {
  beforeEach(() => vi.clearAllMocks());

  it("routes EMAIL broadcast to sendEmailBatch", async () => {
    const { sendEmailBatch } = await import("@/lib/email");

    mockDb.broadcast.findUnique.mockResolvedValue({
      id: "bc-1",
      eventId: "ev-1",
      status: "PENDING",
      channel: "EMAIL",
      subject: "See you soon!",
      body: { type: "doc", content: [{ type: "paragraph", content: [{ type: "text", text: "Hello!" }] }] },
      targetAudience: "ALL_CONFIRMED",
    });

    mockDb.rSVP.findMany.mockResolvedValue([
      { userId: "u1", user: { id: "u1", email: "a@b.com", name: "A" } },
      { userId: "u2", user: { id: "u2", email: "c@d.com", name: "C" } },
    ]);

    const { sendBroadcast } = await import("@/lib/services/broadcast.service");
    await sendBroadcast("bc-1", "organizer-1");

    expect(sendEmailBatch).toHaveBeenCalledWith(
      expect.arrayContaining([
        expect.objectContaining({ to: "a@b.com", subject: "See you soon!" }),
        expect.objectContaining({ to: "c@d.com" }),
      ])
    );
  });

  it("routes SMS broadcast to sendSmsBatch with user phone numbers", async () => {
    const { sendSmsBatch } = await import("@/lib/sms/twilio");

    mockDb.broadcast.findUnique.mockResolvedValue({
      id: "bc-2",
      eventId: "ev-1",
      status: "PENDING",
      channel: "SMS",
      subject: null,
      body: { type: "doc", content: [{ type: "paragraph", content: [{ type: "text", text: "Reminder!" }] }] },
      targetAudience: "ALL_CONFIRMED",
    });

    mockDb.rSVP.findMany.mockResolvedValue([
      { userId: "u1", user: { id: "u1", email: "a@b.com", name: "A" } },
    ]);

    mockDb.user.findMany.mockResolvedValue([
      { id: "u1", phone: "+14155551234" },
    ]);

    const { sendBroadcast } = await import("@/lib/services/broadcast.service");
    await sendBroadcast("bc-2", "organizer-1");

    expect(sendSmsBatch).toHaveBeenCalledWith(
      expect.arrayContaining([
        expect.objectContaining({ to: "+14155551234", body: expect.any(String) }),
      ])
    );
  });

  it("marks broadcast SENT with correct recipientCount", async () => {
    mockDb.broadcast.findUnique.mockResolvedValue({
      id: "bc-3",
      eventId: "ev-1",
      status: "PENDING",
      channel: "EMAIL",
      subject: "Hi",
      body: { type: "doc", content: [] },
      targetAudience: "ALL_CONFIRMED",
    });
    mockDb.rSVP.findMany.mockResolvedValue([
      { userId: "u1", user: { id: "u1", email: "a@b.com", name: "A" } },
      { userId: "u2", user: { id: "u2", email: "c@d.com", name: "C" } },
      { userId: "u3", user: { id: "u3", email: "e@f.com", name: "E" } },
    ]);

    const { sendBroadcast } = await import("@/lib/services/broadcast.service");
    await sendBroadcast("bc-3", "organizer-1");

    expect(mockDb.broadcast.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          status: "SENT",
          recipientCount: 3,
        }),
      })
    );
  });

  it("marks broadcast FAILED and rethrows on error", async () => {
    mockDb.broadcast.findUnique.mockResolvedValue({
      id: "bc-4",
      eventId: "ev-1",
      status: "PENDING",
      channel: "EMAIL",
      subject: "Hi",
      body: {},
      targetAudience: "ALL_CONFIRMED",
    });
    mockDb.rSVP.findMany.mockRejectedValue(new Error("DB timeout"));

    const { sendBroadcast } = await import("@/lib/services/broadcast.service");

    await expect(sendBroadcast("bc-4", "organizer-1")).rejects.toThrow("DB timeout");

    expect(mockDb.broadcast.update).toHaveBeenCalledWith(
      expect.objectContaining({ data: { status: "FAILED" } })
    );
  });
});
