import { describe, it, expect } from "vitest";
import { makeBadge } from "@/lib/services/directory.service";

describe("makeBadge", () => {
  it("returns correct config for FOUNDING_ORGANIZER", () => {
    const badge = makeBadge("FOUNDING_ORGANIZER");
    expect(badge.type).toBe("FOUNDING_ORGANIZER");
    expect(badge.label).toBe("Organizer");
    expect(badge.emoji).toBe("⭐");
    expect(badge.color).toContain("amber");
  });

  it("returns correct config for FLYING_IN", () => {
    const badge = makeBadge("FLYING_IN");
    expect(badge.emoji).toBe("✈️");
    expect(badge.label).toBe("Flying In");
  });

  it("returns correct config for TEACHER", () => {
    const badge = makeBadge("TEACHER");
    expect(badge.emoji).toBe("🍎");
    expect(badge.color).toContain("red");
  });

  it("returns correct config for VIP", () => {
    const badge = makeBadge("VIP");
    expect(badge.label).toBe("VIP");
    expect(badge.emoji).toBe("💎");
  });

  it("returns correct config for CLASS_AMBASSADOR", () => {
    const badge = makeBadge("CLASS_AMBASSADOR");
    expect(badge.emoji).toBe("🏆");
  });

  it("returns correct config for COMMITTEE", () => {
    const badge = makeBadge("COMMITTEE");
    expect(badge.emoji).toBe("🤝");
  });
});
