import { describe, it, expect } from "vitest";
import {
  rsvpSchema,
  createEventSchema,
  sendInvitesSchema,
  updateProfileSchema,
  createMemorySchema,
  sendMessageSchema,
} from "@/schemas";

describe("rsvpSchema", () => {
  const validRsvp = {
    status: "CONFIRMED" as const,
    guestCount: 1,
    dietaryRequirements: ["Vegetarian"],
    customAnswers: {},
    consentEmail: true,
  };

  it("accepts valid RSVP", () => {
    expect(() => rsvpSchema.parse(validRsvp)).not.toThrow();
  });

  it("rejects missing consentEmail", () => {
    const result = rsvpSchema.safeParse({ ...validRsvp, consentEmail: undefined });
    expect(result.success).toBe(false);
  });

  it("rejects guestCount > 4", () => {
    const result = rsvpSchema.safeParse({ ...validRsvp, guestCount: 5 });
    expect(result.success).toBe(false);
  });

  it("rejects invalid status", () => {
    const result = rsvpSchema.safeParse({ ...validRsvp, status: "MAYBE" });
    expect(result.success).toBe(false);
  });

  it("defaults guestCount to 0", () => {
    const result = rsvpSchema.parse({ ...validRsvp, guestCount: undefined });
    expect(result.guestCount).toBe(0);
  });
});

describe("createEventSchema", () => {
  const validEvent = {
    title: "Class of 2015 Reunion",
    schoolName: "Central High",
    graduationYear: 2015,
    startAt: new Date(Date.now() + 86400000).toISOString(),
    timezone: "America/New_York",
  };

  it("accepts valid event", () => {
    expect(() => createEventSchema.parse(validEvent)).not.toThrow();
  });

  it("rejects title shorter than 3 chars", () => {
    const result = createEventSchema.safeParse({ ...validEvent, title: "AB" });
    expect(result.success).toBe(false);
  });

  it("rejects graduation year before 1950", () => {
    const result = createEventSchema.safeParse({
      ...validEvent,
      graduationYear: 1900,
    });
    expect(result.success).toBe(false);
  });

  it("rejects graduation year in the future", () => {
    const result = createEventSchema.safeParse({
      ...validEvent,
      graduationYear: new Date().getFullYear() + 5,
    });
    expect(result.success).toBe(false);
  });

  it("rejects invalid coverImageUrl", () => {
    const result = createEventSchema.safeParse({
      ...validEvent,
      coverImageUrl: "not-a-url",
    });
    expect(result.success).toBe(false);
  });

  it("accepts empty string coverImageUrl", () => {
    const result = createEventSchema.safeParse({
      ...validEvent,
      coverImageUrl: "",
    });
    expect(result.success).toBe(true);
  });
});

describe("sendInvitesSchema", () => {
  it("rejects missing consentConfirmed", () => {
    const result = sendInvitesSchema.safeParse({
      channel: "EMAIL",
      recipients: [{ email: "test@example.com" }],
      consentConfirmed: false,
    });
    expect(result.success).toBe(false);
  });

  it("rejects empty recipients array", () => {
    const result = sendInvitesSchema.safeParse({
      channel: "EMAIL",
      recipients: [],
      consentConfirmed: true,
    });
    expect(result.success).toBe(false);
  });

  it("rejects invalid email in recipients", () => {
    const result = sendInvitesSchema.safeParse({
      channel: "EMAIL",
      recipients: [{ email: "not-valid" }],
      consentConfirmed: true,
    });
    expect(result.success).toBe(false);
  });
});

describe("updateProfileSchema", () => {
  it("accepts valid profile update", () => {
    const result = updateProfileSchema.safeParse({
      name: "Maya Chen",
      bio: "Class rep",
      currentCity: "San Francisco",
    });
    expect(result.success).toBe(true);
  });

  it("rejects username with spaces", () => {
    const result = updateProfileSchema.safeParse({
      username: "maya chen",
    });
    expect(result.success).toBe(false);
  });

  it("rejects username shorter than 3 chars", () => {
    const result = updateProfileSchema.safeParse({ username: "ab" });
    expect(result.success).toBe(false);
  });

  it("rejects non-LinkedIn URL for linkedinUrl", () => {
    const result = updateProfileSchema.safeParse({
      linkedinUrl: "https://twitter.com/foo",
    });
    expect(result.success).toBe(false);
  });

  it("accepts empty string for linkedinUrl", () => {
    const result = updateProfileSchema.safeParse({ linkedinUrl: "" });
    expect(result.success).toBe(true);
  });
});

describe("createMemorySchema", () => {
  it("requires mediaUrls for PHOTO type", () => {
    const result = createMemorySchema.safeParse({
      type: "PHOTO",
      mediaUrls: [],
    });
    expect(result.success).toBe(false);
  });

  it("requires content for TEXT type", () => {
    const result = createMemorySchema.safeParse({
      type: "TEXT",
      content: "",
    });
    expect(result.success).toBe(false);
  });

  it("requires videoEmbedUrl for VIDEO type", () => {
    const result = createMemorySchema.safeParse({
      type: "VIDEO",
    });
    expect(result.success).toBe(false);
  });

  it("accepts valid TEXT memory", () => {
    const result = createMemorySchema.safeParse({
      type: "TEXT",
      content: "A great memory from school!",
    });
    expect(result.success).toBe(true);
  });
});

describe("sendMessageSchema", () => {
  it("trims content", () => {
    const result = sendMessageSchema.parse({ content: "  hello  " });
    expect(result.content).toBe("hello");
  });

  it("rejects empty content after trim", () => {
    const result = sendMessageSchema.safeParse({ content: "   " });
    expect(result.success).toBe(false);
  });

  it("rejects content exceeding 4000 chars", () => {
    const result = sendMessageSchema.safeParse({ content: "a".repeat(4001) });
    expect(result.success).toBe(false);
  });
});
