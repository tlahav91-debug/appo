import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── Mocks ────────────────────────────────────────────────────────────────────

const mockDb = {
  invite: {
    findMany: vi.fn().mockResolvedValue([]),
    findFirst: vi.fn(),
    create: vi.fn(),
    update: vi.fn(),
    count: vi.fn(),
  },
  rSVP: {
    findMany: vi.fn().mockResolvedValue([]),
    findUnique: vi.fn(),
  },
  event: { findUnique: vi.fn() },
  referralLink: {
    findUnique: vi.fn(),
    update: vi.fn(),
    create: vi.fn(),
  },
  $transaction: vi.fn((fn: Function) => fn(mockDb)),
};

vi.mock("@/lib/db", () => ({ db: mockDb }));
vi.mock("@/lib/audit/log", () => ({ auditLog: vi.fn() }));
vi.mock("@/lib/email", () => ({ sendInviteEmail: vi.fn() }));
vi.mock("@/lib/auth/permissions", () => ({
  requireEventPermission: vi.fn().mockResolvedValue({ role: "ORGANIZER" }),
}));

import { parseCsvForImport } from "@/lib/services/invite.service";

const EVENT_ID = "event-test-123";

// ─── parseCsvForImport tests ──────────────────────────────────────────────────

describe("parseCsvForImport", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockDb.invite.findMany.mockResolvedValue([]);
    mockDb.rSVP.findMany.mockResolvedValue([]);
  });

  it("parses standard CSV with header row into valid rows", async () => {
    const csv = `email,name,phone
alice@example.com,Alice Smith,+14155551234
bob@example.com,Bob Jones,`;

    const result = await parseCsvForImport(csv, EVENT_ID);

    expect(result.total).toBe(2);
    expect(result.valid).toHaveLength(2);
    expect(result.valid[0]).toMatchObject({
      email: "alice@example.com",
      name: "Alice Smith",
    });
    expect(result.invalid).toHaveLength(0);
  });

  it("normalizes email addresses to lowercase", async () => {
    const csv = `email\nALICE@EXAMPLE.COM`;
    const result = await parseCsvForImport(csv, EVENT_ID);
    expect(result.valid[0]?.email).toBe("alice@example.com");
  });

  it("puts rows with invalid email into invalid array", async () => {
    const csv = `email,name
valid@example.com,Valid
not-an-email,Invalid`;

    const result = await parseCsvForImport(csv, EVENT_ID);
    expect(result.valid).toHaveLength(1);
    expect(result.invalid).toHaveLength(1);
    expect(result.invalid[0]?.reason).toBeTruthy();
  });

  it("marks already-invited emails as duplicates", async () => {
    mockDb.invite.findMany.mockResolvedValue([
      { email: "existing@example.com", phone: null },
    ]);

    const csv = `email\nexisting@example.com\nnew@example.com`;
    const result = await parseCsvForImport(csv, EVENT_ID);

    expect(result.duplicates).toHaveLength(1);
    expect(result.duplicates[0]?.email).toBe("existing@example.com");
    expect(result.valid).toHaveLength(1);
    expect(result.valid[0]?.email).toBe("new@example.com");
  });

  it("marks already-RSVP'd users as duplicates", async () => {
    mockDb.rSVP.findMany.mockResolvedValue([
      { user: { email: "rsvpd@example.com" } },
    ]);

    const csv = `email\nrsvpd@example.com\nfresh@example.com`;
    const result = await parseCsvForImport(csv, EVENT_ID);

    const allDupEmails = result.duplicates.map((d) => d.email);
    expect(allDupEmails).toContain("rsvpd@example.com");
    expect(result.valid.some((v) => v.email === "fresh@example.com")).toBe(true);
  });

  it("handles Windows line endings (CRLF)", async () => {
    const csv = "email,name\r\nalice@example.com,Alice\r\nbob@example.com,Bob";
    const result = await parseCsvForImport(csv, EVENT_ID);
    expect(result.total).toBe(2);
    expect(result.valid).toHaveLength(2);
  });

  it("returns empty result for empty input", async () => {
    const result = await parseCsvForImport("", EVENT_ID);
    expect(result.total).toBe(0);
    expect(result.valid).toHaveLength(0);
  });

  it("deduplicates within-file duplicate emails", async () => {
    const csv = `email\nalice@example.com\nalice@example.com\nbob@example.com`;
    const result = await parseCsvForImport(csv, EVENT_ID);
    // Only one alice should appear in valid
    const alices = result.valid.filter((v) => v.email === "alice@example.com");
    expect(alices).toHaveLength(1);
  });

  it("returns total as sum of valid + invalid + duplicates", async () => {
    mockDb.invite.findMany.mockResolvedValue([
      { email: "dup@example.com", phone: null },
    ]);

    const csv = `email
valid@example.com
not-an-email
dup@example.com`;

    const result = await parseCsvForImport(csv, EVENT_ID);
    expect(result.total).toBe(
      result.valid.length + result.invalid.length + result.duplicates.length
    );
  });
});
