import { test, expect } from "@playwright/test";

// ─── Public event page ────────────────────────────────────────────────────────

test.describe("Public Event Page", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/events/central-high-2015");
  });

  test("displays event title and school metadata", async ({ page }) => {
    await expect(
      page.getByRole("heading", { name: /central high/i })
    ).toBeVisible();
    await expect(page.getByText("Class of 2015")).toBeVisible();
  });

  test("shows attendee count badge", async ({ page }) => {
    await expect(page.getByText(/going/i)).toBeVisible();
  });

  test("tab navigation works", async ({ page }) => {
    await page.getByRole("tab", { name: "Memories" }).click();
    await expect(page).toHaveURL(/tab=memories/);
  });

  test("share button opens dropdown", async ({ page }) => {
    await page.getByRole("button", { name: /share/i }).click();
    await expect(page.getByText("Copy link")).toBeVisible();
    await expect(page.getByText("Share via WhatsApp")).toBeVisible();
  });

  test("RSVP button is visible and navigates to RSVP page", async ({ page }) => {
    await page.getByRole("link", { name: /rsvp now/i }).first().click();
    await expect(page).toHaveURL(/rsvp/);
  });

  test("event page has correct OG meta tags", async ({ page }) => {
    const ogTitle = await page
      .locator('meta[property="og:title"]')
      .getAttribute("content");
    expect(ogTitle).toContain("Central High");
  });
});

// ─── RSVP flow ────────────────────────────────────────────────────────────────

test.describe("RSVP Flow", () => {
  test("shows RSVP form with consent checkbox", async ({ page }) => {
    await page.goto("/events/central-high-2015/rsvp");
    await expect(
      page.getByText(/contact me about this event/i)
    ).toBeVisible();
  });

  test("cannot submit RSVP without consent", async ({ page }) => {
    await page.goto("/events/central-high-2015/rsvp");

    // Click RSVP Yes card
    await page.getByRole("radio", { name: /yes/i }).click();
    await page.getByRole("button", { name: /continue/i }).click();

    // Try to submit without checking consent
    await page.getByRole("button", { name: /confirm rsvp/i }).click();

    // Should show validation error
    await expect(
      page.getByText(/must agree/i)
    ).toBeVisible();
  });
});

// ─── Dashboard (authenticated) ───────────────────────────────────────────────

test.describe("Dashboard", () => {
  // These tests require authentication — use stored auth state
  test.use({ storageState: "tests/e2e/.auth/user.json" });

  test("shows empty state for new user with no events", async ({ page }) => {
    await page.goto("/dashboard/events");
    // Either shows events or shows the empty state CTA
    const hasEvents = await page.getByRole("link", { name: /create event/i }).isVisible();
    expect(hasEvents).toBe(true);
  });

  test("navigates to event creation wizard", async ({ page }) => {
    await page.goto("/dashboard/events/new");
    await expect(page.getByText(/school info/i)).toBeVisible();
  });

  test("event wizard step 1 validates required fields", async ({ page }) => {
    await page.goto("/dashboard/events/new");
    await page.getByRole("button", { name: /continue/i }).click();
    // Should show school name error
    await expect(page.getByText(/school name is required/i)).toBeVisible();
  });
});

// ─── Invite landing ───────────────────────────────────────────────────────────

test.describe("Invite landing page", () => {
  test("shows coming soon for unpublished events via expired/invalid token", async ({
    page,
  }) => {
    await page.goto("/invite/invalid-token-12345");
    await expect(page).toHaveURL(/404|not-found|invite/);
  });
});

// ─── Unsubscribe ──────────────────────────────────────────────────────────────

test.describe("Unsubscribe page", () => {
  test("shows confirmation or error message", async ({ page }) => {
    await page.goto("/unsubscribe/some-invalid-token");
    // Either success or "Link expired" should be shown — never a crash
    const success = page.getByText(/unsubscribed/i);
    const expired = page.getByText(/link expired/i);
    await expect(success.or(expired)).toBeVisible();
  });
});
