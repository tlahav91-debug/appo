# Reunitely — Security & Privacy Hardening Reference

## 1. RBAC Review — Status: ✅ Solid

Two-tier model: Platform role (`SUPER_ADMIN`, `MODERATOR`, `USER`) + Event role (`ORGANIZER`, `CO_ORGANIZER`, `COMMITTEE`) + implicit RSVP attendee tier.

All permissions flow through `lib/auth/permissions.ts` — no inline role string comparisons in routes. `requireEventPermission` / `withEventPermission` / `withApiAuth` wrap all mutating routes. `SUPER_ADMIN` auto-grants all event permissions.

**Remaining gaps:**
- [ ] Add `deletedAt: null` check inside `resolveEventContext` so soft-deleted users cannot authenticate to events
- [ ] Periodic permission audit: monthly log of all `committeeMember` records per event

---

## 2. Route Protection Matrix

| Layer | Mechanism | Notes |
|-------|-----------|-------|
| Edge | `isProtectedApiRoute` Clerk JWT check | Early rejection, no DB |
| Handler | `withApiAuth` / `withEventPermission` | Auth + permission check |
| Service | `requireEventPermission` re-check | Defense-in-depth |

Routes added to `isProtectedApiRoute` this pass: `/api/events/:id/cohort-leads`, `/api/events/:id/directory`, `/api/payments`, `/api/chat/messages/:id`, `/api/media-assets`.

**Not yet protected at edge (rely on handler guards):**
- `/invite/[token]` page load — add IP-based rate limit (5/min) to prevent token brute-force

---

## 3. Invite Token Security

| Property | Status |
|----------|--------|
| Entropy | `nanoid(32)` = 192 bits ✅ |
| Expiry | Configurable `expiresAt`, enforced on redemption ✅ |
| One-time use | Status → `RSVPD` after completion ✅ |
| Stored in plaintext | ⚠️ Tokens stored unhashed in DB |

**Recommended:** Store `SHA-256(token)` in DB, compare hash on lookup. This prevents a DB read exposure from revealing valid invite tokens.

```typescript
import { createHash } from "crypto";
const tokenHash = createHash("sha256").update(token).digest("hex");
await db.invite.findFirst({ where: { tokenHash } });
```

---

## 4. Upload Safety

**Applied this pass:**
- Extension ↔ MIME cross-validation: prevents `.php` disguised as `image/jpeg` ✅
- Minimum file size check: rejects `< 100` byte "files" ✅
- Error messages don't echo back contentType (type oracle prevention) ✅
- `fileExtension` now passed to `validateUploadRequest` ✅

**S3 bucket hardening checklist:**
- [ ] Block Public Access ON, serve via CloudFront signed URLs for private folders
- [ ] Object lifecycle: delete `UPLOADING`-status objects older than 24h (orphan cleanup)
- [ ] Server-side encryption: AES-256 or KMS
- [ ] Versioning enabled (recovery from accidental overwrites)
- [ ] Server-access logging to separate bucket
- [ ] Server-side malware scanning (AWS Rekognition or VirusTotal) for uploaded images

---

## 5. Rate Limiting — Complete Table

| Limiter | Limit | Window | Applied to |
|---------|-------|--------|------------|
| `auth` | 10 req | 1 min | Auth endpoints |
| `api` | 100 req | 1 min | General API |
| `rsvp` | 5 req | 1 min | RSVP creation |
| `chat` | 30 msg | 1 min | Chat message sends |
| `reaction` | 60 | 1 min | Chat/memory reactions |
| `broadcast` | 2 | 10 min | Email/SMS broadcasts |
| `upload` | 20 | 1 hour | File uploads |
| `checkIn` | 60 | 1 min | QR scan check-ins |
| `cohortLead` | 10 | 1 hour | Classmate nominations |
| `report` | 10 | 1 hour | Content reports |
| `unsubscribe` | 5 | 1 min | Unsubscribe processing |
| `publicPage` | 60 | 1 min | Public event pages (IP) |

**Not yet rate-limited:**
- [ ] `/invite/[token]` page: add `auth` limiter keyed on IP
- [ ] Password-protected event unlock: add `auth` limiter on IP

---

## 6. Content Security Policy (CSP)

Added to middleware this pass:

```
default-src 'self'
script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com https://*.clerk.accounts.dev https://js.pusher.com
style-src 'self' 'unsafe-inline'
img-src 'self' data: blob: https:
font-src 'self' data:
connect-src 'self' https://api.stripe.com https://*.pusher.com wss://*.pusher.com
frame-src https://js.stripe.com
object-src 'none'
base-uri 'self'
form-action 'self'
```

**Recommendations:**
- [ ] Remove `'unsafe-eval'` once all dependencies support strict CSP
- [ ] Add `require-trusted-types-for 'script'` for high-security mode
- [ ] Use nonce-based CSP for inline scripts (requires Next.js middleware nonce injection)

---

## 7. Spam & Abuse Prevention

| Vector | Prevention |
|--------|-----------|
| Cohort nominations | 5 per attendee per event (DB guard) + 10/hr rate limit |
| Memory posts | Organizer approval queue; `memoriesAutoApprove` flag |
| Memory auto-hide | 5 reports → status → `PENDING` for review ✅ |
| Chat messages | Slow mode + 30/min rate limit + HTML stripping |
| Invite bulk import | 500-row cap; dedup against existing invites |
| Broadcasts | 2/10min + `messages:broadcast` permission |
| Content reports | 10/hr + idempotency via AuditLog dedup |

**Recommendations:**
- [ ] Profanity filter on chat messages (word-list or ML API)
- [ ] Flag chat messages with >3 external URLs for review
- [ ] Image moderation: AWS Rekognition `DetectModerationLabels` on uploaded photos

---

## 8. Moderation Workflows

### Memory moderation
1. Auto-approve OR queue → `PENDING` (per event setting)
2. Organizer reviews in dashboard `/dashboard/events/[id]/memories`
3. Reports: any attendee can report → increments `reportCount` (deduplicated per reporter)
4. Auto-hide: `reportCount >= 5` → status → `PENDING` (re-queued for review) ✅
5. Organizer actions: Approve, Feature, Delete (all audit-logged) ✅

### Chat moderation
1. Slow mode: per-room cooldown (organizer sets) ✅
2. Mute: per-user, duration-based, organizer-only ✅
3. Delete message: author or organizer ✅
4. All moderation actions audit-logged ✅

**Recommendations:**
- [ ] Appeal workflow: muted users should be able to message organizer directly
- [ ] Bulk moderation: select + delete/hide multiple reports at once

---

## 9. Consent & Unsubscribe Compliance

| Requirement | Status |
|-------------|--------|
| Consent captured at RSVP | ✅ email/SMS/WhatsApp flags |
| Consent audit trail | ✅ `ConsentRecord` table |
| Unsubscribe token format | ✅ `nanoid(20)_hmac(24)`, INTERNAL_API_SECRET signed |
| Token enumeration prevention | ✅ constant-time delay + format pre-validation |
| Unsubscribe scope | ✅ event-only OR all-platform |
| `List-Unsubscribe` header | ✅ set on all outbound emails |
| GDPR data export | ✅ Art. 20 portability — all PII exported |

**CAN-SPAM / GDPR gaps:**
- [ ] Physical mailing address in email footer (CAN-SPAM requirement)
- [ ] Privacy Policy URL in all outbound email footers
- [ ] Cookie consent banner (PostHog analytics)
- [ ] Data Processing Agreement with Resend, Twilio, Stripe

---

## 10. GDPR Data Export (Art. 20)

`GET /api/profile/export` now exports:
- Account fields (email, name, phone, username)
- Attendee profile (bio, city, job, social links, privacy settings)
- RSVP history with event context
- Payment records with ticket codes
- Consent history (full audit trail)
- Memory posts authored
- Comments
- Chat messages (non-deleted)
- Cohort nominations submitted
- Referral links created
- Check-in history

**Gaps:**
- [ ] Nominations received (user was nominated)
- [ ] Photo tags (user was tagged in a photo)
- [ ] Notification history

---

## 11. Audit Log Coverage

### Logged ✅
`RSVP_CREATED`, `RSVP_UPDATED`, `PAYMENT_RECEIVED`, `PAYMENT_REFUNDED`, `DISPUTE_CREATED`, `ATTENDEE_CHECKED_IN`, `MEMORY_FEATURED`, `MEMORY_UNFEATURED`, `MEMORY_DELETED`, `MEMORY_REPORTED`, `CONTENT_REPORTED`, `CHAT_USER_MUTED`, `CHAT_SLOW_MODE_CHANGED`, `COHORT_LEAD_REVIEWED`, `COHORT_LEAD_CONVERTED`, `DATA_EXPORTED`

### Not yet logged ⚠️
- [ ] Invite sent / resent / bulk import
- [ ] Event published / archived
- [ ] Profile updated (with field diff)
- [ ] Chat message deleted by organizer (vs. self-delete)
- [ ] Memory comment deleted

---

## 12. PII Minimization

**Applied:**
- `console.log` with emails stripped from Clerk webhook ✅
- Error messages don't echo user-supplied contentType ✅
- Export excludes internal IDs from consent records
- Directory API: field-level privacy controls enforced ✅

**Recommendations:**
- [ ] Hash invite tokens in DB (SHA-256 before storage)
- [ ] Mask email in structured logs: `al***@example.com`
- [ ] Store `phone` encrypted at application layer (`prisma-field-encryption` library)
- [ ] Add `retentionDays` to `AuditLog` — cron purge after 2 years
- [ ] Separate PII data store from operational data (future: separate DB or schema)

---

## 13. Recommended Production Environment

```bash
# Security secrets — minimum 32 chars, generated via openssl rand -hex 32
INTERNAL_API_SECRET=       # HMAC for unsubscribe tokens
TICKET_QR_SECRET=          # HMAC for QR code signing (separate from above)
CRON_SECRET=               # Cron job bearer token
STRIPE_WEBHOOK_SECRET=     # Stripe signature verification
CLERK_WEBHOOK_SECRET=      # Clerk/svix signature verification

# Infrastructure
DATABASE_URL=              # Use connection pooler (PgBouncer/Neon pooled)
DATABASE_URL_UNPOOLED=     # Direct connection for migrations only
UPSTASH_REDIS_REST_URL=    # Rate limiting + caching
UPSTASH_REDIS_REST_TOKEN=

# Storage (use CloudFront in front of S3)
S3_BUCKET_NAME=
S3_REGION=
S3_ACCESS_KEY_ID=          # IAM user with minimal permissions (PutObject + DeleteObject only)
S3_SECRET_ACCESS_KEY=
NEXT_PUBLIC_CDN_URL=       # CloudFront distribution URL

# Monitoring
SENTRY_DSN=
SENTRY_AUTH_TOKEN=
NEXT_PUBLIC_POSTHOG_KEY=   # Analytics (ensure cookieless mode for GDPR)
```

### IAM Policy for S3 upload user (least-privilege)
```json
{
  "Effect": "Allow",
  "Action": ["s3:PutObject"],
  "Resource": "arn:aws:s3:::your-bucket/events/*",
  "Condition": {
    "StringEquals": { "s3:x-amz-server-side-encryption": "AES256" }
  }
}
```

---

## 14. Capacity Race Condition

**Current status:** Pre-check only — not atomic.

**Risk level:** Low for typical reunion events (tens to hundreds of seats), Medium for high-demand launches.

**Recommended fix for high-demand events:**
```typescript
// Atomic reservation using updateMany with conditional where
const reserved = await db.ticket.updateMany({
  where: {
    id: ticketId,
    soldCount: { lt: capacity }, // Only update if still has capacity
  },
  data: { reservedCount: { increment: quantity } },
});
if (reserved.count === 0) return badRequest("Sold out");
// On payment failure/cancellation: decrement reservedCount
```

For very high demand, use a Redis-based seat lock with TTL:
```typescript
const lockKey = `seat-lock:${ticketId}:${userId}`;
const acquired = await redis.set(lockKey, "1", { nx: true, ex: 900 }); // 15 min TTL
if (!acquired) return badRequest("Seats temporarily held by another buyer");
```

---

_This document reflects the state after the hardening pass. Review quarterly or after any significant feature addition._
