import * as Sentry from "@sentry/nextjs";

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  enabled: process.env.NODE_ENV === "production",
  tracesSampleRate: 0.1,

  // Scrub PII from server-side error payloads
  beforeSend(event) {
    // Redact email addresses from messages
    if (event.message) {
      event.message = event.message.replace(
        /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,
        "[email]"
      );
    }
    // Redact phone numbers (E.164)
    if (event.message) {
      event.message = event.message.replace(/\+\d{7,15}/g, "[phone]");
    }
    return event;
  },
});
