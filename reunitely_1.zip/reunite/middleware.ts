import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import {
  PUBLIC_ROUTES,
  AUTH_REDIRECT_ROUTES,
  ADMIN_ROUTES,
  AFTER_SIGN_IN_URL,
  SIGN_IN_URL,
  type ClerkPublicMetadata,
} from "@/lib/auth/config";

// ─── Route matchers ───────────────────────────────────────────────────────────

const isPublicRoute = createRouteMatcher(PUBLIC_ROUTES);
const isAuthRoute = createRouteMatcher(AUTH_REDIRECT_ROUTES);
const isAdminRoute = createRouteMatcher(ADMIN_ROUTES);

// API routes that require authentication (cannot use isPublicRoute alone
// because some API paths are partially public — e.g. GET /api/events/:id)
const isProtectedApiRoute = createRouteMatcher([
  "/api/events/:id/memberships(.*)",
  "/api/events/:id/invites(.*)",
  "/api/events/:id/broadcasts(.*)",
  "/api/events/:id/checkout(.*)",
  "/api/events/:id/payments(.*)",
  "/api/events/:id/nominations(.*)",
  "/api/events/:id/publish(.*)",
  "/api/events/:id/settings(.*)",
  "/api/events/:id/stats(.*)",
  "/api/events/:id/check-in(.*)",
  "/api/events/:id/cohort-leads(.*)",
  "/api/events/:id/message-templates(.*)",
  "/api/events/:id/chat(.*)",
  "/api/events/:id/directory",
  "/api/broadcasts(.*)",
  "/api/chat(.*)",
  "/api/payments(.*)",           // includes /api/payments/:id/refund
  "/api/memories/:id/approve",
  "/api/memories/:id/reject",
  "/api/profile(.*)",
  "/api/notifications(.*)",
  "/api/upload(.*)",
  "/api/pusher/auth",
  "/api/consent(.*)",
  "/api/media-assets(.*)",
  "/api/admin(.*)",
]);

// ─── Middleware ───────────────────────────────────────────────────────────────

export default clerkMiddleware((auth, req: NextRequest) => {
  const { userId, sessionClaims } = auth();
  const url = req.nextUrl;

  // ── 1. Request ID for distributed tracing ─────────────────────────────────
  const requestId = req.headers.get("x-request-id") ?? crypto.randomUUID();
  const requestHeaders = new Headers(req.headers);
  requestHeaders.set("x-request-id", requestId);
  requestHeaders.set("x-forwarded-path", url.pathname);

  // ── 2. Redirect signed-in users away from auth pages ──────────────────────
  if (isAuthRoute(req) && userId) {
    const redirectTo = url.searchParams.get("redirect_url") ?? AFTER_SIGN_IN_URL;
    // Prevent open redirect — only allow relative paths
    const safePath = redirectTo.startsWith("/") ? redirectTo : AFTER_SIGN_IN_URL;
    return NextResponse.redirect(new URL(safePath, req.url));
  }

  // ── 3. Admin route protection: requires MODERATOR or SUPER_ADMIN ──────────
  if (isAdminRoute(req)) {
    if (!userId) {
      const loginUrl = new URL(SIGN_IN_URL, req.url);
      loginUrl.searchParams.set("redirect_url", url.pathname);
      return NextResponse.redirect(loginUrl);
    }

    const meta = sessionClaims?.publicMetadata as ClerkPublicMetadata | undefined;
    const platformRole = meta?.platformRole ?? "USER";
    if (platformRole !== "MODERATOR" && platformRole !== "SUPER_ADMIN") {
      return NextResponse.redirect(new URL("/dashboard/events?error=unauthorized", req.url));
    }
  }

  // ── 4. Protected API routes: must be authenticated ────────────────────────
  if (isProtectedApiRoute(req) && !userId) {
    return NextResponse.json(
      { data: null, error: { code: "UNAUTHORIZED", message: "Authentication required" } },
      {
        status: 401,
        headers: { "x-request-id": requestId },
      }
    );
  }

  // ── 5. All other non-public routes: must be authenticated ─────────────────
  if (!isPublicRoute(req)) {
    auth().protect({
      // Clerk will redirect to sign-in with ?redirect_url= automatically
      unauthenticatedUrl: new URL(
        `${SIGN_IN_URL}?redirect_url=${encodeURIComponent(url.pathname)}`,
        req.url
      ).toString(),
    });
  }

  // ── 6. Pass through with enriched headers ─────────────────────────────────
  const response = NextResponse.next({
    request: { headers: requestHeaders },
    headers: { "x-request-id": requestId },
  });

  // Security headers applied at middleware level (complement next.config.ts headers)
  response.headers.set(
    "Content-Security-Policy",
    [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com https://*.clerk.accounts.dev https://js.pusher.com",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob: https: http:",  // broad for user avatars / S3 / CDN
      "font-src 'self' data:",
      "connect-src 'self' https://api.stripe.com https://*.pusher.com wss://*.pusher.com https://api.resend.com https://upstash.io",
      "frame-src https://js.stripe.com",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
    ].join("; ")
  );

  return response;
});

export const config = {
  matcher: [
    // Match all paths except Next.js internals and static assets
    "/((?!_next/static|_next/image|favicon.ico|apple-touch-icon|site.webmanifest|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|woff2?)$).*)",
  ],
};
