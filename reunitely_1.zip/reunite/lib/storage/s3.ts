import {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { getEnv } from "@/env";
import { nanoid } from "nanoid";

let _s3: S3Client | undefined;

function getS3(): S3Client {
  if (!_s3) {
    const env = getEnv();
    _s3 = new S3Client({
      region: env.S3_REGION,
      endpoint: env.S3_ENDPOINT,
      credentials: {
        accessKeyId: env.S3_ACCESS_KEY_ID,
        secretAccessKey: env.S3_SECRET_ACCESS_KEY,
      },
      // R2 requires path-style URLs
      forcePathStyle: !!env.S3_ENDPOINT,
    });
  }
  return _s3;
}

// ─── Types ───────────────────────────────────────────────────────────────────

export type UploadFolder =
  | "events/covers"
  | "events/memories"
  | "users/avatars"
  | "users/exports";

export type AllowedMimeType =
  | "image/jpeg"
  | "image/png"
  | "image/gif"
  | "image/webp"
  | "application/pdf";

export const ALLOWED_IMAGE_TYPES: AllowedMimeType[] = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
];

export const MAX_FILE_SIZES: Record<UploadFolder, number> = {
  "events/covers": 10 * 1024 * 1024,   // 10 MB
  "events/memories": 25 * 1024 * 1024, // 25 MB
  "users/avatars": 5 * 1024 * 1024,    // 5 MB
  "users/exports": 50 * 1024 * 1024,   // 50 MB
};

export interface PresignedUploadResult {
  uploadUrl: string;
  key: string;
  publicUrl: string;
  expiresAt: Date;
}

// ─── Presigned upload URL (client uploads directly to S3) ────────────────────

export async function createPresignedUpload(
  folder: UploadFolder,
  contentType: AllowedMimeType,
  fileExtension: string,
  userId: string
): Promise<PresignedUploadResult> {
  const env = getEnv();
  const s3 = getS3();

  // Generate a unique key with user namespacing
  const key = `${folder}/${userId}/${nanoid(16)}.${fileExtension}`;
  const expiresInSeconds = 15 * 60; // 15 minutes

  const command = new PutObjectCommand({
    Bucket: env.S3_BUCKET_NAME,
    Key: key,
    ContentType: contentType,
    // Prevent overwriting via metadata
    Metadata: {
      "uploaded-by": userId,
      "upload-time": new Date().toISOString(),
    },
  });

  const uploadUrl = await getSignedUrl(s3, command, {
    expiresIn: expiresInSeconds,
  });

  const publicUrl = getPublicUrl(key);

  return {
    uploadUrl,
    key,
    publicUrl,
    expiresAt: new Date(Date.now() + expiresInSeconds * 1000),
  };
}

// ─── Presigned read URL (for private files) ───────────────────────────────────

export async function createPresignedReadUrl(
  key: string,
  expiresInSeconds = 3600
): Promise<string> {
  const env = getEnv();
  const s3 = getS3();

  const command = new GetObjectCommand({
    Bucket: env.S3_BUCKET_NAME,
    Key: key,
  });

  return getSignedUrl(s3, command, { expiresIn: expiresInSeconds });
}

// ─── Delete file ─────────────────────────────────────────────────────────────

export async function deleteFile(key: string): Promise<void> {
  const env = getEnv();
  const s3 = getS3();

  await s3.send(
    new DeleteObjectCommand({
      Bucket: env.S3_BUCKET_NAME,
      Key: key,
    })
  );
}

// ─── URL helpers ─────────────────────────────────────────────────────────────

export function getPublicUrl(key: string): string {
  const cdnUrl = process.env.NEXT_PUBLIC_CDN_URL;
  if (cdnUrl) {
    return `${cdnUrl}/${key}`;
  }
  const env = getEnv();
  if (env.S3_ENDPOINT) {
    // R2 public URL pattern
    return `${env.S3_ENDPOINT}/${env.S3_BUCKET_NAME}/${key}`;
  }
  // AWS S3
  return `https://${env.S3_BUCKET_NAME}.s3.${env.S3_REGION}.amazonaws.com/${key}`;
}

export function extractKeyFromUrl(url: string): string | null {
  try {
    const cdnUrl = process.env.NEXT_PUBLIC_CDN_URL;
    if (cdnUrl && url.startsWith(cdnUrl)) {
      return url.slice(cdnUrl.length + 1);
    }
    const urlObj = new URL(url);
    // Remove leading slash and bucket name prefix if present
    return urlObj.pathname.replace(/^\/[^/]+\//, "");
  } catch {
    return null;
  }
}

// ─── Validation (server-side) ─────────────────────────────────────────────────

// Allowed MIME → valid file extensions (prevents MIME/extension spoofing)
const MIME_TO_EXTENSIONS: Record<string, string[]> = {
  "image/jpeg": ["jpg", "jpeg"],
  "image/png": ["png"],
  "image/webp": ["webp"],
  "image/gif": ["gif"],
  "application/pdf": ["pdf"],
};

export function validateUploadRequest(
  contentType: string,
  fileSize: number,
  folder: UploadFolder,
  fileExtension?: string
): { valid: boolean; error?: string } {
  if (!ALLOWED_IMAGE_TYPES.includes(contentType as AllowedMimeType)) {
    return {
      valid: false,
      error: `File type not allowed. Use JPEG, PNG, WebP, or GIF.`,
      // Note: don't echo contentType back to avoid type oracle
    };
  }

  // Extension ↔ MIME consistency check (prevents .php disguised as image/jpeg)
  if (fileExtension) {
    const ext = fileExtension.toLowerCase().replace(/^\./, "");
    const allowedExts = MIME_TO_EXTENSIONS[contentType];
    if (allowedExts && !allowedExts.includes(ext)) {
      return {
        valid: false,
        error: `File extension does not match content type.`,
      };
    }
  }

  const maxSize = MAX_FILE_SIZES[folder];
  if (fileSize > maxSize) {
    const maxMb = maxSize / (1024 * 1024);
    return {
      valid: false,
      error: `File too large. Maximum size for ${folder} is ${maxMb}MB.`,
    };
  }

  // Reject suspiciously small "images" (< 100 bytes = likely not a real image)
  if (fileSize < 100 && contentType.startsWith("image/")) {
    return { valid: false, error: "File appears to be empty or corrupted." };
  }

  return { valid: true };
}
