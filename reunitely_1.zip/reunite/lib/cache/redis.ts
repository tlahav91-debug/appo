import { Redis } from "@upstash/redis";
import { getEnv } from "@/env";

let _redis: Redis | undefined;

export function getRedis(): Redis {
  if (!_redis) {
    const env = getEnv();
    _redis = new Redis({
      url: env.UPSTASH_REDIS_REST_URL,
      token: env.UPSTASH_REDIS_REST_TOKEN,
    });
  }
  return _redis;
}

// ─── Cache helpers ───────────────────────────────────────────────────────────

export async function cacheGet<T>(key: string): Promise<T | null> {
  const redis = getRedis();
  try {
    return await redis.get<T>(key);
  } catch {
    // Degrade gracefully if Redis is unavailable
    return null;
  }
}

export async function cacheSet<T>(
  key: string,
  value: T,
  ttlSeconds?: number
): Promise<void> {
  const redis = getRedis();
  try {
    if (ttlSeconds) {
      await redis.setex(key, ttlSeconds, value);
    } else {
      await redis.set(key, value);
    }
  } catch {
    // Non-fatal
  }
}

export async function cacheDelete(key: string): Promise<void> {
  const redis = getRedis();
  try {
    await redis.del(key);
  } catch {
    // Non-fatal
  }
}

export async function cacheDeletePattern(pattern: string): Promise<void> {
  const redis = getRedis();
  try {
    const keys = await redis.keys(pattern);
    if (keys.length > 0) {
      await redis.del(...keys);
    }
  } catch {
    // Non-fatal
  }
}

// ─── Cache key factory (prevents typos) ─────────────────────────────────────

export const cacheKeys = {
  event: (slug: string) => `event:slug:${slug}`,
  eventStats: (id: string) => `event:stats:${id}`,
  attendeeCount: (eventId: string) => `event:attendee_count:${eventId}`,
  memories: (eventId: string, page: number) =>
    `event:memories:${eventId}:${page}`,
  nominations: (eventId: string) => `event:nominations:${eventId}`,
} as const;

// ─── TTLs ────────────────────────────────────────────────────────────────────

export const TTL = {
  SHORT: 30,        // 30 seconds — attendee counts
  MEDIUM: 60,       // 1 minute — event page data
  LONG: 60 * 10,   // 10 minutes — nomination results
  HOUR: 60 * 60,   // 1 hour — static reference data
} as const;
