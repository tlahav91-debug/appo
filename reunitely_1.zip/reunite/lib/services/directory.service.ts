/**
 * lib/services/directory.service.ts
 *
 * Privacy-aware attendee directory.
 *
 * Visibility rules (from AttendeeProfile.profileVisibleTo):
 *   EVENT_ATTENDEES → visible to confirmed attendees + organizers
 *   ORGANIZERS_ONLY → visible only to committee members
 *   NOBODY          → hidden from directory entirely
 *
 * Individual toggles (showCurrentCity, showCurrentJob, showSocialLinks)
 * are applied on top of the visibility tier.
 *
 * Badges are derived from contextual signals, not a separate badge table:
 *   - Founding Organizer: CommitteeMember.role = ORGANIZER
 *   - Class Ambassador:   ReferralLink.rsvpCount > 0
 *   - Flying In:          RSVP.customAnswers._transport_mode = FLYING
 *   - Teacher:            AttendeeProfile.currentJob contains 'teacher/professor/lecturer'
 *   - VIP:                Ticket.type = VIP
 *   - Committee:          CommitteeMember.role = CO_ORGANIZER | COMMITTEE
 */

import { db } from "@/lib/db";

// ─── Types ───────────────────────────────────────────────────────────────────

export type AttendeeBadgeType =
  | "FOUNDING_ORGANIZER"
  | "CLASS_AMBASSADOR"
  | "TEACHER"
  | "FLYING_IN"
  | "VIP"
  | "COMMITTEE";

export interface AttendeeBadge {
  type: AttendeeBadgeType;
  label: string;
  emoji: string;
  color: string; // tailwind bg class
  textColor: string; // tailwind text class
}

export interface DirectoryAttendee {
  userId: string;
  name: string;
  avatarUrl: string | null;
  // Profile — privacy-filtered
  bio: string | null;
  currentCity: string | null;
  currentCountry: string | null;
  currentJob: string | null;
  currentEmployer: string | null;
  funFact: string | null;
  favoriteMemory: string | null;
  linkedinUrl: string | null;
  instagramHandle: string | null;
  // Badges
  badges: AttendeeBadge[];
  // RSVP metadata
  confirmedAt: Date | null;
  transportMode: string | null; // from customAnswers._transport_mode
  // Privacy flags
  allowDirectMessages: boolean;
  isPublic: boolean;
}

export interface DirectoryFilters {
  search?: string;
  city?: string;
  badge?: AttendeeBadgeType;
  cursor?: string;
  limit?: number;
}

// ─── Badge definitions ────────────────────────────────────────────────────────

const BADGE_CONFIG: Record<AttendeeBadgeType, Omit<AttendeeBadge, "type">> = {
  FOUNDING_ORGANIZER: {
    label: "Organizer",
    emoji: "⭐",
    color: "bg-amber-100",
    textColor: "text-amber-800",
  },
  CLASS_AMBASSADOR: {
    label: "Class Ambassador",
    emoji: "🏆",
    color: "bg-yellow-100",
    textColor: "text-yellow-800",
  },
  TEACHER: {
    label: "Teacher",
    emoji: "🍎",
    color: "bg-red-100",
    textColor: "text-red-800",
  },
  FLYING_IN: {
    label: "Flying In",
    emoji: "✈️",
    color: "bg-blue-100",
    textColor: "text-blue-700",
  },
  VIP: {
    label: "VIP",
    emoji: "💎",
    color: "bg-violet-100",
    textColor: "text-violet-800",
  },
  COMMITTEE: {
    label: "Committee",
    emoji: "🤝",
    color: "bg-emerald-100",
    textColor: "text-emerald-800",
  },
};

export function makeBadge(type: AttendeeBadgeType): AttendeeBadge {
  return { type, ...BADGE_CONFIG[type] };
}

// ─── Privacy helper ───────────────────────────────────────────────────────────

function applyPrivacy(
  profile: {
    bio: string | null;
    currentCity: string | null;
    currentCountry: string | null;
    currentJob: string | null;
    currentEmployer: string | null;
    funFact: string | null;
    favoriteMemory: string | null;
    linkedinUrl: string | null;
    instagramHandle: string | null;
    showCurrentCity: boolean;
    showCurrentJob: boolean;
    showSocialLinks: boolean;
    allowDirectMessages: boolean;
  } | null,
  isOrganizer: boolean
) {
  if (!profile) {
    return {
      bio: null,
      currentCity: null,
      currentCountry: null,
      currentJob: null,
      currentEmployer: null,
      funFact: null,
      favoriteMemory: null,
      linkedinUrl: null,
      instagramHandle: null,
      allowDirectMessages: false,
    };
  }

  return {
    bio: profile.bio,
    currentCity: profile.showCurrentCity || isOrganizer ? profile.currentCity : null,
    currentCountry: profile.showCurrentCity || isOrganizer ? profile.currentCountry : null,
    currentJob: profile.showCurrentJob || isOrganizer ? profile.currentJob : null,
    currentEmployer: profile.showCurrentJob || isOrganizer ? profile.currentEmployer : null,
    funFact: profile.funFact,
    favoriteMemory: profile.favoriteMemory,
    linkedinUrl: profile.showSocialLinks || isOrganizer ? profile.linkedinUrl : null,
    instagramHandle: profile.showSocialLinks || isOrganizer ? profile.instagramHandle : null,
    allowDirectMessages: profile.allowDirectMessages,
  };
}

// ─── Badge computation ────────────────────────────────────────────────────────

function computeBadges(
  rsvp: {
    customAnswers: Record<string, unknown>;
    ticket?: { type: string } | null;
  },
  committee: { role: string } | null,
  isAmbassador: boolean,
  currentJob: string | null
): AttendeeBadge[] {
  const badges: AttendeeBadge[] = [];

  if (committee?.role === "ORGANIZER") {
    badges.push(makeBadge("FOUNDING_ORGANIZER"));
  } else if (committee?.role === "CO_ORGANIZER" || committee?.role === "COMMITTEE") {
    badges.push(makeBadge("COMMITTEE"));
  }

  if (isAmbassador) {
    badges.push(makeBadge("CLASS_AMBASSADOR"));
  }

  if (rsvp.ticket?.type === "VIP") {
    badges.push(makeBadge("VIP"));
  }

  const transportMode = rsvp.customAnswers["_transport_mode"] as string | undefined;
  if (transportMode === "FLYING") {
    badges.push(makeBadge("FLYING_IN"));
  }

  if (currentJob) {
    const jobLower = currentJob.toLowerCase();
    if (
      jobLower.includes("teacher") ||
      jobLower.includes("professor") ||
      jobLower.includes("lecturer") ||
      jobLower.includes("educator") ||
      jobLower.includes("instructor")
    ) {
      badges.push(makeBadge("TEACHER"));
    }
  }

  return badges;
}

// ─── Main directory loader ────────────────────────────────────────────────────

export async function getDirectoryAttendees(
  eventId: string,
  viewerId: string | null,
  filters: DirectoryFilters = {}
): Promise<{
  attendees: DirectoryAttendee[];
  total: number;
  nextCursor: string | null;
  viewerIsAttendee: boolean;
}> {
  const limit = filters.limit ?? 48;

  // Who is the viewer?
  let viewerIsAttendee = false;
  let viewerIsOrganizer = false;

  if (viewerId) {
    const [viewerRsvp, viewerCommittee] = await Promise.all([
      db.rSVP.findUnique({
        where: { eventId_userId: { eventId, userId: viewerId } },
        select: { status: true },
      }),
      db.committeeMember.findUnique({
        where: { eventId_userId: { eventId, userId: viewerId }, revokedAt: null },
        select: { role: true },
      }),
    ]);
    viewerIsAttendee =
      !!viewerCommittee ||
      (!!viewerRsvp &&
        viewerRsvp.status !== "CANCELLED" &&
        viewerRsvp.status !== "DECLINED");
    viewerIsOrganizer =
      !!viewerCommittee &&
      (viewerCommittee.role === "ORGANIZER" ||
        viewerCommittee.role === "CO_ORGANIZER");
  }

  // Build the privacy filter
  const visibilityFilter = viewerIsOrganizer
    ? { profileVisibleTo: { in: ["EVENT_ATTENDEES", "ORGANIZERS_ONLY"] } }
    : viewerIsAttendee
    ? { profileVisibleTo: "EVENT_ATTENDEES" }
    : { profileVisibleTo: "EVENT_ATTENDEES", showInDirectory: true };

  // Build name search filter
  const searchFilter = filters.search
    ? { name: { contains: filters.search, mode: "insensitive" as const } }
    : {};

  // City filter
  const cityFilter = filters.city
    ? {
        attendeeProfile: {
          currentCity: { contains: filters.city, mode: "insensitive" as const },
          showCurrentCity: true,
        },
      }
    : {};

  // Count total
  const total = await db.rSVP.count({
    where: {
      eventId,
      status: "CONFIRMED",
      user: {
        ...searchFilter,
        ...cityFilter,
        attendeeProfile: {
          ...visibilityFilter,
          showInDirectory: true,
        },
        deletedAt: null,
      },
    },
  });

  // Fetch attendees
  const rsvps = await db.rSVP.findMany({
    where: {
      eventId,
      status: "CONFIRMED",
      ...(filters.cursor ? { id: { gt: filters.cursor } } : {}),
      user: {
        ...searchFilter,
        ...cityFilter,
        attendeeProfile: {
          ...visibilityFilter,
          showInDirectory: true,
        },
        deletedAt: null,
      },
    },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          avatarUrl: true,
          attendeeProfile: {
            select: {
              bio: true,
              currentCity: true,
              currentCountry: true,
              currentJob: true,
              currentEmployer: true,
              funFact: true,
              favoriteMemory: true,
              linkedinUrl: true,
              instagramHandle: true,
              showCurrentCity: true,
              showCurrentJob: true,
              showSocialLinks: true,
              allowDirectMessages: true,
              profileVisibleTo: true,
            },
          },
        },
      },
      ticket: { select: { type: true } },
    },
    orderBy: { confirmedAt: "asc" },
    take: limit,
  });

  // Get committee roles for all attendees in one query
  const userIds = rsvps.map((r) => r.userId);
  const [committeeRoles, ambassadorUserIds] = await Promise.all([
    db.committeeMember.findMany({
      where: { eventId, userId: { in: userIds }, revokedAt: null },
      select: { userId: true, role: true },
    }),
    db.referralLink.findMany({
      where: { eventId, createdById: { in: userIds }, rsvpCount: { gt: 0 } },
      select: { createdById: true },
    }),
  ]);

  const committeeMap = new Map(committeeRoles.map((c) => [c.userId, c]));
  const ambassadorSet = new Set(ambassadorUserIds.map((r) => r.createdById));

  // Assemble attendees
  const attendees: DirectoryAttendee[] = rsvps.map((rsvp) => {
    const committee = committeeMap.get(rsvp.userId) ?? null;
    const profile = rsvp.user.attendeeProfile;
    const privacyFiltered = applyPrivacy(profile, viewerIsOrganizer);
    const customAnswers = (rsvp.customAnswers ?? {}) as Record<string, unknown>;

    const badges = computeBadges(
      { customAnswers, ticket: rsvp.ticket },
      committee,
      ambassadorSet.has(rsvp.userId),
      privacyFiltered.currentJob
    );

    return {
      userId: rsvp.userId,
      name: rsvp.user.name,
      avatarUrl: rsvp.user.avatarUrl,
      ...privacyFiltered,
      badges,
      confirmedAt: rsvp.confirmedAt,
      transportMode: (customAnswers["_transport_mode"] as string) ?? null,
      isPublic: profile?.profileVisibleTo === "EVENT_ATTENDEES",
    };
  });

  // Filter by badge type if requested
  const filtered =
    filters.badge
      ? attendees.filter((a) => a.badges.some((b) => b.type === filters.badge))
      : attendees;

  const nextCursor =
    rsvps.length === limit ? rsvps[rsvps.length - 1]?.id ?? null : null;

  return {
    attendees: filtered,
    total,
    nextCursor,
    viewerIsAttendee,
  };
}

// ─── Single attendee profile loader ──────────────────────────────────────────

export async function getAttendeeProfile(
  eventId: string,
  profileUserId: string,
  viewerId: string | null
): Promise<DirectoryAttendee | null> {
  // Determine viewer's access level
  let viewerIsOrganizer = false;
  let viewerIsAttendee = false;

  if (viewerId) {
    const [viewerCommittee, viewerRsvp] = await Promise.all([
      db.committeeMember.findUnique({
        where: { eventId_userId: { eventId, userId: viewerId }, revokedAt: null },
        select: { role: true },
      }),
      db.rSVP.findUnique({
        where: { eventId_userId: { eventId, userId: viewerId } },
        select: { status: true },
      }),
    ]);
    viewerIsOrganizer =
      !!viewerCommittee &&
      (viewerCommittee.role === "ORGANIZER" ||
        viewerCommittee.role === "CO_ORGANIZER");
    viewerIsAttendee =
      !!viewerCommittee ||
      (!!viewerRsvp &&
        viewerRsvp.status !== "CANCELLED" &&
        viewerRsvp.status !== "DECLINED");
  }

  const rsvp = await db.rSVP.findUnique({
    where: { eventId_userId: { eventId, userId: profileUserId } },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          avatarUrl: true,
          attendeeProfile: {
            select: {
              bio: true,
              currentCity: true,
              currentCountry: true,
              currentJob: true,
              currentEmployer: true,
              funFact: true,
              favoriteMemory: true,
              linkedinUrl: true,
              instagramHandle: true,
              twitterHandle: true,
              facebookUrl: true,
              showCurrentCity: true,
              showCurrentJob: true,
              showSocialLinks: true,
              allowDirectMessages: true,
              profileVisibleTo: true,
              profileCompleteness: true,
            },
          },
        },
      },
      ticket: { select: { type: true } },
    },
  });

  if (!rsvp || rsvp.status !== "CONFIRMED") return null;

  const profile = rsvp.user.attendeeProfile;

  // Check visibility
  if (!profile) return null;
  if (profile.profileVisibleTo === "NOBODY") return null;
  if (profile.profileVisibleTo === "ORGANIZERS_ONLY" && !viewerIsOrganizer) return null;
  if (profile.profileVisibleTo === "EVENT_ATTENDEES" && !viewerIsAttendee) return null;

  const [committee, ambassadorLink] = await Promise.all([
    db.committeeMember.findUnique({
      where: { eventId_userId: { eventId, userId: profileUserId }, revokedAt: null },
      select: { role: true, title: true },
    }),
    db.referralLink.findFirst({
      where: { eventId, createdById: profileUserId, rsvpCount: { gt: 0 } },
      select: { rsvpCount: true },
    }),
  ]);

  const privacyFiltered = applyPrivacy(profile, viewerIsOrganizer);
  const customAnswers = (rsvp.customAnswers ?? {}) as Record<string, unknown>;

  const badges = computeBadges(
    { customAnswers, ticket: rsvp.ticket },
    committee,
    !!ambassadorLink,
    privacyFiltered.currentJob
  );

  return {
    userId: rsvp.userId,
    name: rsvp.user.name,
    avatarUrl: rsvp.user.avatarUrl,
    ...privacyFiltered,
    badges,
    confirmedAt: rsvp.confirmedAt,
    transportMode: (customAnswers["_transport_mode"] as string) ?? null,
    isPublic: profile.profileVisibleTo === "EVENT_ATTENDEES",
    allowDirectMessages: profile.allowDirectMessages,
  };
}

// ─── Get unique cities for filter UI ─────────────────────────────────────────

export async function getDirectoryCities(eventId: string): Promise<string[]> {
  const profiles = await db.attendeeProfile.findMany({
    where: {
      showInDirectory: true,
      showCurrentCity: true,
      profileVisibleTo: "EVENT_ATTENDEES",
      currentCity: { not: null },
      user: {
        rsvps: { some: { eventId, status: "CONFIRMED" } },
      },
    },
    select: { currentCity: true },
    distinct: ["currentCity"],
    orderBy: { currentCity: "asc" },
  });

  return profiles.map((p) => p.currentCity!).filter(Boolean);
}
