import { db } from "@/lib/db";
import { requireEventPermission } from "@/lib/auth/permissions";
import { auditLog } from "@/lib/audit/log";
import { deleteFile, extractKeyFromUrl } from "@/lib/storage/s3";
import type { ContentStatus } from "@prisma/client";

// ─── Approve / reject memories ────────────────────────────────────────────────

export async function approveMemory(
  memoryId: string,
  moderatorId: string
): Promise<void> {
  const memory = await db.memoryPost.findUniqueOrThrow({
    where: { id: memoryId },
    select: { eventId: true, status: true },
  });

  await requireEventPermission(moderatorId, memory.eventId, "memories:moderate");

  await db.memoryPost.update({
    where: { id: memoryId },
    data: {
      status: "APPROVED" as ContentStatus,
      moderatedById: moderatorId,
      moderatedAt: new Date(),
    },
  });

  await auditLog({
    actorId: moderatorId,
    action: "MEMORY_APPROVED",
    resourceType: "Memory",
    resourceId: memoryId,
    eventId: memory.eventId,
  });
}

export async function rejectMemory(
  memoryId: string,
  moderatorId: string,
  deleteFiles = false
): Promise<void> {
  const memory = await db.memoryPost.findUniqueOrThrow({
    where: { id: memoryId },
    select: { eventId: true, mediaUrls: true },
  });

  await requireEventPermission(moderatorId, memory.eventId, "memories:moderate");

  await db.memoryPost.update({
    where: { id: memoryId },
    data: {
      status: "REJECTED" as ContentStatus,
      moderatedById: moderatorId,
      moderatedAt: new Date(),
    },
  });

  // Optionally purge media from S3 (for CSAM or severe violations)
  if (deleteFiles && memory.mediaUrls.length > 0) {
    await Promise.allSettled(
      memory.mediaUrls.map((url) => {
        const key = extractKeyFromUrl(url);
        return key ? deleteFile(key) : Promise.resolve();
      })
    );
  }

  await auditLog({
    actorId: moderatorId,
    action: "MEMORY_REJECTED",
    resourceType: "Memory",
    resourceId: memoryId,
    eventId: memory.eventId,
    metadata: { deletedFiles: deleteFiles },
  });
}

// ─── Report content ───────────────────────────────────────────────────────────

export async function reportMemory(
  memoryId: string,
  reporterId: string,
  reason: string
): Promise<void> {
  const memory = await db.memoryPost.findUniqueOrThrow({
    where: { id: memoryId },
    select: { eventId: true },
  });

  // For MVP: log the report; in production, store in a ReportQueue table
  // and notify organizers
  console.warn("[Moderation] Memory reported:", {
    memoryId,
    reporterId,
    reason,
    eventId: memory.eventId,
  });

  await auditLog({
    actorId: reporterId,
    action: "MEMORY_REPORTED",
    resourceType: "Memory",
    resourceId: memoryId,
    eventId: memory.eventId,
    metadata: { reason },
  });
}

// ─── Bulk moderation: get pending memories ────────────────────────────────────

export async function getPendingMemories(
  eventId: string,
  moderatorId: string
) {
  await requireEventPermission(moderatorId, eventId, "memories:moderate");

  return db.memoryPost.findMany({
    where: { eventId, status: "PENDING" as ContentStatus },
    include: {
      user: { select: { id: true, name: true, avatarUrl: true } },
    },
    orderBy: { createdAt: "asc" },
  });
}

// ─── Delete message (chat moderation) ────────────────────────────────────────

export async function deleteMessage(
  messageId: string,
  moderatorId: string
): Promise<void> {
  const message = await db.chatMessage.findUniqueOrThrow({
    where: { id: messageId },
    select: { room: { select: { eventId: true } }, userId: true },
  });

  const isOwner = message.userId === moderatorId;
  if (!isOwner) {
    await requireEventPermission(
      moderatorId,
      message.room.eventId,
      "chat:moderate"
    );
  }

  await db.chatMessage.update({
    where: { id: messageId },
    data: { isDeleted: true, content: "" },
  });

  await auditLog({
    actorId: moderatorId,
    action: "MEMORY_DELETED",
    resourceType: "ChatMessage",
    resourceId: messageId,
    eventId: message.room.eventId,
    metadata: { deletedByOwner: isOwner },
  });
}
