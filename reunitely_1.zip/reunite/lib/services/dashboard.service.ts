/**
 * lib/services/dashboard.service.ts
 *
 * Comprehensive data loader for the organizer dashboard overview.
 * Single function fetches all sections in parallel with fine-grained
 * selects to avoid N+1s and keep the payload lean.
 */

import { db } from "@/lib/db";
import type { EventStatus } from "@prisma/client";
import { cacheGet, cacheSet, cacheKeys, TTL } from "@/lib/cache/redis";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface DashboardData {
  event: {
    id: string;
    title: string;
    slug: string;
    status: EventStatus;
    startAt: Date;
    endAt: Date | null;
    timezone: string;
    schoolName: string;
    graduationYear: number;
    capacity: number | null;
    ticketingEnabled: boolean;
    waitlistEnabled: boolean;
  };

  /** Core RSVP funnel */
  rsvp: {
    total: number;
    confirmed: number;
    pending: number;
    declined: number;
    waitlisted: number;
    checkedIn: number;
    capacityPct: number | null; // null if unlimited
    conversionRate: number; // confirmed / total
    trend: Array<{ date: string; count: number }>; // last 14 days
  };

  /** Invite funnel */
  invites: {
    total: number;
    sent: number;
    delivered: number;
    opened: number;
    rsvpd: number;
    conversionRate: number;
    topReferrers: Array<{
      code: string;
      label: string | null;
      rsvpCount: number;
      clickCount: number;
    }>;
  };

  /** Payment summary */
  payments: {
    enabled: boolean;
    totalRevenueCents: number;
    paidCount: number;
    pendingCount: number;
    refundedCount: number;
    currency: string;
  };

  /** Nomination summary */
  nominations: {
    enabled: boolean;
    categoryCount: number;
    nominationCount: number;
    voteCount: number;
    categories: Array<{
      id: string;
      title: string;
      emoji: string | null;
      votingStatus: string;
      nominationCount: number;
      voteCount: number;
    }>;
  };

  /** Cohort coverage estimate */
  cohort: {
    graduationYear: number;
    schoolName: string;
    confirmedCount: number;
    estimatedClassSize: number | null; // user-set or null
    coveragePct: number | null;
  };

  /** Ambassador / referral leaderboard */
  ambassadors: Array<{
    userId: string;
    name: string;
    avatarUrl: string | null;
    rsvpsGenerated: number;
    code: string;
    label: string | null;
  }>;

  /** Reminders panel */
  reminders: Array<{
    type: "uncollected_payment" | "pending_rsvp" | "waitlist_promote" | "nominations_open" | "event_soon" | "memories_pending";
    priority: "high" | "medium" | "low";
    title: string;
    description: string;
    count: number;
    actionHref: string;
  }>;

  /** Recent activity (audit log) */
  recentActivity: Array<{
    id: string;
    action: string;
    actorName: string;
    actorAvatar: string | null;
    createdAt: Date;
  }>;

  /** Committee roster */
  committee: Array<{
    userId: string;
    name: string;
    avatarUrl: string | null;
    role: string;
    title: string | null;
  }>;
}

// ─── Loader ───────────────────────────────────────────────────────────────────

export async function loadDashboardData(
  eventId: string,
  userId: string
): Promise<DashboardData | null> {
  const cacheKey = `dashboard:${eventId}:${userId}`;
  const cached = await cacheGet<DashboardData>(cacheKey);
  if (cached) return cached;

  // ── Permission + event fetch ───────────────────────────────────────────────
  const [committee, event] = await Promise.all([
    db.committeeMember.findUnique({
      where: { eventId_userId: { eventId, userId }, revokedAt: null },
      select: { role: true },
    }),
    db.event.findUnique({
      where: { id: eventId },
      select: {
        id: true,
        title: true,
        slug: true,
        status: true,
        startAt: true,
        endAt: true,
        timezone: true,
        schoolName: true,
        graduationYear: true,
        capacity: true,
        ticketingEnabled: true,
        waitlistEnabled: true,
        settings: true,
      },
    }),
  ]);

  if (!event) return null;
  if (!committee && userId !== "SUPER_ADMIN") return null;

  const settings = event.settings as Record<string, unknown> | null;
  const nominationsEnabled = settings?.nominationsEnabled !== false;

  // ── All parallel fetches ──────────────────────────────────────────────────
  const [
    rsvpGroups,
    checkedInCount,
    rsvpTrend,
    inviteGroups,
    referralLinks,
    payments,
    nominationData,
    auditLogs,
    committeeMembers,
    memoriesPending,
  ] = await Promise.all([
    // RSVP status breakdown
    db.rSVP.groupBy({
      by: ["status"],
      where: { eventId },
      _count: { status: true },
    }),

    // Check-ins (separate model)
    db.checkIn.count({ where: { eventId, status: "CHECKED_IN" } }),

    // RSVP trend — last 14 days, confirmed only
    db.rSVP.findMany({
      where: {
        eventId,
        status: "CONFIRMED",
        submittedAt: {
          gte: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
        },
      },
      select: { submittedAt: true },
      orderBy: { submittedAt: "asc" },
    }),

    // Invite status breakdown
    db.invite.groupBy({
      by: ["status"],
      where: { eventId },
      _count: { status: true },
    }),

    // Top referral links with creator info
    db.referralLink.findMany({
      where: { eventId, isActive: true },
      include: {
        createdBy: { select: { id: true, name: true, avatarUrl: true } },
      },
      orderBy: { rsvpCount: "desc" },
      take: 10,
    }),

    // Payment summary
    db.payment.groupBy({
      by: ["status", "currency"],
      where: { eventId },
      _count: { status: true },
      _sum: { totalAmountCents: true },
    }),

    // Nominations
    nominationsEnabled
      ? db.nominationCategory.findMany({
          where: { eventId },
          include: {
            _count: {
              select: { nominations: true, votes: true },
            },
          },
          orderBy: { sortOrder: "asc" },
        })
      : Promise.resolve([]),

    // Recent audit log
    db.auditLog.findMany({
      where: { eventId },
      include: {
        actor: { select: { name: true, avatarUrl: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 15,
    }),

    // Committee
    db.committeeMember.findMany({
      where: { eventId, revokedAt: null },
      include: {
        user: { select: { id: true, name: true, avatarUrl: true } },
      },
      orderBy: { addedAt: "asc" },
    }),

    // Pending memories
    db.memoryPost.count({ where: { eventId, status: "PENDING" } }),
  ]);

  // ── Assemble RSVP section ─────────────────────────────────────────────────
  const rsvpByStatus: Record<string, number> = {};
  rsvpGroups.forEach((g) => { rsvpByStatus[g.status] = g._count.status; });

  const confirmed = rsvpByStatus["CONFIRMED"] ?? 0;
  const pending = rsvpByStatus["PENDING"] ?? 0;
  const declined = rsvpByStatus["DECLINED"] ?? 0;
  const waitlisted = rsvpByStatus["WAITLISTED"] ?? 0;
  const total = confirmed + pending + declined + waitlisted;

  // Build trend: group by day
  const trendMap: Record<string, number> = {};
  const today = new Date();
  for (let i = 13; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().split("T")[0]!;
    trendMap[key] = 0;
  }
  rsvpTrend.forEach((r) => {
    const key = r.submittedAt.toISOString().split("T")[0]!;
    if (trendMap[key] !== undefined) trendMap[key]!++;
  });
  const trend = Object.entries(trendMap).map(([date, count]) => ({ date, count }));

  // ── Assemble invite section ───────────────────────────────────────────────
  const inviteByStatus: Record<string, number> = {};
  inviteGroups.forEach((g) => { inviteByStatus[g.status] = g._count.status; });

  const inviteTotal = Object.values(inviteByStatus).reduce((a, b) => a + b, 0);
  const inviteRsvpd = inviteByStatus["RSVPD"] ?? 0;

  // ── Assemble payment section ──────────────────────────────────────────────
  const paymentByStatus: Record<string, { count: number; sum: number }> = {};
  payments.forEach((p) => {
    const key = p.status;
    paymentByStatus[key] = {
      count: (paymentByStatus[key]?.count ?? 0) + p._count.status,
      sum: (paymentByStatus[key]?.sum ?? 0) + (p._sum.totalAmountCents ?? 0),
    };
  });

  const paidRevenue = paymentByStatus["PAID"]?.sum ?? 0;
  // Pick the most common currency across payments (fall back to USD)
  const currency =
    payments
      .filter((p) => p.status === "PAID")
      .sort((a, b) => (b._sum.totalAmountCents ?? 0) - (a._sum.totalAmountCents ?? 0))[0]
      ?.currency ?? "USD";

  // ── Assemble nominations section ──────────────────────────────────────────
  const nomCategories = nominationData.map((cat) => ({
    id: cat.id,
    title: cat.title,
    emoji: cat.emoji,
    votingStatus: cat.votingStatus,
    nominationCount: cat._count.nominations,
    voteCount: cat._count.votes,
  }));

  // ── Ambassadors: referral links sorted by rsvpCount ──────────────────────
  const ambassadors = referralLinks
    .filter((rl) => rl.rsvpCount > 0)
    .slice(0, 5)
    .map((rl) => ({
      userId: rl.createdBy.id,
      name: rl.createdBy.name,
      avatarUrl: rl.createdBy.avatarUrl,
      rsvpsGenerated: rl.rsvpCount,
      code: rl.code,
      label: rl.label,
    }));

  // ── Build reminders ───────────────────────────────────────────────────────
  const reminders: DashboardData["reminders"] = [];
  const daysUntilEvent = Math.floor(
    (event.startAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
  );

  if (event.ticketingEnabled && paymentByStatus["PENDING"]?.count) {
    reminders.push({
      type: "uncollected_payment",
      priority: "high",
      title: "Uncollected payments",
      description: `${paymentByStatus["PENDING"]!.count} attendees haven't completed payment`,
      count: paymentByStatus["PENDING"]!.count,
      actionHref: `payments`,
    });
  }

  if (waitlisted > 0 && event.capacity) {
    const spots = event.capacity - confirmed;
    if (spots > 0) {
      reminders.push({
        type: "waitlist_promote",
        priority: "high",
        title: "Waitlist can be promoted",
        description: `${spots} spot${spots !== 1 ? "s" : ""} available — ${waitlisted} on waitlist`,
        count: Math.min(spots, waitlisted),
        actionHref: `attendees`,
      });
    }
  }

  if (memoriesPending > 0) {
    reminders.push({
      type: "memories_pending",
      priority: "medium",
      title: "Memories awaiting review",
      description: `${memoriesPending} memory post${memoriesPending !== 1 ? "s" : ""} need${memoriesPending === 1 ? "s" : ""} approval`,
      count: memoriesPending,
      actionHref: `memories`,
    });
  }

  if (nominationsEnabled) {
    const openVoting = nomCategories.filter((c) => c.votingStatus === "OPEN");
    if (openVoting.length > 0) {
      reminders.push({
        type: "nominations_open",
        priority: "medium",
        title: "Voting is live",
        description: `${openVoting.length} categor${openVoting.length !== 1 ? "ies" : "y"} with open voting`,
        count: openVoting.length,
        actionHref: `nominations`,
      });
    }
  }

  if (daysUntilEvent <= 7 && daysUntilEvent > 0) {
    reminders.push({
      type: "event_soon",
      priority: "high",
      title: `Event in ${daysUntilEvent} day${daysUntilEvent !== 1 ? "s" : ""}`,
      description: "Final reminder: check attendee list, confirm venue, send last message",
      count: daysUntilEvent,
      actionHref: `attendees`,
    });
  }

  if (pending > 0 && daysUntilEvent <= 14) {
    reminders.push({
      type: "pending_rsvp",
      priority: "low",
      title: "Undecided RSVPs",
      description: `${pending} people haven't confirmed or declined`,
      count: pending,
      actionHref: `attendees`,
    });
  }

  // Sort by priority
  const priorityOrder = { high: 0, medium: 1, low: 2 };
  reminders.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);

  // ── Assemble final data ───────────────────────────────────────────────────
  const data: DashboardData = {
    event: {
      id: event.id,
      title: event.title,
      slug: event.slug,
      status: event.status,
      startAt: event.startAt,
      endAt: event.endAt,
      timezone: event.timezone,
      schoolName: event.schoolName,
      graduationYear: event.graduationYear,
      capacity: event.capacity,
      ticketingEnabled: event.ticketingEnabled,
      waitlistEnabled: event.waitlistEnabled,
    },

    rsvp: {
      total,
      confirmed,
      pending,
      declined,
      waitlisted,
      checkedIn: checkedInCount,
      capacityPct:
        event.capacity && event.capacity > 0
          ? Math.min(100, Math.round((confirmed / event.capacity) * 100))
          : null,
      conversionRate: total > 0 ? Math.round((confirmed / total) * 100) : 0,
      trend,
    },

    invites: {
      total: inviteTotal,
      sent: (inviteByStatus["SENT"] ?? 0) + (inviteByStatus["DELIVERED"] ?? 0),
      delivered: inviteByStatus["DELIVERED"] ?? 0,
      opened: inviteByStatus["OPENED"] ?? 0,
      rsvpd: inviteRsvpd,
      conversionRate:
        inviteTotal > 0 ? Math.round((inviteRsvpd / inviteTotal) * 100) : 0,
      topReferrers: referralLinks
        .slice(0, 5)
        .map((rl) => ({
          code: rl.code,
          label: rl.label,
          rsvpCount: rl.rsvpCount,
          clickCount: rl.clickCount,
        })),
    },

    payments: {
      enabled: event.ticketingEnabled,
      totalRevenueCents: paidRevenue,
      paidCount: paymentByStatus["PAID"]?.count ?? 0,
      pendingCount: paymentByStatus["PENDING"]?.count ?? 0,
      refundedCount: paymentByStatus["REFUNDED"]?.count ?? 0,
      currency,
    },

    nominations: {
      enabled: nominationsEnabled,
      categoryCount: nomCategories.length,
      nominationCount: nomCategories.reduce((s, c) => s + c.nominationCount, 0),
      voteCount: nomCategories.reduce((s, c) => s + c.voteCount, 0),
      categories: nomCategories,
    },

    cohort: {
      graduationYear: event.graduationYear,
      schoolName: event.schoolName,
      confirmedCount: confirmed,
      estimatedClassSize: typeof settings?.classSize === "number"
        ? settings.classSize
        : null,
      coveragePct: typeof settings?.classSize === "number" && settings.classSize > 0
        ? Math.min(100, Math.round((confirmed / settings.classSize) * 100))
        : null,
    },

    ambassadors,

    reminders,

    recentActivity: auditLogs.map((log) => ({
      id: log.id,
      action: log.action,
      actorName: log.actor?.name ?? "System",
      actorAvatar: log.actor?.avatarUrl ?? null,
      createdAt: log.createdAt,
    })),

    committee: committeeMembers.map((m) => ({
      userId: m.userId,
      name: m.user.name,
      avatarUrl: m.user.avatarUrl,
      role: m.role,
      title: m.title,
    })),
  };

  await cacheSet(cacheKey, data, TTL.SHORT); // 2 min cache
  return data;
}
