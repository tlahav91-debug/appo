/**
 * lib/services/memory.service.ts
 *
 * Memory Wall — core data layer.
 *
 * Upload flow:
 *   1. Client requests presigned URL → POST /api/upload (existing)
 *   2. Client uploads directly to S3 with presigned URL
 *   3. Client calls POST /api/events/[id]/memories with { s3Keys, caption, yearContext }
 *   4. Server creates MediaAsset records + MemoryPost linked together
 *   5. Status = PENDING (goes to moderation queue) or APPROVED (if auto-approve)
 *
 * Privacy: memories are visible to EVENT_ATTENDEES unless overridden.
 * Moderation: PENDING → organizer approves/rejects → APPROVED/REJECTED
 */

import { db } from "@/lib/db";
import type { ContentStatus, MemoryType } from "@prisma/client";
import { auditLog } from "@/lib/audit/log";
import { createNotification } from "@/lib/services/notification.service";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface MemoryPostWithMedia {
  id: string;
  type: MemoryType;
  caption: string | null;
  yearContext: number | null;
  contextLabel: string | null;
  videoEmbedUrl: string | null;
  status: ContentStatus;
  likeCount: number;
  commentCount: number;
  reportCount: number;
  isFeatured: boolean;
  createdAt: Date;
  author: { id: string; name: string; avatarUrl: string | null };
  media: Array<{
    id: string;
    publicUrl: string | null;
    cdnUrl: string | null;
    width: number | null;
    height: number | null;
    thumbnailUrl: string | null;
    blurhash: string | null;
  }>;
  viewerReaction: string | null; // emoji if viewer has reacted
  reactionSummary: Array<{ emoji: string; count: number }>;
  taggedUsers: Array<{ userId: string; name: string; avatarUrl: string | null }>;
}

export interface CreateMemoryInput {
  type: MemoryType;
  caption?: string;
  yearContext?: number;
  contextLabel?: string;
  videoEmbedUrl?: string;
  // S3 keys for uploaded files (up to 10)
  s3Keys: string[];
  taggedUserIds?: string[];
}

// ─── Create a memory post ─────────────────────────────────────────────────────

export async function createMemory(
  eventId: string,
  authorId: string,
  input: CreateMemoryInput
): Promise<{ postId: string; status: ContentStatus }> {
  // Check access
  const [rsvp, committee] = await Promise.all([
    db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId: authorId } },
      select: { status: true },
    }),
    db.committeeMember.findUnique({
      where: { eventId_userId: { eventId, userId: authorId }, revokedAt: null },
      select: { role: true },
    }),
  ]);

  if (!committee && !rsvp) {
    throw new Error("UNAUTHORIZED: You must RSVP to add memories.");
  }

  const event = await db.event.findUnique({
    where: { id: eventId },
    select: { settings: true, title: true },
  });
  if (!event) throw new Error("Event not found.");

  const autoApprove =
    (event.settings as { memoriesAutoApprove?: boolean } | null)
      ?.memoriesAutoApprove ?? false;
  const isOrganizer = !!committee;
  const status: ContentStatus = autoApprove || isOrganizer ? "APPROVED" : "PENDING";

  const post = await db.$transaction(async (tx) => {
    const post = await tx.memoryPost.create({
      data: {
        eventId,
        authorId,
        type: input.type,
        caption: sanitizeText(input.caption),
        yearContext: input.yearContext ?? null,
        contextLabel: sanitizeText(input.contextLabel),
        videoEmbedUrl: input.videoEmbedUrl ?? null,
        status,
        moderatedById: status === "APPROVED" ? authorId : null,
        moderatedAt: status === "APPROVED" ? new Date() : null,
      },
    });

    // Link MediaAsset records to this post and mark them READY
    if (input.s3Keys.length > 0) {
      await tx.mediaAsset.updateMany({
        where: {
          s3Key: { in: input.s3Keys },
          uploadedById: authorId,
          // Allow re-linking in case of retry (memoryPostId null or same)
        },
        data: {
          memoryPostId: post.id,
          eventId,
          status: "READY",
          moderationStatus: status === "APPROVED" ? "APPROVED" : "PENDING",
        },
      });
    }

    // Tag users (respecting their allowPhotoTagging setting)
    if (input.taggedUserIds?.length) {
      const eligible = await tx.attendeeProfile.findMany({
        where: {
          userId: { in: input.taggedUserIds },
          allowPhotoTagging: true,
        },
        select: { userId: true },
      });
      const eligibleIds = eligible.map((e) => e.userId);

      if (eligibleIds.length > 0) {
        await tx.memoryPostTag.createMany({
          data: eligibleIds.map((userId) => ({
            memoryPostId: post.id,
            taggedUserId: userId,
            taggedByUserId: authorId,
            notifiedAt: new Date(),
          })),
          skipDuplicates: true,
        });
      }
    }

    return post;
  });

  await auditLog({
    actorId: authorId,
    action: "MEMORY_CREATED",
    resourceType: "MemoryPost",
    resourceId: post.id,
    eventId,
    metadata: { type: input.type, status, mediaCount: input.s3Keys.length },
  });

  // Notify organizers of new pending memory
  if (status === "PENDING") {
    const organizers = await db.committeeMember.findMany({
      where: {
        eventId,
        role: { in: ["ORGANIZER", "CO_ORGANIZER"] },
        revokedAt: null,
        userId: { not: authorId },
      },
      select: { userId: true },
    });
    await Promise.allSettled(
      organizers.map((o) =>
        createNotification(o.userId, {
          type: "MEMORY_PENDING",
          eventId,
          memoryId: post.id,
        } as any)
      )
    );
  }

  return { postId: post.id, status };
}

// ─── Fetch memory wall posts ──────────────────────────────────────────────────

export async function getMemoryFeed(
  eventId: string,
  viewerId: string | null,
  options: {
    status?: ContentStatus;
    cursor?: string;
    limit?: number;
    featuredOnly?: boolean;
  } = {}
): Promise<{ posts: MemoryPostWithMedia[]; nextCursor: string | null }> {
  const limit = options.limit ?? 20;

  const posts = await db.memoryPost.findMany({
    where: {
      eventId,
      status: options.status ?? "APPROVED",
      deletedAt: null,
      ...(options.featuredOnly ? { isFeatured: true } : {}),
      ...(options.cursor ? { id: { lt: options.cursor } } : {}),
    },
    include: {
      author: { select: { id: true, name: true, avatarUrl: true } },
      media: {
        where: { status: "READY", deletedAt: null },
        select: {
          id: true,
          publicUrl: true,
          cdnUrl: true,
          width: true,
          height: true,
          thumbnailUrl: true,
          blurhash: true,
        },
        orderBy: { createdAt: "asc" },
      },
      reactions: {
        select: { userId: true, emoji: true },
      },
      tags: {
        where: { status: "APPROVED" },
        include: {
          taggedUser: { select: { id: true, name: true, avatarUrl: true } },
        },
      },
    },
    orderBy: [{ isFeatured: "desc" }, { createdAt: "desc" }],
    take: limit,
  });

  const mapped: MemoryPostWithMedia[] = posts.map((post) => {
    // Aggregate reactions
    const emojiCounts = new Map<string, number>();
    for (const r of post.reactions) {
      emojiCounts.set(r.emoji, (emojiCounts.get(r.emoji) ?? 0) + 1);
    }
    const reactionSummary = Array.from(emojiCounts.entries())
      .map(([emoji, count]) => ({ emoji, count }))
      .sort((a, b) => b.count - a.count);

    const viewerReaction =
      viewerId
        ? (post.reactions.find((r) => r.userId === viewerId)?.emoji ?? null)
        : null;

    return {
      id: post.id,
      type: post.type,
      caption: post.caption,
      yearContext: post.yearContext,
      contextLabel: post.contextLabel,
      videoEmbedUrl: post.videoEmbedUrl,
      status: post.status,
      likeCount: post.likeCount,
      commentCount: post.commentCount,
      reportCount: post.reportCount,
      isFeatured: post.isFeatured,
      createdAt: post.createdAt,
      author: post.author,
      media: post.media,
      viewerReaction,
      reactionSummary,
      taggedUsers: post.tags.map((t) => ({
        userId: t.taggedUserId,
        name: (t as any).taggedUser?.name ?? "",
        avatarUrl: (t as any).taggedUser?.avatarUrl ?? null,
      })),
    };
  });

  const nextCursor =
    posts.length === limit ? posts[posts.length - 1]?.id ?? null : null;

  return { posts: mapped, nextCursor };
}

// ─── Toggle reaction ──────────────────────────────────────────────────────────

export async function toggleReaction(
  postId: string,
  userId: string,
  emoji: string
): Promise<{ added: boolean; totalCount: number }> {
  const existing = await db.memoryReaction.findUnique({
    where: { memoryPostId_userId_emoji: { memoryPostId: postId, userId, emoji } },
  });

  if (existing) {
    await db.memoryReaction.delete({ where: { id: existing.id } });
    await db.memoryPost.update({
      where: { id: postId },
      data: { likeCount: { decrement: 1 } },
    });
    const count = await db.memoryReaction.count({ where: { memoryPostId: postId } });
    return { added: false, totalCount: count };
  } else {
    // Remove any existing reaction from this user for this post (one reaction per user)
    await db.memoryReaction.deleteMany({
      where: { memoryPostId: postId, userId },
    });
    await db.memoryReaction.create({
      data: { memoryPostId: postId, userId, emoji },
    });
    await db.memoryPost.update({
      where: { id: postId },
      data: { likeCount: { increment: 1 } },
    });
    const count = await db.memoryReaction.count({ where: { memoryPostId: postId } });
    return { added: true, totalCount: count };
  }
}

// ─── Comments ─────────────────────────────────────────────────────────────────

export async function addComment(
  postId: string,
  authorId: string,
  content: string,
  parentId?: string
): Promise<{ id: string }> {
  const comment = await db.memoryComment.create({
    data: {
      memoryPostId: postId,
      authorId,
      content: content.trim(),
      parentId: parentId ?? null,
      status: "APPROVED",
    },
  });
  await db.memoryPost.update({
    where: { id: postId },
    data: { commentCount: { increment: 1 } },
  });
  return { id: comment.id };
}

export async function getComments(postId: string) {
  return db.memoryComment.findMany({
    where: { memoryPostId: postId, isDeleted: false, status: "APPROVED" },
    include: {
      author: { select: { id: true, name: true, avatarUrl: true } },
    },
    orderBy: { createdAt: "asc" },
    take: 50,
  });
}

// ─── Report ───────────────────────────────────────────────────────────────────

export async function reportMemory(
  postId: string,
  reporterId: string,
  reason: string
): Promise<void> {
  // Idempotency: prevent duplicate reports from the same user
  // Use upsert on a composite key pattern: check AuditLog for prior report
  const alreadyReported = await db.auditLog.findFirst({
    where: {
      actorId: reporterId,
      action: "MEMORY_REPORTED",
      resourceId: postId,
    },
    select: { id: true },
  });

  if (alreadyReported) {
    // Silently succeed — user already reported this, no need to re-increment
    return;
  }

  await db.memoryPost.update({
    where: { id: postId },
    data: {
      reportCount: { increment: 1 },
      flaggedAt: new Date(),
    },
  });

  await auditLog({
    actorId: reporterId,
    action: "MEMORY_REPORTED",
    resourceType: "MemoryPost",
    resourceId: postId,
    metadata: { reason },
  });

  // Auto-hide if reportCount reaches threshold (5 reports)
  const post = await db.memoryPost.findUnique({
    where: { id: postId },
    select: { reportCount: true, status: true },
  });
  if (post && post.reportCount >= 5 && post.status === "APPROVED") {
    await db.memoryPost.update({
      where: { id: postId },
      data: { status: "PENDING" }, // re-queue for moderator review
    });
  }
}

// ─── Feature / unfeature ─────────────────────────────────────────────────────

export async function setFeatured(
  postId: string,
  moderatorId: string,
  featured: boolean
): Promise<void> {
  await db.memoryPost.update({
    where: { id: postId },
    data: { isFeatured: featured },
  });
  await auditLog({
    actorId: moderatorId,
    action: featured ? "MEMORY_FEATURED" : "MEMORY_UNFEATURED",
    resourceType: "MemoryPost",
    resourceId: postId,
  });
}

// ─── Delete (soft) ───────────────────────────────────────────────────────────

export async function deleteMemory(
  postId: string,
  deleterId: string,
  isOrganizer: boolean
): Promise<void> {
  const post = await db.memoryPost.findUnique({
    where: { id: postId },
    select: { authorId: true, eventId: true },
  });
  if (!post) throw new Error("Memory not found.");
  if (!isOrganizer && post.authorId !== deleterId) {
    throw new Error("You can only delete your own memories.");
  }
  await db.memoryPost.update({
    where: { id: postId },
    data: {
      deletedAt: new Date(),
      deletedById: deleterId,
      status: "REMOVED_BY_MOD",
    },
  });
  await auditLog({
    actorId: deleterId,
    action: "MEMORY_DELETED",
    resourceType: "MemoryPost",
    resourceId: postId,
    eventId: post.eventId,
    metadata: { byOrganizer: isOrganizer },
  });
}
