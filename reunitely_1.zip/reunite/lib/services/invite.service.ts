/**
 * lib/services/invite.service.ts
 *
 * Invitation system for the reunion platform.
 *
 * Data flow:
 *   1. Organizer creates invites (manual / CSV / bulk)
 *   2. Deduplication runs against existing invites + RSVPs
 *   3. Invites created in DB with status PENDING
 *   4. Delivery queued → status SENT → DELIVERED (via provider webhook)
 *   5. Recipient opens link → status OPENED
 *   6. Recipient RSVPs → status RSVPD, referral attribution recorded
 *
 * Channels: EMAIL | SMS | WHATSAPP | LINK | QR_CODE
 */

import { db } from "@/lib/db";
import type { InviteChannel, InviteStatus, Prisma } from "@prisma/client";
import { generateInviteToken, getInviteUrl, isValidEmail, isValidE164Phone } from "@/lib/utils";
import { sendInviteEmail, sendBatchInviteEmails } from "@/lib/email";
import { sendInviteSms } from "@/lib/sms/twilio";
import { requireEventPermission } from "@/lib/auth/permissions";
import { auditLog } from "@/lib/audit/log";
import { applyRateLimit } from "@/lib/rate-limit";

// ─── Types ───────────────────────────────────────────────────────────────────

export interface InviteRecipient {
  email?: string;
  phone?: string;
  name?: string;
  /** If set, attributes the invite to a referral link */
  referralCode?: string;
}

export interface BatchInviteInput {
  channel: InviteChannel;
  recipients: InviteRecipient[];
  personalMessage?: string;
  /** Organizer confirmed recipients consented to be contacted */
  consentConfirmed: boolean;
  expiryDays?: number; // default 30
}

export interface BatchInviteResult {
  sent: number;
  skipped: number; // already invited or already RSVP'd
  invalid: number;
  inviteIds: string[];
  skippedReasons: Array<{ recipient: string; reason: string }>;
}

export interface CsvImportResult {
  valid: ParsedCsvRow[];
  invalid: InvalidCsvRow[];
  duplicates: DuplicateCsvRow[];
  total: number;
}

export interface ParsedCsvRow {
  rowIndex: number;
  email?: string;
  phone?: string;
  name?: string;
  raw: Record<string, string>;
}

export interface InvalidCsvRow {
  rowIndex: number;
  raw: Record<string, string>;
  errors: string[];
}

export interface DuplicateCsvRow {
  rowIndex: number;
  email?: string;
  phone?: string;
  name?: string;
  reason: "already_invited" | "already_rsvpd" | "duplicate_in_file";
}

// ─── Core: send batch invites ─────────────────────────────────────────────────

export async function sendBatchInvites(
  eventId: string,
  senderId: string,
  input: BatchInviteInput
): Promise<BatchInviteResult> {
  if (!input.consentConfirmed) {
    throw new Error("Recipient consent must be confirmed before sending invites.");
  }

  await requireEventPermission(senderId, eventId, "invites:manage");

  const event = await db.event.findUniqueOrThrow({
    where: { id: eventId },
    select: {
      id: true,
      title: true,
      slug: true,
      schoolName: true,
      graduationYear: true,
      startAt: true,
      timezone: true,
      venueName: true,
      createdBy: { select: { name: true } },
    },
  });

  const expiryDays = input.expiryDays ?? 30;
  const expiresAt = new Date(Date.now() + expiryDays * 24 * 60 * 60 * 1000);

  const result: BatchInviteResult = {
    sent: 0,
    skipped: 0,
    invalid: 0,
    inviteIds: [],
    skippedReasons: [],
  };

  // ── Build deduplication sets ───────────────────────────────────────────────
  const existingEmails = new Set<string>();
  const existingPhones = new Set<string>();

  // Already invited
  const existingInvites = await db.invite.findMany({
    where: {
      eventId,
      status: { notIn: ["EXPIRED", "BOUNCED"] },
    },
    select: { email: true, phone: true },
  });
  existingInvites.forEach((inv) => {
    if (inv.email) existingEmails.add(inv.email.toLowerCase());
    if (inv.phone) existingPhones.add(inv.phone);
  });

  // Already RSVP'd (via user email)
  const rsvpdUsers = await db.rSVP.findMany({
    where: {
      eventId,
      status: { notIn: ["CANCELLED", "DECLINED"] },
    },
    include: { user: { select: { email: true } } },
  });
  rsvpdUsers.forEach((r) => {
    if (r.user.email) existingEmails.add(r.user.email.toLowerCase());
  });

  // ── Track emails seen in this batch for dedup within batch ─────────────────
  const seenInBatch = new Set<string>();

  // ── Lookup referral links ──────────────────────────────────────────────────
  const referralCodes = input.recipients
    .map((r) => r.referralCode)
    .filter(Boolean) as string[];
  const referralLinks =
    referralCodes.length > 0
      ? await db.referralLink.findMany({
          where: { code: { in: referralCodes }, eventId, isActive: true },
        })
      : [];
  const referralMap = new Map(referralLinks.map((r) => [r.code, r]));

  // ── Process each recipient ─────────────────────────────────────────────────
  const emailBatch: Array<{
    invite: typeof input.recipients[0] & { token: string; inviteId: string };
  }> = [];

  for (const recipient of input.recipients) {
    const key = recipient.email?.toLowerCase() || recipient.phone || "";

    // Validate
    const errors: string[] = [];
    if (input.channel === "EMAIL" || recipient.email) {
      if (!recipient.email || !isValidEmail(recipient.email)) {
        errors.push("Invalid email address");
      }
    }
    if (input.channel === "SMS" || input.channel === "WHATSAPP") {
      if (!recipient.phone || !isValidE164Phone(recipient.phone)) {
        errors.push("Invalid phone number (must be E.164 format, e.g. +12125551234)");
      }
    }
    if (!recipient.email && !recipient.phone) {
      errors.push("Either email or phone is required");
    }

    if (errors.length > 0) {
      result.invalid++;
      result.skippedReasons.push({
        recipient: key || "unknown",
        reason: errors.join("; "),
      });
      continue;
    }

    // Deduplication
    const emailKey = recipient.email?.toLowerCase();
    const phoneKey = recipient.phone;

    if (emailKey && (existingEmails.has(emailKey) || seenInBatch.has(emailKey))) {
      result.skipped++;
      result.skippedReasons.push({
        recipient: emailKey,
        reason: existingEmails.has(emailKey)
          ? "Already invited or RSVP'd"
          : "Duplicate in this batch",
      });
      continue;
    }
    if (phoneKey && (existingPhones.has(phoneKey) || seenInBatch.has(phoneKey))) {
      result.skipped++;
      result.skippedReasons.push({
        recipient: phoneKey,
        reason: existingPhones.has(phoneKey)
          ? "Already invited"
          : "Duplicate in this batch",
      });
      continue;
    }

    // Mark as seen in this batch
    if (emailKey) seenInBatch.add(emailKey);
    if (phoneKey) seenInBatch.add(phoneKey);

    // Create invite record
    try {
      const token = generateInviteToken();
      const referralLink = recipient.referralCode
        ? referralMap.get(recipient.referralCode)
        : null;

      const invite = await db.invite.create({
        data: {
          eventId,
          invitedById: senderId,
          token,
          email: emailKey ?? null,
          phone: phoneKey ?? null,
          channel: input.channel,
          status: "SENT",
          sentAt: new Date(),
          expiresAt,
          personalMessage: input.personalMessage ?? null,
          recipientConsentConfirmed: true,
          consentConfirmedAt: new Date(),
          referralLinkId: referralLink?.id ?? null,
        },
      });

      result.inviteIds.push(invite.id);

      // Queue delivery record
      await db.inviteDelivery.create({
        data: {
          inviteId: invite.id,
          channel: input.channel,
          status: "SENDING",
          sentAt: new Date(),
        },
      });

      // Batch email or send immediately for SMS/WhatsApp
      if (input.channel === "EMAIL" && emailKey) {
        emailBatch.push({
          invite: { ...recipient, token, inviteId: invite.id },
        });
        if (emailKey) existingEmails.add(emailKey);
      } else if (input.channel === "SMS" && phoneKey) {
        await sendInviteSms({
          to: phoneKey,
          inviteUrl: getInviteUrl(token),
          eventTitle: event.title,
          organizerName: event.createdBy.name,
        }).catch(async (err) => {
          await db.inviteDelivery.updateMany({
            where: { inviteId: invite.id },
            data: { status: "FAILED", failedAt: new Date(), failureReason: String(err) },
          });
        });
        if (phoneKey) existingPhones.add(phoneKey);
      }

      result.sent++;
    } catch (err) {
      result.invalid++;
      result.skippedReasons.push({
        recipient: key,
        reason: "Failed to create invite record",
      });
    }
  }

  // ── Send email batch ───────────────────────────────────────────────────────
  if (emailBatch.length > 0) {
    try {
      await sendBatchInviteEmails(
        emailBatch.map(({ invite }) => ({
          to: invite.email!,
          inviteToken: invite.token,
          eventTitle: event.title,
          eventSlug: event.slug,
          organizerName: event.createdBy.name,
          schoolName: event.schoolName,
          graduationYear: event.graduationYear,
          startAt: event.startAt,
          timezone: event.timezone,
          personalMessage: input.personalMessage,
        }))
      );

      // Mark deliveries as delivered (optimistic — webhook will correct if failed)
      await db.inviteDelivery.updateMany({
        where: {
          inviteId: { in: emailBatch.map((b) => b.invite.inviteId) },
        },
        data: { status: "DELIVERED", deliveredAt: new Date() },
      });
    } catch (err) {
      console.error("[InviteService] Batch email failed:", err);
      // Update individual delivery records
      await db.inviteDelivery.updateMany({
        where: { inviteId: { in: emailBatch.map((b) => b.invite.inviteId) } },
        data: { status: "FAILED", failedAt: new Date(), failureReason: "Batch email failed" },
      });
    }
  }

  // ── Update referral link click counts ──────────────────────────────────────
  if (referralLinks.length > 0) {
    await Promise.all(
      referralLinks.map((rl) =>
        db.referralLink.update({
          where: { id: rl.id },
          data: { rsvpCount: { increment: 0 } }, // incremented on actual RSVP
        })
      )
    );
  }

  await auditLog({
    actorId: senderId,
    action: "INVITE_SENT",
    resourceType: "Event",
    resourceId: eventId,
    eventId,
    metadata: {
      channel: input.channel,
      sent: result.sent,
      skipped: result.skipped,
      invalid: result.invalid,
    },
  });

  return result;
}

// ─── Resend invite ────────────────────────────────────────────────────────────

export async function resendInvite(
  inviteId: string,
  senderId: string
): Promise<void> {
  const invite = await db.invite.findUniqueOrThrow({
    where: { id: inviteId },
    include: {
      event: {
        select: {
          id: true,
          title: true,
          slug: true,
          schoolName: true,
          graduationYear: true,
          startAt: true,
          timezone: true,
          createdBy: { select: { name: true } },
        },
      },
    },
  });

  await requireEventPermission(senderId, invite.eventId, "invites:manage");

  if (invite.status === "RSVPD") {
    throw new Error("This person has already RSVP'd — no need to resend.");
  }

  // Extend expiry
  const newExpiry = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

  await db.invite.update({
    where: { id: inviteId },
    data: {
      status: "SENT",
      sentAt: new Date(),
      expiresAt: newExpiry,
    },
  });

  // New delivery record for tracking
  await db.inviteDelivery.create({
    data: {
      inviteId,
      channel: invite.channel,
      status: "SENDING",
      sentAt: new Date(),
      attemptNumber:
        (await db.inviteDelivery.count({ where: { inviteId } })) + 1,
    },
  });

  if (invite.channel === "EMAIL" && invite.email) {
    await sendInviteEmail({
      to: invite.email,
      inviteToken: invite.token,
      eventTitle: invite.event.title,
      eventSlug: invite.event.slug,
      organizerName: invite.event.createdBy.name,
      schoolName: invite.event.schoolName,
      graduationYear: invite.event.graduationYear,
      startAt: invite.event.startAt,
      timezone: invite.event.timezone,
      personalMessage: invite.personalMessage ?? undefined,
    });
  } else if (invite.channel === "SMS" && invite.phone) {
    await sendInviteSms({
      to: invite.phone,
      inviteUrl: getInviteUrl(invite.token),
      eventTitle: invite.event.title,
      organizerName: invite.event.createdBy.name,
    });
  }

  await auditLog({
    actorId: senderId,
    action: "INVITE_RESENT",
    resourceType: "Invite",
    resourceId: inviteId,
    eventId: invite.eventId,
  });
}

// ─── CSV parsing and validation ───────────────────────────────────────────────

export async function parseCsvForImport(
  csvText: string,
  eventId: string
): Promise<CsvImportResult> {
  const lines = csvText.trim().split(/\r?\n/);
  if (lines.length < 2) {
    return { valid: [], invalid: [], duplicates: [], total: 0 };
  }

  // Flexible header detection
  const rawHeaders = lines[0]!.split(",").map((h) =>
    h.trim().toLowerCase().replace(/[^a-z0-9]/g, "_").replace(/_+/g, "_")
  );

  const headerMap = detectHeaders(rawHeaders);

  // Pre-load deduplication data
  const existingInvites = await db.invite.findMany({
    where: { eventId, status: { notIn: ["EXPIRED", "BOUNCED"] } },
    select: { email: true, phone: true },
  });
  const rsvpdEmails = await db.rSVP.findMany({
    where: { eventId, status: { notIn: ["CANCELLED", "DECLINED"] } },
    include: { user: { select: { email: true } } },
  });

  const existingEmailSet = new Set([
    ...existingInvites.map((i) => i.email?.toLowerCase()).filter(Boolean),
    ...rsvpdEmails.map((r) => r.user.email.toLowerCase()),
  ] as string[]);
  const existingPhoneSet = new Set(
    existingInvites.map((i) => i.phone).filter(Boolean) as string[]
  );

  const valid: ParsedCsvRow[] = [];
  const invalid: InvalidCsvRow[] = [];
  const duplicates: DuplicateCsvRow[] = [];
  const seenInFile = new Set<string>();

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i]?.trim();
    if (!line) continue;

    const cols = parseCsvLine(line);
    const raw: Record<string, string> = {};
    rawHeaders.forEach((h, idx) => {
      raw[h] = cols[idx]?.trim() ?? "";
    });

    const email = headerMap.email !== -1
      ? cols[headerMap.email]?.trim().toLowerCase()
      : undefined;
    const phone = headerMap.phone !== -1
      ? normalizePhone(cols[headerMap.phone]?.trim())
      : undefined;
    const name = headerMap.name !== -1
      ? cols[headerMap.name]?.trim()
      : undefined;

    const rowErrors: string[] = [];

    if (email && !isValidEmail(email)) rowErrors.push("Invalid email address");
    if (phone && !isValidE164Phone(phone)) rowErrors.push("Phone must be E.164 format (e.g. +12125551234)");
    if (!email && !phone) rowErrors.push("Either email or phone is required");

    if (rowErrors.length > 0) {
      invalid.push({ rowIndex: i, raw, errors: rowErrors });
      continue;
    }

    // Check for duplicates in file
    const key = email || phone!;
    if (seenInFile.has(key)) {
      duplicates.push({ rowIndex: i, email, phone, name, reason: "duplicate_in_file" });
      continue;
    }
    seenInFile.add(key);

    // Check against existing invites / RSVPs
    if (email && existingEmailSet.has(email)) {
      duplicates.push({ rowIndex: i, email, phone, name, reason: "already_invited" });
      continue;
    }
    if (phone && existingPhoneSet.has(phone)) {
      duplicates.push({ rowIndex: i, email, phone, name, reason: "already_invited" });
      continue;
    }

    valid.push({ rowIndex: i, email, phone, name, raw });
  }

  return { valid, invalid, duplicates, total: lines.length - 1 };
}

// ─── Referral link management ─────────────────────────────────────────────────

export async function createReferralLink(
  eventId: string,
  creatorId: string,
  label?: string,
  expiryDays?: number
): Promise<{ code: string; url: string }> {
  await requireEventPermission(creatorId, eventId, "invites:manage");

  const code = generateReferralCode();
  const expiresAt = expiryDays
    ? new Date(Date.now() + expiryDays * 24 * 60 * 60 * 1000)
    : null;

  await db.referralLink.create({
    data: {
      eventId,
      createdById: creatorId,
      code,
      label: label ?? null,
      expiresAt,
    },
  });

  const url = `${process.env.NEXT_PUBLIC_APP_URL}/r/${code}`;
  return { code, url };
}

export async function getReferralLinks(eventId: string) {
  return db.referralLink.findMany({
    where: { eventId },
    include: {
      createdBy: { select: { name: true, avatarUrl: true } },
      _count: { select: { invites: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function trackReferralClick(code: string): Promise<string | null> {
  const link = await db.referralLink.findUnique({
    where: { code, isActive: true },
    select: { id: true, eventId: true, expiresAt: true, event: { select: { slug: true } } },
  });

  if (!link) return null;
  if (link.expiresAt && link.expiresAt < new Date()) return null;

  await db.referralLink.update({
    where: { id: link.id },
    data: { clickCount: { increment: 1 } },
  });

  return link.event.slug;
}

export async function attributeReferral(
  referralCode: string,
  userId: string
): Promise<void> {
  const link = await db.referralLink.findUnique({
    where: { code: referralCode, isActive: true },
    select: { id: true, eventId: true },
  });

  if (!link) return;

  await db.referralLink.update({
    where: { id: link.id },
    data: { rsvpCount: { increment: 1 } },
  });

  // Update invite if one exists
  await db.invite.updateMany({
    where: { referralLinkId: link.id, eventId: link.eventId },
    data: { status: "RSVPD", rsvpdAt: new Date() },
  }).catch(() => {}); // non-fatal
}

// ─── Track invite open / click ────────────────────────────────────────────────

export async function trackInviteOpen(token: string): Promise<string | null> {
  const invite = await db.invite.findUnique({
    where: { token },
    select: { id: true, eventId: true, openedAt: true, status: true, event: { select: { slug: true } } },
  });

  if (!invite || invite.status === "EXPIRED") return null;

  if (!invite.openedAt) {
    await db.invite.update({
      where: { id: invite.id },
      data: { openedAt: new Date(), status: "OPENED" },
    }).catch(() => {});
  }

  return invite.event.slug;
}

// ─── Delivery webhook update (from Resend/Twilio webhooks) ───────────────────

export async function updateDeliveryStatus(
  providerMsgId: string,
  status: "DELIVERED" | "FAILED" | "BOUNCED",
  reason?: string
): Promise<void> {
  const delivery = await db.inviteDelivery.findFirst({
    where: { providerMsgId },
    select: { id: true, inviteId: true },
  });

  if (!delivery) return;

  await db.$transaction([
    db.inviteDelivery.update({
      where: { id: delivery.id },
      data: {
        status,
        ...(status === "DELIVERED" && { deliveredAt: new Date() }),
        ...(status === "FAILED" || status === "BOUNCED"
          ? { failedAt: new Date(), failureReason: reason }
          : {}),
      },
    }),
    db.invite.update({
      where: { id: delivery.inviteId },
      data: {
        status:
          status === "DELIVERED"
            ? "DELIVERED"
            : status === "BOUNCED"
            ? "BOUNCED"
            : undefined,
        ...(status === "DELIVERED" && { deliveredAt: new Date() }),
      },
    }),
  ]);
}

// ─── Reminder workflow ────────────────────────────────────────────────────────

/**
 * Get invites eligible for reminder (sent > N days ago, not yet RSVP'd)
 * Used by cron job at /api/cron/send-reminders
 */
export async function getRemindableInvites(
  eventId: string,
  daysSinceSent: number = 7,
  limit: number = 200
) {
  const cutoffDate = new Date(Date.now() - daysSinceSent * 24 * 60 * 60 * 1000);

  return db.invite.findMany({
    where: {
      eventId,
      status: { in: ["SENT", "DELIVERED", "OPENED"] },
      sentAt: { lte: cutoffDate },
      expiresAt: { gt: new Date() },
    },
    orderBy: { sentAt: "asc" },
    take: limit,
  });
}

// ─── Invite statistics ────────────────────────────────────────────────────────

export async function getInviteStats(eventId: string) {
  const [byStatus, byChannel, referralPerformance] = await Promise.all([
    db.invite.groupBy({
      by: ["status"],
      where: { eventId },
      _count: { status: true },
    }),
    db.invite.groupBy({
      by: ["channel"],
      where: { eventId },
      _count: { channel: true },
    }),
    db.referralLink.findMany({
      where: { eventId },
      select: { code: true, label: true, clickCount: true, rsvpCount: true },
      orderBy: { rsvpCount: "desc" },
    }),
  ]);

  const statusCounts: Record<string, number> = {};
  byStatus.forEach((r) => { statusCounts[r.status] = r._count.status; });

  const channelCounts: Record<string, number> = {};
  byChannel.forEach((r) => { channelCounts[r.channel] = r._count.channel; });

  const total = Object.values(statusCounts).reduce((a, b) => a + b, 0);
  const rsvpdCount = statusCounts["RSVPD"] ?? 0;
  const conversionRate = total > 0 ? Math.round((rsvpdCount / total) * 100) : 0;

  return {
    total,
    byStatus: statusCounts,
    byChannel: channelCounts,
    conversionRate,
    referralPerformance,
  };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function detectHeaders(headers: string[]): Record<string, number> {
  const map: Record<string, number> = { email: -1, phone: -1, name: -1 };

  const emailPatterns = ["email", "email_address", "e_mail", "mail"];
  const phonePatterns = ["phone", "mobile", "cell", "phone_number", "mobile_number", "tel"];
  const namePatterns = ["name", "full_name", "first_name", "display_name", "contact_name"];

  headers.forEach((h, idx) => {
    if (emailPatterns.some((p) => h.includes(p))) map["email"] = idx;
    else if (phonePatterns.some((p) => h.includes(p))) map["phone"] = idx;
    else if (namePatterns.some((p) => h.includes(p))) map["name"] = idx;
  });

  // Fallback: if no email header detected, try first column if it looks like email
  if (map["email"] === -1 && headers[0]) map["email"] = 0;

  return map;
}

function parseCsvLine(line: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === "," && !inQuotes) {
      result.push(current);
      current = "";
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}

function normalizePhone(raw?: string): string | undefined {
  if (!raw) return undefined;
  // Strip spaces, dashes, parens. If starts with a digit (not +), prepend +1 (US default).
  const stripped = raw.replace(/[\s\-().]/g, "");
  if (!stripped) return undefined;
  if (!stripped.startsWith("+")) {
    return "+" + stripped.replace(/^0+/, "1");
  }
  return stripped;
}

function generateReferralCode(): string {
  const chars = "abcdefghijkmnpqrstuvwxyz23456789";
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}
