import { db } from "@/lib/db";
import type { BroadcastChannel, RSVPStatus } from "@prisma/client";
import { sendEmailBatch } from "@/lib/email";
import { sendSmsBatch } from "@/lib/sms/twilio";
import { auditLog } from "@/lib/audit/log";
import { requireEventPermission } from "@/lib/auth/permissions";
import type { CreateBroadcastInput } from "@/schemas";

// ─── Types ───────────────────────────────────────────────────────────────────

interface AudienceFilter {
  statuses?: RSVPStatus[];
}

// ─── Create broadcast (draft) ─────────────────────────────────────────────────

export async function createBroadcast(
  eventId: string,
  userId: string,
  input: CreateBroadcastInput
) {
  await requireEventPermission(userId, eventId, "messages:broadcast");

  return db.broadcast.create({
    data: {
      eventId,
      createdById: userId,
      subject: input.subject,
      body: input.body as object,
      channel: input.channel as BroadcastChannel,
      audienceFilter: input.audienceFilter as object,
      status: "DRAFT",
    },
  });
}

// ─── Send broadcast ───────────────────────────────────────────────────────────

export async function sendBroadcast(
  broadcastId: string,
  userId: string
): Promise<{ sent: number; failed: number }> {
  const broadcast = await db.broadcast.findUniqueOrThrow({
    where: { id: broadcastId },
    include: {
      event: { select: { id: true, title: true, slug: true } },
    },
  });

  await requireEventPermission(userId, broadcast.eventId, "messages:broadcast");

  if (broadcast.status === "SENT" || broadcast.status === "SENDING") {
    throw new Error("Broadcast already sent or in progress");
  }

  // Mark as sending
  await db.broadcast.update({
    where: { id: broadcastId },
    data: { status: "SENDING" },
  });

  const filter = broadcast.audienceFilter as AudienceFilter;
  const statusFilter = filter.statuses ?? ["CONFIRMED"];

  // Resolve recipients
  const memberships = await db.rSVP.findMany({
    where: {
      eventId: broadcast.eventId,
      status: { in: statusFilter as RSVPStatus[] },
      // Enforce channel consent
      ...(broadcast.channel === "EMAIL" ? { consentEmail: true } : {}),
      ...(broadcast.channel === "SMS" ? { consentSms: true } : {}),
      ...(broadcast.channel === "WHATSAPP" ? { consentWhatsApp: true } : {}),
    },
    include: {
      user: { select: { id: true, name: true, email: true } },
    },
  });

  let sent = 0;
  let failed = 0;

  try {
    if (broadcast.channel === "EMAIL") {
      const bodyHtml = renderBroadcastBodyToHtml(
        broadcast.body as Record<string, unknown>
      );
      const subject = broadcast.subject ?? `Message from your event organizer`;

      const emails = memberships.map((m) => ({
        to: m.user.email,
        subject,
        html: bodyHtml,
        text: extractPlainText(broadcast.body as Record<string, unknown>),
      }));

      const result = await sendEmailBatch(emails);
      sent = result.sent;
      failed = result.failed;
    } else if (broadcast.channel === "SMS") {
      // Fetch users who have a phone number on file
      const usersWithPhone = await db.user.findMany({
        where: {
          id: { in: memberships.map((m) => m.userId) },
          phone: { not: null },
        },
        select: { id: true, phone: true },
      });

      const bodyText = extractPlainText(broadcast.body as Record<string, unknown>);
      const smsMessages = usersWithPhone
        .filter((u): u is typeof u & { phone: string } => !!u.phone)
        .map((u) => ({ to: u.phone, body: bodyText.slice(0, 1600) }));

      if (smsMessages.length > 0) {
        const result = await sendSmsBatch(smsMessages);
        sent = result.sent;
        failed = result.failed;
      }
    } else if (broadcast.channel === "WHATSAPP") {
      // WhatsApp requires pre-approved templates and TWILIO_WHATSAPP_FROM configured.
      // Fall back to SMS text delivery if WhatsApp is not configured.
      const { getEnv } = await import("@/env");
      const env = getEnv();

      const usersWithPhone = await db.user.findMany({
        where: {
          id: { in: memberships.map((m) => m.userId) },
          phone: { not: null },
          rsvps: {
            some: {
              eventId: broadcast.eventId,
              consentWhatsApp: true,
            },
          },
        },
        select: { id: true, phone: true },
      });

      const bodyText = extractPlainText(broadcast.body as Record<string, unknown>);

      if (env.TWILIO_WHATSAPP_FROM && usersWithPhone.length > 0) {
        // Use SMS helper (sendSms supports whatsapp: prefix via sendWhatsApp)
        const { sendSmsBatch: sendWaBatch } = await import("@/lib/sms/twilio");
        const waMessages = usersWithPhone
          .filter((u): u is typeof u & { phone: string } => !!u.phone)
          .map((u) => ({ to: u.phone, body: bodyText.slice(0, 1600) }));
        const result = await sendWaBatch(waMessages);
        sent = result.sent;
        failed = result.failed;
      } else {
        // No WhatsApp configured — count as skipped (not failed)
        sent = 0;
        failed = 0;
      }
    }
  } catch (err) {
    await db.broadcast.update({
      where: { id: broadcastId },
      data: { status: "FAILED" },
    });
    throw err;
  }

  // Mark as sent
  await db.broadcast.update({
    where: { id: broadcastId },
    data: {
      status: "SENT",
      sentAt: new Date(),
      recipientCount: sent,
    },
  });

  await auditLog({
    actorId: userId,
    action: "BROADCAST_SENT",
    resourceType: "Broadcast",
    resourceId: broadcastId,
    eventId: broadcast.eventId,
    metadata: {
      channel: broadcast.channel,
      recipientCount: sent,
      failedCount: failed,
    },
  });

  return { sent, failed };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function renderBroadcastBodyToHtml(body: Record<string, unknown>): string {
  // Tiptap JSON → HTML conversion (simplified)
  // In production use @tiptap/html or tiptap's generateHTML()
  try {
    const content = (body as { content?: Array<{ type: string; content?: Array<{ type: string; text?: string }> }> }).content;
    if (!Array.isArray(content)) return "<p>Message from your organizer.</p>";

    return content
      .map((node) => {
        if (node.type === "paragraph") {
          const text = node.content
            ?.map((c) => c.text ?? "")
            .join("") ?? "";
          return `<p style="margin: 0 0 16px; color: #334155;">${escapeHtml(text)}</p>`;
        }
        if (node.type === "heading") {
          const text = node.content
            ?.map((c) => c.text ?? "")
            .join("") ?? "";
          return `<h2 style="margin: 0 0 12px; font-weight: 700; color: #0F172A;">${escapeHtml(text)}</h2>`;
        }
        return "";
      })
      .join("");
  } catch {
    return "<p>Message from your organizer.</p>";
  }
}

function extractPlainText(body: Record<string, unknown>): string {
  try {
    const content = (body as { content?: Array<{ content?: Array<{ text?: string }> }> }).content;
    if (!Array.isArray(content)) return "";
    return content
      .flatMap((node) => node.content ?? [])
      .map((c) => c.text ?? "")
      .join("\n")
      .trim();
  } catch {
    return "";
  }
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
