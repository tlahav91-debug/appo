import { db } from "@/lib/db";
import {
  type Event,
  
  EventStatus,
  type Prisma,
} from "@prisma/client";
import { generateUniqueSlug } from "@/lib/utils";
import {
  cacheGet,
  cacheSet,
  cacheDelete,
  cacheKeys,
  TTL,
} from "@/lib/cache/redis";
import { auditLog } from "@/lib/audit/log";
import { requireEventPermission } from "@/lib/auth/permissions";

// ─── Types ───────────────────────────────────────────────────────────────────

export type PublicEvent = Event & {
  _count: { rsvps: number };
  createdBy: { name: string; avatarUrl: string | null };
  theme: {
    primaryColor: string;
    accentColor: string;
    headerLayout: string;
  } | null;
};

export type EventWithOrganizer = Event & {
  createdBy: { name: string; avatarUrl: string | null; clerkId: string };
  _count: { memberships: number; memories: number };
};

export type EventStats = {
  id: string;
  status: EventStatus;
  totalRsvps: number;
  confirmedCount: number;
  declinedCount: number;
  pendingCount: number;
  waitlistCount: number;
  checkedInCount: number;
  totalRevenueCents: number;
  pageViews: number; // from PostHog or Redis counter
};

export type CreateEventInput = {
  title: string;
  schoolName: string;
  schoolCity?: string;
  schoolCountry?: string;
  graduationYear: number;
  classSections?: string[];
  startAt: Date;
  endAt?: Date;
  timezone: string;
  venueName?: string;
  venueAddress?: string;
  description?: Prisma.InputJsonValue;
  coverImageUrl?: string;
  capacity?: number;
  waitlistEnabled?: boolean;
  ticketingEnabled?: boolean;
  organizationId?: string;
};

export type UpdateEventInput = Partial<CreateEventInput> & {
  settings?: Prisma.InputJsonValue;
};

// ─── Read ─────────────────────────────────────────────────────────────────────

export async function getPublicEvent(
  slug: string
): Promise<PublicEvent | null> {
  const cacheKey = cacheKeys.event(slug);
  const cached = await cacheGet<PublicEvent>(cacheKey);
  if (cached) return cached;

  const event = await db.event.findFirst({
    where: { slug, status: EventStatus.PUBLISHED },
    include: {
      createdBy: { select: { name: true, avatarUrl: true } },
      theme: { select: { primaryColor: true, accentColor: true, headerLayout: true } },
      _count: {
        select: {
          rsvps: { where: { status: "CONFIRMED" } },
        },
      },
    },
  });

  if (event) {
    await cacheSet(cacheKey, event, TTL.MEDIUM);
  }

  return event;
}

export async function getEventForOrganizer(
  id: string,
  userId: string
): Promise<EventWithOrganizer | null> {
  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId: id, userId }, revokedAt: null },
    select: { role: true },
  });

  const isManager =
    committee?.role === "ORGANIZER" ||
    committee?.role === "CO_ORGANIZER";

  if (!isManager) return null;

  return db.event.findUnique({
    where: { id },
    include: {
      createdBy: {
        select: { name: true, avatarUrl: true, clerkId: true },
      },
      _count: { select: { memberships: true, memories: true } },
    },
  });
}

export async function listUserEvents(
  userId: string
): Promise<EventWithOrganizer[]> {
  // New schema uses CommitteeMember instead of EventMembership
  const committeeRoles = await db.committeeMember.findMany({
    where: {
      userId,
      revokedAt: null,
      role: { in: ["ORGANIZER", "CO_ORGANIZER"] },
    },
    select: { eventId: true },
    orderBy: { addedAt: "desc" },
  });

  const eventIds = committeeRoles.map((m) => m.eventId);

  return db.event.findMany({
    where: {
      id: { in: eventIds },
      status: { not: "ARCHIVED" },
    },
    include: {
      createdBy: {
        select: { name: true, avatarUrl: true, clerkId: true },
      },
      _count: { select: { rsvps: true, memoryPosts: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function getEventStats(
  eventId: string,
  userId: string
): Promise<EventStats | null> {
  // Permission check
  const committee = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId, userId }, revokedAt: null },
    select: { role: true },
  });
  const canView =
    committee?.role === "ORGANIZER" ||
    committee?.role === "CO_ORGANIZER";
  if (!canView) return null;

  const cacheKey = cacheKeys.eventStats(eventId);
  const cached = await cacheGet<EventStats>(cacheKey);
  if (cached) return cached;

  const [event, statusCounts, revenue] = await Promise.all([
    db.event.findUnique({ where: { id: eventId }, select: { id: true, status: true } }),
    db.rSVP.groupBy({
      by: ["status"],
      where: { eventId },
      _count: { status: true },
    }),
    db.payment.aggregate({
      where: { eventId, status: "PAID" },
      _sum: { totalAmountCents: true },
    }),
  ]);

  if (!event) return null;

  // Also get checked-in count from CheckIn model
  const checkedInCount = await db.checkIn.count({
    where: { eventId, status: "CHECKED_IN" },
  });

  const countByStatus: Record<string, number> = {};
  statusCounts.forEach((s) => {
    countByStatus[s.status] = s._count.status;
  });

  const stats: EventStats = {
    id: eventId,
    status: event.status,
    totalRsvps:
      (countByStatus["CONFIRMED"] ?? 0) +
      (countByStatus["PENDING"] ?? 0) +
      (countByStatus["DECLINED"] ?? 0) +
      (countByStatus["WAITLISTED"] ?? 0),
    confirmedCount: countByStatus["CONFIRMED"] ?? 0,
    declinedCount: countByStatus["DECLINED"] ?? 0,
    pendingCount: countByStatus["PENDING"] ?? 0,
    waitlistCount: countByStatus["WAITLISTED"] ?? 0,
    checkedInCount,
    totalRevenueCents: revenue._sum.totalAmountCents ?? 0,
    pageViews: 0, // Populated from PostHog separately
  };

  await cacheSet(cacheKey, stats, TTL.SHORT);
  return stats;
}

// ─── Write ───────────────────────────────────────────────────────────────────

export async function createEvent(
  userId: string,
  input: CreateEventInput
): Promise<Event> {
  const slug = await generateAvailableSlug(
    `${input.schoolName} ${input.graduationYear}`
  );

  const event = await db.$transaction(async (tx) => {
    const newEvent = await tx.event.create({
      data: {
        ...input,
        slug,
        status: EventStatus.DRAFT,
        createdById: userId,
        classSections: input.classSections ?? [],
        settings: {},
      },
    });

    // Creator automatically becomes ORGANIZER
    await tx.committeeMember.create({
      data: {
        eventId: newEvent.id,
        userId,
        role: "ORGANIZER",
        title: "Lead Organizer",
        canManageRsvps: true,
        canSendMessages: true,
        canModerateContent: true,
        canManageTickets: true,
        canViewPayments: true,
        canCheckIn: true,
        addedByUserId: userId,
        status: "CONFIRMED",
        consentEmail: true,
      },
    });

    return newEvent;
  });

  await auditLog({
    actorId: userId,
    action: "EVENT_CREATED",
    resourceType: "Event",
    resourceId: event.id,
    eventId: event.id,
  });

  return event;
}

export async function updateEvent(
  eventId: string,
  userId: string,
  input: UpdateEventInput
): Promise<Event> {
  await requireEventPermission(userId, eventId, "event:update");

  // Deep-merge settings so a partial patch (e.g. { settings: { classSize: 200 } })
  // doesn't clobber other existing settings keys.
  let data: typeof input = input;
  if (input.settings) {
    const existing = await db.event.findUnique({
      where: { id: eventId },
      select: { settings: true },
    });
    data = {
      ...input,
      settings: {
        ...(existing?.settings as Record<string, unknown> ?? {}),
        ...(input.settings as Record<string, unknown>),
      },
    };
  }

  const event = await db.event.update({
    where: { id: eventId },
    data,
  });

  // Invalidate caches
  await cacheDelete(cacheKeys.event(event.slug));
  await cacheDelete(cacheKeys.eventStats(eventId));

  await auditLog({
    actorId: userId,
    action: "EVENT_UPDATED",
    resourceType: "Event",
    resourceId: eventId,
    eventId,
    metadata: { updatedFields: Object.keys(input) },
  });

  return event;
}

export async function publishEvent(
  eventId: string,
  userId: string
): Promise<Event> {
  await requireEventPermission(userId, eventId, "event:publish");

  const event = await db.event.update({
    where: { id: eventId },
    data: { status: EventStatus.PUBLISHED },
  });

  await cacheDelete(cacheKeys.event(event.slug));

  await auditLog({
    actorId: userId,
    action: "EVENT_PUBLISHED",
    resourceType: "Event",
    resourceId: eventId,
    eventId,
  });

  return event;
}

export async function archiveEvent(
  eventId: string,
  userId: string
): Promise<Event> {
  await requireEventPermission(userId, eventId, "event:delete");

  const event = await db.event.update({
    where: { id: eventId },
    data: { status: EventStatus.ARCHIVED },
  });

  await cacheDelete(cacheKeys.event(event.slug));

  await auditLog({
    actorId: userId,
    action: "EVENT_ARCHIVED",
    resourceType: "Event",
    resourceId: eventId,
    eventId,
  });

  return event;
}

export async function cloneEvent(
  eventId: string,
  userId: string,
  overrides: Partial<CreateEventInput> = {}
): Promise<Event> {
  await requireEventPermission(userId, eventId, "event:update");

  const source = await db.event.findUniqueOrThrow({ where: { id: eventId } });
  const slug = await generateAvailableSlug(`${source.title} copy`);

  const cloned = await db.$transaction(async (tx) => {
    const newEvent = await tx.event.create({
      data: {
        title: `${source.title} (Copy)`,
        schoolName: source.schoolName,
        schoolCity: source.schoolCity,
        schoolCountry: source.schoolCountry,
        graduationYear: source.graduationYear,
        classSections: source.classSections,
        timezone: source.timezone,
        description: source.description ?? Prisma.JsonNull,
        coverImageUrl: source.coverImageUrl,
        capacity: source.capacity,
        waitlistEnabled: source.waitlistEnabled,
        ticketingEnabled: source.ticketingEnabled,
        settings: source.settings ?? {},
        slug,
        status: EventStatus.DRAFT,
        createdById: userId,
        startAt: new Date(), // Must be overridden
        ...overrides,
      },
    });

    await tx.committeeMember.create({
      data: {
        eventId: newEvent.id,
        userId,
        role: "ORGANIZER",
        title: "Lead Organizer",
        canManageRsvps: true,
        canSendMessages: true,
        canModerateContent: true,
        canManageTickets: true,
        canViewPayments: true,
        canCheckIn: true,
        addedByUserId: userId,
        status: "CONFIRMED",
        consentEmail: true,
      },
    });

    return newEvent;
  });

  await auditLog({
    actorId: userId,
    action: "EVENT_CLONED",
    resourceType: "Event",
    resourceId: cloned.id,
    eventId: cloned.id,
    metadata: { sourceEventId: eventId },
  });

  return cloned;
}

// ─── Internal helpers ─────────────────────────────────────────────────────────

async function generateAvailableSlug(base: string): Promise<string> {
  const baseSlug = base
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .slice(0, 40);

  // Try clean slug first, then add suffix if taken
  const existing = await db.event.findUnique({
    where: { slug: baseSlug },
    select: { id: true },
  });

  if (!existing) return baseSlug;
  return generateUniqueSlug(base);
}

// Re-export Prisma for service consumers
export { Prisma };
