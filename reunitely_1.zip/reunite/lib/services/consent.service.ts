import { db } from "@/lib/db";
import { ConsentType } from "@prisma/client";
import { nanoid } from "nanoid";

// ─── Log consent grants/revocations ──────────────────────────────────────────

export async function logConsent(params: {
  userId: string;
  eventId?: string;
  grants: Partial<Record<ConsentType, boolean>>;
  ipAddress?: string;
  userAgent?: string;
}): Promise<void> {
  const entries = Object.entries(params.grants).map(([type, granted]) => ({
    userId: params.userId,
    eventId: params.eventId,
    type: type as ConsentType,
    granted: granted ?? false,
    ipAddress: params.ipAddress ?? null,
    userAgent: params.userAgent ?? null,
  }));

  if (entries.length === 0) return;

  await db.consentRecord.createMany({ data: entries });
}

// ─── Check if user has given consent ────────────────────────────────────────

export async function hasConsent(
  userId: string,
  type: ConsentType,
  eventId?: string
): Promise<boolean> {
  const latest = await db.consentRecord.findFirst({
    where: {
      userId,
      type,
      ...(eventId ? { eventId } : {}),
    },
    orderBy: { createdAt: "desc" },
    select: { granted: true },
  });

  return latest?.granted ?? false;
}

// ─── Unsubscribe token management ─────────────────────────────────────────────
// Tokens are stored as a simple hash in EventMembership or a dedicated table.
// For MVP, we encode userId + eventId in a signed token.

export function generateUnsubscribeToken(
  userId: string,
  eventId?: string
): string {
  // HMAC-signed token: userId:eventId:timestamp, signed with INTERNAL_API_SECRET
  // This allows verification without a DB lookup for simple cases,
  // while still storing in invite.token for revocability.
  const { createHmac } = require("crypto");
  const { getEnv } = require("@/env");
  const secret = getEnv().INTERNAL_API_SECRET;
  const ts = Math.floor(Date.now() / 1000);
  const payload = `${userId}:${eventId ?? "all"}:${ts}`;
  const sig = createHmac("sha256", secret).update(payload).digest("hex").slice(0, 24);
  // Still use nanoid for the stored token (opaque to client), but bind sig to validate on redemption
  return `${nanoid(20)}_${sig}`;
}

/** Validate an unsubscribe token's embedded signature. Returns true if not tampered. */
export function validateUnsubscribeTokenFormat(token: string): boolean {
  // Tokens have format: {20 chars}_{24-char hex sig}
  return /^[A-Za-z0-9_-]{20}_[a-f0-9]{24}$/.test(token);
}

export async function processUnsubscribe(
  token: string,
  type: "event" | "all"
): Promise<{ success: boolean; message: string }> {
  // Validate token format before DB lookup (prevents enumeration via timing)
  if (!token || token.length < 20 || token.length > 60) {
    // Constant-time response to prevent token length oracle
    await new Promise((r) => setTimeout(r, 50));
    return { success: false, message: "Invalid unsubscribe token." };
  }

  // Look up token in invites table (we embed unsubscribe tokens in invites)
  const invite = await db.invite.findFirst({
    where: { token },
    select: { eventId: true, email: true },
  });

  if (!invite?.email) {
    return { success: false, message: "Invalid unsubscribe token." };
  }

  // Find user by email
  const user = await db.user.findUnique({
    where: { email: invite.email },
    select: { id: true },
  });

  if (!user) {
    return { success: true, message: "You have been unsubscribed." };
  }

  if (type === "event" && invite.eventId) {
    // Revoke consent for this event only
    await db.rSVP.updateMany({
      where: { userId: user.id, eventId: invite.eventId },
      data: { consentEmail: false, consentSms: false, consentWhatsApp: false },
    });

    await logConsent({
      userId: user.id,
      eventId: invite.eventId,
      grants: {
        EMAIL_MARKETING: false,
        SMS: false,
        WHATSAPP: false,
      },
    });
  } else {
    // Revoke all email consent for all events
    await db.rSVP.updateMany({
      where: { userId: user.id },
      data: { consentEmail: false },
    });

    await db.consentRecord.create({
      data: {
        userId: user.id,
        type: ConsentType.EMAIL_MARKETING,
        granted: false,
      },
    });
  }

  return {
    success: true,
    message:
      type === "event"
        ? "You've been unsubscribed from this event's communications."
        : "You've been unsubscribed from all Reunitely communications.",
  };
}

// ─── Get user's consent summary ────────────────────────────────────────────────

export async function getUserConsentSummary(
  userId: string,
  eventId?: string
): Promise<Record<ConsentType, boolean>> {
  const allTypes = Object.values(ConsentType);

  const results = await Promise.all(
    allTypes.map(async (type) => {
      const granted = await hasConsent(userId, type, eventId);
      return [type, granted] as const;
    })
  );

  return Object.fromEntries(results) as Record<ConsentType, boolean>;
}
