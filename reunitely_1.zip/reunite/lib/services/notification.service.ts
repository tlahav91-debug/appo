import { db } from "@/lib/db";
import { triggerUserNotification } from "@/lib/pusher";
import type { NotificationPayload } from "@/types";

// ─── Create a notification and push in real-time ──────────────────────────────

export async function createNotification(
  userId: string,
  payload: NotificationPayload
): Promise<void> {
  try {
    const notification = await db.notification.create({
      data: {
        userId,
        type: payload.type,
        payload: payload as object,
        isRead: false,
      },
    });

    // Push real-time update via Pusher (fire and forget)
    triggerUserNotification(userId, {
      id: notification.id,
      type: notification.type,
      payload: notification.payload,
      createdAt: notification.createdAt,
    }).catch(console.error);
  } catch (err) {
    // Notification failure is non-fatal
    console.error("[NotificationService] Failed to create notification:", err);
  }
}

// ─── Notify all organizers of an event ───────────────────────────────────────

export async function notifyEventOrganizers(
  eventId: string,
  payload: NotificationPayload
): Promise<void> {
  const organizers = await db.committeeMember.findMany({
    where: {
      eventId,
      role: { in: ["ORGANIZER", "CO_ORGANIZER"] }, revokedAt: null,
    },
    select: { userId: true },
  });

  await Promise.allSettled(
    organizers.map((o) => createNotification(o.userId, payload))
  );
}

// ─── Common notification triggers ────────────────────────────────────────────

export async function notifyRsvpConfirmed(
  eventId: string,
  attendeeName: string,
  eventTitle: string
): Promise<void> {
  await notifyEventOrganizers(eventId, {
    type: "RSVP_CONFIRMED",
    userName: attendeeName,
    eventTitle,
    eventId,
  });
}

export async function notifyPaymentReceived(
  eventId: string,
  amount: number,
  currency: string,
  eventTitle: string
): Promise<void> {
  await notifyEventOrganizers(eventId, {
    type: "PAYMENT_RECEIVED",
    amount,
    currency,
    eventTitle,
  });
}

export async function notifyWaitlistPromoted(
  userId: string,
  eventId: string,
  eventTitle: string
): Promise<void> {
  await createNotification(userId, {
    type: "WAITLIST_PROMOTED",
    eventTitle,
    eventId,
  });
}
