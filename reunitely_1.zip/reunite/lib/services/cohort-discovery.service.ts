/**
 * lib/services/cohort-discovery.service.ts
 *
 * Classmate nomination / cohort discovery system.
 *
 * Data flow:
 *   1. Attendee submits a lead (name + optional contact + school proof + consent)
 *   2. System runs dedup check (name similarity + email/phone match)
 *   3. Lead enters PENDING queue for organizer review
 *   4. Organizer approves / rejects / marks as duplicate
 *   5. Approved leads can be converted into Invite records
 *   6. If the person RSVPs, lead is marked RSVPD and linked to their User record
 *
 * Anti-spam safeguards:
 *   - Rate limit: max 5 leads per attendee per event
 *   - Consent required before submission
 *   - Confidence score (0–100) based on data completeness
 *   - All personal data is encrypted-at-rest via Prisma field-level encryption (future)
 *   - Personal data only visible to organizers, never to other attendees
 */

import { db } from "@/lib/db";
import type { CohortLeadStatus } from "@prisma/client";
import { requireEventPermission } from "@/lib/auth/permissions";
import { auditLog } from "@/lib/audit/log";
import { sendBatchInvites } from "@/lib/services/invite.service";
import { generateInviteToken } from "@/lib/utils";

// ─── Types ───────────────────────────────────────────────────────────────────

export interface SubmitLeadInput {
  fullName: string;
  emailHint?: string;
  phoneHint?: string;
  socialHint?: string;
  schoolConnection: string;
  graduationYear?: number;
  knownSince?: string;
  submitterNote?: string;
  consentGiven: boolean; // Must be true to submit
}

export interface ReviewLeadInput {
  status: "APPROVED" | "REJECTED" | "DUPLICATE";
  adminNote?: string;
  rejectionReason?: string;
  duplicateOfId?: string; // When marking as duplicate of another lead
}

export interface LeadWithSubmitter {
  id: string;
  fullName: string;
  emailHint: string | null;
  phoneHint: string | null;
  socialHint: string | null;
  schoolConnection: string;
  graduationYear: number | null;
  knownSince: string | null;
  submitterNote: string | null;
  status: CohortLeadStatus;
  confidenceScore: number;
  adminNote: string | null;
  rejectionReason: string | null;
  createdAt: Date;
  reviewedAt: Date | null;
  inviteId: string | null;
  submittedBy: {
    id: string;
    name: string;
    avatarUrl: string | null;
    email: string;
  };
  reviewedBy: {
    name: string;
    avatarUrl: string | null;
  } | null;
  duplicateOf: { id: string; fullName: string } | null;
}

export interface DuplicateCheckResult {
  isDuplicate: boolean;
  existingLeadId?: string;
  existingUserId?: string;
  matchType?: "exact_email" | "exact_phone" | "name_similarity" | "existing_user";
  confidence: number; // 0-100
}

// ─── Submit a lead ────────────────────────────────────────────────────────────

export async function submitCohortLead(
  eventId: string,
  submitterId: string,
  input: SubmitLeadInput
): Promise<{ leadId: string; duplicateWarning?: DuplicateCheckResult }> {
  if (!input.consentGiven) {
    throw new Error(
      "CONSENT_REQUIRED: You must confirm you have the right to share this person's information."
    );
  }

  // Verify submitter has RSVPd or is on committee
  const [rsvp, committee] = await Promise.all([
    db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId: submitterId } },
      select: { status: true },
    }),
    db.committeeMember.findUnique({
      where: { eventId_userId: { eventId, userId: submitterId }, revokedAt: null },
      select: { id: true },
    }),
  ]);

  const hasAccess =
    committee ||
    (rsvp && rsvp.status !== "CANCELLED" && rsvp.status !== "DECLINED");

  if (!hasAccess) {
    throw new Error("UNAUTHORIZED: Only event attendees can submit classmate leads.");
  }

  // Rate limit: max 5 leads per submitter per event
  const existingCount = await db.cohortNominationLead.count({
    where: {
      eventId,
      submittedById: submitterId,
      status: { notIn: ["REJECTED", "DUPLICATE"] },
    },
  });
  if (existingCount >= 5) {
    throw new Error(
      "RATE_LIMIT: You've already submitted 5 classmate leads for this event. Contact the organizer to add more."
    );
  }

  // Dedup check
  const dupCheck = await checkForDuplicates(eventId, input);

  // Compute confidence score
  const confidence = computeConfidenceScore(input);

  // Create the lead
  const lead = await db.cohortNominationLead.create({
    data: {
      eventId,
      submittedById: submitterId,
      fullName: input.fullName.trim(),
      emailHint: input.emailHint?.trim().toLowerCase() ?? null,
      phoneHint: input.phoneHint?.trim() ?? null,
      socialHint: input.socialHint?.trim() ?? null,
      schoolConnection: input.schoolConnection.trim(),
      graduationYear: input.graduationYear ?? null,
      knownSince: input.knownSince?.trim() ?? null,
      submitterNote: input.submitterNote?.trim() ?? null,
      confidenceScore: confidence,
      status: dupCheck.isDuplicate ? "DUPLICATE" : "PENDING",
      duplicateOfId: dupCheck.existingLeadId ?? null,
      resolvedUserId: dupCheck.existingUserId ?? null,
      consentGiven: true,
      consentNote: `Submitted by ${submitterId} on ${new Date().toISOString()}`,
    },
  });

  await auditLog({
    actorId: submitterId,
    action: "COHORT_LEAD_SUBMITTED",
    resourceType: "CohortNominationLead",
    resourceId: lead.id,
    eventId,
    metadata: {
      fullName: input.fullName,
      hasEmail: !!input.emailHint,
      hasPhone: !!input.phoneHint,
      confidenceScore: confidence,
      isDuplicate: dupCheck.isDuplicate,
    },
  });

  return {
    leadId: lead.id,
    duplicateWarning: dupCheck.isDuplicate ? dupCheck : undefined,
  };
}

// ─── Duplicate detection ──────────────────────────────────────────────────────

export async function checkForDuplicates(
  eventId: string,
  input: Pick<SubmitLeadInput, "fullName" | "emailHint" | "phoneHint">
): Promise<DuplicateCheckResult> {
  const normalEmail = input.emailHint?.trim().toLowerCase();
  const normalPhone = input.phoneHint?.trim();

  // 1. Exact email match in existing Users who have RSVPd
  if (normalEmail) {
    const existingUser = await db.user.findFirst({
      where: {
        email: normalEmail,
        rsvps: { some: { eventId, status: { notIn: ["CANCELLED", "DECLINED"] } } },
      },
      select: { id: true },
    });
    if (existingUser) {
      return {
        isDuplicate: true,
        existingUserId: existingUser.id,
        matchType: "existing_user",
        confidence: 100,
      };
    }

    // Email in existing leads
    const emailLead = await db.cohortNominationLead.findFirst({
      where: {
        eventId,
        emailHint: normalEmail,
        status: { notIn: ["REJECTED"] },
      },
      select: { id: true },
    });
    if (emailLead) {
      return {
        isDuplicate: true,
        existingLeadId: emailLead.id,
        matchType: "exact_email",
        confidence: 95,
      };
    }
  }

  // 2. Exact phone match
  if (normalPhone) {
    const phoneLead = await db.cohortNominationLead.findFirst({
      where: {
        eventId,
        phoneHint: normalPhone,
        status: { notIn: ["REJECTED"] },
      },
      select: { id: true },
    });
    if (phoneLead) {
      return {
        isDuplicate: true,
        existingLeadId: phoneLead.id,
        matchType: "exact_phone",
        confidence: 90,
      };
    }
  }

  // 3. Name similarity check — exact name match (case-insensitive)
  const normalName = input.fullName.trim().toLowerCase();
  const nameLead = await db.cohortNominationLead.findFirst({
    where: {
      eventId,
      status: { notIn: ["REJECTED", "DUPLICATE"] },
      // Prisma doesn't support fuzzy match — do exact lower-case match
      fullName: { equals: input.fullName.trim(), mode: "insensitive" },
    },
    select: { id: true, fullName: true },
  });
  if (nameLead) {
    return {
      isDuplicate: false, // Same name doesn't auto-mark as dup — just warn organizer
      existingLeadId: nameLead.id,
      matchType: "name_similarity",
      confidence: 60,
    };
  }

  return { isDuplicate: false, confidence: 0 };
}

// ─── Review a lead (organizer action) ────────────────────────────────────────

export async function reviewCohortLead(
  leadId: string,
  reviewerId: string,
  input: ReviewLeadInput
): Promise<void> {
  const lead = await db.cohortNominationLead.findUniqueOrThrow({
    where: { id: leadId },
    select: { id: true, eventId: true, status: true },
  });

  await requireEventPermission(reviewerId, lead.eventId, "invites:manage");

  if (lead.status !== "PENDING") {
    throw new Error("ALREADY_REVIEWED: This lead has already been reviewed.");
  }

  await db.cohortNominationLead.update({
    where: { id: leadId },
    data: {
      status: input.status,
      reviewedById: reviewerId,
      reviewedAt: new Date(),
      adminNote: input.adminNote?.trim() ?? null,
      rejectionReason:
        input.status === "REJECTED" ? input.rejectionReason?.trim() ?? null : null,
      duplicateOfId:
        input.status === "DUPLICATE" ? input.duplicateOfId ?? null : undefined,
    },
  });

  await auditLog({
    actorId: reviewerId,
    action: "COHORT_LEAD_REVIEWED",
    resourceType: "CohortNominationLead",
    resourceId: leadId,
    eventId: lead.eventId,
    metadata: { status: input.status, adminNote: !!input.adminNote },
  });
}

// ─── Convert approved lead → Invite ──────────────────────────────────────────

export async function convertLeadToInvite(
  leadId: string,
  reviewerId: string
): Promise<{ inviteId: string; token: string }> {
  const lead = await db.cohortNominationLead.findUniqueOrThrow({
    where: { id: leadId },
    select: {
      id: true,
      eventId: true,
      status: true,
      fullName: true,
      emailHint: true,
      phoneHint: true,
      submittedById: true,
    },
  });

  await requireEventPermission(reviewerId, lead.eventId, "invites:manage");

  if (lead.status !== "APPROVED") {
    throw new Error("LEAD_NOT_APPROVED: Only approved leads can be converted to invites.");
  }
  if (!lead.emailHint && !lead.phoneHint) {
    throw new Error(
      "NO_CONTACT_INFO: Cannot create an invite without email or phone. Edit the lead to add contact info first."
    );
  }

  // Check for existing invite to this email/phone for this event
  if (lead.emailHint) {
    const existing = await db.invite.findFirst({
      where: {
        eventId: lead.eventId,
        email: lead.emailHint,
        status: { notIn: ["EXPIRED", "BOUNCED"] },
      },
      select: { id: true, token: true },
    });
    if (existing) {
      // Link this lead to the existing invite
      await db.cohortNominationLead.update({
        where: { id: leadId },
        data: { inviteId: existing.id, status: "INVITED" },
      });
      return { inviteId: existing.id, token: existing.token };
    }
  }

  // Create the invite
  const result = await sendBatchInvites(lead.eventId, reviewerId, {
    channel: lead.emailHint ? "EMAIL" : "SMS",
    recipients: [
      {
        email: lead.emailHint ?? undefined,
        phone: lead.phoneHint ?? undefined,
        name: lead.fullName,
      },
    ],
    personalMessage: `You've been recommended by a classmate who thinks you'd love to reconnect at the upcoming reunion!`,
    consentConfirmed: true, // Organizer takes responsibility
    expiryDays: 30,
  });

  if (result.inviteIds.length === 0) {
    throw new Error("INVITE_FAILED: Could not create invite — the address may have already been invited.");
  }

  const inviteId = result.inviteIds[0]!;
  const invite = await db.invite.findUnique({
    where: { id: inviteId },
    select: { token: true },
  });

  // Link lead to invite
  await db.cohortNominationLead.update({
    where: { id: leadId },
    data: { inviteId, status: "INVITED" },
  });

  await auditLog({
    actorId: reviewerId,
    action: "COHORT_LEAD_CONVERTED",
    resourceType: "CohortNominationLead",
    resourceId: leadId,
    eventId: lead.eventId,
    metadata: { inviteId, channel: lead.emailHint ? "EMAIL" : "SMS" },
  });

  return { inviteId, token: invite!.token };
}

// ─── Bulk convert approved leads ─────────────────────────────────────────────

export async function bulkConvertApprovedLeads(
  eventId: string,
  reviewerId: string
): Promise<{ converted: number; failed: number; errors: string[] }> {
  await requireEventPermission(reviewerId, eventId, "invites:manage");

  const approved = await db.cohortNominationLead.findMany({
    where: {
      eventId,
      status: "APPROVED",
      inviteId: null,
      OR: [
        { emailHint: { not: null } },
        { phoneHint: { not: null } },
      ],
    },
    select: { id: true },
  });

  let converted = 0;
  let failed = 0;
  const errors: string[] = [];

  for (const lead of approved) {
    try {
      await convertLeadToInvite(lead.id, reviewerId);
      converted++;
    } catch (err) {
      failed++;
      errors.push(err instanceof Error ? err.message : String(err));
    }
  }

  return { converted, failed, errors };
}

// ─── List leads for organizer ─────────────────────────────────────────────────

export async function listLeads(
  eventId: string,
  reviewerId: string,
  options: {
    status?: CohortLeadStatus | CohortLeadStatus[];
    search?: string;
    limit?: number;
    cursor?: string;
  } = {}
): Promise<LeadWithSubmitter[]> {
  await requireEventPermission(reviewerId, eventId, "invites:view");

  const statuses = options.status
    ? Array.isArray(options.status)
      ? options.status
      : [options.status]
    : undefined;

  const leads = await db.cohortNominationLead.findMany({
    where: {
      eventId,
      ...(statuses ? { status: { in: statuses } } : {}),
      ...(options.search
        ? {
            OR: [
              { fullName: { contains: options.search, mode: "insensitive" } },
              { emailHint: { contains: options.search, mode: "insensitive" } },
            ],
          }
        : {}),
      ...(options.cursor ? { id: { gt: options.cursor } } : {}),
    },
    include: {
      submittedBy: { select: { id: true, name: true, avatarUrl: true, email: true } },
      reviewedBy: { select: { name: true, avatarUrl: true } },
      duplicateOf: { select: { id: true, fullName: true } },
    },
    orderBy: [{ status: "asc" }, { createdAt: "desc" }],
    take: options.limit ?? 50,
  });

  return leads as unknown as LeadWithSubmitter[];
}

// ─── Stats ────────────────────────────────────────────────────────────────────

export async function getLeadStats(eventId: string) {
  const groups = await db.cohortNominationLead.groupBy({
    by: ["status"],
    where: { eventId },
    _count: { status: true },
  });
  const stats: Record<string, number> = {};
  groups.forEach((g) => { stats[g.status] = g._count.status; });
  return {
    total: Object.values(stats).reduce((a, b) => a + b, 0),
    pending: stats["PENDING"] ?? 0,
    approved: stats["APPROVED"] ?? 0,
    rejected: stats["REJECTED"] ?? 0,
    duplicate: stats["DUPLICATE"] ?? 0,
    invited: stats["INVITED"] ?? 0,
    rsvpd: stats["RSVPD"] ?? 0,
  };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function computeConfidenceScore(input: SubmitLeadInput): number {
  let score = 20; // Base score for having a name
  if (input.emailHint) score += 35;
  if (input.phoneHint) score += 25;
  if (input.socialHint) score += 10;
  if (input.schoolConnection.length > 50) score += 5;
  if (input.graduationYear) score += 5;
  // Cap at 100
  return Math.min(100, score);
}
