import { db } from "@/lib/db";
import type { User } from "@prisma/client";

export async function getUserByClerkId(clerkId: string): Promise<User | null> {
  return db.user.findUnique({ where: { clerkId, deletedAt: null } });
}

export async function getUserById(id: string): Promise<User | null> {
  return db.user.findUnique({ where: { id, deletedAt: null } });
}

export async function upsertUserFromClerk(params: {
  clerkId: string;
  email: string;
  name: string;
  avatarUrl?: string | null;
}): Promise<User> {
  return db.user.upsert({
    where: { clerkId: params.clerkId },
    create: {
      clerkId: params.clerkId,
      email: params.email,
      name: params.name,
      avatarUrl: params.avatarUrl,
    },
    update: {
      email: params.email,
      name: params.name,
      avatarUrl: params.avatarUrl,
    },
  });
}

// ─── User-level updates (name, username, avatar only) ─────────────────────────
// Profile details (bio, city, job, privacy) are on AttendeeProfile — see /api/profile

export async function updateUserCore(
  userId: string,
  data: {
    name?: string;
    username?: string | null;
    avatarUrl?: string | null;
  }
): Promise<User> {
  return db.user.update({ where: { id: userId }, data });
}

// ─── Soft delete — anonymises PII, preserves referential integrity ────────────

export async function softDeleteUser(userId: string): Promise<void> {
  const anonEmail = `deleted-${userId}@deleted.invalid`;
  const anonName = "Deleted User";

  await db.$transaction([
    // Anonymise User record — only fields that actually exist on User model
    db.user.update({
      where: { id: userId },
      data: {
        deletedAt: new Date(),
        email: anonEmail,
        name: anonName,
        avatarUrl: null,
        username: null,
        firstName: null,
        lastName: null,
      },
    }),

    // Clear consent from RSVPs
    db.rSVP.updateMany({
      where: { userId },
      data: {
        consentEmail: false,
        consentSms: false,
        consentWhatsApp: false,
        attendeeNote: null,
      },
    }),

    // Anonymise AttendeeProfile if it exists
    db.attendeeProfile.updateMany({
      where: { userId },
      data: {
        bio: null,
        currentCity: null,
        currentCountry: null,
        currentJob: null,
        currentEmployer: null,
        linkedinUrl: null,
        instagramHandle: null,
        twitterHandle: null,
        facebookUrl: null,
        funFact: null,
        favoriteMemory: null,
        showInDirectory: false,
        profileVisibleTo: "NOBODY",
      },
    }),
  ]);
}

// ─── GDPR data export ─────────────────────────────────────────────────────────

export async function exportUserData(
  userId: string
): Promise<Record<string, unknown>> {
  // GDPR Art. 20 — data portability. Return all personal data held about this user.
  const [
    user,
    attendeeProfile,
    rsvps,
    payments,
    consentLogs,
    memoryPosts,
    memoryComments,
    chatMessages,
    nominations,
    invitesSent,
    checkIns,
  ] = await Promise.all([
    db.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        username: true,
        phone: true,
        createdAt: true,
        lastLoginAt: true,
      },
    }),
    db.attendeeProfile.findUnique({
      where: { userId },
      select: {
        bio: true,
        currentCity: true,
        currentCountry: true,
        currentJob: true,
        currentEmployer: true,
        funFact: true,
        favoriteMemory: true,
        linkedinUrl: true,
        instagramHandle: true,
        twitterHandle: true,
        profileVisibleTo: true,
        showInDirectory: true,
        showCurrentCity: true,
        showCurrentJob: true,
        showSocialLinks: true,
        allowDirectMessages: true,
        allowPhotoTagging: true,
        allowNominations: true,
      },
    }),
    db.rSVP.findMany({
      where: { userId },
      include: {
        event: { select: { title: true, schoolName: true, graduationYear: true, startAt: true } },
      },
      orderBy: { submittedAt: "desc" },
    }),
    db.payment.findMany({
      where: { userId },
      select: {
        id: true,
        totalAmountCents: true,
        currency: true,
        status: true,
        ticketCode: true,
        paidAt: true,
        refundedAmountCents: true,
        refundedAt: true,
        createdAt: true,
      },
      orderBy: { createdAt: "desc" },
    }),
    db.consentRecord.findMany({
      where: { userId },
      select: { type: true, granted: true, version: true, ipAddress: true, createdAt: true },
      orderBy: { createdAt: "desc" },
      take: 500,
    }),
    // Memory posts authored by this user
    db.memoryPost.findMany({
      where: { authorId: userId, deletedAt: null },
      select: {
        id: true,
        type: true,
        caption: true,
        yearContext: true,
        contextLabel: true,
        status: true,
        createdAt: true,
        event: { select: { title: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 500,
    }),
    // Comments
    db.memoryComment.findMany({
      where: { authorId: userId, isDeleted: false },
      select: { content: true, createdAt: true },
      orderBy: { createdAt: "desc" },
      take: 500,
    }),
    // Chat messages (non-deleted)
    db.chatMessage.findMany({
      where: { authorId: userId, isDeleted: false },
      select: {
        content: true,
        editedContent: true,
        createdAt: true,
        room: { select: { name: true, event: { select: { title: true } } } },
      },
      orderBy: { createdAt: "desc" },
      take: 1000,
    }),
    // Cohort nominations submitted
    db.cohortNominationLead.findMany({
      where: { submittedById: userId },
      select: {
        nomineeName: true,
        nomineeEmail: true,
        status: true,
        submittedAt: true,
        event: { select: { title: true } },
      },
      orderBy: { submittedAt: "desc" },
      take: 100,
    }),
    // Invites sent on behalf of (referral ambassador)
    db.referralLink.findMany({
      where: { createdById: userId },
      select: { code: true, label: true, clickCount: true, rsvpCount: true, createdAt: true },
    }),
    // Check-in history
    db.checkIn.findMany({
      where: { userId },
      select: {
        status: true,
        checkedInAt: true,
        checkInMethod: true,
        event: { select: { title: true } },
      },
      orderBy: { checkedInAt: "desc" },
      take: 100,
    }),
  ]);

  return {
    exportedAt: new Date().toISOString(),
    exportVersion: "2",
    notice: "This export contains all personal data held by Reunitely about your account.",
    // Identity
    account: user ?? null,
    profile: attendeeProfile ?? null,
    // Event participation
    rsvps: rsvps.map((r) => ({
      event: r.event.title,
      school: `${r.event.schoolName} ${r.event.graduationYear}`,
      eventDate: r.event.startAt,
      rsvpStatus: r.status,
      guestCount: r.guestCount,
      submittedAt: r.submittedAt,
      confirmedAt: r.confirmedAt,
    })),
    checkIns: checkIns.map((c) => ({
      event: c.event.title,
      status: c.status,
      method: c.checkInMethod,
      checkedInAt: c.checkedInAt,
    })),
    // Financial
    payments: payments.map((p) => ({
      id: p.id,
      amount: `${(p.totalAmountCents / 100).toFixed(2)} ${p.currency}`,
      status: p.status,
      ticketCode: p.ticketCode,
      paidAt: p.paidAt,
      refundedAmount: p.refundedAmountCents > 0
        ? `${(p.refundedAmountCents / 100).toFixed(2)} ${p.currency}`
        : null,
      refundedAt: p.refundedAt,
    })),
    // Content authored
    memoryPosts: memoryPosts.map((m) => ({
      event: m.event.title,
      type: m.type,
      caption: m.caption,
      year: m.yearContext,
      status: m.status,
      createdAt: m.createdAt,
    })),
    comments: memoryComments.map((c) => ({
      content: c.content,
      createdAt: c.createdAt,
    })),
    chatMessages: chatMessages.map((m) => ({
      room: m.room.name,
      event: m.room.event?.title,
      content: m.editedContent ?? m.content,
      createdAt: m.createdAt,
    })),
    // Social actions
    nominations: nominations.map((n) => ({
      event: n.event.title,
      nomineeName: n.nomineeName,
      nomineeEmail: n.nomineeEmail,
      status: n.status,
      submittedAt: n.submittedAt,
    })),
    referralLinks: invitesSent,
    // Consent audit trail (required by GDPR Art. 7)
    consentHistory: consentLogs,
  };
}
