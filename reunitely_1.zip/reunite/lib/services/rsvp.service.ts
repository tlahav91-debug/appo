import { db } from "@/lib/db";
import type { RSVP, Prisma } from "@prisma/client";
import { cacheDelete, cacheKeys } from "@/lib/cache/redis";
import { auditLog } from "@/lib/audit/log";
import { sendRsvpConfirmation } from "@/lib/email";
import { logConsent } from "@/lib/services/consent.service";

// ─── Types ────────────────────────────────────────────────────────────────────

export type RsvpInput = {
  status: "CONFIRMED" | "DECLINED" | "PENDING";
  guestCount?: number;
  guestNames?: string[];
  dietaryRequirements?: string[];
  mealChoice?: string;
  customAnswers?: Record<string, string>;
  consentEmail: boolean;
  consentSms?: boolean;
  consentWhatsApp?: boolean;
  attendeeNote?: string;
  inviteToken?: string;
};

export type RsvpResult = {
  rsvp: RSVP;
  isWaitlisted: boolean;
  isNew: boolean;
};

// ─── Create / update RSVP ────────────────────────────────────────────────────

export async function createOrUpdateRsvp(
  eventId: string,
  userId: string,
  input: RsvpInput,
  ipAddress?: string
): Promise<RsvpResult> {
  const event = await db.event.findUniqueOrThrow({
    where: { id: eventId },
    select: {
      id: true,
      title: true,
      capacity: true,
      waitlistEnabled: true,
      startAt: true,
      timezone: true,
      slug: true,
      settings: true,
    },
  });

  // ── Capacity gate ──────────────────────────────────────────────────────────
  let resolvedStatus = input.status as "CONFIRMED" | "DECLINED" | "PENDING" | "WAITLISTED";
  let waitlistPosition: number | undefined;
  let isWaitlisted = false;

  if (input.status === "CONFIRMED" && event.capacity !== null) {
    const confirmedCount = await db.rSVP.count({
      where: { eventId, status: { in: ["CONFIRMED"] } },
    });

    if (confirmedCount >= event.capacity) {
      if (event.waitlistEnabled) {
        resolvedStatus = "WAITLISTED";
        isWaitlisted = true;
        // Get current waitlist length for position
        const waitlistCount = await db.rSVP.count({
          where: { eventId, status: "WAITLISTED" },
        });
        waitlistPosition = waitlistCount + 1;
      } else {
        throw new Error("EVENT_FULL");
      }
    }
  }

  // ── Upsert RSVP ───────────────────────────────────────────────────────────
  const existing = await db.rSVP.findUnique({
    where: { eventId_userId: { eventId, userId } },
    select: { id: true, status: true },
  });

  const now = new Date();

  const rsvpData: Prisma.RSVPUncheckedCreateInput = {
    eventId,
    userId,
    status: resolvedStatus,
    previousStatus: existing?.status ?? null,
    guestCount: input.guestCount ?? 0,
    guestNames: input.guestNames ?? [],
    dietaryRequirements: input.dietaryRequirements ?? [],
    mealChoice: input.mealChoice ?? null,
    customAnswers: (input.customAnswers ?? {}) as Prisma.InputJsonValue,
    consentEmail: input.consentEmail,
    consentSms: input.consentSms ?? false,
    consentWhatsApp: input.consentWhatsApp ?? false,
    consentGivenAt: now,
    consentIpAddress: ipAddress ?? null,
    attendeeNote: input.attendeeNote ?? null,
    waitlistPosition: waitlistPosition ?? null,
    submittedAt: existing ? undefined : now,
    confirmedAt: resolvedStatus === "CONFIRMED" ? now : null,
  };

  const rsvp = await db.rSVP.upsert({
    where: { eventId_userId: { eventId, userId } },
    create: rsvpData,
    update: {
      status: resolvedStatus,
      previousStatus: existing?.status ?? null,
      guestCount: input.guestCount ?? existing?.guestCount ?? 0,
      guestNames: input.guestNames ?? [],
      dietaryRequirements:
        input.dietaryRequirements ?? existing?.dietaryRequirements ?? [],
      mealChoice: input.mealChoice ?? null,
      customAnswers: (input.customAnswers ?? {}) as Prisma.InputJsonValue,
      consentEmail: input.consentEmail,
      consentSms: input.consentSms ?? false,
      consentWhatsApp: input.consentWhatsApp ?? false,
      consentGivenAt: now,
      consentIpAddress: ipAddress ?? null,
      attendeeNote: input.attendeeNote ?? null,
      waitlistPosition: waitlistPosition ?? null,
      confirmedAt: resolvedStatus === "CONFIRMED" ? now : null,
    },
  });

  // ── Mark invite as used if token provided ─────────────────────────────────
  if (input.inviteToken) {
    await db.invite.updateMany({
      where: { token: input.inviteToken, eventId },
      data: { status: "RSVPD", rsvpdAt: now },
    }).catch(console.error);
  }

  // ── Cache invalidation ────────────────────────────────────────────────────
  await Promise.all([
    cacheDelete(cacheKeys.attendeeCount(eventId)),
    cacheDelete(cacheKeys.eventStats(eventId)),
  ]);

  // ── Consent record ────────────────────────────────────────────────────────
  await logConsent({
    userId,
    eventId,
    grants: {
      EMAIL_MARKETING: input.consentEmail,
      SMS_MARKETING: input.consentSms ?? false,
      WHATSAPP_MARKETING: input.consentWhatsApp ?? false,
    },
    ipAddress,
  }).catch(console.error);

  // ── Send confirmation email (fire and forget) ─────────────────────────────
  if (resolvedStatus === "CONFIRMED" || resolvedStatus === "WAITLISTED") {
    sendRsvpConfirmation({
      userId,
      eventId,
      eventTitle: event.title,
      eventSlug: event.slug,
      startAt: event.startAt,
      timezone: event.timezone,
      isWaitlisted,
    }).catch(console.error);
  }

  // ── Audit ────────────────────────────────────────────────────────────────
  await auditLog({
    actorId: userId,
    action: existing ? "RSVP_UPDATED" : "RSVP_CREATED",
    resourceType: "RSVP",
    resourceId: rsvp.id,
    eventId,
    metadata: {
      status: resolvedStatus,
      previousStatus: existing?.status ?? null,
      isWaitlisted,
    },
  });

  return { rsvp, isWaitlisted, isNew: !existing };
}

// ─── Cancel RSVP ─────────────────────────────────────────────────────────────

export async function cancelRsvp(
  eventId: string,
  userId: string
): Promise<void> {
  const rsvp = await db.rSVP.findUnique({
    where: { eventId_userId: { eventId, userId } },
    select: { id: true, status: true },
  });

  if (!rsvp) throw new Error("RSVP_NOT_FOUND");

  await db.rSVP.update({
    where: { eventId_userId: { eventId, userId } },
    data: {
      status: "CANCELLED",
      previousStatus: rsvp.status,
      cancelledAt: new Date(),
      cancelledReason: "Cancelled by attendee",
    },
  });

  // Try to promote next person from waitlist
  await promoteFromWaitlist(eventId).catch(console.error);

  await Promise.all([
    cacheDelete(cacheKeys.attendeeCount(eventId)),
    cacheDelete(cacheKeys.eventStats(eventId)),
  ]);

  await auditLog({
    actorId: userId,
    action: "RSVP_CANCELLED",
    resourceType: "RSVP",
    resourceId: rsvp.id,
    eventId,
  });
}

// ─── Waitlist promotion ───────────────────────────────────────────────────────

export async function promoteFromWaitlist(eventId: string): Promise<void> {
  const event = await db.event.findUnique({
    where: { id: eventId },
    select: {
      capacity: true,
      waitlistEnabled: true,
      title: true,
      slug: true,
      schoolName: true,
      graduationYear: true,
      startAt: true,
      timezone: true,
    },
  });

  if (!event?.capacity || !event.waitlistEnabled) return;

  const confirmedCount = await db.rSVP.count({
    where: { eventId, status: "CONFIRMED" },
  });

  if (confirmedCount >= event.capacity) return;

  // Promote the first person on the waitlist (FIFO by submittedAt)
  const nextInQueue = await db.rSVP.findFirst({
    where: { eventId, status: "WAITLISTED" },
    orderBy: { submittedAt: "asc" },
    include: {
      user: { select: { id: true, email: true, name: true } },
    },
  });

  if (!nextInQueue) return;

  await db.rSVP.update({
    where: { id: nextInQueue.id },
    data: {
      status: "CONFIRMED",
      previousStatus: "WAITLISTED",
      confirmedAt: new Date(),
      waitlistPosition: null,
    },
  });

  // Send promotion email + in-app notification (non-blocking)
  Promise.all([
    import("@/lib/email").then(({ sendWaitlistPromoted }) =>
      sendWaitlistPromoted({
        userId: nextInQueue.user.id,
        eventId,
        eventTitle: event.title,
        eventSlug: event.slug,
        schoolName: event.schoolName,
        graduationYear: event.graduationYear,
        startAt: event.startAt,
        timezone: event.timezone,
      })
    ),
    import("@/lib/services/notification.service").then(
      ({ createNotification }) =>
        createNotification(nextInQueue.user.id, {
          type: "WAITLIST_PROMOTED",
          eventTitle: event.title,
          eventId,
        })
    ),
  ]).catch((err) =>
    console.error("[Waitlist] Failed to send promotion notifications:", err)
  );
}

// ─── Check in attendee ────────────────────────────────────────────────────────

export interface CheckInResult {
  alreadyCheckedIn: boolean;
  checkedInAt: Date;
  guestCount: number;
  guestNames: string[];
  ticketCode: string | null;
  attendeeName: string;
}

export async function checkInAttendee(
  eventId: string,
  attendeeUserId: string,
  organizerUserId: string,
  method: "MANUAL" | "QR" | "SEARCH" = "MANUAL"
): Promise<CheckInResult> {
  // Check for existing check-in (duplicate prevention)
  const existing = await db.checkIn.findUnique({
    where: { eventId_userId: { eventId, userId: attendeeUserId } },
    select: { status: true, checkedInAt: true },
  });

  if (existing?.status === "CHECKED_IN" && existing.checkedInAt) {
    // Already checked in — return gracefully (idempotent)
    const rsvp = await db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId: attendeeUserId } },
      select: { guestCount: true, guestNames: true, user: { select: { name: true } } },
    });
    const payment = await db.payment.findFirst({
      where: { eventId, userId: attendeeUserId, status: "PAID" },
      select: { ticketCode: true },
    });
    return {
      alreadyCheckedIn: true,
      checkedInAt: existing.checkedInAt,
      guestCount: rsvp?.guestCount ?? 0,
      guestNames: rsvp?.guestNames ?? [],
      ticketCode: payment?.ticketCode ?? null,
      attendeeName: rsvp?.user.name ?? "",
    };
  }

  // Fetch RSVP for guest info
  const rsvp = await db.rSVP.findUnique({
    where: { eventId_userId: { eventId, userId: attendeeUserId } },
    select: { id: true, guestCount: true, guestNames: true, user: { select: { name: true } } },
  });

  const payment = await db.payment.findFirst({
    where: { eventId, userId: attendeeUserId, status: "PAID" },
    select: { ticketCode: true, id: true },
  });

  const now = new Date();

  const [checkIn] = await db.$transaction([
    db.checkIn.upsert({
      where: { eventId_userId: { eventId, userId: attendeeUserId } },
      create: {
        eventId,
        userId: attendeeUserId,
        rsvpId: rsvp?.id ?? null,
        status: "CHECKED_IN",
        checkedInAt: now,
        checkedInByUserId: organizerUserId,
        checkInMethod: method,
      },
      update: {
        status: "CHECKED_IN",
        checkedInAt: now,
        checkedInByUserId: organizerUserId,
        checkInMethod: method,
      },
    }),
    // Mark payment as checked in if exists
    ...(payment
      ? [
          db.payment.update({
            where: { id: payment.id },
            data: { checkedInAt: now },
          }),
        ]
      : []),
  ]);

  await auditLog({
    actorId: organizerUserId,
    action: "ATTENDEE_CHECKED_IN",
    resourceType: "CheckIn",
    resourceId: checkIn.id,
    eventId,
    metadata: { attendeeUserId, method },
  });

  return {
    alreadyCheckedIn: false,
    checkedInAt: now,
    guestCount: rsvp?.guestCount ?? 0,
    guestNames: rsvp?.guestNames ?? [],
    ticketCode: payment?.ticketCode ?? null,
    attendeeName: rsvp?.user.name ?? "",
  };
}

// ─── Get RSVP for user ────────────────────────────────────────────────────────

export async function getRsvpForUser(
  eventId: string,
  userId: string
): Promise<RSVP | null> {
  return db.rSVP.findUnique({
    where: { eventId_userId: { eventId, userId } },
  });
}
