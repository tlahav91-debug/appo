import { Ratelimit } from "@upstash/ratelimit";
import { getRedis } from "@/lib/cache/redis";
import { NextResponse } from "next/server";

// ─── Rate limiter instances ───────────────────────────────────────────────────

function createRatelimit(requests: number, windowSeconds: number) {
  return new Ratelimit({
    redis: getRedis(),
    limiter: Ratelimit.slidingWindow(requests, `${windowSeconds}s`),
    analytics: true,
    prefix: "reunitely:rl",
  });
}

// Named rate limiters — adjust limits per environment
export const rateLimiters = {
  // Auth endpoints — strict
  auth: createRatelimit(10, 60), // 10 req/min

  // General API — per authenticated user
  api: createRatelimit(100, 60), // 100 req/min

  // RSVP — prevent flooding
  rsvp: createRatelimit(5, 60), // 5 req/min

  // Chat messages — per user (separate from slow mode which is per room)
  chat: createRatelimit(30, 60), // 30 msg/min per user

  // Chat reactions — lighter but still bounded
  reaction: createRatelimit(60, 60), // 60 reactions/min

  // Broadcast — expensive operation
  broadcast: createRatelimit(2, 600), // 2 req/10min

  // File uploads
  upload: createRatelimit(20, 3600), // 20 req/hour

  // Public event page — per IP
  publicPage: createRatelimit(60, 60), // 60 req/min

  // Check-in QR scan — fast but bounded to prevent brute-force ticket codes
  checkIn: createRatelimit(60, 60), // 60 scans/min per operator

  // Cohort nominations — prevent spam nominations
  cohortLead: createRatelimit(10, 3600), // 10 per hour per user

  // Report content — prevent report flooding
  report: createRatelimit(10, 3600), // 10 reports/hour

  // Unsubscribe — prevent scraping
  unsubscribe: createRatelimit(5, 60), // 5/min per IP
} as const;

export type RateLimiterName = keyof typeof rateLimiters;

// ─── Helper: apply rate limit in route handler ───────────────────────────────

export async function applyRateLimit(
  limiterName: RateLimiterName,
  identifier: string
): Promise<{ success: boolean; response?: NextResponse }> {
  const limiter = rateLimiters[limiterName];
  const { success, limit, remaining, reset } = await limiter.limit(identifier);

  if (!success) {
    const retryAfter = Math.ceil((reset - Date.now()) / 1000);
    return {
      success: false,
      response: NextResponse.json(
        {
          error: {
            code: "RATE_LIMITED",
            message: "Too many requests. Please slow down.",
            retryAfter,
          },
        },
        {
          status: 429,
          headers: {
            "X-RateLimit-Limit": String(limit),
            "X-RateLimit-Remaining": String(remaining),
            "X-RateLimit-Reset": String(reset),
            "Retry-After": String(retryAfter),
          },
        }
      ),
    };
  }

  return { success: true };
}
