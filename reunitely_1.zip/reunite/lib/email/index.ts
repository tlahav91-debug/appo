import { Resend } from "resend";
import { getEnv } from "@/env";

let _resend: Resend | undefined;

function getResend(): Resend {
  if (!_resend) {
    _resend = new Resend(getEnv().RESEND_API_KEY);
  }
  return _resend;
}

// ─── Core send function ───────────────────────────────────────────────────────

interface SendEmailOptions {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  replyTo?: string;
  tags?: Array<{ name: string; value: string }>;
}

export async function sendEmail(options: SendEmailOptions): Promise<void> {
  const env = getEnv();
  const resend = getResend();

  const { error } = await resend.emails.send({
    from: `${env.EMAIL_FROM_NAME} <${env.EMAIL_FROM_ADDRESS}>`,
    to: Array.isArray(options.to) ? options.to : [options.to],
    subject: options.subject,
    html: options.html,
    text: options.text,
    replyTo: options.replyTo ?? env.EMAIL_REPLY_TO,
    tags: options.tags,
    headers: {
      // Unsubscribe support
      "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
    },
  });

  if (error) {
    throw new Error(`Email send failed: ${error.message}`);
  }
}

// ─── Batch send (up to 100 per call per Resend limits) ───────────────────────

interface BatchEmailItem {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmailBatch(
  emails: BatchEmailItem[]
): Promise<{ sent: number; failed: number }> {
  const env = getEnv();
  const resend = getResend();

  // Chunk into batches of 100
  const chunks: BatchEmailItem[][] = [];
  for (let i = 0; i < emails.length; i += 100) {
    chunks.push(emails.slice(i, i + 100));
  }

  let sent = 0;
  let failed = 0;

  for (const chunk of chunks) {
    try {
      const { data, error } = await resend.batch.send(
        chunk.map((email) => ({
          from: `${env.EMAIL_FROM_NAME} <${env.EMAIL_FROM_ADDRESS}>`,
          to: [email.to],
          subject: email.subject,
          html: email.html,
          text: email.text,
        }))
      );
      sent += data?.data.length ?? 0;
      if (error) failed += chunk.length;
    } catch {
      failed += chunk.length;
    }
  }

  return { sent, failed };
}

// ─── Transactional email helpers ──────────────────────────────────────────────
// These are thin wrappers — actual content is in /emails/*.tsx templates
// rendered via @react-email/render

export async function sendRsvpConfirmation(params: {
  userId: string;
  eventId: string;
  eventTitle: string;
  eventSlug: string;
  startAt: Date;
  timezone: string;
  isWaitlisted: boolean;
}): Promise<void> {
  // Template render happens in the email template module
  // Import lazily to avoid bundling React Email in edge runtime
  const { renderRsvpConfirmation } = await import(
    "@/emails/rsvp-confirmation"
  );
  const { to, subject, html, text } = await renderRsvpConfirmation(params);
  await sendEmail({ to, subject, html, text });
}

export async function sendEventReminder(params: {
  to: string;
  eventTitle: string;
  eventSlug: string;
  startAt: Date;
  timezone: string;
  daysUntil: 1 | 3;
}): Promise<void> {
  const { renderEventReminder } = await import("@/emails/event-reminder");
  const { subject, html, text } = await renderEventReminder(params);
  await sendEmail({ to: params.to, subject, html, text });
}

export async function sendInviteEmail(params: {
  to: string;
  inviteToken: string;
  eventTitle: string;
  eventSlug: string;
  organizerName: string;
  schoolName: string;
  graduationYear: number;
  startAt: Date;
  timezone: string;
  personalMessage?: string;
  isReminder?: boolean;
}): Promise<void> {
  const { renderInviteEmail } = await import("@/emails/invite-received");
  const { subject, html, text } = await renderInviteEmail(params);
  const emailSubject = params.isReminder
    ? `Reminder: ${subject}`
    : subject;
  await sendEmail({
    to: params.to,
    subject: emailSubject,
    html,
    text,
    tags: [
      { name: "type", value: params.isReminder ? "invite_reminder" : "invite" },
      { name: "event", value: params.eventSlug },
    ],
  });
}

export async function sendNominationEmail(params: {
  to: string;
  nomineeName: string;
  nominationId: string;
  categoryTitle: string;
  eventTitle: string;
  nominatorName: string;
}): Promise<void> {
  const { renderNominationEmail } = await import("@/emails/nomination-received");
  const { subject, html, text } = await renderNominationEmail(params);
  await sendEmail({ to: params.to, subject, html, text });
}

export async function sendMemoryTagEmail(params: {
  to: string;
  taggedUserName: string;
  memoryTagId: string;
  uploaderName: string;
  eventTitle: string;
  memoryId: string;
}): Promise<void> {
  const { renderMemoryTagEmail } = await import("@/emails/memory-tagged");
  const { subject, html, text } = await renderMemoryTagEmail(params);
  await sendEmail({ to: params.to, subject, html, text });
}


// ─── Batch invite emails ──────────────────────────────────────────────────────

export async function sendBatchInviteEmails(
  invites: Array<Parameters<typeof sendInviteEmail>[0]>
): Promise<void> {
  // Send in chunks of 50 to respect rate limits
  const CHUNK_SIZE = 50;
  for (let i = 0; i < invites.length; i += CHUNK_SIZE) {
    const chunk = invites.slice(i, i + CHUNK_SIZE);
    await Promise.allSettled(chunk.map((invite) => sendInviteEmail(invite)));
    // Small delay between chunks to avoid hitting rate limits
    if (i + CHUNK_SIZE < invites.length) {
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
  }
}

export async function sendWaitlistPromoted(params: {
  userId: string;
  eventId: string;
  eventTitle: string;
  eventSlug: string;
  schoolName: string;
  graduationYear: number;
  startAt: Date;
  timezone: string;
}): Promise<void> {
  const { renderWaitlistPromoted } = await import("@/emails/waitlist-promoted");
  const { to, subject, html, text } = await renderWaitlistPromoted(params);
  await sendEmail({ to, subject, html, text });
}
