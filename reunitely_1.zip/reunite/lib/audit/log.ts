import { db } from "@/lib/db";
import { headers } from "next/headers";

// All auditable actions — extend as features are added
export type AuditAction =
  | "EVENT_CREATED"
  | "EVENT_PUBLISHED"
  | "EVENT_UPDATED"
  | "EVENT_ARCHIVED"
  | "EVENT_CLONED"
  | "RSVP_CREATED"
  | "RSVP_UPDATED"
  | "RSVP_CANCELLED"
  | "ATTENDEE_REMOVED"
  | "ATTENDEE_STATUS_CHANGED"
  | "ATTENDEE_CHECKED_IN"
  | "INVITE_SENT"
  | "INVITE_REVOKED"
  | "BROADCAST_SENT"
  | "MEMORY_APPROVED"
  | "MEMORY_REJECTED"
  | "MEMORY_REPORTED"
  | "MEMORY_DELETED"
  | "TAG_APPROVED"
  | "TAG_REJECTED"
  | "NOMINATION_CREATED"
  | "NOMINATION_ACCEPTED"
  | "NOMINATION_DECLINED"
  | "VOTE_CAST"
  | "RESULTS_REVEALED"
  | "PAYMENT_REFUNDED"
  | "PAYMENT_MANUALLY_MARKED"
  | "STRIPE_CONNECTED"
  | "ROLE_CHANGED"
  | "CO_ORGANIZER_ADDED"
  | "CO_ORGANIZER_REMOVED"
  | "DATA_EXPORTED"
  | "ACCOUNT_DELETED"
  | "CONSENT_GRANTED"
  | "CONSENT_REVOKED"
  | "USER_BANNED"
  | "CONTENT_TAKEN_DOWN";

export interface AuditLogEntry {
  actorId?: string;
  action: AuditAction;
  resourceType: string;
  resourceId: string;
  eventId?: string;
  metadata?: Record<string, unknown>;
}

/**
 * Write an audit log entry.
 * Fire-and-forget — never throws. Logs failures to console/Sentry only.
 */
export async function writeAuditLog(entry: AuditLogEntry): Promise<void> {
  try {
    const headersList = headers();
    const ip =
      headersList.get("x-forwarded-for")?.split(",")[0]?.trim() ??
      headersList.get("x-real-ip") ??
      "unknown";

    await db.auditLog.create({
      data: {
        actorId: entry.actorId,
        action: entry.action,
        resourceType: entry.resourceType,
        resourceId: entry.resourceId,
        eventId: entry.eventId,
        metadata: entry.metadata ?? {},
        ipAddress: ip,
      },
    });
  } catch (err) {
    // Audit failure is non-fatal — log but never crash the request
    console.error("[AuditLog] Failed to write audit log entry:", err, entry);
  }
}

/**
 * Convenience wrapper — returns void, safe to await or fire-and-forget
 */
export function auditLog(entry: AuditLogEntry): Promise<void> {
  return writeAuditLog(entry);
}
