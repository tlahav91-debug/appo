"use server";

/**
 * lib/actions/event.actions.ts
 *
 * Server Actions for event management.
 * All actions use withServerAction for consistent auth + error handling.
 *
 * Client usage:
 *   import { publishEventAction } from "@/lib/actions/event.actions";
 *   const result = await publishEventAction(eventId);
 *   if (result.success) { ... } else { toast.error(result.error); }
 */

import { revalidatePath } from "next/cache";
import { withServerAction, type ActionResult } from "@/lib/auth/action-guards";
import {
  requireEventPermission,
  PermissionError,
} from "@/lib/auth/permissions";
import { publishEvent, archiveEvent, updateEvent } from "@/lib/services/event.service";
import { updateEventSchema } from "@/schemas";
import { db } from "@/lib/db";
import { auditLog } from "@/lib/audit/log";
import { z } from "zod";

// ─── Publish event ────────────────────────────────────────────────────────────

export async function publishEventAction(
  eventId: string
): Promise<ActionResult<{ slug: string }>> {
  return withServerAction(async (userId) => {
    const event = await publishEvent(eventId, userId);
    revalidatePath(`/events/${event.slug}`);
    revalidatePath(`/dashboard/events/${eventId}/overview`);
    return { slug: event.slug };
  });
}

// ─── Archive event ────────────────────────────────────────────────────────────

export async function archiveEventAction(
  eventId: string
): Promise<ActionResult<{ archived: boolean }>> {
  return withServerAction(async (userId) => {
    await archiveEvent(eventId, userId);
    revalidatePath("/dashboard/events");
    return { archived: true };
  });
}

// ─── Update event settings ────────────────────────────────────────────────────

const settingsSchema = z.object({
  eventId: z.string().cuid(),
  settings: z.record(z.unknown()),
});

export async function updateEventSettingsAction(
  input: z.infer<typeof settingsSchema>
): Promise<ActionResult<{ updated: boolean }>> {
  return withServerAction(async (userId) => {
    const parsed = settingsSchema.parse(input);
    await requireEventPermission(userId, parsed.eventId, "settings:manage");
    await db.event.update({
      where: { id: parsed.eventId },
      data: { settings: parsed.settings },
    });
    revalidatePath(`/dashboard/events/${parsed.eventId}/settings`);
    return { updated: true };
  });
}

// ─── Approve memory post ──────────────────────────────────────────────────────

export async function approveMemoryAction(
  memoryPostId: string
): Promise<ActionResult<{ approved: boolean }>> {
  return withServerAction(async (userId) => {
    const memory = await db.memoryPost.findUnique({
      where: { id: memoryPostId },
      select: { eventId: true, status: true },
    });
    if (!memory) throw new PermissionError("NOT_FOUND", "Memory not found.");

    await requireEventPermission(userId, memory.eventId, "memories:moderate");

    await db.memoryPost.update({
      where: { id: memoryPostId },
      data: {
        status: "APPROVED",
        moderatedById: userId,
        moderatedAt: new Date(),
      },
    });

    revalidatePath(`/dashboard/events/${memory.eventId}/memories`);
    return { approved: true };
  });
}

// ─── Reject memory post ───────────────────────────────────────────────────────

export async function rejectMemoryAction(
  memoryPostId: string,
  reason?: string
): Promise<ActionResult<{ rejected: boolean }>> {
  return withServerAction(async (userId) => {
    const memory = await db.memoryPost.findUnique({
      where: { id: memoryPostId },
      select: { eventId: true },
    });
    if (!memory) throw new PermissionError("NOT_FOUND", "Memory not found.");

    await requireEventPermission(userId, memory.eventId, "memories:moderate");

    await db.memoryPost.update({
      where: { id: memoryPostId },
      data: {
        status: "REJECTED",
        moderatedById: userId,
        moderatedAt: new Date(),
        moderationNote: reason,
      },
    });

    await auditLog({
      actorId: userId,
      action: "MEMORY_REJECTED",
      resourceType: "MemoryPost",
      resourceId: memoryPostId,
      eventId: memory.eventId,
      metadata: { reason },
    });

    revalidatePath(`/dashboard/events/${memory.eventId}/memories`);
    return { rejected: true };
  });
}

// ─── Check in attendee ────────────────────────────────────────────────────────

export async function checkInAttendeeAction(
  eventId: string,
  attendeeUserId: string
): Promise<ActionResult<{ checkedIn: boolean; checkedInAt: Date }>> {
  return withServerAction(async (userId) => {
    await requireEventPermission(userId, eventId, "attendees:checkin");

    const rsvp = await db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId: attendeeUserId } },
      select: { status: true },
    });

    if (!rsvp || rsvp.status !== "CONFIRMED") {
      throw new PermissionError(
        "FORBIDDEN",
        "Attendee must have a confirmed RSVP to check in."
      );
    }

    const checkedInAt = new Date();

    await db.checkIn.upsert({
      where: { eventId_userId: { eventId, userId: attendeeUserId } },
      create: {
        eventId,
        userId: attendeeUserId,
        status: "CHECKED_IN",
        checkedInAt,
        checkedInByUserId: userId,
        checkInMethod: "MANUAL",
      },
      update: {
        status: "CHECKED_IN",
        checkedInAt,
        checkedInByUserId: userId,
      },
    });

    await auditLog({
      actorId: userId,
      action: "ATTENDEE_CHECKED_IN",
      resourceType: "CheckIn",
      resourceId: attendeeUserId,
      eventId,
    });

    return { checkedIn: true, checkedInAt };
  });
}

// ─── Update attendee organizer note ──────────────────────────────────────────

export async function updateAttendeeNoteAction(
  eventId: string,
  attendeeUserId: string,
  note: string
): Promise<ActionResult<{ updated: boolean }>> {
  return withServerAction(async (userId) => {
    await requireEventPermission(userId, eventId, "attendees:update");

    await db.rSVP.update({
      where: { eventId_userId: { eventId, userId: attendeeUserId } },
      data: { organizerNote: note.trim() || null },
    });

    return { updated: true };
  });
}

// ─── Reveal nomination results ────────────────────────────────────────────────

export async function revealNominationResultsAction(
  categoryId: string
): Promise<ActionResult<{ revealed: boolean }>> {
  return withServerAction(async (userId) => {
    const category = await db.nominationCategory.findUnique({
      where: { id: categoryId },
      select: { eventId: true },
    });
    if (!category) throw new PermissionError("NOT_FOUND", "Category not found.");

    await requireEventPermission(userId, category.eventId, "nominations:manage");

    await db.nominationCategory.update({
      where: { id: categoryId },
      data: { resultsRevealedAt: new Date(), votingStatus: "RESULTS_REVEALED" },
    });

    await auditLog({
      actorId: userId,
      action: "RESULTS_REVEALED",
      resourceType: "NominationCategory",
      resourceId: categoryId,
      eventId: category.eventId,
    });

    revalidatePath(`/dashboard/events/${category.eventId}/nominations`);
    return { revealed: true };
  });
}

// ─── Add committee member ─────────────────────────────────────────────────────

const addCommitteeSchema = z.object({
  eventId: z.string().cuid(),
  email: z.string().email("Valid email required"),
  role: z.enum(["CO_ORGANIZER", "COMMITTEE"]),
  title: z.string().max(80).optional(),
  permissions: z.object({
    canManageRsvps: z.boolean().default(false),
    canSendMessages: z.boolean().default(false),
    canModerateContent: z.boolean().default(false),
    canManageTickets: z.boolean().default(false),
    canViewPayments: z.boolean().default(false),
    canCheckIn: z.boolean().default(true),
  }),
});

export async function addCommitteeMemberAction(
  input: z.infer<typeof addCommitteeSchema>
): Promise<ActionResult<{ memberId: string; userName: string }>> {
  return withServerAction(async (userId) => {
    const parsed = addCommitteeSchema.parse(input);
    await requireEventPermission(userId, parsed.eventId, "settings:manage");

    const targetUser = await db.user.findUnique({
      where: { email: parsed.email, deletedAt: null },
      select: { id: true, name: true },
    });

    if (!targetUser) {
      throw new Error(
        `No Reunitely account found for ${parsed.email}. They need to create an account first.`
      );
    }

    const existing = await db.committeeMember.findUnique({
      where: {
        eventId_userId: { eventId: parsed.eventId, userId: targetUser.id },
      },
    });

    if (existing && !existing.revokedAt) {
      throw new Error(`${targetUser.name} is already a committee member.`);
    }

    const member = existing
      ? await db.committeeMember.update({
          where: { id: existing.id },
          data: {
            role: parsed.role,
            title: parsed.title,
            ...parsed.permissions,
            revokedAt: null,
            addedByUserId: userId,
            addedAt: new Date(),
          },
        })
      : await db.committeeMember.create({
          data: {
            eventId: parsed.eventId,
            userId: targetUser.id,
            role: parsed.role,
            title: parsed.title,
            ...parsed.permissions,
            addedByUserId: userId,
          },
        });

    await auditLog({
      actorId: userId,
      action: "CO_ORGANIZER_ADDED",
      resourceType: "CommitteeMember",
      resourceId: member.id,
      eventId: parsed.eventId,
      metadata: { addedUserId: targetUser.id, role: parsed.role },
    });

    revalidatePath(`/dashboard/events/${parsed.eventId}/settings`);
    return { memberId: member.id, userName: targetUser.name };
  });
}
