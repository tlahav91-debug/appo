"use server";

/**
 * lib/actions/rsvp.actions.ts
 *
 * Server actions for the RSVP flow.
 * These are the primary mutation path — API routes proxy to these.
 */

import { revalidatePath } from "next/cache";
import { withServerAction, type ActionResult } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";
import { auditLog } from "@/lib/audit/log";
import { logConsent } from "@/lib/services/consent.service";
import { cacheDelete, cacheKeys } from "@/lib/cache/redis";
import { sendRsvpConfirmation } from "@/lib/email";
import { promoteFromWaitlist } from "@/lib/services/rsvp.service";
import type { FullRsvpInput } from "@/schemas/rsvp";
import type { Prisma } from "@prisma/client";
import { headers } from "next/headers";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface RsvpActionResult {
  rsvpId: string;
  status: "CONFIRMED" | "PENDING" | "DECLINED" | "WAITLISTED";
  isWaitlisted: boolean;
  waitlistPosition: number | null;
  isNew: boolean;
  requiresPayment: boolean;
  checkoutUrl: string | null;
  eventSlug: string;
}

// ─── submitRsvpAction ─────────────────────────────────────────────────────────

export async function submitRsvpAction(
  eventId: string,
  data: FullRsvpInput,
  inviteToken?: string
): Promise<ActionResult<RsvpActionResult>> {
  return withServerAction(async (userId) => {
    const ip =
      headers().get("x-forwarded-for")?.split(",")[0]?.trim() ?? undefined;

    // ── 1. Load event ──────────────────────────────────────────────────────
    const event = await db.event.findUnique({
      where: { id: eventId, status: "PUBLISHED" },
      select: {
        id: true,
        slug: true,
        title: true,
        startAt: true,
        timezone: true,
        capacity: true,
        waitlistEnabled: true,
        waitlistCapacity: true,
        ticketingEnabled: true,
        stripeAccountId: true,
        settings: true,
      },
    });

    if (!event) throw new Error("Event not found or no longer available.");

    // ── 2. Verify invite token if provided ────────────────────────────────
    let inviteId: string | undefined;
    if (inviteToken) {
      const invite = await db.invite.findUnique({
        where: { token: inviteToken },
        select: { id: true, eventId: true, status: true, expiresAt: true },
      });
      if (
        invite &&
        invite.eventId === eventId &&
        invite.status !== "RSVPD" &&
        (!invite.expiresAt || invite.expiresAt > new Date())
      ) {
        inviteId = invite.id;
      }
    }

    // ── 3. Capacity check ─────────────────────────────────────────────────
    let resolvedStatus: "CONFIRMED" | "DECLINED" | "PENDING" | "WAITLISTED" =
      data.status;
    let waitlistPosition: number | null = null;
    let isWaitlisted = false;

    if (data.status === "CONFIRMED" && event.capacity !== null) {
      const confirmedCount = await db.rSVP.count({
        where: { eventId, status: "CONFIRMED" },
      });

      if (confirmedCount >= event.capacity) {
        if (!event.waitlistEnabled) {
          throw new Error("EVENT_FULL");
        }

        // Check waitlist capacity
        const waitlistCount = await db.rSVP.count({
          where: { eventId, status: "WAITLISTED" },
        });

        if (
          event.waitlistCapacity !== null &&
          waitlistCount >= event.waitlistCapacity
        ) {
          throw new Error("WAITLIST_FULL");
        }

        resolvedStatus = "WAITLISTED";
        waitlistPosition = waitlistCount + 1;
        isWaitlisted = true;
      }
    }

    // ── 4. Upsert RSVP ────────────────────────────────────────────────────
    const existing = await db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId } },
      select: { id: true, status: true },
    });

    // Build dietary array — deduplicate, remove "NONE" if other options present
    const dietaryList = data.dietaryRequirements.filter(
      (d) =>
        d !== "NONE" ||
        data.dietaryRequirements.filter((x) => x !== "NONE").length === 0
    );
    if (data.dietaryNotes?.trim()) {
      dietaryList.push(`Note: ${data.dietaryNotes.trim()}`);
    }

    // Build guest names from guest objects
    const guestNames = data.guests
      .slice(0, data.guestCount)
      .map((g) => g.name)
      .filter(Boolean);

    // Build customAnswers — merge accessibility and transport into it
    const customAnswers: Record<string, string> = { ...data.customAnswers };
    if (data.accessibilityNeeds?.trim()) {
      customAnswers["_accessibility"] = data.accessibilityNeeds.trim();
    }
    if (data.transportationMode) {
      customAnswers["_transport_mode"] = data.transportationMode;
      if (data.transportationNotes?.trim()) {
        customAnswers["_transport_notes"] = data.transportationNotes.trim();
      }
      if (
        data.transportationMode === "OFFERING_RIDE" &&
        data.offeringSeats
      ) {
        customAnswers["_offering_seats"] = String(data.offeringSeats);
      }
      if (data.arrivalCity?.trim()) {
        customAnswers["_arrival_city"] = data.arrivalCity.trim();
      }
    }

    const now = new Date();

    const rsvp = await db.rSVP.upsert({
      where: { eventId_userId: { eventId, userId } },
      create: {
        eventId,
        userId,
        inviteId: inviteId ?? null,
        status: resolvedStatus,
        previousStatus: null,
        guestCount: data.bringGuest ? data.guestCount : 0,
        guestNames,
        dietaryRequirements: dietaryList,
        customAnswers: customAnswers as Prisma.InputJsonValue,
        attendeeNote: data.attendeeNote?.trim() || null,
        consentEmail: data.consentEmail,
        consentSms: data.consentSms,
        consentWhatsApp: data.consentWhatsApp,
        consentGivenAt: now,
        consentIpAddress: ip ?? null,
        waitlistPosition,
        submittedAt: now,
        confirmedAt: resolvedStatus === "CONFIRMED" ? now : null,
      },
      update: {
        status: resolvedStatus,
        previousStatus: existing?.status ?? null,
        guestCount: data.bringGuest ? data.guestCount : 0,
        guestNames,
        dietaryRequirements: dietaryList,
        customAnswers: customAnswers as Prisma.InputJsonValue,
        attendeeNote: data.attendeeNote?.trim() || null,
        consentEmail: data.consentEmail,
        consentSms: data.consentSms,
        consentWhatsApp: data.consentWhatsApp,
        consentGivenAt: now,
        consentIpAddress: ip ?? null,
        waitlistPosition,
        updatedAt: now,
        confirmedAt:
          resolvedStatus === "CONFIRMED" && !existing?.status ? now : undefined,
        cancelledAt: null,
        cancelledReason: null,
      },
    });

    // ── 5. Mark invite as RSVPD ───────────────────────────────────────────
    if (inviteId) {
      await db.invite.update({
        where: { id: inviteId },
        data: { status: "RSVPD", rsvpdAt: now },
      }).catch(console.error);
    }

    // ── 6. Update attendee profile if requested ───────────────────────────
    if (data.updateProfile) {
      await db.attendeeProfile.upsert({
        where: { userId },
        create: {
          userId,
          currentCity: data.currentCity?.trim() || null,
          currentJob: data.currentJob?.trim() || null,
          currentEmployer: data.currentEmployer?.trim() || null,
          bio: data.bio?.trim() || null,
          funFact: data.funFact?.trim() || null,
          linkedinUrl: data.linkedinUrl?.trim() || null,
          showInDirectory: data.showInDirectory,
          showCurrentJob: data.showCurrentJob,
          showCurrentCity: data.showCurrentCity,
          allowDirectMessages: data.allowDirectMessages,
          allowNominations: data.allowNominations,
          profileVisibleTo: data.profileVisibleTo,
        },
        update: {
          ...(data.currentCity?.trim() && { currentCity: data.currentCity.trim() }),
          ...(data.currentJob?.trim() && { currentJob: data.currentJob.trim() }),
          ...(data.currentEmployer?.trim() && { currentEmployer: data.currentEmployer.trim() }),
          ...(data.bio?.trim() && { bio: data.bio.trim() }),
          ...(data.funFact?.trim() && { funFact: data.funFact.trim() }),
          ...(data.linkedinUrl?.trim() && { linkedinUrl: data.linkedinUrl.trim() }),
          showInDirectory: data.showInDirectory,
          showCurrentJob: data.showCurrentJob,
          showCurrentCity: data.showCurrentCity,
          allowDirectMessages: data.allowDirectMessages,
          allowNominations: data.allowNominations,
          profileVisibleTo: data.profileVisibleTo,
        },
      });
    } else {
      // Still update privacy preferences even if not updating profile
      await db.attendeeProfile.updateMany({
        where: { userId },
        data: {
          showInDirectory: data.showInDirectory,
          showCurrentJob: data.showCurrentJob,
          allowDirectMessages: data.allowDirectMessages,
          allowNominations: data.allowNominations,
          profileVisibleTo: data.profileVisibleTo,
        },
      });
    }

    // ── 7. Log consent ────────────────────────────────────────────────────
    await logConsent({
      userId,
      eventId,
      grants: {
        EMAIL_MARKETING: data.consentEmail,
        SMS_MARKETING: data.consentSms,
        WHATSAPP_MARKETING: data.consentWhatsApp,
        PHOTO_TAGGING: data.consentPhotoTagging,
      },
      ipAddress: ip,
    }).catch(console.error);

    // ── 8. Cache invalidation ─────────────────────────────────────────────
    await Promise.all([
      cacheDelete(cacheKeys.attendeeCount(eventId)),
      cacheDelete(cacheKeys.eventStats(eventId)),
      cacheDelete(cacheKeys.event(event.slug)),
    ]);

    // ── 9. Confirmation email (fire and forget) ───────────────────────────
    if (resolvedStatus === "CONFIRMED" || resolvedStatus === "WAITLISTED") {
      sendRsvpConfirmation({
        userId,
        eventId,
        eventTitle: event.title,
        eventSlug: event.slug,
        startAt: event.startAt,
        timezone: event.timezone,
        isWaitlisted,
      }).catch(console.error);
    }

    // ── 10. Payment hook ──────────────────────────────────────────────────
    let requiresPayment = false;
    let checkoutUrl: string | null = null;

    if (
      resolvedStatus === "CONFIRMED" &&
      event.ticketingEnabled &&
      event.stripeAccountId
    ) {
      requiresPayment = true;
      // checkoutUrl returned so client can redirect — created separately
      // to avoid Stripe API call in the action
      // Caller will use /api/events/[id]/checkout to get the URL
    }

    // ── 11. Audit ─────────────────────────────────────────────────────────
    await auditLog({
      actorId: userId,
      action: existing ? "RSVP_UPDATED" : "RSVP_CREATED",
      resourceType: "RSVP",
      resourceId: rsvp.id,
      eventId,
      metadata: {
        status: resolvedStatus,
        previousStatus: existing?.status ?? null,
        isWaitlisted,
        guestCount: rsvp.guestCount,
      },
    });

    revalidatePath(`/events/${event.slug}`);
    revalidatePath(`/dashboard/events/${eventId}/attendees`);

    return {
      rsvpId: rsvp.id,
      status: resolvedStatus as RsvpActionResult["status"],
      isWaitlisted,
      waitlistPosition,
      isNew: !existing,
      requiresPayment,
      checkoutUrl,
      eventSlug: event.slug,
    };
  });
}

// ─── cancelRsvpAction ─────────────────────────────────────────────────────────

export async function cancelRsvpAction(
  eventId: string
): Promise<ActionResult<{ cancelled: boolean }>> {
  return withServerAction(async (userId) => {
    const rsvp = await db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId } },
      select: { id: true, status: true },
    });

    if (!rsvp) throw new Error("RSVP_NOT_FOUND");
    if (rsvp.status === "CANCELLED") throw new Error("Already cancelled.");

    await db.rSVP.update({
      where: { id: rsvp.id },
      data: {
        status: "CANCELLED",
        previousStatus: rsvp.status,
        cancelledAt: new Date(),
        cancelledReason: "Cancelled by attendee",
        waitlistPosition: null,
      },
    });

    await promoteFromWaitlist(eventId).catch(console.error);

    await Promise.all([
      cacheDelete(cacheKeys.attendeeCount(eventId)),
      cacheDelete(cacheKeys.eventStats(eventId)),
    ]);

    await auditLog({
      actorId: userId,
      action: "RSVP_CANCELLED",
      resourceType: "RSVP",
      resourceId: rsvp.id,
      eventId,
    });

    return { cancelled: true };
  });
}

// ─── getExistingRsvpAction ────────────────────────────────────────────────────

export async function getExistingRsvpAction(
  eventId: string
): Promise<ActionResult<{
  status: string;
  guestCount: number;
  dietaryRequirements: string[];
  customAnswers: Record<string, string>;
  attendeeNote: string | null;
  consentEmail: boolean;
  consentSms: boolean;
  consentWhatsApp: boolean;
} | null>> {
  return withServerAction(async (userId) => {
    const rsvp = await db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId } },
      select: {
        status: true,
        guestCount: true,
        guestNames: true,
        dietaryRequirements: true,
        customAnswers: true,
        attendeeNote: true,
        consentEmail: true,
        consentSms: true,
        consentWhatsApp: true,
      },
    });

    if (!rsvp || rsvp.status === "CANCELLED") return null;

    return {
      ...rsvp,
      customAnswers: (rsvp.customAnswers ?? {}) as Record<string, string>,
    };
  });
}
