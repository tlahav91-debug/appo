"use server";

/**
 * lib/actions/wizard.actions.ts
 *
 * Server actions for the 8-step event creation wizard.
 *
 * Draft strategy:
 *   - First save creates an Event with status=DRAFT
 *   - Subsequent saves update by eventId
 *   - URL carries ?draft=<eventId> after first save
 *   - wizardSchema is applied server-side at publish time
 *   - Partial saves never require full validation
 */

import { revalidatePath } from "next/cache";
import { withServerAction, type ActionResult } from "@/lib/auth/action-guards";
import { db } from "@/lib/db";
import { auditLog } from "@/lib/audit/log";
import { generateUniqueSlug } from "@/lib/utils";
import { wizardSchema, type WizardFormData } from "@/schemas/wizard";
import { hash } from "bcryptjs";
import type { Prisma } from "@prisma/client";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface DraftSaveResult {
  eventId: string;
  slug: string;
  savedAt: string;
}

export interface PublishResult {
  eventId: string;
  slug: string;
  url: string;
}

// ─── Convert wizard form data → Prisma event fields ──────────────────────────

function buildEventPayload(
  data: Partial<WizardFormData>,
  userId: string
): Prisma.EventUpdateInput {
  const startAt =
    data.startDate && data.startTime
      ? new Date(`${data.startDate}T${data.startTime}:00`)
      : undefined;

  const endAt =
    data.endDate && data.endTime
      ? new Date(`${data.endDate}T${data.endTime}:00`)
      : data.endDate
      ? new Date(`${data.endDate}T23:59:00`)
      : undefined;

  const doorsOpenAt =
    data.startDate && data.doorsOpenTime
      ? new Date(`${data.startDate}T${data.doorsOpenTime}:00`)
      : undefined;

  // Build venue address from components
  const venueParts = [
    data.venueAddress,
    data.venueCity,
    data.venueState,
    data.venueCountry !== "United States" ? data.venueCountry : undefined,
  ].filter(Boolean);
  const fullVenueAddress = venueParts.join(", ") || undefined;

  const settings: Record<string, unknown> = {
    chatEnabled: data.chatEnabled ?? true,
    memoriesEnabled: data.memoriesEnabled ?? true,
    memoriesAutoApprove: data.memoriesAutoApprove ?? false,
    nominationsEnabled: data.nominationsEnabled ?? true,
    directoryEnabled: data.directoryEnabled ?? true,
    scheduleEnabled: data.scheduleEnabled ?? false,
    inviteMode: data.inviteMode ?? "OPEN",
    allowAttendeesInvite: data.allowAttendeesInvite ?? true,
    referralLinksEnabled: data.referralLinksEnabled ?? true,
    showAttendeeCount: data.showAttendeeCount ?? true,
    showAttendeeList: data.showAttendeeList ?? false,
    verifySchoolEmail: data.verifySchoolEmail ?? false,
    schoolEmailDomain: data.schoolEmailDomain ?? null,
    sendRsvpConfirmation: data.sendRsvpConfirmation ?? true,
    sendEventReminder: data.sendEventReminder ?? true,
    reminderDaysBefore: data.reminderDaysBefore ?? 3,
    smsRemindersEnabled: data.smsRemindersEnabled ?? false,
    whatsappRemindersEnabled: data.whatsappRemindersEnabled ?? false,
    notificationEmail: data.notificationEmail ?? null,
    customQuestions: data.customQuestions ?? [],
    headerLayout: data.headerLayout ?? "CENTERED",
    virtualLink: data.virtualLink ?? null,
    virtualPlatform: data.virtualPlatform ?? null,
    venueType: data.venueType ?? "PHYSICAL",
    reunionNumber: data.reunionNumber ?? null,
    eventType: data.eventType ?? "REUNION",
  };

  return {
    ...(data.title && { title: data.title }),
    ...(data.shortDescription !== undefined && {
      shortDescription: data.shortDescription || null,
    }),
    ...(data.visibility && { visibility: data.visibility }),
    ...(data.schoolName && { schoolName: data.schoolName }),
    ...(data.schoolCity !== undefined && {
      schoolCity: data.schoolCity || null,
    }),
    ...(data.schoolCountry !== undefined && {
      schoolCountry: data.schoolCountry || "US",
    }),
    ...(data.graduationYear && { graduationYear: data.graduationYear }),
    ...(data.classSections !== undefined && {
      classSections: data.classSections,
    }),
    ...(startAt && { startAt }),
    ...(endAt !== undefined && { endAt }),
    ...(doorsOpenAt !== undefined && { doorsOpenAt }),
    ...(data.timezone && { timezone: data.timezone }),
    ...(data.venueName !== undefined && {
      venueName: data.venueName || null,
    }),
    ...(fullVenueAddress !== undefined && { venueAddress: fullVenueAddress }),
    ...(data.coverImageUrl !== undefined && {
      coverImageUrl: data.coverImageUrl || null,
    }),
    ...(!data.capacityUnlimited && data.capacity
      ? { capacity: data.capacity }
      : { capacity: null }),
    ...(data.waitlistEnabled !== undefined && {
      waitlistEnabled: data.waitlistEnabled,
    }),
    ...(data.waitlistCapacity !== undefined && {
      waitlistCapacity: data.waitlistCapacity,
    }),
    ...(data.ticketingEnabled !== undefined && {
      ticketingEnabled: data.ticketingEnabled,
    }),
    settings,
    ...(data.descriptionText !== undefined && {
      description: data.descriptionText
        ? ({ type: "doc", content: [{ type: "paragraph", content: [{ type: "text", text: data.descriptionText }] }] } as Prisma.InputJsonValue)
        : null,
    }),
  };
}

// ─── saveDraftAction ──────────────────────────────────────────────────────────
// Upserts a DRAFT event. Idempotent — safe to call on every field blur.

export async function saveDraftAction(
  data: Partial<WizardFormData>,
  eventId?: string
): Promise<ActionResult<DraftSaveResult>> {
  return withServerAction(async (userId) => {
    const payload = buildEventPayload(data, userId);

    // ── Update existing draft ──────────────────────────────────────────────
    if (eventId) {
      // Verify ownership — only the creator can save their draft
      const existing = await db.event.findUnique({
        where: { id: eventId, createdById: userId, status: "DRAFT" },
        select: { id: true, slug: true },
      });
      if (!existing) {
        throw new Error("Draft not found or access denied.");
      }

      const updated = await db.event.update({
        where: { id: eventId },
        data: payload,
        select: { id: true, slug: true },
      });

      return {
        eventId: updated.id,
        slug: updated.slug,
        savedAt: new Date().toISOString(),
      };
    }

    // ── Create new draft ───────────────────────────────────────────────────
    const title = (data.title?.trim()) || "Untitled Reunion";
    const baseSlug = `${data.schoolName?.toLowerCase().replace(/\s+/g, "-") || "reunion"}-${data.graduationYear ?? new Date().getFullYear()}`;
    const slug = generateUniqueSlug(baseSlug);

    const event = await db.event.create({
      data: {
        slug,
        title,
        status: "DRAFT",
        visibility: data.visibility ?? "UNLISTED",
        schoolName: data.schoolName ?? "TBD",
        schoolCountry: data.schoolCountry ?? "US",
        graduationYear: data.graduationYear ?? new Date().getFullYear(),
        classSections: data.classSections ?? [],
        startAt: data.startDate
          ? new Date(`${data.startDate}T${data.startTime ?? "18:00"}:00`)
          : new Date(Date.now() + 90 * 24 * 60 * 60 * 1000), // 90 days out default
        timezone: data.timezone ?? "America/New_York",
        createdById: userId,
        settings: (payload.settings ?? {}) as Prisma.InputJsonValue,
        ...Object.fromEntries(
          Object.entries(payload).filter(([k]) => k !== "settings")
        ),
      },
      select: { id: true, slug: true },
    });

    // Add organizer as committee member
    await db.committeeMember.create({
      data: {
        eventId: event.id,
        userId,
        role: "ORGANIZER",
        title: "Lead Organizer",
        canManageRsvps: true,
        canSendMessages: true,
        canModerateContent: true,
        canManageTickets: true,
        canViewPayments: true,
        canCheckIn: true,
        addedByUserId: userId,
      },
    });

    await auditLog({
      actorId: userId,
      action: "EVENT_CREATED",
      resourceType: "Event",
      resourceId: event.id,
      metadata: { via: "wizard", status: "DRAFT" },
    });

    return {
      eventId: event.id,
      slug: event.slug,
      savedAt: new Date().toISOString(),
    };
  });
}

// ─── loadDraftAction ──────────────────────────────────────────────────────────
// Loads a draft and converts DB fields back to WizardFormData shape.

export async function loadDraftAction(
  eventId: string
): Promise<ActionResult<Partial<WizardFormData>>> {
  return withServerAction(async (userId) => {
    const event = await db.event.findUnique({
      where: { id: eventId, createdById: userId, status: "DRAFT" },
      include: {
        theme: true,
        tickets: { where: { isActive: true }, take: 3 },
      },
    });

    if (!event) throw new Error("Draft not found.");

    const settings = (event.settings ?? {}) as Record<string, unknown>;

    // Parse stored datetime back to date + time strings
    const startDate = event.startAt
      ? event.startAt.toISOString().split("T")[0] ?? ""
      : "";
    const startTime = event.startAt
      ? event.startAt.toISOString().split("T")[1]?.slice(0, 5) ?? ""
      : "";
    const endDate = event.endAt
      ? event.endAt.toISOString().split("T")[0] ?? ""
      : "";
    const endTime = event.endAt
      ? event.endAt.toISOString().split("T")[1]?.slice(0, 5) ?? ""
      : "";

    const primaryTicket = event.tickets[0];

    const data: Partial<WizardFormData> = {
      // Step 1
      title: event.title,
      shortDescription: event.shortDescription ?? "",
      eventType: (settings.eventType as WizardFormData["eventType"]) ?? "REUNION",
      visibility: event.visibility as WizardFormData["visibility"],

      // Step 2
      schoolName: event.schoolName,
      schoolCity: event.schoolCity ?? "",
      schoolCountry: event.schoolCountry ?? "United States",
      graduationYear: event.graduationYear,
      classSections: event.classSections,
      reunionNumber: (settings.reunionNumber as number) ?? undefined,

      // Step 3
      startDate,
      startTime,
      endDate,
      endTime,
      timezone: event.timezone,
      venueType: (settings.venueType as WizardFormData["venueType"]) ?? "PHYSICAL",
      venueName: event.venueName ?? "",
      venueAddress: event.venueAddress ?? "",
      virtualLink: (settings.virtualLink as string) ?? "",

      // Step 4
      coverImageUrl: event.coverImageUrl ?? "",
      primaryColor: event.theme?.primaryColor ?? "#1E3A5F",
      accentColor: event.theme?.accentColor ?? "#D4AF37",
      headerLayout: (event.theme?.headerLayout as WizardFormData["headerLayout"]) ?? "CENTERED",
      descriptionText:
        event.description && typeof event.description === "object"
          ? extractTextFromTiptap(event.description as Record<string, unknown>)
          : "",

      // Step 5
      capacityUnlimited: !event.capacity,
      capacity: event.capacity ?? undefined,
      waitlistEnabled: event.waitlistEnabled,
      waitlistCapacity: event.waitlistCapacity ?? undefined,
      ticketingEnabled: event.ticketingEnabled,
      ticketName: primaryTicket?.name ?? "General Admission",
      ticketPrice: primaryTicket ? primaryTicket.price / 100 : undefined,
      ticketCurrency: primaryTicket?.currency ?? "USD",
      ticketCapacity: primaryTicket?.capacity ?? undefined,
      customQuestions: (settings.customQuestions as WizardFormData["customQuestions"]) ?? [],

      // Step 6
      inviteMode: (settings.inviteMode as WizardFormData["inviteMode"]) ?? "OPEN",
      allowAttendeesInvite: (settings.allowAttendeesInvite as boolean) ?? true,
      referralLinksEnabled: (settings.referralLinksEnabled as boolean) ?? true,
      showAttendeeCount: (settings.showAttendeeCount as boolean) ?? true,
      showAttendeeList: (settings.showAttendeeList as boolean) ?? false,
      verifySchoolEmail: (settings.verifySchoolEmail as boolean) ?? false,
      schoolEmailDomain: (settings.schoolEmailDomain as string) ?? "",

      // Step 7
      chatEnabled: (settings.chatEnabled as boolean) ?? true,
      memoriesEnabled: (settings.memoriesEnabled as boolean) ?? true,
      memoriesAutoApprove: (settings.memoriesAutoApprove as boolean) ?? false,
      nominationsEnabled: (settings.nominationsEnabled as boolean) ?? true,
      directoryEnabled: (settings.directoryEnabled as boolean) ?? true,
      scheduleEnabled: (settings.scheduleEnabled as boolean) ?? false,
      sendRsvpConfirmation: (settings.sendRsvpConfirmation as boolean) ?? true,
      sendEventReminder: (settings.sendEventReminder as boolean) ?? true,
      reminderDaysBefore: (settings.reminderDaysBefore as number) ?? 3,
      smsRemindersEnabled: (settings.smsRemindersEnabled as boolean) ?? false,
      whatsappRemindersEnabled: (settings.whatsappRemindersEnabled as boolean) ?? false,
      notificationEmail: (settings.notificationEmail as string) ?? "",
    };

    return data;
  });
}

// ─── publishWizardAction ──────────────────────────────────────────────────────
// Full validation then status DRAFT → PUBLISHED.

export async function publishWizardAction(
  data: WizardFormData,
  eventId: string
): Promise<ActionResult<PublishResult>> {
  return withServerAction(async (userId) => {
    // 1. Full schema validation server-side
    const parsed = wizardSchema.parse(data);

    // 2. Ownership check
    const existing = await db.event.findUnique({
      where: { id: eventId, createdById: userId, status: "DRAFT" },
      select: { id: true, slug: true },
    });
    if (!existing) {
      throw new Error("Draft not found or already published.");
    }

    // 3. Build and apply payload
    const payload = buildEventPayload(parsed, userId);

    // 4. Hash password if private
    let passwordHash: string | undefined;
    if (parsed.visibility === "PRIVATE" && parsed.password) {
      passwordHash = await hash(parsed.password, 10);
    }

    // 5. Update event to PUBLISHED in a transaction
    await db.$transaction(async (tx) => {
      await tx.event.update({
        where: { id: eventId },
        data: {
          ...payload,
          status: "PUBLISHED",
          visibility: parsed.visibility,
          publishedAt: new Date(),
          ...(passwordHash ? { passwordHash } : {}),
        },
      });

      // Upsert event theme
      await tx.eventTheme.upsert({
        where: { eventId },
        create: {
          eventId,
          primaryColor: parsed.primaryColor,
          accentColor: parsed.accentColor,
          headerLayout: parsed.headerLayout.toLowerCase(),
        },
        update: {
          primaryColor: parsed.primaryColor,
          accentColor: parsed.accentColor,
          headerLayout: parsed.headerLayout.toLowerCase(),
        },
      });

      // Create ticket if ticketing enabled
      if (parsed.ticketingEnabled && parsed.ticketPrice !== undefined) {
        const existingTickets = await tx.ticket.count({ where: { eventId } });
        if (existingTickets === 0) {
          await tx.ticket.create({
            data: {
              eventId,
              type: "GENERAL",
              name: parsed.ticketName,
              price: Math.round((parsed.ticketPrice ?? 0) * 100),
              currency: parsed.ticketCurrency,
              capacity: parsed.ticketCapacity,
              isVisible: true,
              isActive: true,
            },
          });

          // Early bird ticket
          if (parsed.earlyBirdEnabled && parsed.earlyBirdPrice !== undefined && parsed.earlyBirdDeadline) {
            await tx.ticket.create({
              data: {
                eventId,
                type: "EARLY_BIRD",
                name: "Early Bird",
                price: Math.round(parsed.earlyBirdPrice * 100),
                currency: parsed.ticketCurrency,
                earlyBirdDeadline: new Date(parsed.earlyBirdDeadline),
                saleEndsAt: new Date(parsed.earlyBirdDeadline),
                isVisible: true,
                isActive: true,
              },
            });
          }
        }
      }

      // Create default chat rooms
      await tx.chatRoom.createMany({
        data: [
          { eventId, name: "general", slug: "general", type: "GENERAL", isPinned: true, createdById: userId },
          { eventId, name: "travel-and-hotels", slug: "travel-and-hotels", type: "TOPIC", createdById: userId },
        ],
        skipDuplicates: true,
      });
    });

    await auditLog({
      actorId: userId,
      action: "EVENT_PUBLISHED",
      resourceType: "Event",
      resourceId: eventId,
      metadata: { via: "wizard" },
    });

    revalidatePath(`/events/${existing.slug}`);
    revalidatePath("/dashboard/events");

    return {
      eventId,
      slug: existing.slug,
      url: `${process.env.NEXT_PUBLIC_APP_URL}/events/${existing.slug}`,
    };
  });
}

// ─── deleteDraftAction ────────────────────────────────────────────────────────

export async function deleteDraftAction(
  eventId: string
): Promise<ActionResult<{ deleted: boolean }>> {
  return withServerAction(async (userId) => {
    await db.event.deleteMany({
      where: { id: eventId, createdById: userId, status: "DRAFT" },
    });
    revalidatePath("/dashboard/events");
    return { deleted: true };
  });
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function extractTextFromTiptap(doc: Record<string, unknown>): string {
  try {
    const content = doc.content as Array<Record<string, unknown>>;
    if (!Array.isArray(content)) return "";
    return content
      .flatMap((node) => {
        const inner = node.content as Array<Record<string, unknown>> | undefined;
        return inner?.filter((n) => n.type === "text").map((n) => n.text as string) ?? [];
      })
      .join(" ");
  } catch {
    return "";
  }
}
