/**
 * lib/messaging/notify.ts
 *
 * Unified notification abstraction layer.
 *
 * All outbound communications go through this module, which handles:
 * - Channel routing (email / SMS / WhatsApp / in-app)
 * - Consent checking (per channel)
 * - Quiet hours enforcement
 * - Idempotency (prevent duplicate sends)
 * - Delivery record creation + status updates
 * - Unsubscribe token injection
 */

import { db } from "@/lib/db";
import { sendEmail, sendEmailBatch } from "@/lib/email";
import { sendSmsBatch } from "@/lib/sms/twilio";
import { createNotification } from "@/lib/services/notification.service";
import { renderTemplate, renderSubject } from "@/lib/messaging/templates";
import { getInviteUrl, getUnsubscribeUrl } from "@/lib/utils";
import { formatEventDate } from "@/lib/utils";
import { getEnv } from "@/env";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface RecipientContext {
  userId: string;
  name: string;
  email: string;
  phone?: string | null;
  unsubscribeToken?: string | null;
}

export interface SendContext {
  broadcastId: string;
  eventId: string;
  eventTitle: string;
  eventSlug: string;
  schoolName: string;
  graduationYear: number;
  startAt: Date;
  timezone: string;
  organizerName: string;
  channel: "EMAIL" | "SMS" | "WHATSAPP" | "IN_APP";
  subject?: string;
  bodyText: string;      // plain text (SMS/WhatsApp/in-app)
  bodyHtml?: string;     // HTML (email only)
  quietHoursStart?: number | null; // 0-23 hour to BEGIN quiet period
  quietHoursEnd?: number | null;   // 0-23 hour to END quiet period
  templateVariables?: Record<string, string>;
}

export interface DeliveryResult {
  userId: string;
  status: "SENT" | "SKIPPED" | "FAILED";
  reason?: string;
  providerMessageId?: string;
}

// ─── Quiet hours check ────────────────────────────────────────────────────────

function isInQuietHours(
  start: number | null | undefined,
  end: number | null | undefined,
  timezone: string
): boolean {
  if (start == null || end == null) return false;

  // Get current hour in event timezone
  const now = new Date();
  const localHour = parseInt(
    new Intl.DateTimeFormat("en-US", {
      timeZone: timezone,
      hour: "numeric",
      hour12: false,
    }).format(now),
    10
  );

  // Handle overnight quiet window (e.g. 22 → 8)
  if (start > end) {
    return localHour >= start || localHour < end;
  }
  return localHour >= start && localHour < end;
}

// ─── Idempotency key ──────────────────────────────────────────────────────────

function makeIdempotencyKey(
  broadcastId: string,
  userId: string,
  channel: string
): string {
  return `${broadcastId}:${userId}:${channel}`;
}

// ─── Single recipient send ────────────────────────────────────────────────────

export async function sendToRecipient(
  recipient: RecipientContext,
  ctx: SendContext
): Promise<DeliveryResult> {
  const idempotencyKey = makeIdempotencyKey(
    ctx.broadcastId,
    recipient.userId,
    ctx.channel
  );

  // Idempotency: skip if already sent
  const existing = await db.broadcastDelivery.findUnique({
    where: { idempotencyKey },
    select: { id: true, status: true },
  });

  if (existing && existing.status !== "FAILED") {
    return { userId: recipient.userId, status: "SKIPPED", reason: "Already sent" };
  }

  // Quiet hours check
  if (isInQuietHours(ctx.quietHoursStart, ctx.quietHoursEnd, ctx.timezone)) {
    // Upsert delivery record as SKIPPED (will be retried by scheduler)
    await upsertDelivery(idempotencyKey, {
      broadcastId: ctx.broadcastId,
      userId: recipient.userId,
      channel: ctx.channel,
      recipientEmail: ctx.channel === "EMAIL" ? recipient.email : null,
      recipientPhone: ["SMS", "WHATSAPP"].includes(ctx.channel) ? (recipient.phone ?? null) : null,
      status: "SKIPPED",
    });
    return { userId: recipient.userId, status: "SKIPPED", reason: "Quiet hours" };
  }

  // Create/update delivery record as QUEUED
  const delivery = await upsertDelivery(idempotencyKey, {
    broadcastId: ctx.broadcastId,
    userId: recipient.userId,
    channel: ctx.channel,
    recipientEmail: ctx.channel === "EMAIL" ? recipient.email : null,
    recipientPhone: ["SMS", "WHATSAPP"].includes(ctx.channel) ? (recipient.phone ?? null) : null,
    status: "QUEUED",
  });

  // Build variables for template rendering
  const appUrl = getEnv().NEXT_PUBLIC_APP_URL;
  const eventUrl = `${appUrl}/events/${ctx.eventSlug}`;
  const unsubUrl = recipient.unsubscribeToken
    ? getUnsubscribeUrl(recipient.unsubscribeToken)
    : `${appUrl}/unsubscribe/placeholder?type=event`;

  const vars: Record<string, string> = {
    recipientName: recipient.name.split(" ")[0] ?? recipient.name,
    organizerName: ctx.organizerName,
    eventTitle: ctx.eventTitle,
    schoolName: ctx.schoolName,
    graduationYear: String(ctx.graduationYear),
    eventDate: formatEventDate(ctx.startAt, ctx.timezone),
    eventUrl,
    unsubscribeUrl: unsubUrl,
    ...(ctx.templateVariables ?? {}),
  };

  const renderedText = renderTemplate(ctx.bodyText, vars);
  const renderedHtml = ctx.bodyHtml ? renderTemplate(ctx.bodyHtml, vars) : undefined;
  const renderedSubject = ctx.subject ? renderSubject(ctx.subject, vars) : undefined;

  try {
    let providerMessageId: string | undefined;

    if (ctx.channel === "EMAIL") {
      await sendEmail({
        to: recipient.email,
        subject: renderedSubject ?? `Message from ${ctx.organizerName}`,
        html: renderedHtml ?? `<p>${renderedText}</p>`,
        text: renderedText,
      });
    } else if (ctx.channel === "SMS" && recipient.phone) {
      const result = await sendSmsBatch([
        { to: recipient.phone, body: renderedText.slice(0, 1600) },
      ]);
      if (result.failed > 0) throw new Error(result.errors[0] ?? "SMS failed");
    } else if (ctx.channel === "WHATSAPP" && recipient.phone) {
      const env = getEnv();
      if (!env.TWILIO_WHATSAPP_FROM) {
        throw new Error("WhatsApp not configured");
      }
      const { sendSmsBatch: sendWa } = await import("@/lib/sms/twilio");
      const result = await sendWa([
        { to: recipient.phone, body: renderedText.slice(0, 1600) },
      ]);
      if (result.failed > 0) throw new Error(result.errors[0] ?? "WhatsApp failed");
    } else if (ctx.channel === "IN_APP") {
      await createNotification(recipient.userId, {
        type: "RSVP_CONFIRMED", // closest available type — displayed as announcement
        eventTitle: ctx.eventTitle,
        eventId: ctx.eventId,
      });
    }

    // Mark sent
    await db.broadcastDelivery.update({
      where: { id: delivery.id },
      data: {
        status: "SENT",
        sentAt: new Date(),
        providerMessageId: providerMessageId ?? null,
        errorMessage: null,
      },
    });

    return { userId: recipient.userId, status: "SENT", providerMessageId };
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : "Unknown error";

    await db.broadcastDelivery.update({
      where: { id: delivery.id },
      data: {
        status: "FAILED",
        failedAt: new Date(),
        errorMessage,
      },
    });

    return { userId: recipient.userId, status: "FAILED", reason: errorMessage };
  }
}

// ─── Batch send (all recipients of a broadcast) ───────────────────────────────

export async function sendBroadcastToAll(
  broadcastId: string
): Promise<{ sent: number; failed: number; skipped: number }> {
  const broadcast = await db.broadcast.findUniqueOrThrow({
    where: { id: broadcastId },
    include: {
      event: {
        select: {
          id: true,
          title: true,
          slug: true,
          schoolName: true,
          graduationYear: true,
          startAt: true,
          timezone: true,
        },
      },
    },
  });

  const filter = broadcast.audienceFilter as {
    statuses?: string[];
    cities?: string[];
    badgeTypes?: string[];
  };

  const statusFilter = (filter.statuses ?? ["CONFIRMED"]) as string[];

  // Build the where clause for RSVPs
  const rsvpWhere: Record<string, unknown> = {
    eventId: broadcast.eventId,
    status: { in: statusFilter },
  };

  // Channel-specific consent enforcement
  if (broadcast.channel === "EMAIL") rsvpWhere.consentEmail = true;
  else if (broadcast.channel === "SMS") rsvpWhere.consentSms = true;
  else if (broadcast.channel === "WHATSAPP") rsvpWhere.consentWhatsApp = true;

  const memberships = await db.rSVP.findMany({
    where: rsvpWhere,
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
        },
      },
    },
  });

  // Get organizer name
  const organizer = await db.user.findUnique({
    where: { id: broadcast.createdById },
    select: { name: true },
  });

  // Render body text
  const { renderBroadcastBodyToHtml, extractPlainText } = await import(
    "@/lib/services/broadcast.service"
  );
  const bodyText = extractPlainText(broadcast.body as Record<string, unknown>);
  const bodyHtml =
    broadcast.channel === "EMAIL"
      ? renderBroadcastBodyToHtml(broadcast.body as Record<string, unknown>)
      : undefined;

  const ctx: Omit<SendContext, "broadcastId"> = {
    eventId: broadcast.event.id,
    eventTitle: broadcast.event.title,
    eventSlug: broadcast.event.slug,
    schoolName: broadcast.event.schoolName,
    graduationYear: broadcast.event.graduationYear,
    startAt: broadcast.event.startAt,
    timezone: broadcast.event.timezone,
    organizerName: organizer?.name ?? "The organizing team",
    channel: broadcast.channel as SendContext["channel"],
    subject: broadcast.subject ?? undefined,
    bodyText,
    bodyHtml,
    quietHoursStart: broadcast.quietHoursStart,
    quietHoursEnd: broadcast.quietHoursEnd,
  };

  let sent = 0;
  let failed = 0;
  let skipped = 0;

  // Process in chunks to avoid memory pressure
  const CHUNK_SIZE = 50;
  for (let i = 0; i < memberships.length; i += CHUNK_SIZE) {
    const chunk = memberships.slice(i, i + CHUNK_SIZE);
    const results = await Promise.allSettled(
      chunk.map((m) =>
        sendToRecipient(
          {
            userId: m.userId,
            name: m.user.name,
            email: m.user.email,
            phone: m.user.phone,
          },
          { ...ctx, broadcastId }
        )
      )
    );

    for (const r of results) {
      if (r.status === "fulfilled") {
        if (r.value.status === "SENT") sent++;
        else if (r.value.status === "FAILED") failed++;
        else skipped++;
      } else {
        failed++;
      }
    }

    // Small delay between chunks
    if (i + CHUNK_SIZE < memberships.length) {
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
  }

  return { sent, failed, skipped };
}

// ─── Test send ────────────────────────────────────────────────────────────────

export async function sendTestBroadcast(
  broadcastId: string,
  recipientEmail: string,
  senderName: string
): Promise<void> {
  const broadcast = await db.broadcast.findUniqueOrThrow({
    where: { id: broadcastId },
    include: {
      event: {
        select: {
          title: true,
          slug: true,
          schoolName: true,
          graduationYear: true,
          startAt: true,
          timezone: true,
        },
      },
    },
  });

  const { renderBroadcastBodyToHtml, extractPlainText } = await import(
    "@/lib/services/broadcast.service"
  );
  const bodyText = extractPlainText(broadcast.body as Record<string, unknown>);
  const bodyHtml = renderBroadcastBodyToHtml(
    broadcast.body as Record<string, unknown>
  );

  const appUrl = getEnv().NEXT_PUBLIC_APP_URL;
  const vars: Record<string, string> = {
    recipientName: "Test Recipient",
    organizerName: senderName,
    eventTitle: broadcast.event.title,
    schoolName: broadcast.event.schoolName,
    graduationYear: String(broadcast.event.graduationYear),
    eventDate: formatEventDate(broadcast.event.startAt, broadcast.event.timezone),
    eventUrl: `${appUrl}/events/${broadcast.event.slug}`,
    unsubscribeUrl: `${appUrl}/unsubscribe/preview`,
  };

  const renderedHtml = renderTemplate(bodyHtml, vars);
  const renderedText = renderTemplate(bodyText, vars);
  const subject = broadcast.subject
    ? `[TEST] ${renderSubject(broadcast.subject, vars)}`
    : `[TEST] Message from ${senderName}`;

  await sendEmail({
    to: recipientEmail,
    subject,
    html: `
      <div style="background:#fef3c7;padding:12px 16px;border-radius:8px;margin-bottom:24px;font-family:sans-serif;">
        <strong>⚠️ Test email</strong> — This is a preview. It was not sent to your attendees.
      </div>
      ${renderedHtml}
    `,
    text: `[TEST EMAIL]\n\n${renderedText}`,
  });
}

// ─── Delivery upsert helper ───────────────────────────────────────────────────

async function upsertDelivery(
  idempotencyKey: string,
  data: {
    broadcastId: string;
    userId: string;
    channel: string;
    recipientEmail: string | null;
    recipientPhone: string | null;
    status: string;
  }
) {
  return db.broadcastDelivery.upsert({
    where: { idempotencyKey },
    create: {
      idempotencyKey,
      broadcastId: data.broadcastId,
      userId: data.userId,
      channel: data.channel as "EMAIL" | "SMS" | "WHATSAPP" | "IN_APP",
      recipientEmail: data.recipientEmail,
      recipientPhone: data.recipientPhone,
      status: data.status as "QUEUED" | "SKIPPED",
    },
    update: {
      status: data.status as "QUEUED" | "SKIPPED",
    },
  });
}
