/**
 * lib/messaging/templates.ts
 *
 * Built-in message templates. These are seeded as defaults and can be
 * overridden per-event. Variables are rendered at send time via renderTemplate().
 *
 * Variable syntax: {{variable_name}}
 * Available variables: eventTitle, schoolName, graduationYear, eventDate,
 *   eventUrl, organizerName, recipientName, unsubscribeUrl
 */

export interface TemplateVariable {
  key: string;
  label: string;
  defaultValue: string;
}

export interface BuiltInTemplate {
  type: string;
  name: string;
  channel: "EMAIL" | "SMS";
  subject?: string;
  body: string; // plain text / markdown-ish for SMS; HTML for email
  variables: TemplateVariable[];
}

// ─── Shared variables present in all templates ────────────────────────────────
const COMMON_VARS: TemplateVariable[] = [
  { key: "recipientName", label: "Recipient name", defaultValue: "there" },
  { key: "organizerName", label: "Organizer name", defaultValue: "your organizer" },
  { key: "eventTitle", label: "Event title", defaultValue: "Reunion" },
  { key: "schoolName", label: "School name", defaultValue: "School" },
  { key: "graduationYear", label: "Graduation year", defaultValue: "2005" },
  { key: "eventDate", label: "Event date", defaultValue: "TBD" },
  { key: "eventUrl", label: "Event URL", defaultValue: "" },
  { key: "unsubscribeUrl", label: "Unsubscribe URL", defaultValue: "" },
];

// ─── Email templates ──────────────────────────────────────────────────────────

export const EMAIL_TEMPLATES: BuiltInTemplate[] = [
  {
    type: "INVITE",
    name: "Invitation",
    channel: "EMAIL",
    subject: "You're invited: {{eventTitle}} 🎓",
    body: `Hi {{recipientName}},

{{organizerName}} is organizing the **{{schoolName}} Class of {{graduationYear}}** reunion and would love for you to join!

📅 **{{eventDate}}**

This is your chance to reconnect with old friends, share memories, and celebrate how far you've all come.

**[RSVP Now →]({{eventUrl}})**

Can't make it? Let us know so we can keep you in the loop for future events.

Looking forward to seeing you there!

{{organizerName}}

---
*You received this because someone thought of you. [Unsubscribe]({{unsubscribeUrl}})*`,
    variables: COMMON_VARS,
  },

  {
    type: "REMINDER",
    name: "Event Reminder",
    channel: "EMAIL",
    subject: "Reminder: {{eventTitle}} is coming up! 🗓️",
    body: `Hi {{recipientName}},

Just a friendly reminder — **{{eventTitle}}** is happening on **{{eventDate}}**!

You're confirmed and we can't wait to see you. Here's everything you need:

**[View Event Details →]({{eventUrl}})**

A few things to look forward to:
- Reconnecting with classmates you haven't seen in years
- Sharing memories from your time at {{schoolName}}
- Making new ones

See you soon!

{{organizerName}}

---
*[Manage your preferences]({{unsubscribeUrl}})*`,
    variables: COMMON_VARS,
  },

  {
    type: "RSVP_FOLLOWUP",
    name: "RSVP Follow-up",
    channel: "EMAIL",
    subject: "Still thinking about it? {{eventTitle}} awaits 👋",
    body: `Hi {{recipientName}},

We noticed you haven't RSVP'd yet for **{{eventTitle}}** — and we'd love to have you there!

Your classmates from **{{schoolName}} Class of {{graduationYear}}** are gathering on **{{eventDate}}** and spots are going fast.

**[RSVP Now →]({{eventUrl}})**

Whether you can make it or not, let us know — it helps us plan and makes sure you stay in the loop.

Hope to see you there!

{{organizerName}}

---
*[Unsubscribe]({{unsubscribeUrl}}) if you'd prefer not to hear from us.*`,
    variables: COMMON_VARS,
  },

  {
    type: "PAYMENT_REMINDER",
    name: "Payment Reminder",
    channel: "EMAIL",
    subject: "Your spot is reserved — complete your payment for {{eventTitle}}",
    body: `Hi {{recipientName}},

You've RSVP'd for **{{eventTitle}}** — amazing! There's just one thing left: your ticket payment is still pending.

To confirm your spot, please complete your payment before the deadline:

**[Complete Payment →]({{eventUrl}})**

If you have any questions about payment or need assistance, just reply to this email.

See you at {{eventTitle}}!

{{organizerName}}

---
*[Manage preferences]({{unsubscribeUrl}})*`,
    variables: [
      ...COMMON_VARS,
      { key: "ticketPrice", label: "Ticket price", defaultValue: "" },
      { key: "paymentDeadline", label: "Payment deadline", defaultValue: "" },
    ],
  },

  {
    type: "ANNOUNCEMENT",
    name: "Organizer Announcement",
    channel: "EMAIL",
    subject: "📢 {{eventTitle}} Update",
    body: `Hi {{recipientName}},

{{organizerName}} has an update for **{{eventTitle}}**:

---

*[Your message goes here — describe the update, schedule change, or important news]*

---

**[View Event →]({{eventUrl}})**

Thank you for your patience and excitement — we're thrilled to celebrate with you on **{{eventDate}}**!

{{organizerName}}

---
*[Manage your notification preferences]({{unsubscribeUrl}})*`,
    variables: COMMON_VARS,
  },

  {
    type: "THANK_YOU",
    name: "Post-Event Thank You",
    channel: "EMAIL",
    subject: "Thank you for coming to {{eventTitle}} 💛",
    body: `Hi {{recipientName}},

What a night! Thank you so much for joining us at **{{eventTitle}}**.

Seeing the {{schoolName}} Class of {{graduationYear}} all together was everything we hoped for and more. The laughter, the stories, the moments — we hope you'll carry them with you.

**Memories from the event:**
**[View & Share Photos →]({{eventUrl}})**

Until next time — stay connected, stay in touch, and here's to the next reunion!

With gratitude,
{{organizerName}} and the entire planning committee

---
*[Unsubscribe]({{unsubscribeUrl}}) from future updates.*`,
    variables: COMMON_VARS,
  },
];

// ─── SMS templates ────────────────────────────────────────────────────────────

export const SMS_TEMPLATES: BuiltInTemplate[] = [
  {
    type: "INVITE",
    name: "Invitation (SMS)",
    channel: "SMS",
    body: "Hey {{recipientName}}! {{organizerName}} is inviting you to the {{schoolName}} Class of {{graduationYear}} reunion on {{eventDate}}. RSVP: {{eventUrl}} — Reply STOP to opt out.",
    variables: COMMON_VARS,
  },
  {
    type: "REMINDER",
    name: "Event Reminder (SMS)",
    channel: "SMS",
    body: "Reminder: {{eventTitle}} is coming up on {{eventDate}}! You're confirmed. Details: {{eventUrl}} — Reply STOP to opt out.",
    variables: COMMON_VARS,
  },
  {
    type: "RSVP_FOLLOWUP",
    name: "RSVP Follow-up (SMS)",
    channel: "SMS",
    body: "Hi {{recipientName}}! Still haven't RSVPd for {{eventTitle}} on {{eventDate}}. Spots filling fast: {{eventUrl}} — Reply STOP to opt out.",
    variables: COMMON_VARS,
  },
  {
    type: "PAYMENT_REMINDER",
    name: "Payment Reminder (SMS)",
    channel: "SMS",
    body: "{{eventTitle}}: Your RSVP is confirmed but payment is pending. Complete here: {{eventUrl}} — Reply STOP to opt out.",
    variables: COMMON_VARS,
  },
  {
    type: "ANNOUNCEMENT",
    name: "Announcement (SMS)",
    channel: "SMS",
    body: "{{eventTitle}} update from {{organizerName}}: [your message here]. Details: {{eventUrl}} — Reply STOP to opt out.",
    variables: COMMON_VARS,
  },
  {
    type: "THANK_YOU",
    name: "Post-Event Thank You (SMS)",
    channel: "SMS",
    body: "Thank you for coming to {{eventTitle}}! View event photos & memories: {{eventUrl}} — Reply STOP to opt out.",
    variables: COMMON_VARS,
  },
];

export const ALL_TEMPLATES = [...EMAIL_TEMPLATES, ...SMS_TEMPLATES];

// ─── Template renderer ────────────────────────────────────────────────────────

export function renderTemplate(
  body: string,
  variables: Record<string, string>
): string {
  return body.replace(/\{\{(\w+)\}\}/g, (_, key: string) => {
    return variables[key] ?? `{{${key}}}`;
  });
}

export function renderSubject(
  subject: string,
  variables: Record<string, string>
): string {
  return renderTemplate(subject, variables);
}

// ─── Variable extractor ───────────────────────────────────────────────────────

export function extractVariables(text: string): string[] {
  const matches = text.match(/\{\{(\w+)\}\}/g) ?? [];
  return [...new Set(matches.map((m) => m.slice(2, -2)))];
}
