import twilio from "twilio";
import { getEnv } from "@/env";
import { isValidE164Phone } from "@/lib/utils";

let _client: ReturnType<typeof twilio> | undefined;

function getTwilio() {
  if (!_client) {
    const env = getEnv();
    _client = twilio(env.TWILIO_ACCOUNT_SID, env.TWILIO_AUTH_TOKEN);
  }
  return _client;
}

// ─── SMS ─────────────────────────────────────────────────────────────────────

export interface SendSmsOptions {
  to: string; // E.164 format
  body: string;
}

export async function sendSms(options: SendSmsOptions): Promise<void> {
  if (!isValidE164Phone(options.to)) {
    throw new Error(`Invalid phone number format: ${options.to}`);
  }

  const env = getEnv();
  const client = getTwilio();

  await client.messages.create({
    to: options.to,
    from: env.TWILIO_FROM_NUMBER,
    body: options.body,
  });
}

// ─── SMS batch (rate-limited by Twilio — process sequentially with delay) ─────

export async function sendSmsBatch(
  messages: SendSmsOptions[],
  delayMs = 100
): Promise<{ sent: number; failed: number; errors: string[] }> {
  let sent = 0;
  let failed = 0;
  const errors: string[] = [];

  for (const msg of messages) {
    try {
      await sendSms(msg);
      sent++;
      // Respect Twilio rate limits
      if (delayMs > 0) {
        await new Promise((resolve) => setTimeout(resolve, delayMs));
      }
    } catch (err) {
      failed++;
      errors.push(
        `Failed to send to ${msg.to}: ${err instanceof Error ? err.message : "Unknown error"}`
      );
    }
  }

  return { sent, failed, errors };
}

// ─── WhatsApp (pre-approved templates only) ───────────────────────────────────
// All WhatsApp messages MUST use pre-approved Twilio/Meta message templates.
// Template format: https://www.twilio.com/docs/whatsapp/tutorial/send-whatsapp-notification-messages-templates

export interface SendWhatsAppOptions {
  to: string; // E.164 format
  templateSid: string; // Twilio content template SID
  variables: Record<string, string>; // Template variable substitutions
}

export async function sendWhatsApp(
  options: SendWhatsAppOptions
): Promise<void> {
  const env = getEnv();
  if (!env.TWILIO_WHATSAPP_FROM) {
    throw new Error(
      "TWILIO_WHATSAPP_FROM is not configured. WhatsApp messaging is disabled."
    );
  }

  if (!isValidE164Phone(options.to)) {
    throw new Error(`Invalid phone number format: ${options.to}`);
  }

  const client = getTwilio();

  await client.messages.create({
    to: `whatsapp:${options.to}`,
    from: env.TWILIO_WHATSAPP_FROM,
    contentSid: options.templateSid,
    contentVariables: JSON.stringify(options.variables),
  });
}

// ─── Pre-built template wrappers ──────────────────────────────────────────────
// Template SIDs must be created and approved in your Twilio console first.
// These are placeholder SIDs — replace with actual approved template SIDs.

export async function sendEventReminderSms(params: {
  to: string;
  eventTitle: string;
  eventDate: string;
  eventUrl: string;
}): Promise<void> {
  await sendSms({
    to: params.to,
    body: `Reminder: ${params.eventTitle} is on ${params.eventDate}. Details: ${params.eventUrl}`,
  });
}

export async function sendInviteSms(params: {
  to: string;
  organizerName: string;
  eventTitle: string;
  inviteUrl: string;
}): Promise<void> {
  await sendSms({
    to: params.to,
    body: `${params.organizerName} invited you to ${params.eventTitle}. RSVP here: ${params.inviteUrl} — Reply STOP to opt out.`,
  });
}

/**
 * WhatsApp invite using approved template.
 * Template variables: {{1}}=organizerName, {{2}}=eventTitle, {{3}}=eventDate, {{4}}=inviteUrl
 * Template must be pre-approved as "reunitely_event_invite_v1" in Twilio console.
 */
export async function sendWhatsAppInvite(params: {
  to: string;
  organizerName: string;
  eventTitle: string;
  eventDate: string;
  inviteUrl: string;
  templateSid: string;
}): Promise<void> {
  await sendWhatsApp({
    to: params.to,
    templateSid: params.templateSid,
    variables: {
      "1": params.organizerName,
      "2": params.eventTitle,
      "3": params.eventDate,
      "4": params.inviteUrl,
    },
  });
}
