import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { PermissionError } from "@/lib/auth/permissions";
import * as Sentry from "@sentry/nextjs";

// ─── Response type ────────────────────────────────────────────────────────────

export type ApiResponse<T> =
  | { data: T; error: null }
  | { data: null; error: ApiError };

export interface ApiError {
  code: string;
  message: string;
  details?: unknown;
}

// ─── Success helpers ──────────────────────────────────────────────────────────

export function ok<T>(data: T, status = 200): NextResponse<ApiResponse<T>> {
  return NextResponse.json({ data, error: null }, { status });
}

export function created<T>(data: T): NextResponse<ApiResponse<T>> {
  return ok(data, 201);
}

export function noContent(): NextResponse {
  return new NextResponse(null, { status: 204 });
}

// ─── Error helpers ────────────────────────────────────────────────────────────

export function apiError(
  code: string,
  message: string,
  status: number,
  details?: unknown
): NextResponse<ApiResponse<never>> {
  return NextResponse.json(
    { data: null, error: { code, message, details } },
    { status }
  );
}

export function badRequest(
  message = "Bad request",
  details?: unknown
): NextResponse {
  return apiError("BAD_REQUEST", message, 400, details);
}

export function unauthorized(
  message = "Authentication required"
): NextResponse {
  return apiError("UNAUTHORIZED", message, 401);
}

export function forbidden(message = "Access denied"): NextResponse {
  return apiError("FORBIDDEN", message, 403);
}

export function notFound(message = "Resource not found"): NextResponse {
  return apiError("NOT_FOUND", message, 404);
}

export function conflict(message: string): NextResponse {
  return apiError("CONFLICT", message, 409);
}

export function unprocessable(message: string, details?: unknown): NextResponse {
  return apiError("UNPROCESSABLE", message, 422, details);
}

export function tooManyRequests(retryAfter?: number): NextResponse {
  return apiError(
    "RATE_LIMITED",
    "Too many requests. Please slow down.",
    429,
    retryAfter ? { retryAfter } : undefined
  );
}

export function internalError(message = "Internal server error"): NextResponse {
  return apiError("INTERNAL_ERROR", message, 500);
}

// ─── Route handler error boundary ─────────────────────────────────────────────
// Wrap any route handler to get consistent error handling

export function withErrorHandling(
  handler: (...args: Parameters<typeof handler>) => Promise<NextResponse>
) {
  return async (...args: Parameters<typeof handler>): Promise<NextResponse> => {
    try {
      return await handler(...args);
    } catch (err) {
      // Known: validation errors
      if (err instanceof ZodError) {
        return badRequest("Validation failed", err.flatten().fieldErrors);
      }

      // Known: permission errors
      if (err instanceof PermissionError) {
        if (err.code === "NOT_MEMBER" || err.code === "NOT_FOUND") {
          return notFound();
        }
        return forbidden(err.message);
      }

      // Prisma unique constraint
      if (
        typeof err === "object" &&
        err !== null &&
        "code" in err &&
        err.code === "P2002"
      ) {
        return conflict("A record with this value already exists.");
      }

      // Unknown: capture in Sentry
      Sentry.captureException(err);
      console.error("[API Error]", err);
      return internalError();
    }
  };
}
