/**
 * SERVER / CLIENT BOUNDARY GUIDELINES
 * =====================================
 *
 * This project uses Next.js App Router with strict server/client separation.
 * Every file is a Server Component by default unless marked "use client".
 *
 * ─── RULE 1: Default to Server Components ─────────────────────────────────
 *
 * Server Components can:
 *   ✅ Access databases directly (Prisma)
 *   ✅ Read environment variables (including secrets)
 *   ✅ Fetch data without waterfalls (parallel Promise.all)
 *   ✅ Reduce client bundle size (no JS sent to browser)
 *   ✅ Call server-only services (email, SMS, S3)
 *
 * Server Components CANNOT:
 *   ❌ Use useState, useEffect, useRef, other hooks
 *   ❌ Add event listeners (onClick, onChange)
 *   ❌ Use browser APIs (window, document, localStorage)
 *   ❌ Use React Context directly
 *
 * ─── RULE 2: Mark Client Components explicitly ────────────────────────────
 *
 * Add "use client" at the top of the file when:
 *   - Using useState / useReducer / useEffect
 *   - Adding event handlers (onClick, onSubmit, onChange)
 *   - Using browser APIs
 *   - Using hooks from third-party libs (useQuery, useForm, etc.)
 *   - Using React Context consumers
 *
 * ─── RULE 3: Push "use client" as deep as possible ───────────────────────
 *
 * BAD — makes the whole page client-side:
 *   // app/dashboard/events/page.tsx
 *   "use client"
 *   export default function Page() { ... }
 *
 * GOOD — only the interactive part is client:
 *   // app/dashboard/events/page.tsx (Server)
 *   import { EventFilters } from "./EventFilters"; // "use client"
 *   export default async function Page() {
 *     const events = await listUserEvents(userId);
 *     return <EventList events={events}><EventFilters /></EventList>;
 *   }
 *
 * ─── RULE 4: Never import server-only code in Client Components ────────────
 *
 * Files that should NEVER be imported client-side:
 *   - lib/db/index.ts (Prisma)
 *   - lib/services/*.ts (they use Prisma)
 *   - lib/email/index.ts (Resend, server SDK)
 *   - lib/sms/twilio.ts (Twilio, server SDK)
 *   - lib/storage/s3.ts (AWS SDK)
 *   - lib/stripe/index.ts (Stripe server SDK)
 *   - env.ts getEnv() function (exposes secrets)
 *
 * Use the "server-only" package to enforce this at compile time:
 *   import "server-only"; // at top of server-only modules
 *
 * ─── RULE 5: Data flow patterns ───────────────────────────────────────────
 *
 * Pattern A — Server Component fetches, passes as props (preferred for initial load)
 *   async function Page() {
 *     const data = await fetchData(); // server-side, no loading state
 *     return <ClientComponent initialData={data} />;
 *   }
 *
 * Pattern B — Client Component fetches via React Query (preferred for interactive/real-time)
 *   "use client"
 *   function Component() {
 *     const { data } = useQuery({ queryKey: ["data"], queryFn: fetchData });
 *     return <div>{data}</div>;
 *   }
 *
 * Pattern C — Server Action (mutations from Client Components without API route)
 *   "use server"
 *   export async function updateEvent(data: FormData) {
 *     const event = await eventService.update(data);
 *     revalidatePath("/events");
 *   }
 *
 * ─── RULE 6: Security boundaries ──────────────────────────────────────────
 *
 * - ALL authentication checks happen SERVER-SIDE (in Route Handlers or Server Components)
 * - Client-side auth (useUser, usePermission) is for UX gating ONLY — never security
 * - Never pass userId from client to server as body param — always derive from auth()
 * - Never trust query params or request bodies without Zod validation
 *
 * ─── Boundary cheat sheet ─────────────────────────────────────────────────
 *
 * File                              | Runtime  | Direct DB? | Event Handlers?
 * ──────────────────────────────────|──────────|────────────|────────────────
 * app/**/page.tsx (default)         | Server   | ✅         | ❌
 * app/**/layout.tsx (default)       | Server   | ✅         | ❌
 * app/**/loading.tsx                | Server   | ❌         | ❌
 * app/api/**/route.ts               | Server   | ✅         | ❌
 * components/providers/*.tsx        | Client   | ❌         | ✅
 * components/shared/*.tsx (default) | Server   | ❌         | ❌
 * components/**/*.tsx "use client"  | Client   | ❌         | ✅
 * hooks/*.ts                        | Client   | ❌         | ✅
 * lib/services/*.ts                 | Server   | ✅         | ❌
 * lib/utils/index.ts                | Both     | ❌         | ❌
 * schemas/index.ts                  | Both     | ❌         | ❌
 * types/index.ts                    | Both     | ❌         | ❌
 */

// This file is documentation only — no executable code
export {};
