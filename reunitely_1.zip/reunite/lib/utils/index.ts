import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import slugifyLib from "slugify";
import { nanoid } from "nanoid";
import { format, formatDistanceToNow, isAfter, isBefore } from "date-fns";
import { formatInTimeZone } from "date-fns-tz";

// ─── Class name merging ───────────────────────────────────────────────────────

export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

// ─── Slug generation ─────────────────────────────────────────────────────────

export function generateSlug(input: string): string {
  return slugifyLib(input, {
    lower: true,
    strict: true,
    trim: true,
  });
}

export function generateUniqueSlug(base: string): string {
  const slug = generateSlug(base);
  const suffix = nanoid(6).toLowerCase();
  return `${slug}-${suffix}`;
}

export function generateInviteToken(): string {
  return nanoid(32);
}

// ─── Date formatting ─────────────────────────────────────────────────────────

export function formatEventDate(
  date: Date,
  timezone: string = "UTC"
): string {
  return formatInTimeZone(date, timezone, "EEEE, MMMM d, yyyy");
}

export function formatEventTime(
  date: Date,
  timezone: string = "UTC"
): string {
  return formatInTimeZone(date, timezone, "h:mm a zzz");
}

export function formatEventDateTime(
  date: Date,
  timezone: string = "UTC"
): string {
  return formatInTimeZone(date, timezone, "MMM d, yyyy · h:mm a zzz");
}

export function formatRelativeTime(date: Date): string {
  return formatDistanceToNow(date, { addSuffix: true });
}

export function formatShortDate(date: Date): string {
  return format(date, "MMM d, yyyy");
}

export function isEventUpcoming(startAt: Date): boolean {
  return isAfter(startAt, new Date());
}

export function isEventPast(endAt: Date | null, startAt: Date): boolean {
  const referenceDate = endAt ?? startAt;
  return isBefore(referenceDate, new Date());
}

// ─── Currency formatting ─────────────────────────────────────────────────────

export function formatCurrency(
  amountCents: number,
  currency: string = "USD",
  locale: string = "en-US"
): string {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency: currency.toUpperCase(),
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amountCents / 100);
}

export function centsToFloat(cents: number): number {
  return cents / 100;
}

export function floatToCents(amount: number): number {
  return Math.round(amount * 100);
}

// ─── String helpers ───────────────────────────────────────────────────────────

export function truncate(str: string, maxLength: number): string {
  if (str.length <= maxLength) return str;
  return `${str.slice(0, maxLength - 3)}...`;
}

export function getInitials(name: string): string {
  return name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

export function pluralize(
  count: number,
  singular: string,
  plural?: string
): string {
  if (count === 1) return `1 ${singular}`;
  return `${count} ${plural ?? `${singular}s`}`;
}

export function formatOrdinal(n: number): string {
  const s = ["th", "st", "nd", "rd"] as const;
  const v = n % 100;
  return `${n}${s[(v - 20) % 10] ?? s[v] ?? s[0]}`;
}

// ─── URL helpers ─────────────────────────────────────────────────────────────

export function getEventUrl(slug: string): string {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "https://reunitely.app";
  return `${base}/events/${slug}`;
}

export function getInviteUrl(token: string): string {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "https://reunitely.app";
  return `${base}/invite/${token}`;
}

export function getUnsubscribeUrl(token: string): string {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "https://reunitely.app";
  return `${base}/unsubscribe/${token}`;
}

// ─── Social share URLs ───────────────────────────────────────────────────────

export function getWhatsAppShareUrl(text: string, url: string): string {
  return `https://wa.me/?text=${encodeURIComponent(`${text}\n${url}`)}`;
}

export function getFacebookShareUrl(url: string): string {
  return `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
}

export function getTwitterShareUrl(text: string, url: string): string {
  return `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
}

// ─── Validation helpers ───────────────────────────────────────────────────────

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function isValidE164Phone(phone: string): boolean {
  return /^\+[1-9]\d{6,14}$/.test(phone);
}

// ─── Type guards ─────────────────────────────────────────────────────────────

export function isDefined<T>(value: T | null | undefined): value is T {
  return value !== null && value !== undefined;
}

export function assertDefined<T>(
  value: T | null | undefined,
  message: string
): asserts value is T {
  if (!isDefined(value)) throw new Error(message);
}

// ─── Array helpers ────────────────────────────────────────────────────────────

export function groupBy<T, K extends string>(
  array: T[],
  keyFn: (item: T) => K
): Record<K, T[]> {
  return array.reduce(
    (acc, item) => {
      const key = keyFn(item);
      if (!acc[key]) acc[key] = [];
      acc[key]!.push(item);
      return acc;
    },
    {} as Record<K, T[]>
  );
}

export function chunk<T>(array: T[], size: number): T[][] {
  return Array.from({ length: Math.ceil(array.length / size) }, (_, i) =>
    array.slice(i * size, i * size + size)
  );
}

// ─── Object helpers ───────────────────────────────────────────────────────────

export function pick<T extends object, K extends keyof T>(
  obj: T,
  keys: K[]
): Pick<T, K> {
  return keys.reduce(
    (acc, key) => {
      if (key in obj) acc[key] = obj[key];
      return acc;
    },
    {} as Pick<T, K>
  );
}

export function omit<T extends object, K extends keyof T>(
  obj: T,
  keys: K[]
): Omit<T, K> {
  const result = { ...obj };
  keys.forEach((key) => delete result[key]);
  return result as Omit<T, K>;
}
