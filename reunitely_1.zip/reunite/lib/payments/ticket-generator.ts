/**
 * lib/payments/ticket-generator.ts
 *
 * Generates ticket codes and QR payloads for attendee tickets.
 *
 * Ticket code format: RUN-XXXXX-XXXXX (12 characters, alphanumeric, URL-safe)
 * QR payload: JSON string signed with a simple HMAC for server-side verification
 *             at check-in. Not cryptographically perfect, but sufficient for
 *             event check-in use cases (not high-value crypto).
 */

import { createHmac, randomBytes } from "crypto";

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no confusable chars (0/O, 1/I)

/** Generate a human-readable ticket code, e.g. RUN-AB3KZ-7MPN2 */
export function generateTicketCode(): string {
  const part = (len: number) =>
    Array.from({ length: len }, () => ALPHABET[randomBytes(1)[0]! % ALPHABET.length]).join("");
  return `RUN-${part(5)}-${part(5)}`;
}

/** QR payload JSON — scanned at check-in */
export interface QrPayload {
  tc: string;   // ticketCode
  ev: string;   // eventId
  u: string;    // userId
  ts: number;   // issued timestamp (seconds)
  sig: string;  // HMAC-SHA256 of tc:ev:u:ts
}

export function generateQrPayload(
  ticketCode: string,
  eventId: string,
  userId: string
): string {
  const ts = Math.floor(Date.now() / 1000);
  const secret = process.env.TICKET_QR_SECRET ?? process.env.CRON_SECRET ?? "dev-secret";
  const sig = createHmac("sha256", secret)
    .update(`${ticketCode}:${eventId}:${userId}:${ts}`)
    .digest("hex")
    .slice(0, 16); // 64-bit hex prefix is plenty for check-in

  const payload: QrPayload = { tc: ticketCode, ev: eventId, u: userId, ts, sig };
  return JSON.stringify(payload);
}

/** Verify a QR payload at check-in. Returns null if invalid. */
export function verifyQrPayload(
  raw: string
): QrPayload | null {
  try {
    const parsed = JSON.parse(raw) as QrPayload;
    const { tc, ev, u, ts, sig } = parsed;
    if (!tc || !ev || !u || !ts || !sig) return null;

    const secret = process.env.TICKET_QR_SECRET ?? process.env.CRON_SECRET ?? "dev-secret";
    const expectedSig = createHmac("sha256", secret)
      .update(`${tc}:${ev}:${u}:${ts}`)
      .digest("hex")
      .slice(0, 16);

    if (expectedSig !== sig) return null;

    // Reject tickets older than 1 year (stale QR defense)
    const ageSeconds = Math.floor(Date.now() / 1000) - ts;
    if (ageSeconds > 365 * 24 * 3600) return null;

    return parsed;
  } catch {
    return null;
  }
}
