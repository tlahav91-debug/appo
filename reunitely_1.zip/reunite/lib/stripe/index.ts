import Stripe from "stripe";
import { getEnv } from "@/env";

let _stripe: Stripe | undefined;

export function getStripe(): Stripe {
  if (!_stripe) {
    _stripe = new Stripe(getEnv().STRIPE_SECRET_KEY, {
      apiVersion: "2024-06-20",
      typescript: true,
      appInfo: {
        name: "Reunitely",
        version: "0.1.0",
        url: "https://reunitely.app",
      },
    });
  }
  return _stripe;
}

// ─── Types ───────────────────────────────────────────────────────────────────

export interface CreateCheckoutSessionParams {
  eventId: string;
  ticketId: string;
  ticketName: string;
  priceInCents: number;
  currency: string;
  quantity: number;
  userId: string;
  userEmail: string;
  eventSlug: string;
  connectedAccountId?: string;
  applicationFeePercent?: number;
  // Optional: override line items entirely (for multi-ticket + donation)
  lineItems?: Stripe.Checkout.SessionCreateParams.LineItem[];
  // Optional: extra metadata fields
  metadata?: Record<string, string>;
}

export interface CheckoutSessionResult {
  sessionId: string;
  url: string;
}

// ─── Checkout ────────────────────────────────────────────────────────────────

export async function createCheckoutSession(
  params: CreateCheckoutSessionParams
): Promise<CheckoutSessionResult> {
  const stripe = getStripe();
  const env = getEnv();
  const baseUrl = env.NEXT_PUBLIC_APP_URL;

  const sessionParams: Stripe.Checkout.SessionCreateParams = {
    mode: "payment",
    payment_method_types: ["card"],
    customer_email: params.userEmail,
    line_items: params.lineItems ?? [
      {
        price_data: {
          currency: params.currency.toLowerCase(),
          unit_amount: params.priceInCents,
          product_data: {
            name: params.ticketName,
          },
        },
        quantity: params.quantity,
      },
    ],
    metadata: {
      eventId: params.eventId,
      ticketId: params.ticketId,
      userId: params.userId,
      ...(params.metadata ?? {}),
    },
    success_url: `${baseUrl}/events/${params.eventSlug}/rsvp?session_id={CHECKOUT_SESSION_ID}&success=true`,
    cancel_url: `${baseUrl}/events/${params.eventSlug}?checkout=cancelled`,
    allow_promotion_codes: true,
    billing_address_collection: "auto",
  };

  // Route payment through Stripe Connect if organizer has connected account
  if (params.connectedAccountId) {
    const feePercent = params.applicationFeePercent ?? 2;
    const applicationFeeAmount = Math.round(
      (params.priceInCents * params.quantity * feePercent) / 100
    );
    sessionParams.payment_intent_data = {
      application_fee_amount: applicationFeeAmount,
      transfer_data: {
        destination: params.connectedAccountId,
      },
    };
  }

  const session = await stripe.checkout.sessions.create(sessionParams);

  if (!session.url) {
    throw new Error("Stripe checkout session URL is missing");
  }

  return { sessionId: session.id, url: session.url };
}

// ─── Connect onboarding ───────────────────────────────────────────────────────

export async function createConnectAccountLink(
  accountId: string,
  eventId: string
): Promise<string> {
  const stripe = getStripe();
  const env = getEnv();

  const link = await stripe.accountLinks.create({
    account: accountId,
    refresh_url: `${env.NEXT_PUBLIC_APP_URL}/dashboard/events/${eventId}/payments?stripe=refresh`,
    return_url: `${env.NEXT_PUBLIC_APP_URL}/dashboard/events/${eventId}/payments?stripe=connected`,
    type: "account_onboarding",
  });

  return link.url;
}

export async function createConnectAccount(
  userEmail: string
): Promise<string> {
  const stripe = getStripe();

  const account = await stripe.accounts.create({
    type: "express",
    email: userEmail,
    capabilities: {
      card_payments: { requested: true },
      transfers: { requested: true },
    },
  });

  return account.id;
}

export async function getConnectAccountStatus(accountId: string): Promise<{
  chargesEnabled: boolean;
  payoutsEnabled: boolean;
  detailsSubmitted: boolean;
}> {
  const stripe = getStripe();
  const account = await stripe.accounts.retrieve(accountId);
  return {
    chargesEnabled: account.charges_enabled,
    payoutsEnabled: account.payouts_enabled,
    detailsSubmitted: account.details_submitted,
  };
}

// ─── Refunds ──────────────────────────────────────────────────────────────────

export async function refundPayment(
  paymentIntentId: string,
  amountCents?: number
): Promise<Stripe.Refund> {
  const stripe = getStripe();
  return stripe.refunds.create({
    payment_intent: paymentIntentId,
    amount: amountCents, // partial refund if specified
  });
}

// ─── Webhook signature verification ──────────────────────────────────────────

export function constructWebhookEvent(
  payload: Buffer,
  signature: string
): Stripe.Event {
  const stripe = getStripe();
  return stripe.webhooks.constructEvent(
    payload,
    signature,
    getEnv().STRIPE_WEBHOOK_SECRET
  );
}
