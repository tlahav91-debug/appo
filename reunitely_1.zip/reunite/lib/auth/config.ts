/**
 * lib/auth/config.ts
 *
 * Auth Architecture: Clerk (not Auth.js)
 * ═══════════════════════════════════════
 *
 * Decision rationale:
 * - Clerk v5 is already installed and wired in this codebase
 * - Clerk handles magic link, Google, Facebook OAuth natively with zero config
 * - Clerk's `auth()` is RSC-compatible and works in both Server Components and
 *   Route Handlers without any session adapter or DB session table
 * - The Clerk → DB user sync already exists via the webhook at
 *   /api/auth/webhook/route.ts
 * - Auth.js would require ripping out Clerk, adding a DB session table to the
 *   schema, and rewriting all auth() call sites — net negative
 *
 * Role model:
 * - Platform-level roles live in User.platformRole (PlatformRole enum)
 *   → USER, MODERATOR, SUPER_ADMIN
 * - Event-level roles live in CommitteeMember.role (MembershipRole enum)
 *   → ORGANIZER, CO_ORGANIZER, COMMITTEE, ATTENDEE, GUEST_ATTENDEE
 * - RSVP attendance status lives in RSVP.status — separate from role
 *
 * Auth flows:
 * - Magic link: Clerk Email Link (zero-config, Clerk-hosted)
 * - Google OAuth: Clerk Social Connection (Google)
 * - Facebook OAuth: Clerk Social Connection (Facebook) — enabled in dashboard
 * - Invite token: validated in /invite/[token] before Clerk signup is required
 *
 * Session boundary:
 * - Server: auth() from @clerk/nextjs/server — synchronous in RSC/Route Handlers
 * - Client: useUser() / useAuth() from @clerk/nextjs — for UI-only checks
 * - NEVER trust client-side auth for security decisions
 */

// ─── Clerk public metadata shape ─────────────────────────────────────────────
// We store the platform role in Clerk's publicMetadata so it is available in
// the JWT without a DB round-trip in middleware.

export interface ClerkPublicMetadata {
  platformRole: "USER" | "MODERATOR" | "SUPER_ADMIN";
}

// ─── Clerk private metadata shape ────────────────────────────────────────────
// Only readable server-side via the Clerk backend API.

export interface ClerkPrivateMetadata {
  dbUserId: string; // our internal User.id — set on first webhook sync
}

// ─── Route protection tiers ───────────────────────────────────────────────────
//
// TIER 0 — Fully public (no auth required, no rate limit)
//   /  /features  /pricing  /about  /events/[slug] (public events)
//
// TIER 1 — Public but invite-gated
//   /invite/[token]  — token validated before signup prompt
//   /events/[slug]/rsvp — may require invite token for private events
//
// TIER 2 — Authenticated (any signed-in user)
//   /dashboard/**  /chat/**  /profile/**
//
// TIER 3 — Event-role gated (server-side committee check)
//   /dashboard/events/[id]/attendees
//   /dashboard/events/[id]/payments
//   /dashboard/events/[id]/settings
//   etc.
//
// TIER 4 — Platform-role gated
//   /admin/**  (MODERATOR or SUPER_ADMIN only)

export const PUBLIC_ROUTES = [
  "/",
  "/features(.*)",
  "/pricing(.*)",
  "/about(.*)",
  "/login(.*)",
  "/signup(.*)",
  "/sso-callback(.*)",      // Clerk OAuth callback
  "/events/(?!preview).*",  // public event pages — /events/preview/* requires auth
  "/invite/(.*)",           // invite landing
  "/unsubscribe/(.*)",
  "/api/auth/webhook",
  "/api/webhooks/(.*)",
  "/api/events/:slug",      // GET only – enforced in handler
  "/api/cron/(.*)",         // CRON_SECRET header protected
] as const;

export const AUTH_REDIRECT_ROUTES = ["/login(.*)", "/signup(.*)"] as const;

export const ADMIN_ROUTES = ["/admin(.*)"] as const;

// ─── Clerk appearance (shared config for sign-in / sign-up) ──────────────────
export const CLERK_APPEARANCE = {
  variables: {
    colorPrimary: "#2563EB",       // blue-600 matches Reunitely brand
    colorBackground: "#FAFAF8",
    fontFamily: "'DM Sans', sans-serif",
    borderRadius: "0.5rem",
  },
  elements: {
    formButtonPrimary:
      "bg-blue-600 hover:bg-blue-700 text-white font-semibold",
    card: "shadow-card border border-border",
    headerTitle: "font-display",
    socialButtonsBlockButton:
      "border-border text-slate-700 hover:bg-slate-50",
  },
} as const;

// ─── Sign-in / sign-up URL constants ─────────────────────────────────────────
export const SIGN_IN_URL = "/login";
export const SIGN_UP_URL = "/signup";
export const AFTER_SIGN_IN_URL = "/dashboard/events";
export const AFTER_SIGN_UP_URL = "/dashboard/events";
