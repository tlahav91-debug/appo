/**
 * lib/auth/session.ts
 *
 * Server-side helpers for getting the current authenticated user.
 * These run in Server Components and Route Handlers only.
 *
 * Pattern:
 *   const { user, dbUser } = await getAuthSession();
 *   if (!dbUser) redirect('/login');
 */

import { auth, currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import type { User } from "@prisma/client";
import type { ClerkPublicMetadata } from "@/lib/auth/config";
import { SIGN_IN_URL } from "@/lib/auth/config";

// ─── Lightweight session (no DB call) ────────────────────────────────────────
// Use when you only need userId/platformRole (available from Clerk JWT).

export function getSession() {
  const { userId, sessionClaims } = auth();
  if (!userId) return null;

  const meta = sessionClaims?.publicMetadata as ClerkPublicMetadata | undefined;
  return {
    clerkUserId: userId,
    platformRole: meta?.platformRole ?? "USER",
    isSuperAdmin: meta?.platformRole === "SUPER_ADMIN",
    isModerator:
      meta?.platformRole === "MODERATOR" ||
      meta?.platformRole === "SUPER_ADMIN",
  };
}

// ─── Full session with DB user (most common) ──────────────────────────────────
// Fetches the User row from our DB. Use in pages/actions that need User.id.

export interface AuthSession {
  clerkUserId: string;
  user: User;
  platformRole: "USER" | "MODERATOR" | "SUPER_ADMIN";
  isSuperAdmin: boolean;
  isModerator: boolean;
}

export async function getAuthSession(): Promise<AuthSession | null> {
  const { userId, sessionClaims } = auth();
  if (!userId) return null;

  const user = await db.user.findUnique({
    where: { clerkId: userId, deletedAt: null },
  });

  if (!user) return null;

  const meta = sessionClaims?.publicMetadata as ClerkPublicMetadata | undefined;
  const platformRole = meta?.platformRole ?? user.platformRole ?? "USER";

  return {
    clerkUserId: userId,
    user,
    platformRole: platformRole as AuthSession["platformRole"],
    isSuperAdmin: platformRole === "SUPER_ADMIN",
    isModerator: platformRole === "MODERATOR" || platformRole === "SUPER_ADMIN",
  };
}

// ─── Require auth — redirects if not signed in ───────────────────────────────
// Use at the top of Server Component page functions.

export async function requireAuth(
  redirectTo?: string
): Promise<AuthSession> {
  const session = await getAuthSession();
  if (!session) {
    const loginUrl = redirectTo
      ? `${SIGN_IN_URL}?redirect_url=${encodeURIComponent(redirectTo)}`
      : SIGN_IN_URL;
    redirect(loginUrl);
  }
  return session;
}

// ─── Require platform role ─────────────────────────────────────────────────────

export async function requirePlatformRole(
  minimumRole: "MODERATOR" | "SUPER_ADMIN"
): Promise<AuthSession> {
  const session = await requireAuth();

  const roleRank: Record<string, number> = {
    USER: 0,
    MODERATOR: 1,
    SUPER_ADMIN: 2,
  };

  if ((roleRank[session.platformRole] ?? 0) < (roleRank[minimumRole] ?? 99)) {
    redirect("/dashboard/events?error=insufficient_permissions");
  }

  return session;
}

// ─── Get user for API routes (returns null instead of redirecting) ────────────

export async function getApiUser(): Promise<User | null> {
  const { userId } = auth();
  if (!userId) return null;
  return db.user.findUnique({
    where: { clerkId: userId, deletedAt: null },
  });
}

// ─── Clerk publicMetadata sync helper ────────────────────────────────────────
// Called from the webhook when platform role changes in DB.
// Updates Clerk's JWT so middleware sees the new role without a DB call.

export async function syncPlatformRoleToClerk(
  clerkUserId: string,
  platformRole: "USER" | "MODERATOR" | "SUPER_ADMIN"
): Promise<void> {
  // Dynamically import Clerk backend client to keep bundle lean
  const { clerkClient } = await import("@clerk/nextjs/server");
  await clerkClient.users.updateUserMetadata(clerkUserId, {
    publicMetadata: { platformRole } satisfies ClerkPublicMetadata,
  });
}
