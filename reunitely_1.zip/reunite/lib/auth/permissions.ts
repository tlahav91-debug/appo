/**
 * lib/auth/permissions.ts
 *
 * Central RBAC authority for Reunitely.
 * All permission checks MUST flow through this module — never inline role strings.
 *
 * Two-tier model:
 *   Platform tier  → User.platformRole   (SUPER_ADMIN, MODERATOR, USER)
 *   Event tier     → CommitteeMember.role (ORGANIZER, CO_ORGANIZER, COMMITTEE, ATTENDEE, GUEST_ATTENDEE)
 *
 * Resolution order for event permissions:
 *   1. SUPER_ADMIN → all permissions granted automatically
 *   2. CommitteeMember granular flags → checked first (most specific)
 *   3. CommitteeMember.role → mapped to base permission set
 *   4. RSVP presence → grants attendee-tier access
 *   5. No record → public-only access
 */

import { db } from "@/lib/db";
import type {
  CommitteeMember,
  MembershipRole,
  PlatformRole,
} from "@prisma/client";

// ─── Permission catalogue ─────────────────────────────────────────────────────
// Adding a new permission? Add it here first, then add it to ROLE_PERMISSION_MAP.

export type EventPermission =
  // Event management
  | "event:read"
  | "event:update"
  | "event:delete"
  | "event:publish"
  | "event:archive"
  | "event:clone"
  // Attendee management
  | "attendees:read"
  | "attendees:update"
  | "attendees:export"
  | "attendees:checkin"
  | "attendees:remove"
  // Invitations
  | "invites:manage"
  | "invites:view"
  // Broadcasting
  | "messages:broadcast"
  | "messages:view_history"
  // Content moderation
  | "memories:read"
  | "memories:create"
  | "memories:moderate"
  | "memories:delete_own"
  | "memories:delete_any"
  // Nominations
  | "nominations:manage"
  | "nominations:vote"
  | "nominations:nominate"
  // Chat
  | "chat:read"
  | "chat:write"
  | "chat:moderate"
  | "chat:manage_rooms"
  // Payments
  | "payments:read"
  | "payments:refund"
  | "payments:mark_manual"
  // Settings
  | "settings:manage"
  | "settings:view"
  // Audit
  | "audit:read";

export type PlatformPermission =
  | "platform:admin"
  | "platform:moderate_content"
  | "platform:view_all_events"
  | "platform:ban_users"
  | "platform:takedown_events";

// ─── Role → base permission sets ─────────────────────────────────────────────
// These are the DEFAULT grants. CommitteeMember granular flags can override.

const ROLE_PERMISSION_MAP: Record<MembershipRole, ReadonlySet<EventPermission>> =
  {
    ORGANIZER: new Set<EventPermission>([
      "event:read", "event:update", "event:delete", "event:publish",
      "event:archive", "event:clone",
      "attendees:read", "attendees:update", "attendees:export",
      "attendees:checkin", "attendees:remove",
      "invites:manage", "invites:view",
      "messages:broadcast", "messages:view_history",
      "memories:read", "memories:create", "memories:moderate",
      "memories:delete_own", "memories:delete_any",
      "nominations:manage", "nominations:vote", "nominations:nominate",
      "chat:read", "chat:write", "chat:moderate", "chat:manage_rooms",
      "payments:read", "payments:refund", "payments:mark_manual",
      "settings:manage", "settings:view",
      "audit:read",
    ]),

    CO_ORGANIZER: new Set<EventPermission>([
      "event:read", "event:update",
      "attendees:read", "attendees:update",
      "attendees:checkin", "attendees:remove",
      "invites:manage", "invites:view",
      "messages:broadcast", "messages:view_history",
      "memories:read", "memories:create", "memories:moderate",
      "memories:delete_own", "memories:delete_any",
      "nominations:vote", "nominations:nominate",
      "chat:read", "chat:write", "chat:moderate",
      "payments:read",
      "settings:view",
    ]),

    COMMITTEE: new Set<EventPermission>([
      "event:read",
      "attendees:read", "attendees:checkin",
      "invites:view",
      "memories:read", "memories:create", "memories:delete_own",
      "nominations:vote", "nominations:nominate",
      "chat:read", "chat:write",
      "settings:view",
    ]),

    ATTENDEE: new Set<EventPermission>([
      "event:read",
      "memories:read", "memories:create", "memories:delete_own",
      "nominations:vote", "nominations:nominate",
      "chat:read", "chat:write",
    ]),

    GUEST_ATTENDEE: new Set<EventPermission>([
      "event:read",
      "memories:read",
      "chat:read",
    ]),
  };

// Platform role → platform permissions
const PLATFORM_PERMISSION_MAP: Record<PlatformRole, ReadonlySet<PlatformPermission>> =
  {
    USER: new Set(),
    MODERATOR: new Set<PlatformPermission>([
      "platform:moderate_content",
      "platform:view_all_events",
    ]),
    SUPER_ADMIN: new Set<PlatformPermission>([
      "platform:admin",
      "platform:moderate_content",
      "platform:view_all_events",
      "platform:ban_users",
      "platform:takedown_events",
    ]),
  };

// ─── Custom error ─────────────────────────────────────────────────────────────

export class PermissionError extends Error {
  constructor(
    public readonly code: "UNAUTHENTICATED" | "NOT_MEMBER" | "FORBIDDEN" | "NOT_FOUND" | "EVENT_PRIVATE",
    message: string
  ) {
    super(message);
    this.name = "PermissionError";
  }
}

// ─── Cached context type (avoids N+1 permission lookups in a single request) ──

export interface ResolvedEventContext {
  userId: string;
  eventId: string;
  platformRole: PlatformRole;
  isSuperAdmin: boolean;
  committee: CommitteeMember | null;
  hasRsvp: boolean;
  effectiveRole: MembershipRole | null;
}

// ─── Context resolver ─────────────────────────────────────────────────────────
// Call once per request, then pass the context to individual checks.

export async function resolveEventContext(
  userId: string,
  eventId: string
): Promise<ResolvedEventContext> {
  const [user, committee, rsvp] = await Promise.all([
    db.user.findUnique({
      where: { id: userId, deletedAt: null },
      select: { id: true, platformRole: true },
    }),
    db.committeeMember.findUnique({
      where: { eventId_userId: { eventId, userId }, revokedAt: null },
    }),
    db.rSVP.findUnique({
      where: { eventId_userId: { eventId, userId } },
      select: { status: true },
    }),
  ]);

  if (!user) {
    throw new PermissionError("UNAUTHENTICATED", "User not found.");
  }

  const isSuperAdmin = user.platformRole === "SUPER_ADMIN";

  // Effective role resolution
  let effectiveRole: MembershipRole | null = committee?.role ?? null;
  if (!effectiveRole && rsvp && rsvp.status !== "CANCELLED") {
    effectiveRole = "ATTENDEE";
  }

  return {
    userId,
    eventId,
    platformRole: user.platformRole,
    isSuperAdmin,
    committee,
    hasRsvp: !!rsvp && rsvp.status !== "CANCELLED",
    effectiveRole,
  };
}

// ─── Core permission check ────────────────────────────────────────────────────

export function contextHasPermission(
  ctx: ResolvedEventContext,
  permission: EventPermission
): boolean {
  // SUPER_ADMIN bypasses all event-level restrictions
  if (ctx.isSuperAdmin) return true;

  // Check granular CommitteeMember flags first (most specific)
  if (ctx.committee && !ctx.committee.revokedAt) {
    const flagMap: Partial<Record<EventPermission, keyof CommitteeMember>> = {
      "attendees:read": "canManageRsvps",
      "attendees:update": "canManageRsvps",
      "attendees:export": "canManageRsvps",
      "attendees:remove": "canManageRsvps",
      "attendees:checkin": "canCheckIn",
      "invites:manage": "canManageRsvps",
      "messages:broadcast": "canSendMessages",
      "messages:view_history": "canSendMessages",
      "memories:moderate": "canModerateContent",
      "memories:delete_any": "canModerateContent",
      "chat:moderate": "canModerateContent",
      "chat:manage_rooms": "canModerateContent",
      "payments:read": "canViewPayments",
      "payments:refund": "canViewPayments",
      "payments:mark_manual": "canViewPayments",
      "nominations:manage": "canManageRsvps",
      "settings:manage": "canManageRsvps",
    };

    const flagKey = flagMap[permission];
    if (flagKey) {
      // If the flag is explicitly set on the committee record, use it
      const flagValue = ctx.committee[flagKey as keyof CommitteeMember];
      if (typeof flagValue === "boolean") {
        return flagValue;
      }
    }
  }

  // Fall back to role-based permission set
  if (!ctx.effectiveRole) return false;
  return ROLE_PERMISSION_MAP[ctx.effectiveRole]?.has(permission) ?? false;
}

// ─── Require permission — throws on failure ───────────────────────────────────
// Use in Route Handlers and Server Actions.

export async function requireEventPermission(
  userId: string,
  eventId: string,
  permission: EventPermission
): Promise<ResolvedEventContext> {
  const ctx = await resolveEventContext(userId, eventId);

  if (!contextHasPermission(ctx, permission)) {
    if (!ctx.effectiveRole) {
      throw new PermissionError(
        "NOT_MEMBER",
        "You are not a member of this event."
      );
    }
    throw new PermissionError(
      "FORBIDDEN",
      `Permission denied: ${permission} requires a higher role than ${ctx.effectiveRole}.`
    );
  }

  return ctx;
}

// ─── Batch permission check (avoids multiple DB calls) ────────────────────────

export async function requireAllEventPermissions(
  userId: string,
  eventId: string,
  permissions: EventPermission[]
): Promise<ResolvedEventContext> {
  const ctx = await resolveEventContext(userId, eventId);

  for (const permission of permissions) {
    if (!contextHasPermission(ctx, permission)) {
      throw new PermissionError(
        "FORBIDDEN",
        `Permission denied: ${permission}`
      );
    }
  }

  return ctx;
}

// ─── Platform permission check ────────────────────────────────────────────────

export function platformRoleHasPermission(
  role: PlatformRole,
  permission: PlatformPermission
): boolean {
  return PLATFORM_PERMISSION_MAP[role]?.has(permission) ?? false;
}

export async function requirePlatformPermission(
  userId: string,
  permission: PlatformPermission
): Promise<void> {
  const user = await db.user.findUnique({
    where: { id: userId, deletedAt: null },
    select: { platformRole: true },
  });

  if (!user) {
    throw new PermissionError("UNAUTHENTICATED", "User not found.");
  }

  if (!platformRoleHasPermission(user.platformRole, permission)) {
    throw new PermissionError(
      "FORBIDDEN",
      `Platform permission required: ${permission}`
    );
  }
}

// ─── Convenience boolean checks (no-throw, for conditional UI logic) ──────────

export async function canUserAccessEvent(
  userId: string,
  eventId: string,
  permission: EventPermission
): Promise<boolean> {
  try {
    const ctx = await resolveEventContext(userId, eventId);
    return contextHasPermission(ctx, permission);
  } catch {
    return false;
  }
}

export async function isEventOrganizer(
  userId: string,
  eventId: string
): Promise<boolean> {
  const member = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId, userId }, revokedAt: null },
    select: { role: true },
  });
  return (
    member?.role === "ORGANIZER" ||
    member?.role === "CO_ORGANIZER"
  );
}

export async function isEventManager(
  userId: string,
  eventId: string
): Promise<boolean> {
  // Manager = any committee member (not just organizer)
  const member = await db.committeeMember.findUnique({
    where: { eventId_userId: { eventId, userId }, revokedAt: null },
    select: { role: true },
  });
  return !!member;
}

// ─── Public event access check ────────────────────────────────────────────────
// Determines if an unauthenticated user can view an event page.

export async function canAccessPublicEvent(eventId: string): Promise<{
  accessible: boolean;
  requiresPassword: boolean;
  requiresInvite: boolean;
}> {
  const event = await db.event.findUnique({
    where: { id: eventId },
    select: { status: true, visibility: true, passwordHash: true },
  });

  if (!event || event.status === "ARCHIVED" || event.status === "DRAFT") {
    return { accessible: false, requiresPassword: false, requiresInvite: false };
  }

  if (event.visibility === "PUBLIC") {
    return { accessible: true, requiresPassword: false, requiresInvite: false };
  }

  if (event.visibility === "UNLISTED") {
    // Unlisted = accessible by link, but password-gated if passwordHash is set
    return {
      accessible: true,
      requiresPassword: !!event.passwordHash,
      requiresInvite: false,
    };
  }

  if (event.visibility === "PRIVATE") {
    return {
      accessible: false,
      requiresPassword: !!event.passwordHash,
      requiresInvite: true,
    };
  }

  return { accessible: false, requiresPassword: false, requiresInvite: false };
}

// ─── Invite token validation ──────────────────────────────────────────────────

export interface InviteValidation {
  valid: boolean;
  expired: boolean;
  alreadyUsed: boolean;
  invite: {
    id: string;
    eventId: string;
    email: string | null;
    token: string;
  } | null;
}

export async function validateInviteToken(
  token: string
): Promise<InviteValidation> {
  const invite = await db.invite.findUnique({
    where: { token },
    select: {
      id: true,
      eventId: true,
      email: true,
      token: true,
      status: true,
      expiresAt: true,
    },
  });

  if (!invite) {
    return { valid: false, expired: false, alreadyUsed: false, invite: null };
  }

  const expired =
    !!invite.expiresAt && invite.expiresAt < new Date();
  const alreadyUsed = invite.status === "RSVPD";

  if (expired || invite.status === "EXPIRED") {
    return { valid: false, expired: true, alreadyUsed: false, invite };
  }

  if (alreadyUsed) {
    return { valid: false, expired: false, alreadyUsed: true, invite };
  }

  return {
    valid: true,
    expired: false,
    alreadyUsed: false,
    invite: {
      id: invite.id,
      eventId: invite.eventId,
      email: invite.email,
      token: invite.token,
    },
  };
}

// ─── Type re-exports for consumers ───────────────────────────────────────────

export type { MembershipRole, PlatformRole, CommitteeMember };
