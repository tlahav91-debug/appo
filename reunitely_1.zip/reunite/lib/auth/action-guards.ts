/**
 * lib/auth/action-guards.ts
 *
 * HOC-style wrappers for Server Actions and Route Handlers.
 * Eliminates boilerplate auth checks from every action.
 *
 * Usage in a Server Action:
 *   const updateEvent = withEventPermission(
 *     "event:update",
 *     async (ctx, { title, description }) => {
 *       return eventService.update(ctx.eventId, ctx.userId, { title, description });
 *     }
 *   );
 *
 * Usage in a Route Handler:
 *   export const POST = withApiAuth(async (req, { user }) => {
 *     ...
 *   });
 */

import { auth } from "@clerk/nextjs/server";
import { type NextRequest, NextResponse } from "next/server";
import { ZodError } from "zod";
import {
  requireEventPermission,
  requirePlatformPermission,
  PermissionError,
  type EventPermission,
  type PlatformPermission,
  type ResolvedEventContext,
} from "@/lib/auth/permissions";
import { getApiUser } from "@/lib/auth/session";
import type { User } from "@prisma/client";
import * as Sentry from "@sentry/nextjs";

// ─── API Route Handler types ───────────────────────────────────────────────────

type ApiContext = { params: Record<string, string> };

type AuthenticatedHandler = (
  req: NextRequest,
  ctx: ApiContext & { user: User }
) => Promise<NextResponse>;

type EventHandler = (
  req: NextRequest,
  ctx: ApiContext & { user: User; eventCtx: ResolvedEventContext }
) => Promise<NextResponse>;

// ─── withApiAuth — require any authenticated user ─────────────────────────────

export function withApiAuth(handler: AuthenticatedHandler) {
  return async (req: NextRequest, ctx: ApiContext): Promise<NextResponse> => {
    try {
      const user = await getApiUser();
      if (!user) {
        return NextResponse.json(
          { data: null, error: { code: "UNAUTHORIZED", message: "Authentication required" } },
          { status: 401 }
        );
      }
      return await handler(req, { ...ctx, user });
    } catch (err) {
      return handleApiError(err);
    }
  };
}

// ─── withEventPermission — require event-level permission ─────────────────────
// Automatically extracts eventId from params.id

export function withEventPermission(
  permission: EventPermission,
  handler: EventHandler
) {
  return async (req: NextRequest, ctx: ApiContext): Promise<NextResponse> => {
    try {
      const user = await getApiUser();
      if (!user) {
        return NextResponse.json(
          { data: null, error: { code: "UNAUTHORIZED", message: "Authentication required" } },
          { status: 401 }
        );
      }

      const eventId = ctx.params["id"];
      if (!eventId) {
        return NextResponse.json(
          { data: null, error: { code: "BAD_REQUEST", message: "Event ID is required" } },
          { status: 400 }
        );
      }

      const eventCtx = await requireEventPermission(user.id, eventId, permission);
      return await handler(req, { ...ctx, user, eventCtx });
    } catch (err) {
      return handleApiError(err);
    }
  };
}

// ─── withPlatformPermission — require platform-level role ─────────────────────

export function withPlatformPermission(
  permission: PlatformPermission,
  handler: AuthenticatedHandler
) {
  return async (req: NextRequest, ctx: ApiContext): Promise<NextResponse> => {
    try {
      const user = await getApiUser();
      if (!user) {
        return NextResponse.json(
          { data: null, error: { code: "UNAUTHORIZED", message: "Authentication required" } },
          { status: 401 }
        );
      }

      await requirePlatformPermission(user.id, permission);
      return await handler(req, { ...ctx, user });
    } catch (err) {
      return handleApiError(err);
    }
  };
}

// ─── Unified API error handler ────────────────────────────────────────────────

export function handleApiError(err: unknown): NextResponse {
  if (err instanceof PermissionError) {
    const statusMap: Record<string, number> = {
      UNAUTHENTICATED: 401,
      NOT_MEMBER: 404,   // 404 not 403 — prevents enumeration
      FORBIDDEN: 403,
      NOT_FOUND: 404,
      EVENT_PRIVATE: 403,
    };
    return NextResponse.json(
      {
        data: null,
        error: { code: err.code, message: err.message },
      },
      { status: statusMap[err.code] ?? 403 }
    );
  }

  if (err instanceof ZodError) {
    return NextResponse.json(
      {
        data: null,
        error: {
          code: "VALIDATION_ERROR",
          message: "Validation failed",
          details: err.flatten().fieldErrors,
        },
      },
      { status: 422 }
    );
  }

  // Prisma unique constraint violation
  if (
    typeof err === "object" &&
    err !== null &&
    "code" in err &&
    err.code === "P2002"
  ) {
    return NextResponse.json(
      { data: null, error: { code: "CONFLICT", message: "A record with this value already exists." } },
      { status: 409 }
    );
  }

  Sentry.captureException(err);
  console.error("[API Error]", err);
  return NextResponse.json(
    { data: null, error: { code: "INTERNAL_ERROR", message: "Internal server error" } },
    { status: 500 }
  );
}

// ─── Server Action guard ──────────────────────────────────────────────────────
// For use with Next.js Server Actions (not Route Handlers).

export type ActionResult<T> =
  | { success: true; data: T }
  | { success: false; error: string; code: string };

export async function withServerAction<T>(
  fn: (userId: string) => Promise<T>
): Promise<ActionResult<T>> {
  try {
    const { userId: clerkId } = auth();
    if (!clerkId) {
      return { success: false, error: "Authentication required", code: "UNAUTHORIZED" };
    }

    const { db } = await import("@/lib/db");
    const user = await db.user.findUnique({
      where: { clerkId, deletedAt: null },
      select: { id: true },
    });

    if (!user) {
      return { success: false, error: "User not found", code: "UNAUTHORIZED" };
    }

    const data = await fn(user.id);
    return { success: true, data };
  } catch (err) {
    if (err instanceof PermissionError) {
      return { success: false, error: err.message, code: err.code };
    }
    if (err instanceof ZodError) {
      return {
        success: false,
        error: "Validation failed",
        code: "VALIDATION_ERROR",
      };
    }
    Sentry.captureException(err);
    return { success: false, error: "Internal error", code: "INTERNAL_ERROR" };
  }
}
