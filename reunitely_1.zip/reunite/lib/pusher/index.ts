import PusherServer from "pusher";
import PusherClient from "pusher-js";
import { getEnv } from "@/env";
import { clientEnv } from "@/env";

// ─── Server-side Pusher ───────────────────────────────────────────────────────

let _pusherServer: PusherServer | undefined;

export function getPusherServer(): PusherServer {
  if (!_pusherServer) {
    const env = getEnv();
    _pusherServer = new PusherServer({
      appId: env.PUSHER_APP_ID,
      key: env.NEXT_PUBLIC_PUSHER_APP_KEY,
      secret: env.PUSHER_APP_SECRET,
      cluster: env.NEXT_PUBLIC_PUSHER_APP_CLUSTER,
      useTLS: true,
    });
  }
  return _pusherServer;
}

// ─── Client-side Pusher ───────────────────────────────────────────────────────

let _pusherClient: PusherClient | undefined;

export function getPusherClient(): PusherClient {
  if (typeof window === "undefined") {
    throw new Error("getPusherClient() must be called client-side only");
  }
  if (!_pusherClient) {
    _pusherClient = new PusherClient(clientEnv.NEXT_PUBLIC_PUSHER_APP_KEY, {
      cluster: clientEnv.NEXT_PUBLIC_PUSHER_APP_CLUSTER,
      authEndpoint: "/api/pusher/auth",
    });
  }
  return _pusherClient;
}

// ─── Channel naming conventions ──────────────────────────────────────────────

export const pusherChannels = {
  // Public event channels (anyone can subscribe)
  eventPublic: (eventId: string) => `event-${eventId}`,

  // Private channels (require auth)
  chatRoom: (roomId: string) => `private-chat-room-${roomId}`,
  eventOrganizer: (eventId: string) => `private-organizer-${eventId}`,
  userNotifications: (userId: string) => `private-user-${userId}`,
} as const;

// ─── Event names ─────────────────────────────────────────────────────────────

export const pusherEvents = {
  // Chat
  NEW_MESSAGE: "new-message",
  MESSAGE_DELETED: "message-deleted",
  MESSAGE_EDITED: "message-edited",
  REACTION_ADDED: "reaction-added",
  USER_TYPING: "client-typing", // client events start with "client-"

  // RSVP (public event channel)
  RSVP_CONFIRMED: "rsvp-confirmed",
  ATTENDEE_CHECKED_IN: "attendee-checked-in",

  // Notifications
  NEW_NOTIFICATION: "new-notification",

  // Organizer dashboard
  RSVP_UPDATED: "rsvp-updated",
  PAYMENT_RECEIVED: "payment-received",
} as const;

export type PusherEvent = (typeof pusherEvents)[keyof typeof pusherEvents];

// ─── Trigger helpers ──────────────────────────────────────────────────────────

export async function triggerPusherEvent(
  channel: string,
  event: string,
  data: unknown
): Promise<void> {
  try {
    const pusher = getPusherServer();
    await pusher.trigger(channel, event, data);
  } catch (err) {
    // Non-fatal — real-time update failure shouldn't break the request
    console.error("[Pusher] Trigger failed:", err);
  }
}

export async function triggerChatMessage(
  roomId: string,
  message: {
    id: string;
    userId: string;
    content: string;
    createdAt: Date;
    user: { name: string; avatarUrl: string | null };
    replyToId?: string | null;
    mediaUrl?: string | null;
  }
): Promise<void> {
  await triggerPusherEvent(
    pusherChannels.chatRoom(roomId),
    pusherEvents.NEW_MESSAGE,
    message
  );
}

export async function triggerUserNotification(
  userId: string,
  notification: {
    id: string;
    type: string;
    payload: unknown;
    createdAt: Date;
  }
): Promise<void> {
  await triggerPusherEvent(
    pusherChannels.userNotifications(userId),
    pusherEvents.NEW_NOTIFICATION,
    notification
  );
}
