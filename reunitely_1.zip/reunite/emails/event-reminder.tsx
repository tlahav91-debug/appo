import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from "@react-email/components";
import { render } from "@react-email/render";
import { formatEventDate, formatEventTime, getEventUrl } from "@/lib/utils";

interface EventReminderProps {
  to: string;
  eventTitle: string;
  eventSlug: string;
  startAt: Date;
  timezone: string;
  daysUntil: 1 | 3;
}

function EventReminderEmail({
  eventTitle,
  eventSlug,
  startAt,
  timezone,
  daysUntil,
}: EventReminderProps) {
  const eventUrl = getEventUrl(eventSlug);
  const formattedDate = formatEventDate(startAt, timezone);
  const formattedTime = formatEventTime(startAt, timezone);
  const emoji = daysUntil === 1 ? "⏰" : "📅";
  const subject =
    daysUntil === 1
      ? `Tomorrow: ${eventTitle}`
      : `${daysUntil} days away: ${eventTitle}`;

  return (
    <Html>
      <Head />
      <Preview>{subject}</Preview>
      <Body style={{ backgroundColor: "#F8FAFC", fontFamily: "'DM Sans', -apple-system, sans-serif" }}>
        <Container style={{ margin: "0 auto", padding: "20px 0 48px", maxWidth: "560px" }}>
          <Section style={{ textAlign: "center", padding: "32px 0 20px" }}>
            <Text style={{ fontSize: "22px", fontWeight: "700", color: "#0F172A", margin: "0" }}>
              <span style={{ color: "#1D4ED8" }}>Re</span>Unite
            </Text>
          </Section>

          <Section
            style={{
              backgroundColor: "#ffffff",
              borderRadius: "12px",
              border: "1px solid #E2E8F0",
              padding: "40px",
            }}
          >
            <Section style={{ textAlign: "center", marginBottom: "24px" }}>
              <Text style={{ fontSize: "48px", margin: "0" }}>{emoji}</Text>
            </Section>

            <Heading
              style={{
                fontSize: "22px",
                fontWeight: "700",
                color: "#0F172A",
                textAlign: "center",
                margin: "0 0 12px",
              }}
            >
              {daysUntil === 1 ? "See you tomorrow!" : `${daysUntil} days to go!`}
            </Heading>

            <Text style={{ color: "#475569", textAlign: "center", margin: "0 0 28px" }}>
              A friendly reminder that <strong>{eventTitle}</strong> is coming up soon.
            </Text>

            <Section
              style={{
                backgroundColor: "#EFF6FF",
                borderRadius: "8px",
                border: "1px solid #FDE68A",
                padding: "16px 20px",
                marginBottom: "32px",
              }}
            >
              <Text style={{ margin: "0 0 4px", fontWeight: "600", color: "#0F172A", fontSize: "15px" }}>
                {eventTitle}
              </Text>
              <Text style={{ margin: "0 0 2px", color: "#475569", fontSize: "14px" }}>
                📅 {formattedDate}
              </Text>
              <Text style={{ margin: "0", color: "#475569", fontSize: "14px" }}>
                🕐 {formattedTime}
              </Text>
            </Section>

            <Section style={{ textAlign: "center" }}>
              <Button
                href={eventUrl}
                style={{
                  backgroundColor: "#2563EB",
                  borderRadius: "8px",
                  color: "#0F172A",
                  fontWeight: "600",
                  fontSize: "15px",
                  padding: "12px 28px",
                  textDecoration: "none",
                  display: "inline-block",
                }}
              >
                View Event Details →
              </Button>
            </Section>
          </Section>
        </Container>
      </Body>
    </Html>
  );
}

export async function renderEventReminder(
  params: EventReminderProps
): Promise<{ subject: string; html: string; text: string }> {
  const html = await render(<EventReminderEmail {...params} />);
  const subject =
    params.daysUntil === 1
      ? `Tomorrow: ${params.eventTitle}`
      : `${params.daysUntil} days away: ${params.eventTitle}`;
  const text = `Reminder: ${params.eventTitle} is on ${formatEventDate(params.startAt, params.timezone)}. View event: ${getEventUrl(params.eventSlug)}`;
  return { subject, html, text };
}

export default EventReminderEmail;
