import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Img,
  Link,
  Preview,
  Section,
  Text,
} from "@react-email/components";
import { render } from "@react-email/render";
import { formatEventDate, formatEventTime, getEventUrl, getUnsubscribeUrl } from "@/lib/utils";
import { generateInviteToken } from "@/lib/utils";

interface RsvpConfirmationProps {
  userId: string;
  eventId: string;
  eventTitle: string;
  eventSlug: string;
  startAt: Date;
  timezone: string;
  isWaitlisted: boolean;
  recipientName?: string;
  recipientEmail?: string;
}

function RsvpConfirmationEmail({
  eventTitle,
  eventSlug,
  startAt,
  timezone,
  isWaitlisted,
  recipientName = "there",
}: RsvpConfirmationProps) {
  const eventUrl = getEventUrl(eventSlug);
  const formattedDate = formatEventDate(startAt, timezone);
  const formattedTime = formatEventTime(startAt, timezone);
  const unsubscribeUrl = `${process.env.NEXT_PUBLIC_APP_URL}/unsubscribe/placeholder?type=event`;

  return (
    <Html>
      <Head />
      <Preview>
        {isWaitlisted
          ? `You're on the waitlist for ${eventTitle}`
          : `You're confirmed for ${eventTitle}!`}
      </Preview>
      <Body
        style={{
          backgroundColor: "#F8FAFC",
          fontFamily:
            "'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        }}
      >
        <Container
          style={{
            margin: "0 auto",
            padding: "20px 0 48px",
            maxWidth: "560px",
          }}
        >
          {/* Logo */}
          <Section style={{ textAlign: "center", padding: "32px 0 20px" }}>
            <Text
              style={{
                fontSize: "22px",
                fontWeight: "700",
                color: "#0F172A",
                margin: "0",
              }}
            >
              <span style={{ color: "#1D4ED8" }}>Re</span>Unite
            </Text>
          </Section>

          {/* Card */}
          <Section
            style={{
              backgroundColor: "#ffffff",
              borderRadius: "12px",
              border: "1px solid #E2E8F0",
              padding: "40px",
            }}
          >
            {/* Checkmark */}
            <Section style={{ textAlign: "center", marginBottom: "24px" }}>
              <Text style={{ fontSize: "48px", margin: "0" }}>
                {isWaitlisted ? "⏳" : "🎉"}
              </Text>
            </Section>

            <Heading
              style={{
                fontSize: "24px",
                fontWeight: "700",
                color: "#0F172A",
                textAlign: "center",
                margin: "0 0 8px",
              }}
            >
              {isWaitlisted ? "You're on the waitlist!" : "You're confirmed!"}
            </Heading>

            <Text
              style={{
                color: "#64748B",
                textAlign: "center",
                margin: "0 0 32px",
              }}
            >
              Hi {recipientName},{" "}
              {isWaitlisted
                ? `we've added you to the waitlist for ${eventTitle}. We'll notify you if a spot opens up.`
                : `your spot is confirmed for ${eventTitle}.`}
            </Text>

            {/* Event details */}
            <Section
              style={{
                backgroundColor: "#EFF6FF",
                borderRadius: "8px",
                border: "1px solid #FDE68A",
                padding: "16px 20px",
                marginBottom: "32px",
              }}
            >
              <Text
                style={{
                  margin: "0 0 4px",
                  fontWeight: "600",
                  color: "#0F172A",
                  fontSize: "15px",
                }}
              >
                {eventTitle}
              </Text>
              <Text style={{ margin: "0 0 2px", color: "#475569", fontSize: "14px" }}>
                📅 {formattedDate}
              </Text>
              <Text style={{ margin: "0", color: "#475569", fontSize: "14px" }}>
                🕐 {formattedTime}
              </Text>
            </Section>

            {/* CTA */}
            <Section style={{ textAlign: "center", marginBottom: "24px" }}>
              <Button
                href={eventUrl}
                style={{
                  backgroundColor: "#2563EB",
                  borderRadius: "8px",
                  color: "#0F172A",
                  fontWeight: "600",
                  fontSize: "15px",
                  padding: "12px 28px",
                  textDecoration: "none",
                  display: "inline-block",
                }}
              >
                View Event Page →
              </Button>
            </Section>

            <Text
              style={{
                color: "#94A3B8",
                fontSize: "13px",
                textAlign: "center",
                margin: "0",
              }}
            >
              Share the event with your classmates and help us reach everyone!
            </Text>
          </Section>

          {/* Footer */}
          <Section style={{ textAlign: "center", padding: "24px 0" }}>
            <Text style={{ color: "#94A3B8", fontSize: "12px", margin: "0 0 8px" }}>
              You're receiving this because you RSVP'd to this event.
            </Text>
            <Text style={{ color: "#94A3B8", fontSize: "12px", margin: "0" }}>
              <Link
                href={unsubscribeUrl}
                style={{ color: "#94A3B8", textDecoration: "underline" }}
              >
                Unsubscribe from event emails
              </Link>
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  );
}

// ─── Render function ──────────────────────────────────────────────────────────

export async function renderRsvpConfirmation(
  params: RsvpConfirmationProps & { recipientName?: string; recipientEmail?: string }
): Promise<{ to: string; subject: string; html: string; text: string }> {
  if (!params.recipientEmail) {
    const { db } = await import("@/lib/db");
    const user = await db.user.findUnique({
      where: { id: params.userId },
      select: { email: true, name: true },
    });
    params.recipientEmail = user?.email ?? "";
    params.recipientName = user?.name ?? "there";
  }

  const html = await render(<RsvpConfirmationEmail {...params} />);
  const text = `Hi ${params.recipientName}, you're ${params.isWaitlisted ? "on the waitlist" : "confirmed"} for ${params.eventTitle} on ${formatEventDate(params.startAt, params.timezone)}.`;

  const subject = params.isWaitlisted
    ? `You're on the waitlist: ${params.eventTitle}`
    : `You're confirmed! ${params.eventTitle}`;

  return {
    to: params.recipientEmail,
    subject,
    html,
    text,
  };
}

export default RsvpConfirmationEmail;
