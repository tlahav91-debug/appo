// ─── nomination-received.tsx ──────────────────────────────────────────────────

import { Body, Button, Container, Head, Heading, Html, Preview, Section, Text } from "@react-email/components";
import { render } from "@react-email/render";

interface NominationEmailProps {
  to: string;
  nomineeName: string;
  nominationId: string;
  categoryTitle: string;
  eventTitle: string;
  nominatorName: string;
}

function NominationReceivedEmail({
  nomineeName,
  categoryTitle,
  eventTitle,
  nominatorName,
  nominationId,
}: NominationEmailProps) {
  const acceptUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/nominations/${nominationId}/accept`;
  const declineUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/nominations/${nominationId}/decline`;

  return (
    <Html>
      <Head />
      <Preview>{nominatorName} nominated you for "{categoryTitle}"</Preview>
      <Body style={{ backgroundColor: "#F8FAFC", fontFamily: "'DM Sans', -apple-system, sans-serif" }}>
        <Container style={{ margin: "0 auto", padding: "20px 0 48px", maxWidth: "560px" }}>
          <Section
            style={{
              backgroundColor: "#ffffff",
              borderRadius: "12px",
              border: "1px solid #E2E8F0",
              padding: "40px",
              marginTop: "32px",
            }}
          >
            <Section style={{ textAlign: "center", marginBottom: "20px" }}>
              <Text style={{ fontSize: "48px", margin: "0" }}>🏆</Text>
            </Section>
            <Heading style={{ fontSize: "22px", fontWeight: "700", color: "#0F172A", textAlign: "center", margin: "0 0 12px" }}>
              You've been nominated!
            </Heading>
            <Text style={{ color: "#475569", textAlign: "center", margin: "0 0 28px" }}>
              <strong>{nominatorName}</strong> nominated you for{" "}
              <strong>"{categoryTitle}"</strong> at the{" "}
              <strong>{eventTitle}</strong>.
            </Text>
            <Text style={{ color: "#475569", textAlign: "center", margin: "0 0 28px" }}>
              Accept to add your name to the ballot — classmates can then vote for you!
            </Text>
            <Section style={{ textAlign: "center", marginBottom: "16px" }}>
              <Button
                href={acceptUrl}
                style={{
                  backgroundColor: "#2563EB",
                  borderRadius: "8px",
                  color: "#0F172A",
                  fontWeight: "600",
                  fontSize: "15px",
                  padding: "12px 28px",
                  textDecoration: "none",
                  display: "inline-block",
                  marginRight: "12px",
                }}
              >
                Accept Nomination
              </Button>
              <Button
                href={declineUrl}
                style={{
                  backgroundColor: "#F1F5F9",
                  borderRadius: "8px",
                  color: "#475569",
                  fontWeight: "600",
                  fontSize: "15px",
                  padding: "12px 28px",
                  textDecoration: "none",
                  display: "inline-block",
                }}
              >
                Decline
              </Button>
            </Section>
          </Section>
        </Container>
      </Body>
    </Html>
  );
}

export async function renderNominationEmail(
  params: NominationEmailProps
): Promise<{ subject: string; html: string; text: string }> {
  const html = await render(<NominationReceivedEmail {...params} />);
  const subject = `You've been nominated: "${params.categoryTitle}" at ${params.eventTitle}`;
  const text = `${params.nominatorName} nominated you for "${params.categoryTitle}" at ${params.eventTitle}. Accept or decline at ${process.env.NEXT_PUBLIC_APP_URL}/nominations/${params.nominationId}`;
  return { subject, html, text };
}

export default NominationReceivedEmail;
