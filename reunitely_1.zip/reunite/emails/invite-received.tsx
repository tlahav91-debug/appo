import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from "@react-email/components";
import { render } from "@react-email/render";
import { formatEventDate, getInviteUrl } from "@/lib/utils";

interface InviteEmailProps {
  inviteToken: string;
  eventTitle: string;
  eventSlug: string;
  organizerName: string;
  schoolName: string;
  graduationYear: number;
  startAt: Date;
  timezone: string;
}

function InviteReceivedEmail({
  inviteToken,
  eventTitle,
  organizerName,
  schoolName,
  graduationYear,
  startAt,
  timezone,
}: InviteEmailProps) {
  const inviteUrl = getInviteUrl(inviteToken);
  const formattedDate = formatEventDate(startAt, timezone);

  return (
    <Html>
      <Head />
      <Preview>
        {organizerName} invited you to {eventTitle}
      </Preview>
      <Body
        style={{
          backgroundColor: "#F8FAFC",
          fontFamily: "'DM Sans', -apple-system, sans-serif",
        }}
      >
        <Container
          style={{ margin: "0 auto", padding: "20px 0 48px", maxWidth: "560px" }}
        >
          <Section style={{ textAlign: "center", padding: "32px 0 20px" }}>
            <Text
              style={{ fontSize: "22px", fontWeight: "700", color: "#0F172A", margin: "0" }}
            >
              <span style={{ color: "#1D4ED8" }}>Re</span>Unite
            </Text>
          </Section>

          <Section
            style={{
              backgroundColor: "#ffffff",
              borderRadius: "12px",
              border: "1px solid #E2E8F0",
              padding: "40px",
            }}
          >
            <Section style={{ textAlign: "center", marginBottom: "24px" }}>
              <Text style={{ fontSize: "48px", margin: "0" }}>🎓</Text>
            </Section>

            <Heading
              style={{
                fontSize: "22px",
                fontWeight: "700",
                color: "#0F172A",
                textAlign: "center",
                margin: "0 0 12px",
              }}
            >
              You've been invited!
            </Heading>

            <Text style={{ color: "#475569", textAlign: "center", margin: "0 0 28px" }}>
              <strong>{organizerName}</strong> has invited you to the{" "}
              <strong>
                {schoolName} Class of {graduationYear}
              </strong>{" "}
              reunion.
            </Text>

            <Section
              style={{
                backgroundColor: "#EFF6FF",
                borderRadius: "8px",
                border: "1px solid #FDE68A",
                padding: "16px 20px",
                marginBottom: "32px",
              }}
            >
              <Text
                style={{ margin: "0 0 4px", fontWeight: "600", color: "#0F172A", fontSize: "15px" }}
              >
                {eventTitle}
              </Text>
              <Text style={{ margin: "0", color: "#475569", fontSize: "14px" }}>
                📅 {formattedDate}
              </Text>
            </Section>

            <Section style={{ textAlign: "center", marginBottom: "24px" }}>
              <Button
                href={inviteUrl}
                style={{
                  backgroundColor: "#2563EB",
                  borderRadius: "8px",
                  color: "#0F172A",
                  fontWeight: "600",
                  fontSize: "15px",
                  padding: "12px 28px",
                  textDecoration: "none",
                  display: "inline-block",
                }}
              >
                View Event & RSVP →
              </Button>
            </Section>

            <Text style={{ color: "#94A3B8", fontSize: "12px", textAlign: "center", margin: "0" }}>
              You received this because {organizerName} has your email address and
              believes you may be a classmate.
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  );
}

export async function renderInviteEmail(
  params: InviteEmailProps
): Promise<{ subject: string; html: string; text: string }> {
  const html = await render(<InviteReceivedEmail {...params} />);
  const subject = `${params.organizerName} invited you to ${params.eventTitle}`;
  const text = `${params.organizerName} invited you to ${params.eventTitle} on ${formatEventDate(params.startAt, params.timezone)}. RSVP here: ${getInviteUrl(params.inviteToken)}`;
  return { subject, html, text };
}

export default InviteReceivedEmail;
