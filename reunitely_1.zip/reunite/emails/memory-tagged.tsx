import { Body, Button, Container, Head, Heading, Html, Preview, Section, Text } from "@react-email/components";
import { render } from "@react-email/render";

interface MemoryTagEmailProps {
  to: string;
  taggedUserName: string;
  memoryTagId: string;
  uploaderName: string;
  eventTitle: string;
  memoryId: string;
}

function MemoryTaggedEmail({
  taggedUserName,
  memoryTagId,
  uploaderName,
  eventTitle,
}: MemoryTagEmailProps) {
  const approveUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/memory-tags/${memoryTagId}/approve`;
  const rejectUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/memory-tags/${memoryTagId}/reject`;

  return (
    <Html>
      <Head />
      <Preview>{uploaderName} tagged you in a memory from {eventTitle}</Preview>
      <Body style={{ backgroundColor: "#F8FAFC", fontFamily: "'DM Sans', -apple-system, sans-serif" }}>
        <Container style={{ margin: "0 auto", padding: "20px 0 48px", maxWidth: "560px" }}>
          <Section
            style={{
              backgroundColor: "#ffffff",
              borderRadius: "12px",
              border: "1px solid #E2E8F0",
              padding: "40px",
              marginTop: "32px",
            }}
          >
            <Section style={{ textAlign: "center", marginBottom: "20px" }}>
              <Text style={{ fontSize: "48px", margin: "0" }}>📸</Text>
            </Section>
            <Heading style={{ fontSize: "22px", fontWeight: "700", color: "#0F172A", textAlign: "center", margin: "0 0 12px" }}>
              You've been tagged in a memory
            </Heading>
            <Text style={{ color: "#475569", textAlign: "center", margin: "0 0 28px" }}>
              Hi {taggedUserName}, <strong>{uploaderName}</strong> tagged you in a memory
              from <strong>{eventTitle}</strong>. Review and decide if you want
              your name visible on this post.
            </Text>
            <Section style={{ textAlign: "center", marginBottom: "16px" }}>
              <Button
                href={approveUrl}
                style={{
                  backgroundColor: "#2563EB",
                  borderRadius: "8px",
                  color: "#0F172A",
                  fontWeight: "600",
                  fontSize: "15px",
                  padding: "12px 24px",
                  textDecoration: "none",
                  display: "inline-block",
                  marginRight: "12px",
                }}
              >
                Approve Tag
              </Button>
              <Button
                href={rejectUrl}
                style={{
                  backgroundColor: "#F1F5F9",
                  borderRadius: "8px",
                  color: "#475569",
                  fontWeight: "600",
                  fontSize: "15px",
                  padding: "12px 24px",
                  textDecoration: "none",
                  display: "inline-block",
                }}
              >
                Remove Tag
              </Button>
            </Section>
            <Text style={{ color: "#94A3B8", fontSize: "12px", textAlign: "center", margin: "0" }}>
              If you don't recognize this memory, you can safely decline the tag.
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  );
}

export async function renderMemoryTagEmail(
  params: MemoryTagEmailProps
): Promise<{ subject: string; html: string; text: string }> {
  const html = await render(<MemoryTaggedEmail {...params} />);
  const subject = `${params.uploaderName} tagged you in a memory from ${params.eventTitle}`;
  const text = `${params.uploaderName} tagged you in a memory from ${params.eventTitle}. Approve or remove the tag at ${process.env.NEXT_PUBLIC_APP_URL}`;
  return { subject, html, text };
}

export default MemoryTaggedEmail;
