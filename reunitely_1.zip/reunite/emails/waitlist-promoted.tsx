import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from "@react-email/components";
import { render } from "@react-email/render";
import { formatEventDate, getEventUrl } from "@/lib/utils";

interface WaitlistPromotedProps {
  userId: string;
  eventId: string;
  eventTitle: string;
  eventSlug: string;
  schoolName: string;
  graduationYear: number;
  startAt: Date;
  timezone: string;
  recipientName?: string;
  recipientEmail?: string;
}

function WaitlistPromotedEmail({
  eventTitle,
  eventSlug,
  schoolName,
  graduationYear,
  startAt,
  timezone,
  recipientName = "there",
}: WaitlistPromotedProps) {
  const eventUrl = getEventUrl(eventSlug);
  const formattedDate = formatEventDate(startAt, timezone);

  return (
    <Html>
      <Head />
      <Preview>Great news — you're off the waitlist for {eventTitle}!</Preview>
      <Body style={{ backgroundColor: "#fafaf9", fontFamily: "sans-serif" }}>
        <Container style={{ maxWidth: 520, margin: "0 auto", padding: "40px 20px" }}>
          {/* Header */}
          <Section
            style={{
              background: "linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)",
              borderRadius: 16,
              padding: "32px 32px 24px",
              textAlign: "center" as const,
              marginBottom: 24,
            }}
          >
            <Text style={{ fontSize: 36, margin: "0 0 8px" }}>🎉</Text>
            <Heading
              style={{
                color: "#fff",
                fontSize: 22,
                fontWeight: 700,
                margin: "0 0 8px",
              }}
            >
              You're off the waitlist!
            </Heading>
            <Text style={{ color: "#dbeafe", fontSize: 14, margin: 0 }}>
              {schoolName} · Class of {graduationYear}
            </Text>
          </Section>

          {/* Body */}
          <Section
            style={{
              backgroundColor: "#fff",
              borderRadius: 12,
              padding: "28px 32px",
              border: "1px solid #e7e5e4",
              marginBottom: 20,
            }}
          >
            <Text style={{ fontSize: 15, color: "#44403c", marginTop: 0 }}>
              Hi {recipientName},
            </Text>
            <Text style={{ fontSize: 15, color: "#44403c" }}>
              Good news — a spot opened up and you've been moved from the
              waitlist to <strong>confirmed</strong> for{" "}
              <strong>{eventTitle}</strong> on {formattedDate}.
            </Text>
            <Text style={{ fontSize: 15, color: "#44403c" }}>
              No action needed — your RSVP is confirmed. We can't wait to see
              you there!
            </Text>

            <Button
              href={eventUrl}
              style={{
                backgroundColor: "#2563eb",
                color: "#fff",
                borderRadius: 8,
                padding: "12px 24px",
                fontWeight: 600,
                fontSize: 14,
                textDecoration: "none",
                display: "block",
                textAlign: "center" as const,
                marginTop: 24,
              }}
            >
              View Event Details →
            </Button>
          </Section>

          <Hr style={{ borderColor: "#e7e5e4", margin: "20px 0" }} />
          <Text style={{ fontSize: 12, color: "#a8a29e", textAlign: "center" as const }}>
            {eventTitle} · Powered by Reunitely
          </Text>
        </Container>
      </Body>
    </Html>
  );
}

// ─── Render function ──────────────────────────────────────────────────────────

export async function renderWaitlistPromoted(
  params: WaitlistPromotedProps
): Promise<{ to: string; subject: string; html: string; text: string }> {
  if (!params.recipientEmail) {
    const { db } = await import("@/lib/db");
    const user = await db.user.findUnique({
      where: { id: params.userId },
      select: { email: true, name: true },
    });
    params.recipientEmail = user?.email ?? "";
    params.recipientName = user?.name ?? "there";
  }

  const html = await render(<WaitlistPromotedEmail {...params} />);
  const formattedDate = formatEventDate(params.startAt, params.timezone);
  const text = `Hi ${params.recipientName}, great news — you've been moved off the waitlist and are now confirmed for ${params.eventTitle} on ${formattedDate}. See you there!`;

  return {
    to: params.recipientEmail,
    subject: `🎉 You're confirmed: ${params.eventTitle}`,
    html,
    text,
  };
}

export default WaitlistPromotedEmail;
